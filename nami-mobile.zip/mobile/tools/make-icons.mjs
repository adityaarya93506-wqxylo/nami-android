// Draws the app icon (the coral tile with a cream "N") into PNGs, with no
// image library. Run: node tools/make-icons.mjs
import zlib from 'node:zlib';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const out = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'web');
const N = [[150,380],[150,132],[196,132],[316,292],[316,132],[362,132],[362,380],[316,380],[196,220],[196,380]];
const CORAL = [239, 100, 97], CREAM = [255, 253, 246];

function inPoly(x, y, pts) {
  let inside = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const [xi, yi] = pts[i], [xj, yj] = pts[j];
    if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}
function inRound(x, y, size, r) {
  const cx = Math.min(Math.max(x, r), size - r), cy = Math.min(Math.max(y, r), size - r);
  return (x - cx) ** 2 + (y - cy) ** 2 <= r * r;
}

function render(size, { maskable }) {
  const scale = maskable ? 0.62 : 1;      // maskable keeps the mark inside the safe circle
  const off = (512 - 512 * scale) / 2;
  const SS = 3;
  const raw = Buffer.alloc(size * (size * 4 + 1));
  for (let py = 0; py < size; py++) {
    raw[py * (size * 4 + 1)] = 0;
    for (let px = 0; px < size; px++) {
      let r = 0, g = 0, b = 0, a = 0;
      for (let sy = 0; sy < SS; sy++) for (let sx = 0; sx < SS; sx++) {
        const x = ((px + (sx + 0.5) / SS) / size) * 512, y = ((py + (sy + 0.5) / SS) / size) * 512;
        const tile = maskable ? true : inRound(x, y, 512, 112);
        if (!tile) continue;
        const mx = (x - off) / scale, my = (y - off) / scale;
        const c = inPoly(mx, my, N) ? CREAM : CORAL;
        r += c[0]; g += c[1]; b += c[2]; a += 255;
      }
      const n = SS * SS, o = py * (size * 4 + 1) + 1 + px * 4;
      if (a > 0) { raw[o] = Math.round(r / (a / 255)); raw[o + 1] = Math.round(g / (a / 255)); raw[o + 2] = Math.round(b / (a / 255)); }
      raw[o + 3] = Math.round(a / n);
    }
  }
  const chunk = (type, data) => {
    const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
    const td = Buffer.concat([Buffer.from(type), data]);
    const crc = Buffer.alloc(4); crc.writeUInt32BE(zlib.crc32(td) >>> 0);
    return Buffer.concat([len, td, crc]);
  };
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0); ihdr.writeUInt32BE(size, 4); ihdr[8] = 8; ihdr[9] = 6;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw, { level: 9 })), chunk('IEND', Buffer.alloc(0))]);
}

fs.writeFileSync(path.join(out, 'icon-192.png'), render(192, { maskable: false }));
fs.writeFileSync(path.join(out, 'icon-512.png'), render(512, { maskable: false }));
fs.writeFileSync(path.join(out, 'icon-maskable-512.png'), render(512, { maskable: true }));
console.log('wrote 3 icons to', out);
