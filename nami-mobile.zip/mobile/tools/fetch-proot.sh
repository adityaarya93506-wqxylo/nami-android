#!/usr/bin/env bash
# Collects proot for Android (arm64) from the Termux package repository and puts it
# where the app's build wants it:  android/app/src/main/jniLibs/arm64-v8a/
#   libproot.so, libproot-loader.so, libtalloc.so  (+ any other library proot needs)
# Android only lets an app run files from its native library folder, so the
# programs are shipped as lib*.so there. Needs: curl, ar/dpkg-deb, tar, xz, readelf, patchelf.
#
# usage: fetch-proot.sh <output-dir> [repo-url]
set -euo pipefail

out="${1:?usage: fetch-proot.sh <output-dir> [repo-url]}"
repo="${2:-${TERMUX_REPO:-https://packages.termux.dev/apt/termux-main}}"
arch=aarch64
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
mkdir -p "$out"

echo "==> package index from $repo"
curl -fsSL "$repo/dists/stable/main/binary-$arch/Packages" -o "$work/Packages"

# field <package> <field>  -> value from the Packages index
field() {
  awk -v p="$1" -v f="$2" '
    BEGIN { RS=""; FS="\n" }
    { name=""; val="";
      for (i=1;i<=NF;i++) {
        if ($i ~ /^Package: /) name=substr($i,10);
        if (index($i, f": ")==1) val=substr($i,length(f)+3);
      }
      if (name==p) { print val; exit } }' "$work/Packages"
}

fetched=" "
fetch_pkg() {
  local p="$1" file
  case "$fetched" in *" $p "*) return;; esac
  fetched="$fetched$p "
  file="$(field "$p" Filename)"
  [ -n "$file" ] || { echo "package $p not found in the index" >&2; exit 1; }
  echo "==> $p"
  curl -fsSL "$repo/$file" -o "$work/$p.deb"
  mkdir -p "$work/x/$p"
  dpkg-deb -x "$work/$p.deb" "$work/x/$p"
  # follow dependencies that are real packages (skip the c library and built-in ones)
  local deps d
  deps="$(field "$p" Depends | tr ',' '\n' | sed -E 's/\(.*//; s/\|.*//; s/ //g' | grep -v '^$' || true)"
  for d in $deps; do
    case "$d" in libc|libc++|libandroid-*|termux-*) continue;; esac
    fetch_pkg "$d"
  done
}
fetch_pkg proot

prefix_files() { find "$work/x" -type f -o -type l; }

proot_bin="$(find "$work/x/proot" -type f -path '*/bin/proot' | head -1)"
loader="$(find "$work/x/proot" -type f -name loader -path '*proot*' | head -1)"
[ -n "$proot_bin" ] || { echo "proot binary not found in package" >&2; exit 1; }
[ -n "$loader" ] || { echo "proot loader not found in package" >&2; exit 1; }
cp "$proot_bin" "$out/libproot.so"
cp "$loader" "$out/libproot-loader.so"

# every shared library from the dependency packages, as lib*.so (versioned names are shortened)
find "$work/x" \( -type f -o -type l \) -name 'lib*.so*' | while read -r f; do
  base="$(basename "$f")"
  short="${base%%.so*}.so"
  [ -e "$out/$short" ] && continue
  if [ -L "$f" ]; then continue; fi
  cp "$f" "$out/$short"
done

# proot asks for libtalloc.so.2 by its versioned name; Android only unpacks plain .so names
if command -v patchelf >/dev/null 2>&1; then
  for f in "$out"/libproot.so; do
    for need in $(readelf -d "$f" | sed -n 's/.*Shared library: \[\(.*\)\]/\1/p'); do
      case "$need" in
        *.so.[0-9]*) patchelf --replace-needed "$need" "${need%%.so*}.so" "$f";;
      esac
    done
  done
else
  echo "patchelf missing: versioned library names cannot be fixed" >&2; exit 1
fi

echo "==> result"
for f in "$out"/*.so; do
  echo "$(basename "$f")  NEEDED: $(readelf -d "$f" 2>/dev/null | sed -n 's/.*Shared library: \[\(.*\)\]/\1/p' | tr '\n' ' ')"
done
