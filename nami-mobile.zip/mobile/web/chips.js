// The little logo tiles for agents and file kinds, drawn the same way as the
// desktop app (icons.mjs is copied from it).
import { chipHtml, iconKeyFor, treeIcon } from '/lib/icons.mjs';

const AGENT_KEY = { claude: 'claude', codex: 'openai', opencode: 'opencode', kimi: 'kimi', hermes: 'hermes', gemini: 'gemini', antigravity: 'antigravity' };

export function agentChip(agentId, { kind = 'agent', size = 'md' } = {}) {
  const wrap = document.createElement('span');
  wrap.className = 'chip-wrap chip-' + size;
  if (!agentId) wrap.innerHTML = chipHtml({ key: null, code: '>_', kind: 'shell' });
  else wrap.innerHTML = chipHtml({ key: AGENT_KEY[agentId] || iconKeyFor(agentId), code: String(agentId).slice(0, 2).toUpperCase(), kind });
  return wrap;
}

export function platformChip(platform, type = 'agent') {
  const wrap = document.createElement('span');
  wrap.className = 'chip-wrap chip-sm';
  const key = { claude: 'claude', codex: 'openai', opencode: 'opencode' }[platform] || null;
  wrap.innerHTML = chipHtml({ key, code: platform.slice(0, 2).toUpperCase(), kind: type });
  return wrap;
}

export function fileIcon(name, type, open = false) {
  const span = document.createElement('span');
  span.className = 'tree-ico';
  span.innerHTML = treeIcon(name, type, open);
  return span;
}

export { iconKeyFor };
