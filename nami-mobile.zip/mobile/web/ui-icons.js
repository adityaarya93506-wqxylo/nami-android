// Small line icons, drawn in the current text colour so every desk can tint them.
const P = {
  mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3M8.5 21h7"/>',
  stop: '<rect x="7" y="7" width="10" height="10" rx="2.2" fill="currentColor"/>',
  clip: '<path d="M20 11.2l-8.3 8.3a5 5 0 0 1-7.1-7.1l8.6-8.6a3.4 3.4 0 0 1 4.8 4.8l-8.6 8.6a1.8 1.8 0 0 1-2.5-2.5l7.9-7.9"/>',
  more: '<circle cx="5.5" cy="12" r="1.7" fill="currentColor"/><circle cx="12" cy="12" r="1.7" fill="currentColor"/><circle cx="18.5" cy="12" r="1.7" fill="currentColor"/>',
  split: '<rect x="3.5" y="5" width="17" height="14" rx="3"/><path d="M12 5v14"/>',
  back: '<path d="M14.5 5.5L8 12l6.5 6.5"/>',
  fwd: '<path d="M9.5 5.5L16 12l-6.5 6.5"/>',
  close: '<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>',
  reload: '<path d="M19 12a7 7 0 1 1-2.3-5.2M19 4.5v4h-4"/>',
  out: '<path d="M14 4.5h5.5V10M19.5 4.5L11 13M17 14v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h4"/>',
  star: '<path d="M12 4l2.5 5.2 5.7.8-4.1 4 1 5.7L12 17l-5.1 2.7 1-5.7-4.1-4 5.7-.8z"/>',
  agent: '<rect x="4.5" y="7" width="15" height="11" rx="3.5"/><path d="M12 7V4M9 12.5h.01M15 12.5h.01M9.5 15.5h5"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 3.5v2.2M12 18.3v2.2M3.5 12h2.2M18.3 12h2.2M6 6l1.6 1.6M16.4 16.4L18 18M18 6l-1.6 1.6M7.6 16.4L6 18"/>',
  theme: '<circle cx="12" cy="12" r="8"/><path d="M12 4a8 8 0 0 0 0 16z" fill="currentColor"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
};
export function icon(name, size = 22) {
  const body = P[name];
  if (!body) return '';
  return `<svg class="ico" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${body}</svg>`;
}
// Any button marked data-icon="name" gets its icon.
export function paintIcons(root = document) {
  for (const b of root.querySelectorAll('[data-icon]')) b.innerHTML = icon(b.dataset.icon);
}
