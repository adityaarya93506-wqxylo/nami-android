// The page's side of ACP (Agent Client Protocol), as plain logic with no DOM, so it can be tested.
// Lines in, lines out: handleLine(line) takes what the agent sent; send(line) is how we answer.
// What the screen needs comes out as events through onEvent.
//
// We offer the agent nothing of ours (no file or terminal access through us): it uses its own
// tools, and asks permission through session/request_permission, which we show as buttons.

export function createChatClient({ send, onEvent }) {
  let n = 0;
  const waiting = new Map();           // our request id -> { resolve, reject }
  let sessionId = null;
  let promptCaps = {};
  let busy = false;
  const asked = new Map();             // agent request id -> true, while we wait for a tap

  const out = (o) => send(JSON.stringify({ jsonrpc: '2.0', ...o }));
  const request = (method, params) => new Promise((resolve, reject) => {
    const id = ++n; waiting.set(id, { resolve, reject });
    out({ id, method, params });
  });

  function update(u) {
    if (!u || typeof u !== 'object') return;
    const text = u.content && u.content.type === 'text' ? String(u.content.text || '') : '';
    switch (u.sessionUpdate) {
      case 'agent_message_chunk': if (text) onEvent({ t: 'text', text }); break;
      case 'agent_thought_chunk': if (text) onEvent({ t: 'thought', text }); break;
      case 'tool_call': onEvent({ t: 'tool', id: String(u.toolCallId), title: String(u.title || 'Working'), kind: String(u.kind || 'other'), status: String(u.status || 'pending') }); break;
      case 'tool_call_update': onEvent({ t: 'toolUpdate', id: String(u.toolCallId), status: u.status ? String(u.status) : undefined, title: u.title ? String(u.title) : undefined }); break;
      case 'available_commands_update': onEvent({ t: 'commands', list: (Array.isArray(u.availableCommands) ? u.availableCommands : []).map((c) => ({ name: String(c.name || ''), description: String(c.description || ''), hint: c.input && c.input.hint ? String(c.input.hint) : '' })).filter((c) => /^[\w:.-]+$/.test(c.name)) }); break;
      case 'plan': onEvent({ t: 'plan', entries: (Array.isArray(u.entries) ? u.entries : []).map((e) => ({ text: String(e.content || ''), status: String(e.status || 'pending') })) }); break;
      default: break;                  // modes, commands, usage… not shown
    }
  }

  return {
    get busy() { return busy; },
    get ready() { return sessionId !== null; },
    get canSendImages() { return promptCaps.image === true; },

    handleLine(line) {
      let m; try { m = JSON.parse(line); } catch (_) { return; }
      if (!m || typeof m !== 'object') return;
      if (m.method === undefined && m.id !== undefined) {             // an answer to us
        const w = waiting.get(m.id); if (!w) return;
        waiting.delete(m.id);
        if (m.error) w.reject(new Error((m.error && m.error.message) || 'The agent reported an error.')); else w.resolve(m.result || {});
        return;
      }
      if (m.method === 'session/update') { update(m.params && m.params.update); return; }
      if (m.method === 'session/request_permission' && m.id !== undefined) {
        const p = m.params || {};
        asked.set(m.id, true);
        onEvent({ t: 'permission', reqId: m.id, title: String((p.toolCall && p.toolCall.title) || 'Permission needed'),
          options: (Array.isArray(p.options) ? p.options : []).map((o) => ({ id: String(o.optionId), name: String(o.name || o.optionId), kind: String(o.kind || '') })) });
        return;
      }
      if (m.id !== undefined && m.method) out({ id: m.id, error: { code: -32601, message: 'Not supported here.' } });   // anything else it asks of us
    },

    async start(cwd) {
      try {
        const init = await request('initialize', { protocolVersion: 1, clientCapabilities: {}, clientInfo: { name: 'nami-mobile', version: '1' } });
        promptCaps = (init.agentCapabilities && init.agentCapabilities.promptCapabilities) || {};
        const r = await request('session/new', { cwd, mcpServers: [] });
        sessionId = r.sessionId;
        onEvent({ t: 'ready' });
      } catch (e) { onEvent({ t: 'error', message: e.message }); }
    },

    // images: [{ data: base64, mimeType }], sent as picture blocks when the agent says it takes them
    async prompt(text, images = []) {
      if (!sessionId || busy) return;
      busy = true; onEvent({ t: 'busy', on: true });
      try {
        const blocks = [...(promptCaps.image ? images.map((i) => ({ type: 'image', data: i.data, mimeType: i.mimeType })) : []), { type: 'text', text }];
        const r = await request('session/prompt', { sessionId, prompt: blocks });
        onEvent({ t: 'done', stopReason: String(r.stopReason || 'end_turn') });
      } catch (e) { onEvent({ t: 'error', message: e.message }); }
      busy = false; onEvent({ t: 'busy', on: false });
    },

    cancel() {
      if (!sessionId) return;
      out({ method: 'session/cancel', params: { sessionId } });
      for (const id of asked.keys()) out({ id, result: { outcome: { outcome: 'cancelled' } } });   // a pending question is answered "no"
      asked.clear();
    },

    answer(reqId, optionId) {
      if (!asked.delete(reqId)) return;
      out({ id: reqId, result: { outcome: optionId ? { outcome: 'selected', optionId } : { outcome: 'cancelled' } } });
    },
  };
}
