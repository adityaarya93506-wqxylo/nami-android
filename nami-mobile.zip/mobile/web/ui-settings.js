// Settings: the desk, text size, the workspace folder, providers (your own API keys),
// and what this app is.
import { el, S, hooks, rpc, toast, shortPath, openSheet, closeSheets, confirmSheet, store } from '/core.js';
import { THEMES } from '/themes.js';
import { applyTheme, applyFont } from '/theme.js';
import { chooseFolder, uploadOne } from '/ui-files.js';
import { openUsage, openPreview, openSetup, openQuickStart } from '/ui-tools.js';

export const VERSION = '0.13.2';

const PRESETS = [
  { id: 'anthropic', label: 'Anthropic-compatible', agent: 'claude', note: 'For Claude Code with another provider or proxy that speaks the Anthropic API.',
    vars: ['ANTHROPIC_BASE_URL', 'ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_MODEL'] },
  { id: 'openai', label: 'OpenAI-compatible', agent: 'codex', note: 'For Codex, OpenCode and other tools that use an OpenAI-style API.',
    vars: ['OPENAI_BASE_URL', 'OPENAI_API_KEY'] },
  { id: 'anthropic-key', label: 'Anthropic API key', agent: 'any', note: 'A plain API key instead of a subscription login.', vars: ['ANTHROPIC_API_KEY'] },
  { id: 'gemini', label: 'Gemini key', agent: 'any', note: '', vars: ['GEMINI_API_KEY'] },
  { id: 'custom', label: 'Custom', agent: 'any', note: 'Any variables your tool reads.', vars: ['', ''] },
];
const SECRET = /KEY|TOKEN|SECRET|PASSWORD/i;

export function openSettings() {
  const chips = el('div', { class: 'chips', role: 'radiogroup', 'aria-label': 'Desk' }, ...THEMES.map((t) => el('button', {
    class: 'chip desk-chip', type: 'button', role: 'radio', 'data-id': t.id, 'aria-checked': String(S.theme === t.id), text: t.name, onclick: () => applyTheme(t.id),
  })));
  const font = el('input', { id: 'font-size', type: 'range', min: '10', max: '20', step: '1', value: String(S.font), oninput: (e) => applyFont(e.target.value) });
  const provBox = el('div', { class: 'menu' });
  const connBox = el('div', { class: 'menu' });
  const agentBox = el('div', { class: 'menu' });
  const voiceBox = el('div', { class: 'stack' });
  openSheet('Settings',
    el('section', { class: 'sect' }, el('h3', { text: 'Look' }),
      el('div', { class: 'field' }, el('span', { text: 'Desk' }), chips),
      el('label', { class: 'field' }, el('span', {}, 'Text size ', el('output', { id: 'font-out', text: S.font + ' px' })), font)),
    el('section', { class: 'sect' }, el('h3', { text: 'Tools' }),
      el('button', { class: 'menu-item', type: 'button', onclick: () => openUsage() }, el('span', { text: 'Usage' }), el('small', { text: 'tokens, last 7 days' })),
      el('button', { class: 'menu-item', type: 'button', onclick: () => openQuickStart() }, el('span', { text: 'Quick start' }), el('small', { text: 'five steps to a first job' })),
      el('button', { class: 'menu-item', type: 'button', onclick: () => openSetup() }, el('span', { text: 'Setup check' }), el('small', { text: 'what is installed, free space' })),
      el('button', { class: 'menu-item', type: 'button', onclick: () => openPreview() }, el('span', { text: 'Preview a page' }), el('small', { text: 'a site your agent serves' }))),
    el('section', { class: 'sect' }, el('h3', { text: 'Voice' }), voiceBox),
    el('section', { class: 'sect' }, el('h3', { text: 'Workspace' }),
      el('button', { class: 'menu-item', type: 'button', onclick: () => { closeSheets(); chooseFolder(); } },
        el('span', { text: 'Folder' }), el('small', { text: shortPath(S.root) }))),
    el('section', { class: 'sect' }, el('h3', { text: 'Providers' }),
      el('p', { class: 'note', text: 'Your own API keys and base URLs. Pick one when you start a session and Nami sets it up for that agent, like exporting the variables in a terminal.' }),
      provBox),
    el('section', { class: 'sect' }, el('h3', { text: 'Agents' }),
      el('p', { class: 'note', text: 'What is installed in this Linux, and who is signed in. Tap one to sign in, sign out or remove it (that runs in a terminal; your sessions and settings stay).' }),
      agentBox),
    el('section', { class: 'sect' }, el('h3', { text: 'Connections' }),
      el('p', { class: 'note', text: 'Tools your agents can use. Nami writes them into Claude Code, OpenCode and Codex for you. Start a new agent session after connecting.' }),
      connBox),
    el('section', { class: 'sect' }, el('h3', { text: 'About' }),
      el('div', { class: 'about' }, el('img', { src: '/logo.png', alt: '', width: '44', height: '44' }),
        el('p', { class: 'note', html: `<b>Nami for Android ${VERSION}</b><br>Runs on this phone, inside its own Linux. Sessions are kept even when the app is closed. “Stop Nami” in the notification ends everything.<br>Built from Nami by Dainami AI (Apache-2.0). An unofficial personal build.` })),
      S.lan ? el('p', { class: 'note error', text: 'This server is reachable from your network. Anyone with the link can run commands on this phone.' }) : null,
      el('button', { class: 'btn btn-quiet', type: 'button', text: 'Forget this token', onclick: () => hooks.signOut() })));
  loadProviders(provBox);
  loadConnections(connBox);
  loadAgents(agentBox);
  loadVoice(voiceBox);
}

// Voice: the phone's own recogniser, or your own OpenAI-compatible speech key.
async function loadVoice(box) {
  let st;
  try { st = await rpc('voice.status'); } catch (e) { box.replaceChildren(el('p', { class: 'note', text: e.message })); return; }
  const cloud = store.get('nami.voice') === 'cloud';
  const chips = el('div', { class: 'chips', role: 'radiogroup', 'aria-label': 'Speech source' },
    ...[['device', 'This phone'], ['cloud', 'My speech key']].map(([id, label]) => el('button', { class: 'chip', type: 'button', role: 'radio', 'aria-checked': String((id === 'cloud') === cloud), text: label,
      onclick: () => { if (id === 'cloud' && !st.configured) { toast('Save a key below first.'); return; } store.set('nami.voice', id); if (hooks.refreshMic) hooks.refreshMic(); loadVoice(box); } })));
  const key = el('input', { type: 'password', placeholder: st.configured ? 'saved — type to replace' : 'sk-…', autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false', 'aria-label': 'Speech API key' });
  const model = el('input', { type: 'text', value: st.model, autocapitalize: 'off', 'aria-label': 'Model' });
  const base = el('input', { type: 'text', value: st.baseUrl, autocapitalize: 'off', spellcheck: 'false', 'aria-label': 'Service address' });
  box.replaceChildren(
    el('p', { class: 'note', text: 'This phone uses Android\'s recogniser (some phones need internet for it). With your own key, a short recording is sent to the service you set, and the text comes back.' }),
    chips,
    el('label', { class: 'field' }, el('span', { text: 'Speech API key' }), key),
    el('label', { class: 'field' }, el('span', { text: 'Model' }), model),
    el('label', { class: 'field' }, el('span', { text: 'Service address' }), base),
    el('div', { class: 'row-end' },
      st.configured ? el('button', { class: 'btn btn-quiet btn-small', type: 'button', text: 'Remove key', onclick: async () => { await rpc('voice.clear'); store.set('nami.voice', 'device'); if (hooks.refreshMic) hooks.refreshMic(); loadVoice(box); } }) : null,
      el('button', { class: 'btn btn-small btn-primary', type: 'button', text: 'Save', onclick: async () => {
        try { await rpc('voice.save', { key: key.value, model: model.value, baseUrl: base.value }); toast('Saved.'); loadVoice(box); } catch (e) { toast(e.message); }
      } })));
}

// Installed agents, each with who is signed in (read from the CLI's own files; never a key).
function loadAgents(box) {
  const inst = S.agents.filter((a) => a.installed);
  if (!inst.length) { box.replaceChildren(el('p', { class: 'note', text: 'No agent installed yet. Start a session and pick one.' })); return; }
  box.replaceChildren(...inst.map((a) => {
    const small = el('small', { text: 'checking…' });
    const row = el('button', { class: 'menu-item', type: 'button' }, el('span', { text: a.name }), small);
    let st = null;
    rpc('agents.status', { id: a.id }).then((r) => {
      st = r;
      small.textContent = r.signedIn === true ? (r.label || 'signed in') : r.signedIn === false ? 'signed out' : 'installed';
      if (r.signedIn === false) small.classList.add('warn');
    }).catch(() => { small.textContent = 'installed'; });
    row.addEventListener('click', () => agentSheet(a, st));
    return row;
  }));
}

function agentSheet(a, st) {
  const line = (cmd, label, danger) => el('button', { class: 'btn' + (danger ? ' btn-danger' : ''), type: 'button', text: label, onclick: () => { closeSheets(); hooks.runInTerminal(label + ' ' + a.name, cmd); } });
  const rows = st && st.rows && st.rows.length ? st.rows.map((r) => el('div', { class: 'menu-item static' }, el('span', { text: r.k }), el('small', { text: r.v }))) : [el('p', { class: 'note', text: st && st.signedIn === false ? 'Not signed in.' : 'No sign-in details available.' })];
  const acts = [];
  if (st && st.login && st.signedIn !== true) acts.push(line(st.login, 'Sign in'));
  if (st && st.logout && st.signedIn === true) acts.push(line(st.logout, st.via === 'account' && st.hasApiKey ? 'Sign out (use my API key)' : 'Sign out'));
  if (a.uninstall) acts.push(el('button', { class: 'btn btn-danger', type: 'button', text: 'Remove', onclick: async () => {
    const keep = { claude: '~/.claude', codex: '~/.codex', opencode: '~/.config/opencode' }[a.id];
    const ok = await confirmSheet({ title: 'Remove ' + a.name + '?', text: 'Nami opens a terminal and runs: ' + a.uninstall + (keep ? '. Your sign-in, settings and conversations in ' + keep + ' stay, so installing it again picks up where you left off.' : ''), ok: 'Remove', danger: true });
    if (!ok) return;
    hooks.runInTerminal('Remove ' + a.name, a.uninstall);
  } }));
  openSheet(a.name, el('div', { class: 'menu' }, ...rows), acts.length ? el('div', { class: 'row-end' }, ...acts) : null);
}

async function loadConnections(box) {
  let list = [];
  try { list = (await rpc('conn.list')).services; } catch (e) { box.append(el('p', { class: 'note', text: e.message })); return; }
  let custom = [];
  try { custom = (await rpc('conn.custom')).servers; } catch (_) { /* optional */ }
  box.replaceChildren(...list.map((c) => el('button', { class: 'menu-item', type: 'button', onclick: () => editConnection(c) },
    el('span', { text: c.name }), el('small', { text: c.connected ? '● connected' : c.desc }))),
    ...custom.map((c) => el('button', { class: 'menu-item', type: 'button', onclick: () => editCustom(c) }, el('span', { text: c.id }), el('small', { text: '● ' + c.command }))),
    ...GUIDED.map((g) => el('button', { class: 'menu-item', type: 'button', onclick: () => guidedSetup(g) }, el('span', { text: g.name }), el('small', { text: g.desc }))),
    ...(list.some((c) => c.connected) || custom.length ? [el('button', { class: 'menu-item add', type: 'button', text: '✓ Test my connections', onclick: () => testConnections([...list.filter((c) => c.connected).map((c) => ({ id: c.id, name: c.name })), ...custom.map((c) => ({ id: c.id, name: c.id }))]) })] : []),
    el('button', { class: 'menu-item add', type: 'button', text: '＋ Add your own server', onclick: () => editCustom(null) }),
    el('button', { class: 'menu-item add', type: 'button', text: '＋ Install a bundle (.mcpb)', onclick: installBundle }));
}

// Starts each connected server once and counts its tools: "connected" should mean it answers.
async function testConnections(items) {
  const rows = items.map((x) => ({ x, small: el('small', { text: 'testing…' }) }));
  openSheet('Test connections', el('p', { class: 'note', text: 'Each server is started once, asked for its tools, then stopped. The first run may download it and take a minute.' }),
    el('div', { class: 'menu' }, ...rows.map((r) => el('div', { class: 'menu-item static' }, el('span', { text: r.x.name }), r.small))));
  for (const r of rows) {
    try {
      const res = await rpc('conn.check', { id: r.x.id });
      r.small.textContent = res.ok ? `✓ answers · ${res.tools} tool${res.tools === 1 ? '' : 's'}` : '✗ ' + res.error;
      if (!res.ok) r.small.classList.add('warn');
    } catch (e) { r.small.textContent = '✗ ' + e.message; r.small.classList.add('warn'); }
  }
}

// Google asks for a short sign-in setup, so an agent walks you through it and finishes the connection.
const GUIDED = [
  { id: 'gmail', name: 'Gmail', desc: 'guided, about 5 minutes', pkg: '@gongrzhe/server-gmail-autoauth-mcp', what: 'read and reply to your email' },
  { id: 'gdrive', name: 'Google Drive', desc: 'guided, about 5 minutes', pkg: '@modelcontextprotocol/server-gdrive', what: 'read your files' },
];
function guidedSetup(g) {
  openSheet(g.name, el('p', { class: 'note-lg', text: `Google needs a one-time sign-in setup before an agent can ${g.what}. Nami starts Claude Code and asks it to walk you through it, step by step, on this phone.` }),
    el('p', { class: 'note', text: 'Needs Claude Code installed and signed in.' }),
    el('div', { class: 'row-end' },
      el('button', { class: 'btn btn-quiet', type: 'button', text: 'Cancel', onclick: closeSheets }),
      el('button', { class: 'btn btn-primary', type: 'button', text: 'Start guided setup', onclick: () => {
        closeSheets();
        hooks.newSession({ agentId: 'claude', name: 'Connect ' + g.name, cwd: S.home, seed:
          `Help me connect ${g.name} so my coding agents can ${g.what}. Use the MCP server ${g.pkg} (run with npx). I am on an Android phone and can only use this terminal and a browser, so go one small step at a time and tell me exactly what to tap. Walk me through creating the Google Cloud OAuth credentials it needs, then finish by running: claude mcp add ${g.id} -- npx ${g.pkg}. Do not show me long explanations.` });
      } })));
}

// Words to arguments, with 'single' and "double" quotes keeping a piece together.
export function splitArgs(text) {
  const out = []; const re = /"([^"]*)"|'([^']*)'|(\S+)/g; let m;
  while ((m = re.exec(String(text || '')))) out.push(m[1] ?? m[2] ?? m[3]);
  return out;
}

function editCustom(cur) {
  const id = el('input', { type: 'text', value: cur ? cur.id : '', placeholder: 'short name, like docs', 'aria-label': 'Name', autocapitalize: 'off', spellcheck: 'false', readonly: !!cur });
  const command = el('input', { type: 'text', value: cur ? cur.command : '', placeholder: 'npx', 'aria-label': 'Program', autocapitalize: 'off', spellcheck: 'false', class: 'mono' });
  const args = el('input', { type: 'text', value: cur ? cur.args.map((a) => (/\s/.test(a) ? JSON.stringify(a) : a)).join(' ') : '', placeholder: '-y some-mcp-server', 'aria-label': 'Arguments', autocapitalize: 'off', spellcheck: 'false', class: 'mono' });
  const rows = el('div', { class: 'stack' });
  const addRow = (k = '', v = '') => {
    const kin = el('input', { type: 'text', value: k, placeholder: 'NAME', 'aria-label': 'Variable name', autocapitalize: 'characters', spellcheck: 'false', class: 'mono' });
    const vin = el('input', { type: 'password', value: v, placeholder: cur && cur.envNames.includes(k) && k ? 'saved; enter again to keep' : 'value', 'aria-label': 'Value', autocapitalize: 'off', autocomplete: 'off', spellcheck: 'false', class: 'mono' });
    const row = el('div', { class: 'var-row' }, kin, vin, el('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Remove', text: '✕', onclick: () => row.remove() }));
    row.kin = kin; row.vin = vin; rows.append(row);
  };
  for (const n of cur ? cur.envNames : []) addRow(n);
  const form = el('form', { class: 'stack', onsubmit: async (e) => {
    e.preventDefault();
    const env = {};
    for (const r of rows.children) if (r.kin.value.trim()) env[r.kin.value.trim()] = r.vin.value;
    try {
      const r = await rpc('conn.connectCustom', { id: id.value.trim(), command: command.value.trim(), args: splitArgs(args.value), env });
      const bad = Object.entries(r.delivered).filter(([, v]) => v !== true);
      closeSheets(); toast(bad.length ? bad.map(([k, v]) => `${k}: ${v}`).join(' · ') : 'Saved.'); openSettings();
    } catch (err) { toast(err.message); }
  } },
    el('p', { class: 'note', text: 'Any MCP server that starts from a command. Nami writes it into Claude Code, OpenCode and Codex.' }),
    el('label', { class: 'field' }, el('span', { text: 'Name' }), id),
    el('label', { class: 'field' }, el('span', { text: 'Program' }), command),
    el('label', { class: 'field' }, el('span', { text: 'Arguments' }), args),
    el('div', { class: 'field' }, el('span', { text: 'Variables (keys and settings it needs)' }), rows,
      el('button', { class: 'btn btn-quiet btn-small', type: 'button', text: '＋ Variable', onclick: () => addRow() })),
    el('div', { class: 'row-end' },
      cur ? el('button', { class: 'btn btn-danger', type: 'button', text: 'Remove', onclick: async () => { try { await rpc('conn.disconnect', { id: cur.id }); closeSheets(); toast('Removed.'); openSettings(); } catch (err) { toast(err.message); } } }) : null,
      el('button', { class: 'btn btn-primary', type: 'submit', text: 'Save' })));
  openSheet(cur ? cur.id : 'Your own server', form);
}

function installBundle() {
  const input = el('input', { type: 'file', accept: '.mcpb,.zip,application/zip' });
  input.addEventListener('change', async () => {
    const f = input.files[0]; if (!f) return;
    try {
      toast('Reading ' + f.name + '…');
      const up = await uploadOne(f, S.root);
      const r = await rpc('conn.importBundle', { path: up.path });
      await rpc('fs.rm', { path: up.path }).catch(() => {});
      closeSheets(); toast('Installed ' + r.id + '.'); openSettings();
    } catch (err) { toast(err.message); }
  });
  input.click();
}

function editConnection(c) {
  const inputs = c.fields.map((f) => el('input', { type: f.secret ? 'password' : 'text', value: f.value || '', placeholder: c.connected && f.secret ? 'saved; enter a new one to replace' : f.placeholder || '', 'aria-label': f.label,
    autocapitalize: 'off', spellcheck: 'false', autocomplete: 'off', class: 'mono' }));
  const form = el('form', { class: 'stack', onsubmit: async (e) => {
    e.preventDefault();
    const values = {};
    c.fields.forEach((f, i) => { values[f.id] = inputs[i].value; });
    // a saved key may be left empty only to keep it: it is not sent back to the page, so ask again
    try {
      const r = await rpc('conn.connect', { id: c.id, values });
      const bad = Object.entries(r.delivered).filter(([, v]) => v !== true);
      closeSheets(); toast(bad.length ? bad.map(([k, v]) => `${k}: ${v}`).join(' · ') : c.name + ' connected.'); openSettings();
    } catch (err) { toast(err.message); }
  } },
    ...c.fields.map((f, i) => el('label', { class: 'field' }, el('span', { text: f.label }), inputs[i])),
    c.id === 'kie' ? el('div', { class: 'stack' },
      el('p', { class: 'note-lg', text: 'Make images, video and music with your KIE key. The tool is built from its source into the Linux first.' }),
      el('button', { class: 'btn', type: 'button', text: 'Step 1: build it (opens a terminal)', onclick: () => { closeSheets(); hooks.runInTerminal('Build Kie', 'git clone https://github.com/mrdainami/kie-mcp ~/kie-mcp && cd ~/kie-mcp && npm install && npm run build && echo "Built. Now connect it in Settings."'); } }),
      el('p', { class: 'note', text: 'Step 2: when it says Built, come back, paste your key below and tap Connect.' })) : null,
    c.id === 'browser' ? el('div', { class: 'stack' },
      el('p', { class: 'note-lg', text: 'Lets your agents open web pages, read them and click through, using a real browser inside Nami\'s Linux. It is large (about 300 MB) and experimental on a phone.' }),
      el('button', { class: 'btn', type: 'button', text: 'Step 1: install the browser (opens a terminal)', onclick: () => { closeSheets(); hooks.runInTerminal('Install browser', 'apk add --no-cache chromium && echo "Browser installed. Now connect it in Settings."'); } }),
      el('button', { class: 'btn', type: 'button', text: 'Step 2: check that it starts', onclick: async (e) => {
        const b = e.currentTarget; b.disabled = true; b.textContent = 'Checking…';
        try { const r = await rpc('conn.browserCheck'); toast(r.ok ? 'The browser starts. Tap Connect.' : r.error); } catch (err) { toast(err.message); }
        b.disabled = false; b.textContent = 'Step 2: check that it starts';
      } }),
      el('p', { class: 'note', text: 'Step 3: tap Connect. If the check fails, this phone cannot run the browser, and the other tools still work.' })) : null,
    c.help ? el('a', { class: 'linkish', href: c.help, target: '_blank', rel: 'noopener', text: 'Where do I get this?' }) : null,
    el('div', { class: 'row-end' },
      c.connected ? el('button', { class: 'btn btn-danger', type: 'button', text: 'Disconnect', onclick: async () => {
        try { await rpc('conn.disconnect', { id: c.id }); closeSheets(); toast(c.name + ' disconnected.'); openSettings(); } catch (err) { toast(err.message); }
      } }) : null,
      el('button', { class: 'btn btn-primary', type: 'submit', text: c.connected ? 'Update' : 'Connect' })));
  openSheet(c.name, form);
}

async function loadProviders(box) {
  let list = [];
  try { list = (await rpc('keys.list')).providers; } catch (e) { toast(e.message); }
  S.providers = list;
  box.replaceChildren(
    ...list.map((p) => el('button', { class: 'menu-item', type: 'button', onclick: () => editProvider(p.id) },
      el('span', { text: p.name }), el('small', { text: p.vars.map((v) => v.name).join(', ') }))),
    el('button', { class: 'menu-item add', type: 'button', text: '＋ Add a provider', onclick: () => editProvider(null) }));
}

async function editProvider(id) {
  let cur = null;
  if (id) { try { cur = await rpc('keys.get', { id }); } catch (e) { toast(e.message); return; } }
  const name = el('input', { type: 'text', value: cur ? cur.name : '', placeholder: 'e.g. My proxy', 'aria-label': 'Name', autocapitalize: 'off' });
  let agent = cur ? cur.agent : 'any';
  const rows = el('div', { class: 'stack' });
  const note = el('p', { class: 'note' });
  const rowFor = (k = '', v = '') => {
    const kin = el('input', { type: 'text', value: k, placeholder: 'NAME', 'aria-label': 'Variable name', autocapitalize: 'characters', spellcheck: 'false', class: 'mono' });
    const secretNow = () => SECRET.test(kin.value);
    const vin = el('input', { type: secretNow() ? 'password' : 'text', value: id && secretNow() ? '' : v, placeholder: id && cur && cur.env[k] != null && secretNow() ? 'saved (leave empty to keep)' : 'value', 'aria-label': 'Value', autocapitalize: 'off', spellcheck: 'false', autocomplete: 'off', class: 'mono' });
    kin.addEventListener('input', () => { vin.type = secretNow() ? 'password' : 'text'; });
    const row = el('div', { class: 'var-row' }, kin, vin,
      el('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Remove', text: '✕', onclick: () => row.remove() }));
    row.kin = kin; row.vin = vin;
    return row;
  };
  const setVars = (names) => { rows.replaceChildren(...names.map((n) => rowFor(n))); };
  if (cur) rows.replaceChildren(...Object.entries(cur.env).map(([k, v]) => rowFor(k, v)));
  else setVars(PRESETS[0].vars);
  const presets = cur ? null : el('div', { class: 'field' }, el('span', { text: 'Start from' }),
    el('div', { class: 'chips' }, ...PRESETS.map((p, i) => el('button', { class: 'chip', type: 'button', text: p.label, 'aria-checked': String(i === 0), role: 'radio',
      onclick: (e) => { setVars(p.vars); agent = p.agent; note.textContent = p.note; for (const c of e.currentTarget.parentNode.children) c.setAttribute('aria-checked', String(c === e.currentTarget)); } }))));
  if (!cur) note.textContent = PRESETS[0].note;
  const agentSel = el('div', { class: 'chips', role: 'radiogroup', 'aria-label': 'For' }, ...[['any', 'Any'], ['claude', 'Claude Code'], ['codex', 'Codex'], ['opencode', 'OpenCode']].map(([v, t]) => el('button', {
    class: 'chip', type: 'button', role: 'radio', text: t, 'data-v': v, 'aria-checked': String(agent === v),
    onclick: (e) => { agent = v; for (const c of e.currentTarget.parentNode.children) c.setAttribute('aria-checked', String(c.dataset.v === v)); } })));
  const save = async () => {
    const env = {};
    for (const r of rows.children) {
      const k = r.kin.value.trim(); const v = r.vin.value;
      if (!k) continue;
      if (v === '' && !(cur && cur.env[k] != null)) continue;   // an empty new variable is just left out
      env[k] = v;
    }
    try { await rpc('keys.save', { id: id || undefined, name: name.value, agent, env }); toast('Saved.'); openSettings(); }
    catch (e) { toast(e.message); }
  };
  openSheet(id ? 'Edit provider' : 'New provider',
    presets, note,
    el('label', { class: 'field' }, el('span', { text: 'Name' }), name),
    el('div', { class: 'field' }, el('span', { text: 'Shown for' }), agentSel),
    el('div', { class: 'field' }, el('span', { text: 'Variables' }), rows,
      el('button', { class: 'btn btn-quiet', type: 'button', text: '＋ Add variable', onclick: () => rows.append(rowFor()) })),
    el('p', { class: 'note', text: 'Stored only on this phone, in a file only Nami can read.' }),
    el('div', { class: 'row-end' },
      id ? el('button', { class: 'btn btn-danger', type: 'button', text: 'Delete', onclick: async () => {
        if (!(await confirmSheet({ title: 'Delete ' + cur.name + '?', text: 'The saved key is removed from this phone.', ok: 'Delete', danger: true }))) { editProvider(id); return; }
        try { await rpc('keys.remove', { id }); toast('Deleted.'); openSettings(); } catch (e) { toast(e.message); }
      } }) : null,
      el('button', { class: 'btn btn-quiet', type: 'button', text: 'Back', onclick: () => openSettings() }),
      el('button', { class: 'btn btn-primary', type: 'button', text: 'Save', onclick: save })));
}

export async function providerChoices(agentId) {
  try { S.providers = (await rpc('keys.list')).providers; } catch (_) { S.providers = S.providers || []; }
  return (S.providers || []).filter((p) => p.agent === 'any' || p.agent === agentId);
}
