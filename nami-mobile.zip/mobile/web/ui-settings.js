// Settings: the desk, text size, the workspace folder, providers (your own API keys),
// and what this app is.
import { el, S, hooks, rpc, toast, shortPath, openSheet, closeSheets, confirmSheet, store } from '/core.js';
import { THEMES } from '/themes.js';
import { applyTheme, applyFont } from '/theme.js';
import { chooseFolder } from '/ui-files.js';

export const VERSION = '0.4.0';

const PRESETS = [
  { id: 'anthropic', label: 'Anthropic-compatible', agent: 'claude', note: 'For Claude Code with another provider or proxy that speaks the Anthropic API.',
    vars: ['ANTHROPIC_BASE_URL', 'ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_MODEL'] },
  { id: 'openai', label: 'OpenAI-compatible', agent: 'codex', note: 'For Codex, OpenCode and other tools that use an OpenAI-style API.',
    vars: ['OPENAI_BASE_URL', 'OPENAI_API_KEY'] },
  { id: 'anthropic-key', label: 'Anthropic API key', agent: 'any', note: 'A plain API key instead of a subscription login.', vars: ['ANTHROPIC_API_KEY'] },
  { id: 'gemini', label: 'Gemini key', agent: 'any', note: '', vars: ['GEMINI_API_KEY'] },
  { id: 'custom', label: 'Custom', agent: 'any', note: 'Any variables your tool reads.', vars: ['', ''] },
];
const SECRET = /KEY|TOKEN|SECRET|PASSWORD/i;

export function openSettings() {
  const chips = el('div', { class: 'chips', role: 'radiogroup', 'aria-label': 'Desk' }, ...THEMES.map((t) => el('button', {
    class: 'chip desk-chip', type: 'button', role: 'radio', 'data-id': t.id, 'aria-checked': String(S.theme === t.id), text: t.name, onclick: () => applyTheme(t.id),
  })));
  const font = el('input', { id: 'font-size', type: 'range', min: '10', max: '20', step: '1', value: String(S.font), oninput: (e) => applyFont(e.target.value) });
  const provBox = el('div', { class: 'menu' });
  openSheet('Settings',
    el('section', { class: 'sect' }, el('h3', { text: 'Look' }),
      el('div', { class: 'field' }, el('span', { text: 'Desk' }), chips),
      el('label', { class: 'field' }, el('span', {}, 'Text size ', el('output', { id: 'font-out', text: S.font + ' px' })), font)),
    el('section', { class: 'sect' }, el('h3', { text: 'Workspace' }),
      el('button', { class: 'menu-item', type: 'button', onclick: () => { closeSheets(); chooseFolder(); } },
        el('span', { text: 'Folder' }), el('small', { text: shortPath(S.root) }))),
    el('section', { class: 'sect' }, el('h3', { text: 'Providers' }),
      el('p', { class: 'note', text: 'Your own API keys and base URLs. Pick one when you start a session and Nami sets it up for that agent, like exporting the variables in a terminal.' }),
      provBox),
    el('section', { class: 'sect' }, el('h3', { text: 'About' }),
      el('div', { class: 'about' }, el('img', { src: '/logo.png', alt: '', width: '44', height: '44' }),
        el('p', { class: 'note', html: `<b>Nami for Android ${VERSION}</b><br>Runs on this phone, inside its own Linux. Sessions are kept even when the app is closed. “Stop Nami” in the notification ends everything.<br>Built from Nami by Dainami AI (Apache-2.0). An unofficial personal build.` })),
      S.lan ? el('p', { class: 'note error', text: 'This server is reachable from your network. Anyone with the link can run commands on this phone.' }) : null,
      el('button', { class: 'btn btn-quiet', type: 'button', text: 'Forget this token', onclick: () => hooks.signOut() })));
  loadProviders(provBox);
}

async function loadProviders(box) {
  let list = [];
  try { list = (await rpc('keys.list')).providers; } catch (e) { toast(e.message); }
  S.providers = list;
  box.replaceChildren(
    ...list.map((p) => el('button', { class: 'menu-item', type: 'button', onclick: () => editProvider(p.id) },
      el('span', { text: p.name }), el('small', { text: p.vars.map((v) => v.name).join(', ') }))),
    el('button', { class: 'menu-item add', type: 'button', text: '＋ Add a provider', onclick: () => editProvider(null) }));
}

async function editProvider(id) {
  let cur = null;
  if (id) { try { cur = await rpc('keys.get', { id }); } catch (e) { toast(e.message); return; } }
  const name = el('input', { type: 'text', value: cur ? cur.name : '', placeholder: 'e.g. My proxy', 'aria-label': 'Name', autocapitalize: 'off' });
  let agent = cur ? cur.agent : 'any';
  const rows = el('div', { class: 'stack' });
  const note = el('p', { class: 'note' });
  const rowFor = (k = '', v = '') => {
    const kin = el('input', { type: 'text', value: k, placeholder: 'NAME', 'aria-label': 'Variable name', autocapitalize: 'characters', spellcheck: 'false', class: 'mono' });
    const secretNow = () => SECRET.test(kin.value);
    const vin = el('input', { type: secretNow() ? 'password' : 'text', value: id && secretNow() ? '' : v, placeholder: id && cur && cur.env[k] != null && secretNow() ? 'saved (leave empty to keep)' : 'value', 'aria-label': 'Value', autocapitalize: 'off', spellcheck: 'false', autocomplete: 'off', class: 'mono' });
    kin.addEventListener('input', () => { vin.type = secretNow() ? 'password' : 'text'; });
    const row = el('div', { class: 'var-row' }, kin, vin,
      el('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Remove', text: '✕', onclick: () => row.remove() }));
    row.kin = kin; row.vin = vin;
    return row;
  };
  const setVars = (names) => { rows.replaceChildren(...names.map((n) => rowFor(n))); };
  if (cur) rows.replaceChildren(...Object.entries(cur.env).map(([k, v]) => rowFor(k, v)));
  else setVars(PRESETS[0].vars);
  const presets = cur ? null : el('div', { class: 'field' }, el('span', { text: 'Start from' }),
    el('div', { class: 'chips' }, ...PRESETS.map((p, i) => el('button', { class: 'chip', type: 'button', text: p.label, 'aria-checked': String(i === 0), role: 'radio',
      onclick: (e) => { setVars(p.vars); agent = p.agent; note.textContent = p.note; for (const c of e.currentTarget.parentNode.children) c.setAttribute('aria-checked', String(c === e.currentTarget)); } }))));
  if (!cur) note.textContent = PRESETS[0].note;
  const agentSel = el('div', { class: 'chips', role: 'radiogroup', 'aria-label': 'For' }, ...[['any', 'Any'], ['claude', 'Claude Code'], ['codex', 'Codex'], ['opencode', 'OpenCode']].map(([v, t]) => el('button', {
    class: 'chip', type: 'button', role: 'radio', text: t, 'data-v': v, 'aria-checked': String(agent === v),
    onclick: (e) => { agent = v; for (const c of e.currentTarget.parentNode.children) c.setAttribute('aria-checked', String(c.dataset.v === v)); } })));
  const save = async () => {
    const env = {};
    for (const r of rows.children) {
      const k = r.kin.value.trim(); const v = r.vin.value;
      if (!k) continue;
      if (v === '' && !(cur && cur.env[k] != null)) continue;   // an empty new variable is just left out
      env[k] = v;
    }
    try { await rpc('keys.save', { id: id || undefined, name: name.value, agent, env }); toast('Saved.'); openSettings(); }
    catch (e) { toast(e.message); }
  };
  openSheet(id ? 'Edit provider' : 'New provider',
    presets, note,
    el('label', { class: 'field' }, el('span', { text: 'Name' }), name),
    el('div', { class: 'field' }, el('span', { text: 'Shown for' }), agentSel),
    el('div', { class: 'field' }, el('span', { text: 'Variables' }), rows,
      el('button', { class: 'btn btn-quiet', type: 'button', text: '＋ Add variable', onclick: () => rows.append(rowFor()) })),
    el('p', { class: 'note', text: 'Stored only on this phone, in a file only Nami can read.' }),
    el('div', { class: 'row-end' },
      id ? el('button', { class: 'btn btn-danger', type: 'button', text: 'Delete', onclick: async () => {
        if (!(await confirmSheet({ title: 'Delete ' + cur.name + '?', text: 'The saved key is removed from this phone.', ok: 'Delete', danger: true }))) { editProvider(id); return; }
        try { await rpc('keys.remove', { id }); toast('Deleted.'); openSettings(); } catch (e) { toast(e.message); }
      } }) : null,
      el('button', { class: 'btn btn-quiet', type: 'button', text: 'Back', onclick: () => openSettings() }),
      el('button', { class: 'btn btn-primary', type: 'button', text: 'Save', onclick: save })));
}

export async function providerChoices(agentId) {
  try { S.providers = (await rpc('keys.list')).providers; } catch (_) { S.providers = S.providers || []; }
  return (S.providers || []).filter((p) => p.agent === 'any' || p.agent === agentId);
}
