import { S, store } from '/core.js';
import { themeById, clampFont } from '/themes.js';

export function applyTheme(id) {
  const t = themeById(id);
  S.theme = t.id;
  document.body.dataset.theme = t.id;
  if (t.id === 'glass' || t.id === 'graphite') document.body.setAttribute('data-glass', ''); else document.body.removeAttribute('data-glass');
  if (t.id === 'soft' || t.id === 'dusk') document.body.setAttribute('data-soft', ''); else document.body.removeAttribute('data-soft');
  store.set('nami.theme', t.id);
  const css = getComputedStyle(document.body);
  const paper = css.getPropertyValue('--paper').trim();
  const desk = css.getPropertyValue('--desk').trim();
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta && desk) meta.setAttribute('content', desk);
  if (S.term) S.term.options.theme = { ...t.xterm, background: paper, cursorAccent: paper };
  if (S.term2) S.term2.options.theme = { ...t.xterm, background: paper, cursorAccent: paper };
  for (const chip of document.querySelectorAll('.desk-chip')) chip.setAttribute('aria-checked', String(chip.dataset.id === t.id));
}

export function applyFont(n) {
  S.font = clampFont(n, S.font);
  store.set('nami.font', String(S.font));
  if (S.term) { S.term.options.fontSize = S.font; if (S.fit) setTimeout(() => { try { S.fit.fit(); } catch (_) { /* not shown */ } }, 30); }
  const out = document.getElementById('font-out'); if (out) out.textContent = S.font + ' px';
  const inp = document.getElementById('font-size'); if (inp) inp.value = String(S.font);
}

// Three levels of polish. Full keeps everything. Balanced keeps every shadow, gradient and lit edge (the
// depth) and drops only what a phone paints slowly: live blur behind panes and endless animations. Light
// also flattens shadows. The default is Full.
export function fxMode() {
  const v = store.get('nami.fx');
  if (v === 'full' || v === 'balanced' || v === 'light') return v;
  const old = store.get('nami.lite');            // older choice
  if (old === '1') return 'light';
  if (old === '0') return 'full';
  return 'full';           // the whole look, everywhere; Balanced and Light stay available if a phone ever needs them
}
export const liteOn = () => fxMode() === 'light';
export function applyFx(mode = fxMode()) {
  const b = document.body;
  b.removeAttribute('data-lite'); b.removeAttribute('data-balanced');
  if (mode === 'light') b.setAttribute('data-lite', '');
  if (mode === 'balanced') b.setAttribute('data-balanced', '');
  const small = mode !== 'full';
  if (S.term) S.term.options.scrollback = small ? 2500 : 6000;
}
export const applyLite = applyFx;
export function setFx(mode) { store.set('nami.fx', mode); applyFx(mode); }
