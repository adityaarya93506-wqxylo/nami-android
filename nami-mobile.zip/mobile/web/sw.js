// Needed so the browser offers "Install app". It caches nothing: the page is
// served by the server on this phone, so there is nothing useful offline, and
// a stale copy of it would be worse than none.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', () => { /* network only */ });
