// Library: the agents and skills on file for Claude Code, Codex and OpenCode.
// Open one to read or edit it; make a new one by describing it to your own agent
// (it writes the file) or from a blank template.
import { $, el, S, hooks, rpc, toast, shortPath, openSheet, closeSheets, confirmSheet } from '/core.js';
import { platformChip } from '/chips.js';

const L = { items: null, filter: 'all', open: null };

const PLATFORMS = { claude: 'Claude Code', codex: 'Codex', opencode: 'OpenCode' };

export async function loadLibrary(force = false) {
  if (L.items && !force) { renderLibrary(); return; }
  try { L.items = (await rpc('lib.scan')).items; } catch (e) { toast(e.message); L.items = L.items || []; }
  renderLibrary();
}

function renderLibrary() {
  for (const b of document.querySelectorAll('#lib-filter .seg')) b.setAttribute('aria-pressed', String(b.dataset.f === L.filter));
  const items = (L.items || []).filter((i) => L.filter === 'all' || i.type === (L.filter === 'agents' ? 'agent' : 'skill'));
  $('lib-empty').hidden = items.length > 0;
  const box = $('lib-list');
  const out = [];
  for (const platform of Object.keys(PLATFORMS)) {
    const mine = items.filter((i) => i.platform === platform);
    if (!mine.length) continue;
    out.push(el('h3', { class: 'group' }, platformChip(platform, 'agent'), el('span', { text: PLATFORMS[platform] }), el('small', { text: String(mine.length) })));
    for (const i of mine) {
      out.push(el('button', { class: 'row-main card-row', type: 'button', onclick: () => openCard(i) },
        el('span', { class: 'kind-dot', 'data-kind': i.type, title: i.type, text: i.type === 'skill' ? '✦' : '◉' }),
        el('span', { class: 'main' },
          el('strong', { text: i.name }),
          el('small', { text: i.description || (i.type === 'skill' ? 'skill' : 'agent') })),
        el('span', { class: 'tag', text: i.scope === 'project' ? 'this folder' : 'yours' })));
    }
  }
  box.replaceChildren(...out);
}

for (const b of document.querySelectorAll('#lib-filter .seg')) b.addEventListener('click', () => { L.filter = b.dataset.f; renderLibrary(); });

// ---- one card -----------------------------------------------------------------

export async function openCard(item) {
  let r;
  try { r = await rpc('lib.read', { path: item.path }); } catch (e) { toast(e.message); return; }
  L.open = { item, text: r.text, mtime: r.mtime, dirty: false };
  $('card-title').textContent = item.name;
  $('card-sub').textContent = shortPath(item.path);
  const ta = $('card-text');
  ta.value = r.text;
  $('card-save').hidden = true;
  $('card-run').hidden = !(item.platform === 'claude' || item.platform === 'codex' || item.platform === 'opencode');
  hooks.showScreen('card');
}

$('card-text').addEventListener('input', () => {
  if (!L.open) return;
  L.open.text = $('card-text').value;
  L.open.dirty = true;
  $('card-save').hidden = false;
  $('card-title').textContent = '● ' + L.open.item.name;
});

$('card-save').addEventListener('click', async () => {
  const o = L.open;
  if (!o) return;
  try {
    const r = await rpc('lib.write', { path: o.item.path, text: o.text, mtime: o.mtime });
    o.mtime = r.mtime; o.dirty = false;
    $('card-save').hidden = true; $('card-title').textContent = o.item.name;
    toast('Saved.');
    loadLibrary(true);
  } catch (e) {
    if (e.code === 'conflict') toast('This file changed on disk. Go back and open it again.'); else toast(e.message);
  }
});

$('card-run').addEventListener('click', () => {
  const o = L.open;
  if (!o) return;
  const it = o.item;
  const agentId = it.platform;
  const seed = it.type === 'skill' ? `Use the ${it.slug} skill.` : `Use the ${it.slug} agent.`;
  hooks.newSession({ agentId, seed, name: it.name, cwd: it.scope === 'project' ? S.root : undefined, open: true });
});

export async function closeCard() {
  if (L.open && L.open.dirty) {
    const ok = await confirmSheet({ title: 'Leave without saving?', text: 'Your changes to ' + L.open.item.name + ' are not saved.', ok: 'Leave', danger: true });
    if (!ok) return false;
  }
  L.open = null;
  hooks.showScreen('main');
  return true;
}
export const cardOpen = () => !!L.open;

// ---- making a new one ---------------------------------------------------------

const DIRS = {
  claude: { agent: '.claude/agents/NAME.md', skill: '.claude/skills/NAME/SKILL.md' },
  codex: { agent: '.codex/agents/NAME.toml', skill: '.codex/skills/NAME/SKILL.md' },
  opencode: { agent: '.opencode/agent/NAME.md', skill: null },
};

function slug(n) { return String(n || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 48); }

function seedText(o) {
  const base = o.where === 'project' ? S.root : S.home;
  const file = (DIRS[o.platform][o.type] || '').replace('NAME', slug(o.name) || 'name');
  const fmt = o.platform === 'codex' && o.type === 'agent'
    ? 'a TOML file with name, description and developer_instructions'
    : 'a markdown file that starts with frontmatter containing name and description';
  return `Help me create a new ${o.type} called "${o.name}". What it should do: ${o.desc.replace(/\s+/g, ' ').trim()} `
    + `Ask me any questions you need first. Then write it as ${fmt} at ${base}/${file}, and tell me when it is ready.`;
}

export function newItemSheet() {
  const o = { type: 'agent', platform: 'claude', where: 'user', name: '', desc: '' };
  const name = el('input', { type: 'text', placeholder: 'Name', autocapitalize: 'off', spellcheck: 'false', 'aria-label': 'Name' });
  const desc = el('textarea', { rows: '4', placeholder: 'What should it do? e.g. read my week of notes and write the Friday client update, in my voice.', 'aria-label': 'What should it do' });
  const hint = el('p', { class: 'note' });
  const seg = (label, key, val, pairs) => el('div', { class: 'field' }, el('span', { text: label }),
    el('div', { class: 'segs', role: 'group', 'aria-label': label }, ...pairs.map(([v, t]) => el('button', {
      class: 'seg', type: 'button', text: t, 'aria-pressed': String(o[key] === v), 'data-v': v,
      onclick: (e) => { if (v === 'skill' && o.platform === 'opencode') { toast('OpenCode has no skills here.'); return; } o[key] = v; for (const b of e.currentTarget.parentNode.children) b.setAttribute('aria-pressed', String(b.dataset.v === o[key])); refresh(); },
    }))));
  const refresh = () => {
    const f = (DIRS[o.platform][o.type] || '').replace('NAME', slug(name.value) || 'name');
    hint.textContent = f ? 'It will be saved as ' + shortPath((o.where === 'project' ? S.root : S.home) + '/' + f) : 'OpenCode has no skills folder here.';
  };
  name.addEventListener('input', refresh);
  const agent = () => S.agents.find((a) => a.id === o.platform);
  const build = el('button', { class: 'btn btn-primary', type: 'button', text: 'Build it with my agent', onclick: () => {
    if (!name.value.trim() || !slug(name.value)) { toast('Give it a name with letters or numbers.'); return; }
    if (!desc.value.trim()) { toast('Describe what it should do first.'); return; }
    if (!DIRS[o.platform][o.type]) { toast('Not available for that tool.'); return; }
    const a = agent();
    if (!a || !a.installed) { toast((a ? a.name : o.platform) + ' is not installed yet. Install it from New session first, or use "write it myself".'); return; }
    o.name = name.value.trim(); o.desc = desc.value;
    closeSheets();
    hooks.newSession({ agentId: o.platform, seed: seedText(o), name: 'build: ' + o.name, cwd: o.where === 'project' ? S.root : S.home, open: true, afterExit: () => loadLibrary(true) });
  } });
  const blank = el('button', { class: 'btn btn-quiet', type: 'button', text: 'Write it myself', onclick: async () => {
    if (!slug(name.value)) { toast('Give it a name with letters or numbers.'); return; }
    try {
      const r = await rpc('lib.create', { platform: o.platform, scope: o.where, type: o.type, name: name.value.trim(), description: desc.value.trim() });
      closeSheets();
      await loadLibrary(true);
      const it = (L.items || []).find((i) => i.path === r.path);
      if (it) openCard(it);
    } catch (e) { toast(e.message); }
  } });
  openSheet('New agent or skill',
    seg('Kind', 'type', null, [['agent', 'Agent'], ['skill', 'Skill']]),
    seg('For', 'platform', null, [['claude', 'Claude Code'], ['codex', 'Codex'], ['opencode', 'OpenCode']]),
    seg('Keep it in', 'where', null, [['user', 'Your account'], ['project', 'Workspace folder']]),
    el('label', { class: 'field' }, el('span', { text: 'Name' }), name),
    el('label', { class: 'field' }, el('span', { text: 'What should it do?' }), desc),
    hint,
    el('div', { class: 'row-end' }, blank, build));
  refresh();
}
