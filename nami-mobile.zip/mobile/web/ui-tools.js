// Usage and the page preview: two small tools reached from Settings and the sessions bar.

import { $, el, S, hooks, rpc, toast, openSheet, closeSheets } from '/core.js';

const nf = (n) => (n >= 1e6 ? (n / 1e6).toFixed(n >= 1e7 ? 0 : 1) + 'M' : n >= 1e3 ? (n / 1e3).toFixed(n >= 1e4 ? 0 : 1) + 'k' : String(n));
const weekday = (day) => new Date(day + 'T12:00:00').toLocaleDateString(undefined, { weekday: 'short' });

export async function openUsage() {
  const body = openSheet('Usage', el('p', { class: 'note', text: 'Counting…' }));
  let r;
  try { r = await rpc('usage.read'); } catch (e) { body.replaceChildren(el('p', { class: 'note', text: e.message })); return; }
  const peak = Math.max(1, ...r.agents.flatMap((a) => a.days.map((d) => d.input + d.output)));
  body.replaceChildren(
    el('p', { class: 'note', text: 'Tokens your agents used on this phone over the last 7 days, from the records they keep. Your plan\'s own limit is shown by the agent itself (for Claude Code, type /usage).' }),
    ...r.agents.map((a) => el('section', { class: 'sect' },
      el('h3', { text: a.name }),
      a.total.turns === 0 ? el('p', { class: 'note', text: 'Nothing used yet.' }) : el('div', { class: 'stack' },
        el('p', { class: 'note-lg', text: `Today ${nf(a.today.input + a.today.output)} · 7 days ${nf(a.total.input + a.total.output)}` }),
        el('div', { class: 'bars', role: 'img', 'aria-label': `${a.name} tokens per day` },
          ...a.days.map((d) => el('div', { class: 'bar-col', title: `${d.day}: ${nf(d.input)} in, ${nf(d.output)} out` },
            el('div', { class: 'bar-fill', style: `height:${Math.round(((d.input + d.output) / peak) * 100)}%` }),
            el('small', { text: weekday(d.day) })))),
        el('p', { class: 'note', text: `${nf(a.total.input)} in · ${nf(a.total.output)} out · ${nf(a.total.cached)} re-read from cache · ${a.total.turns} ${a.total.turns === 1 ? 'turn' : 'turns'}` })))));
}

// ---- preview: show a page the agent is serving on this phone (a dev server), inside the app ----

export function previewAddress(text) {
  let t = String(text || '').trim();
  if (!t) return null;
  if (/^\d{2,5}$/.test(t)) t = '127.0.0.1:' + t;
  if (!/^https?:\/\//i.test(t)) t = 'http://' + t;
  let u; try { u = new URL(t); } catch (_) { return null; }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') return null;
  if (u.hostname === 'localhost') u.hostname = '127.0.0.1';
  // Nami's own page holds the token; never frame it where it could be read.
  if (u.hostname === '127.0.0.1' && (u.port || '80') === (location.port || '80')) return null;
  return u.href;
}

let lastUrl = '';
export function openPreview() {
  closeSheets();
  hooks.showScreen('preview');
  if (!$('preview-frame').src && lastUrl) go(lastUrl);
  if (!lastUrl) $('preview-url').focus();
}
export function closePreview() { hooks.showScreen('main'); }

function go(text) {
  const href = previewAddress(text);
  if (!href) { toast('That address cannot be shown here.'); return; }
  lastUrl = href; $('preview-url').value = href;
  $('preview-frame').src = href;
}
$('preview-form').addEventListener('submit', (e) => { e.preventDefault(); go($('preview-url').value); $('preview-url').blur(); });
$('preview-reload').addEventListener('click', () => { if (lastUrl) { $('preview-frame').src = 'about:blank'; setTimeout(() => go(lastUrl), 30); } });
$('preview-out').addEventListener('click', () => { if (lastUrl) window.open(lastUrl, '_blank'); });
$('preview-back').addEventListener('click', closePreview);
