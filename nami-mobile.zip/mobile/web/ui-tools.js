// Usage and the page preview: two small tools reached from Settings and the sessions bar.

import { $, el, S, hooks, rpc, toast, openSheet, closeSheets, rawUrl } from '/core.js';

const nf = (n) => (n >= 1e6 ? (n / 1e6).toFixed(n >= 1e7 ? 0 : 1) + 'M' : n >= 1e3 ? (n / 1e3).toFixed(n >= 1e4 ? 0 : 1) + 'k' : String(n));
const weekday = (day) => new Date(day + 'T12:00:00').toLocaleDateString(undefined, { weekday: 'short' });

export async function openUsage() {
  const body = openSheet('Usage', el('p', { class: 'note', text: 'Counting…' }));
  let r;
  try { r = await rpc('usage.read'); } catch (e) { body.replaceChildren(el('p', { class: 'note', text: e.message })); return; }
  const peak = Math.max(1, ...r.agents.flatMap((a) => a.days.map((d) => d.input + d.output)));
  body.replaceChildren(
    quotaSection(r.quota, () => { closeSheets(); openUsage(); }),
    el('p', { class: 'note', text: 'Tokens your agents used on this phone over the last 7 days, from the records they keep. Your plan\'s own limit is shown by the agent itself (for Claude Code, type /usage).' }),
    ...r.agents.map((a) => el('section', { class: 'sect' },
      el('h3', { text: a.name }),
      a.total.turns === 0 ? el('p', { class: 'note', text: 'Nothing used yet.' }) : el('div', { class: 'stack' },
        el('p', { class: 'note-lg', text: `Today ${nf(a.today.input + a.today.output)} · 7 days ${nf(a.total.input + a.total.output)}` }),
        el('div', { class: 'bars', role: 'img', 'aria-label': `${a.name} tokens per day` },
          ...a.days.map((d) => el('div', { class: 'bar-col', title: `${d.day}: ${nf(d.input)} in, ${nf(d.output)} out` },
            el('div', { class: 'bar-fill', style: `height:${Math.round(((d.input + d.output) / peak) * 100)}%` }),
            el('small', { text: weekday(d.day) })))),
        el('p', { class: 'note', text: `${nf(a.total.input)} in · ${nf(a.total.output)} out · ${nf(a.total.cached)} re-read from cache · ${a.total.turns} ${a.total.turns === 1 ? 'turn' : 'turns'}` })))));
}

// ---- preview: show a page the agent is serving on this phone (a dev server), inside the app ----

export function previewAddress(text) {
  let t = String(text || '').trim();
  if (!t) return null;
  if (/^\d{2,5}$/.test(t)) t = '127.0.0.1:' + t;
  if (!/^https?:\/\//i.test(t)) t = 'http://' + t;
  let u; try { u = new URL(t); } catch (_) { return null; }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') return null;
  if (u.hostname === 'localhost') u.hostname = '127.0.0.1';
  // Nami's own page holds the token; never frame it where it could be read.
  if (u.hostname === '127.0.0.1' && (u.port || '80') === (location.port || '80')) return null;
  return u.href;
}

let lastUrl = '';
export function openPreview() {
  closeSheets();
  hooks.showScreen('preview');
  if (!$('preview-frame').src && lastUrl) go(lastUrl);
  if (!lastUrl) $('preview-url').focus();
}
export function openPreviewAt(url) { closeSheets(); hooks.showScreen('preview'); go(url); }
export function closePreview() { hooks.showScreen('main'); }

const trail = []; let at = -1;
function go(text, fromTrail = false) {
  const href = previewAddress(text);
  if (!href) { toast('That address cannot be shown here.'); return; }
  lastUrl = href; $('preview-url').value = href; pvVisit(href);
  if (!fromTrail) { trail.splice(at + 1); trail.push(href); at = trail.length - 1; }
  $('preview-back2').disabled = at <= 0; $('preview-fwd').disabled = at >= trail.length - 1;
  $('preview-frame').src = href;
}
$('preview-form').addEventListener('submit', (e) => { e.preventDefault(); go($('preview-url').value); $('preview-url').blur(); });
$('preview-reload').addEventListener('click', () => { if (lastUrl) { $('preview-frame').src = 'about:blank'; setTimeout(() => go(lastUrl), 30); } });
$('preview-out').addEventListener('click', () => { if (lastUrl) window.open(lastUrl, '_blank'); });
$('preview-back').addEventListener('click', closePreview);

// ---- Setup check ----
export async function openSetup() {
  const body = openSheet('Setup check', el('p', { class: 'note', text: 'Checking…' }));
  let r;
  try { r = await rpc('setup.check'); } catch (e) { body.replaceChildren(el('p', { class: 'note', text: e.message })); return; }
  body.replaceChildren(
    el('div', { class: 'menu' }, ...r.tools.map((x) => el('div', { class: 'menu-item static' }, el('span', { text: (x.ok ? '✓ ' : '✗ ') + x.id }), el('small', { text: x.ok ? x.version : 'missing — ' + x.need })))),
    el('p', { class: r.lowDisk ? 'note warn' : 'note', text: r.disk.freeMB === null ? 'Free space: unknown.' : `Free space: ${r.disk.freeMB} MB${r.lowDisk ? ' — low, installs may fail' : ''}` }),
    r.plan.length ? el('section', { class: 'sect' }, el('h3', { text: 'Not installed yet' }),
      ...r.plan.map((p) => el('div', { class: 'menu-item static' }, el('span', { text: p.name }), el('small', { text: p.ready ? 'ready to install' : 'needs ' + p.missing.join(', ') })))) : el('p', { class: 'note', text: 'Every agent is installed.' }));
}

// ---- Preview bookmarks and history (kept on this phone) ----
const PV_KEY = 'nami.preview';
const pvLoad = () => { try { const v = JSON.parse(localStorage.getItem(PV_KEY) || '{}'); return { marks: Array.isArray(v.marks) ? v.marks : [], recent: Array.isArray(v.recent) ? v.recent : [] }; } catch (_) { return { marks: [], recent: [] }; } };
const pvSave = (v) => { try { localStorage.setItem(PV_KEY, JSON.stringify(v)); } catch (_) { /* private mode */ } };
function pvVisit(href) { const v = pvLoad(); v.recent = [href, ...v.recent.filter((x) => x !== href)].slice(0, 15); pvSave(v); }
$('preview-marks').addEventListener('click', () => {
  const v = pvLoad();
  const here = lastUrl;
  const row = (u, marked) => el('div', { class: 'menu-item' }, el('button', { class: 'linkish', type: 'button', text: u, onclick: () => { closeSheets(); go(u); } }),
    marked ? el('button', { class: 'linkish', type: 'button', text: '✕', 'aria-label': 'Remove', onclick: () => { const w = pvLoad(); w.marks = w.marks.filter((x) => x !== u); pvSave(w); closeSheets(); } }) : null);
  openSheet('Bookmarks', el('div', { class: 'menu' },
    here && !v.marks.includes(here) ? el('button', { class: 'btn btn-small', type: 'button', text: '★ Bookmark this page', onclick: () => { const w = pvLoad(); w.marks.unshift(here); pvSave(w); closeSheets(); toast('Bookmarked.'); } }) : null,
    ...(v.marks.length ? [el('h4', { text: 'Bookmarks' }), ...v.marks.map((u) => row(u, true))] : []),
    ...(v.recent.length ? [el('h4', { text: 'Recent' }), ...v.recent.map((u) => row(u, false))] : [el('p', { class: 'note', text: 'Nothing visited yet.' })])));
});

// Claude's own limit windows, if the person has turned the feed on.
function quotaSection(qt, again) {
  if (!qt) return el('span');
  const left = (ms) => { if (!ms) return ''; const m = Math.max(0, Math.round((ms - Date.now()) / 60000)); return m >= 1440 ? `resets in ${Math.round(m / 1440)}d` : m >= 60 ? `resets in ${Math.round(m / 60)}h` : `resets in ${m}m`; };
  const act = async (op) => { try { await rpc(op); again(); } catch (e) { toast(e.message); } };
  const rows = qt.windows.map((w) => el('div', { class: 'stack' },
    el('div', { class: 'row-between' }, el('span', { text: w.label }), el('small', { text: `${w.used}% used${w.resetsAt ? ' · ' + left(w.resetsAt) : ''}` })),
    el('div', { class: 'meter', role: 'img', 'aria-label': `${w.label} ${w.used}% used` }, el('i', { style: `width:${Math.min(100, w.used)}%` }))));
  return el('section', { class: 'sect' }, el('h3', { text: 'Claude plan limit' }),
    ...(rows.length ? rows : [el('p', { class: 'note', text: qt.installed ? 'Waiting for Claude Code to report. Use it once and come back.' : 'Shows how much of your Claude plan window is used.' })]),
    qt.installed ? el('button', { class: 'linkish', type: 'button', text: 'Turn off', onclick: () => act('usage.quotaOff') })
      : qt.blocked === 'other' ? el('p', { class: 'note', text: 'You already use your own Claude status line, so Nami leaves it alone.' })
      : el('button', { class: 'btn btn-small', type: 'button', text: 'Show my Claude limit', onclick: () => act('usage.quotaOn') }));
}

// ---- Quick start: a checklist that ticks itself off, not a tour ----
const QS_KEY = 'nami.qs';
const qsLoad = () => { try { return new Set(JSON.parse(localStorage.getItem(QS_KEY) || '[]')); } catch (_) { return new Set(); } };
const qsMark = (n) => { const d = qsLoad(); d.add(n); try { localStorage.setItem(QS_KEY, JSON.stringify([...d])); } catch (_) { /* private mode */ } };
export function qsNote(n) { qsMark(n); }

export async function openQuickStart() {
  const done = qsLoad();
  let signed = false;
  try { for (const a of S.agents.filter((x) => x.installed && x.id !== 'kimi')) { const r = await rpc('agents.status', { id: a.id }); if (r.signedIn === true) { signed = true; break; } } } catch (_) { /* optional */ }
  if (S.root && S.root !== S.home) qsMark('folder');
  if (S.sessions.length) qsMark('session');
  if (signed) qsMark('signin');
  const d = qsLoad();
  const row = (n, title, sub, ...acts) => el('div', { class: 'qs-row' + (d.has(n) ? ' done' : '') },
    el('span', { class: 'qs-tick', text: d.has(n) ? '✓' : '○' }),
    el('div', { class: 'main' }, el('strong', { text: title }), el('small', { text: sub }), acts.length ? el('div', { class: 'row-end' }, ...acts) : null));
  const go = (label, fn) => el('button', { class: 'btn btn-small btn-primary', type: 'button', text: label, onclick: () => { closeSheets(); fn(); } });
  openSheet('Quick start', el('div', { class: 'stack' },
    row('folder', 'Pick one folder to work in', 'Agents only look inside it. Your files stay on this phone.', go('Choose folder', () => $('ws-pill').click())),
    row('session', 'Press New session and pick who runs it', 'Terminal, Claude Code, Codex and more. Anything missing installs from the same list.', go('New session', () => $('btn-new').click())),
    row('signin', 'Sign in to an agent', 'Claude Code uses your Claude account, Codex your ChatGPT one. Or add your own API key under Providers.', el('button', { class: 'btn btn-small', type: 'button', text: 'Open Settings', onclick: () => { closeSheets(); $('btn-settings').click(); } })),
    row('ask', 'Say what you need, in plain English', 'No commands to learn. For example: "tidy up the files in this folder", or "explain what this project does".'),
    row('ok', 'It asks before it does anything real', 'A permission card means it is waiting on you. Nothing happens behind your back.')));
}

$('preview-back2').addEventListener('click', () => { if (at > 0) { at--; go(trail[at], true); } });
$('preview-fwd').addEventListener('click', () => { if (at < trail.length - 1) { at++; go(trail[at], true); } });
// Hands the address to an agent session so it can look at the page with its own tools.
$('preview-agent').addEventListener('click', () => {
  if (!lastUrl) { toast('Open a page first.'); return; }
  const a = S.agents.find((x) => x.installed && ['claude', 'codex', 'opencode'].includes(x.id));
  if (!a) { toast('Install an agent first.'); return; }
  hooks.newSession({ agentId: a.id, name: 'Look at page', seed: `Please look at the page at ${lastUrl} (it is running on this phone) and tell me what you see, then check whether anything looks broken.`, cwd: S.root });
});

// ---- Storage and backup ----
export async function openStorage() {
  const body = openSheet('Storage and backup', el('p', { class: 'note', text: 'Measuring…' }));
  const again = () => { closeSheets(); openStorage(); };
  let r;
  try { r = await rpc('storage.info'); } catch (e) { body.replaceChildren(el('p', { class: 'note', text: e.message })); return; }
  const fmt = (mb) => (mb >= 1024 ? (mb / 1024).toFixed(1) + ' GB' : mb + ' MB');
  const act = async (btn, label, fn) => { btn.disabled = true; btn.textContent = label; try { await fn(); } catch (e) { toast(e.message); btn.disabled = false; } };
  const cleanBtn = el('button', { class: 'btn btn-small', type: 'button', text: 'Clear caches', onclick: () => act(cleanBtn, 'Clearing…', async () => { const c = await rpc('storage.clean'); toast(`Freed ${fmt(c.freedMB)}.`); again(); }) });
  const backupBtn = el('button', { class: 'btn', type: 'button', text: 'Back up my files', onclick: () => act(backupBtn, 'Backing up… this can take a minute', async () => {
    const b = await rpc('storage.backup');
    backupBtn.replaceWith(el('div', { class: 'stack' },
      el('p', { class: 'note', text: `Saved ${b.name} (${fmt(b.mb)}) in Backups.` }),
      el('button', { class: 'btn', type: 'button', text: 'Download to phone', onclick: () => {
        const url = rawUrl(b.path, true);
        if (window.NamiNative && window.NamiNative.download) { window.NamiNative.download(location.origin + url, b.name); toast('Saving ' + b.name + ' to Downloads…'); }
        else { const a = el('a', { href: url, download: b.name }); document.body.append(a); a.click(); a.remove(); }
      } })));
  }) });
  body.replaceChildren(
    el('div', { class: 'menu' }, ...r.items.map((x) => el('div', { class: 'menu-item static' }, el('span', { text: x.label }), el('small', { text: fmt(x.mb) })))),
    el('p', { class: r.freeMB !== null && r.freeMB < 500 ? 'note warn' : 'note', text: r.freeMB === null ? 'Free space: unknown.' : `Free space on the phone: ${fmt(r.freeMB)}` }),
    el('section', { class: 'sect' }, el('h3', { text: 'Clean up' }), el('p', { class: 'note', text: 'Clears the npm and apt download caches. Nothing you made or installed is touched.' }), cleanBtn),
    el('section', { class: 'sect' }, el('h3', { text: 'Backup' }), el('p', { class: 'note', text: 'Packs your files, settings and agents (without caches) into one file. The last three are kept in Backups. Unpack later with: tar -xzf <file> -C /root' }), backupBtn));
}
