import { Terminal } from '/vendor/xterm.mjs';
import { FitAddon } from '/vendor/addon-fit.mjs';
import { THEMES, DEFAULT_THEME, themeById, clampFont } from '/themes.js';
import { keySeq, ctrlify, composeToInput, pasteToInput, scrollLines } from '/keys.js';

const $ = (id) => document.getElementById(id);

// ---- small helpers ---------------------------------------------------------

const store = {
  get(k) { try { return localStorage.getItem(k); } catch (_) { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (_) { /* private mode */ } },
  del(k) { try { localStorage.removeItem(k); } catch (_) { /* private mode */ } },
};

function el(tag, props = {}, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') n.className = v;
    else if (k === 'text') n.textContent = v;
    else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
    else if (v === true) n.setAttribute(k, '');
    else if (v !== false && v != null) n.setAttribute(k, v);
  }
  for (const kid of kids) if (kid != null) n.append(kid);
  return n;
}

let toastTimer = 0;
function toast(msg) {
  const t = $('toast');
  t.textContent = msg; t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; }, 3200);
}

function ago(ms) {
  const s = Math.max(0, Math.round((Date.now() - ms) / 1000));
  if (s < 60) return 'just now';
  if (s < 3600) return Math.floor(s / 60) + ' min ago';
  if (s < 86400) return Math.floor(s / 3600) + ' h ago';
  return Math.floor(s / 86400) + ' d ago';
}

// ---- state -----------------------------------------------------------------

const S = {
  token: null, ws: null, ready: false, retry: 0, retryTimer: 0,
  sessions: [], agents: [], home: '', lan: false,
  current: null,            // id of the session on screen
  ctrl: false,              // the Ctrl button is armed
  prefill: null,            // text to leave at the prompt of the session being created
  theme: store.get('nami.theme') || DEFAULT_THEME,
  font: clampFont(store.get('nami.font'), 14),
  term: null, fit: null,
};

function send(obj) {
  if (S.ws && S.ws.readyState === 1) { S.ws.send(JSON.stringify(obj)); return true; }
  return false;
}

// ---- screens & sheets ------------------------------------------------------

function show(name) {
  for (const id of ['login', 'home', 'term']) $('screen-' + id).hidden = id !== name;
}
function openSheet(id) { $(id).hidden = false; }
function closeSheets() { for (const s of document.querySelectorAll('.sheet')) s.hidden = true; }

document.addEventListener('click', (e) => {
  if (e.target.closest('[data-close]') || e.target.classList.contains('sheet')) closeSheets();
});
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeSheets(); });

// ---- themes ----------------------------------------------------------------

function applyTheme(id) {
  const t = themeById(id);
  S.theme = t.id;
  document.body.dataset.theme = t.id;
  store.set('nami.theme', t.id);
  const css = getComputedStyle(document.body);
  const paper = css.getPropertyValue('--paper').trim();
  const desk = css.getPropertyValue('--desk').trim();
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta && desk) meta.setAttribute('content', desk);
  if (S.term) S.term.options.theme = { ...t.xterm, background: paper, cursorAccent: paper };
  for (const chip of document.querySelectorAll('.chip')) chip.setAttribute('aria-checked', String(chip.dataset.id === t.id));
}

function buildThemeChips() {
  const box = $('theme-chips');
  box.replaceChildren(...THEMES.map((t) => el('button', {
    class: 'chip', type: 'button', role: 'radio', 'data-id': t.id, 'aria-checked': 'false', text: t.name,
    onclick: () => applyTheme(t.id),
  })));
}

function applyFont(n) {
  S.font = clampFont(n, S.font);
  store.set('nami.font', String(S.font));
  $('font-size').value = String(S.font);
  $('font-out').textContent = S.font + ' px';
  if (S.term) { S.term.options.fontSize = S.font; fitSoon(); }
}

// ---- connection ------------------------------------------------------------

function setConn(state, text) {
  const c = $('conn');
  c.dataset.state = state; c.textContent = text;
}

function connect() {
  clearTimeout(S.retryTimer);
  if (!S.token) { show('login'); return; }
  if (S.ws && S.ws.readyState <= 1) return;
  setConn('wait', 'Connecting…');
  const ws = new WebSocket(`${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws`);
  S.ws = ws;
  ws.onopen = () => ws.send(JSON.stringify({ type: 'auth', token: S.token }));
  ws.onmessage = (e) => { let m; try { m = JSON.parse(e.data); } catch (_) { return; } onMessage(m); };
  ws.onclose = (e) => {
    if (S.ws !== ws) return;
    S.ws = null; S.ready = false;
    if (e.code === 4003) { badToken(); return; }
    setConn('wait', 'Reconnecting…');
    S.retry = Math.min(S.retry + 1, 6);
    S.retryTimer = setTimeout(connect, Math.min(8000, 700 * S.retry));
  };
}

function badToken(message = 'That token was not accepted.') {
  store.del('nami.token'); S.token = null; S.current = null;
  $('login-error').textContent = message; $('login-error').hidden = false;
  show('login');
}

// A phone sleeps its tabs. Come back to a live socket as soon as the page does.
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible' && S.token && !S.ready) connect();
});

function onMessage(m) {
  switch (m.type) {
    case 'authed':
      S.ready = true; S.retry = 0;
      S.sessions = m.sessions; S.agents = m.agents; S.home = m.home || ''; S.lan = !!m.lan;
      setConn('ok', 'Connected');
      renderHome(); renderAbout();
      if (S.current && S.sessions.some((s) => s.id === S.current)) attach(S.current);
      else { S.current = null; show('home'); }
      break;
    case 'denied': badToken(); break;
    case 'sessions':
      S.sessions = m.sessions; renderHome();
      if (S.current) updateTermBar();
      break;
    case 'agents': S.agents = m.agents; renderAgents(); break;
    case 'created':
      S.sessions = [...S.sessions.filter((s) => s.id !== m.session.id), m.session];
      closeSheets(); openTerm(m.session.id);
      break;
    case 'snapshot':
      if (m.id !== S.current || !S.term) break;
      S.term.reset(); S.term.write(m.data || '');
      setEnded(m.exited, m.exitCode);
      if (S.prefill) { send({ type: 'input', id: m.id, data: S.prefill }); S.prefill = null; }
      break;
    case 'data': if (m.id === S.current && S.term) S.term.write(m.data); break;
    case 'exit': if (m.id === S.current) setEnded(true, m.code); break;
    case 'error': toast(m.message || 'Something went wrong.'); $('new-error').textContent = m.message || ''; $('new-error').hidden = !m.message; break;
    default: break;
  }
}

// ---- sessions list ---------------------------------------------------------

function renderHome() {
  const list = $('session-list');
  const sorted = [...S.sessions].sort((a, b) => b.startedAt - a.startedAt);
  $('empty').hidden = sorted.length > 0;
  list.hidden = sorted.length === 0;
  list.replaceChildren(...sorted.map((s) => el('button', { class: 'card', type: 'button', onclick: () => attach(s.id) },
    el('span', { class: 'dot', 'data-state': s.exited ? 'end' : 'run', 'aria-hidden': 'true' }),
    el('span', { class: 'main' }, el('strong', { text: s.name }), el('small', { text: shortPath(s.cwd) + ' · ' + ago(s.startedAt) })),
    el('span', { class: 'tag', text: s.exited ? 'finished' : 'running', ...(s.persistent && !s.exited ? { title: 'Keeps running even if the app is closed' } : {}) }),
  )));
}

function shortPath(p) {
  if (S.home && p === S.home) return '~';
  if (S.home && p.startsWith(S.home + '/')) return '~' + p.slice(S.home.length);
  return p;
}

function renderAbout() {
  $('about').textContent = 'Nami for Android 0.2. ' + (S.sessions.some((x) => x.persistent) || S.keeps ? 'Sessions are kept: they keep running if you close the app. ' : '') + (S.lan
    ? 'This server is reachable from your network. Anyone with the link can run commands on this phone.'
    : 'This server only listens on this phone.');
}

// ---- new session -----------------------------------------------------------

function renderAgents() {
  const box = $('agent-list');
  const cards = [el('button', { class: 'card', type: 'button', onclick: () => createSession({ kind: 'shell' }) },
    el('span', { class: 'main' }, el('strong', { text: 'Terminal' }), el('small', { text: 'a plain shell' })))];
  for (const a of S.agents) {
    if (a.installed) {
      cards.push(el('button', { class: 'card', type: 'button', onclick: () => createSession({ kind: 'agent', agentId: a.id }) },
        el('span', { class: 'main' }, el('strong', { text: a.name }), el('small', { text: a.sub || '' })),
        el('span', { class: 'tag', text: 'ready' })));
    } else {
      cards.push(el('button', { class: 'card needs-install', type: 'button', onclick: () => installAgent(a) },
        el('span', { class: 'main' }, el('strong', { text: a.name }), el('small', { text: 'not installed here' }),
          el('p', { class: 'install-hint', text: a.install || '' })),
        el('span', { class: 'tag', text: 'install' })));
    }
  }
  box.replaceChildren(...cards);
}

function termDims() {
  return S.term ? { cols: S.term.cols, rows: S.term.rows } : { cols: 80, rows: 24 };
}

function createSession(req) {
  const cwd = $('new-cwd').value.trim();
  $('new-error').hidden = true;
  if (!send({ type: 'create', ...req, ...(cwd ? { cwd } : {}), ...termDims() })) toast('Not connected yet.');
}

// Open a terminal with the install line typed at the prompt. It is not run:
// you read it and press Enter yourself.
function installAgent(a) {
  if (!/^(curl|npm|pip|pkg|apt)\b/.test(a.install || '')) { toast('See ' + a.name + "'s docs for how to install it."); return; }
  S.prefill = a.install;
  createSession({ kind: 'shell', name: 'Install ' + a.name });
}

// ---- terminal --------------------------------------------------------------

let fitTimer = 0;
function fitSoon() {
  clearTimeout(fitTimer);
  fitTimer = setTimeout(() => { if (S.fit && !$('screen-term').hidden) { try { S.fit.fit(); } catch (_) { /* not laid out yet */ } } }, 60);
}

function ensureTerm() {
  if (S.term) return;
  const t = themeById(S.theme);
  const paper = getComputedStyle(document.body).getPropertyValue('--paper').trim();
  const term = new Terminal({
    fontFamily: "'Courier Prime', ui-monospace, monospace", fontSize: S.font, scrollback: 6000, cursorBlink: true,
    allowProposedApi: true, minimumContrastRatio: 4.5, theme: { ...t.xterm, background: paper, cursorAccent: paper },
  });
  const fit = new FitAddon();
  term.loadAddon(fit);
  term.open($('term-host'));
  S.term = term; S.fit = fit;

  term.onData((d) => typeInto(d));
  // A keyboard opening or a rotation fires several resizes in a row; tell the
  // server once things settle (a tmux session redraws on each one it hears).
  let resizeTimer = 0;
  term.onResize(({ cols, rows }) => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => { if (S.current) send({ type: 'resize', id: S.current, cols, rows }); }, 250);
  });
  setupTouchScroll();
  new ResizeObserver(fitSoon).observe($('term-host'));
  window.addEventListener('resize', fitSoon);
}

function currentSession() { return S.sessions.find((s) => s.id === S.current) || null; }

// ---- scrolling ---------------------------------------------------------------
// A session kept in tmux has its history in tmux, so the page asks the server to
// scroll it. Any other session scrolls xterm's own buffer.

function lineHeightPx() {
  const rows = $('term-host').querySelector('.xterm-rows');
  return rows && rows.firstElementChild ? rows.firstElementChild.getBoundingClientRect().height || 16 : 16;
}

function scrollBy(lines) {
  const s = currentSession();
  if (!lines || !s) return;
  if (s.persistent) send({ type: 'scroll', id: s.id, lines });
  else S.term.scrollLines(-lines);
}

function setupTouchScroll() {
  const host = $('term-host');
  let y = null; let carry = 0; let pending = 0; let timer = 0;
  const flush = () => { timer = 0; const n = pending; pending = 0; scrollBy(n); };
  host.addEventListener('touchstart', (e) => { y = e.touches.length === 1 ? e.touches[0].clientY : null; carry = 0; }, { passive: true, capture: true });
  host.addEventListener('touchmove', (e) => {
    if (y === null || e.touches.length !== 1) return;
    const now = e.touches[0].clientY;
    const r = scrollLines(now - y, lineHeightPx(), carry);
    y = now; carry = r.carry;
    e.preventDefault(); e.stopPropagation();       // ours, not xterm's own (empty) scroll
    pending += r.lines;
    if (!timer) timer = setTimeout(flush, 70);       // many small moves, one message
  }, { passive: false, capture: true });
  host.addEventListener('touchend', () => { y = null; }, { passive: true, capture: true });
}

function typeInto(data) {
  const s = currentSession();
  if (!s || s.exited) return;
  if (S.ctrl) { data = ctrlify(data); setCtrl(false); }
  send({ type: 'input', id: s.id, data });
}

function openTerm(id) {
  S.current = id;
  show('term');
  ensureTerm();
  updateTermBar();
  S.term.reset();
  fitSoon();
  setTimeout(() => attach(id), 80);
}

function attach(id) {
  S.current = id;
  show('term');
  ensureTerm();
  updateTermBar();
  try { S.fit.fit(); } catch (_) { /* not laid out yet */ }
  send({ type: 'attach', id, ...termDims() });
}

function updateTermBar() {
  const s = currentSession();
  if (!s) return;
  $('term-title').textContent = s.name;
  $('term-sub').textContent = shortPath(s.cwd);
  setEnded(s.exited, s.exitCode);
}

function setEnded(ended, code) {
  $('term-ended').hidden = !ended;
  if (ended) $('term-ended-text').textContent = code ? 'Finished with an error (' + code + ')' : 'Finished';
  $('btn-stop').hidden = !!ended;
  $('compose').hidden = !!ended; $('keybar').hidden = !!ended;
}

function leaveTerm() {
  if (S.current) send({ type: 'detach' });
  S.current = null;
  show('home'); renderHome();
}

function closeCurrent() {
  const s = currentSession();
  if (!s) return;
  if (!s.exited && !confirm('Stop ' + s.name + '? Anything it is doing will end.')) return;
  send({ type: 'close', id: s.id });
  S.sessions = S.sessions.filter((x) => x.id !== s.id);
  leaveTerm();
}

// ---- key bar & message box -------------------------------------------------

function setCtrl(on) {
  S.ctrl = on;
  $('key-ctrl').setAttribute('aria-pressed', String(on));
}

$('keybar').addEventListener('pointerdown', (e) => e.preventDefault()); // keep the keyboard where it is
$('keybar').addEventListener('click', async (e) => {
  const b = e.target.closest('button[data-seq]');
  if (!b) return;
  const name = b.dataset.seq;
  if (name === 'ctrl') { setCtrl(!S.ctrl); return; }
  if (name === 'pgup' || name === 'pgdn') {
    const page = Math.max(3, (S.term ? S.term.rows : 24) - 2);
    scrollBy(name === 'pgup' ? page : -page);
    return;
  }
  if (name === 'live') {
    const s = currentSession();
    if (s && s.persistent) send({ type: 'live', id: s.id }); else if (S.term) S.term.scrollToBottom();
    return;
  }
  if (name === 'paste') {
    try {
      const text = window.NamiNative && window.NamiNative.paste ? window.NamiNative.paste() : await navigator.clipboard.readText();
      const d = pasteToInput(text, { bracketed: !!S.term?.modes.bracketedPasteMode });
      if (d) typeInto(d);
    } catch (_) { toast('The browser would not share the clipboard. Long-press the message box to paste.'); }
    return;
  }
  const seq = keySeq(name, { appCursor: !!S.term?.modes.applicationCursorKeysMode });
  if (seq) { setCtrl(false); typeInto(seq); }
});

const composeText = $('compose-text');
function autosize() {
  composeText.style.height = 'auto';
  composeText.style.height = Math.min(composeText.scrollHeight, 120) + 'px';
}
composeText.addEventListener('input', autosize);
$('compose').addEventListener('submit', (e) => {
  e.preventDefault();
  const data = composeToInput(composeText.value, { bracketed: !!S.term?.modes.bracketedPasteMode });
  typeInto(data);
  composeText.value = ''; autosize();
});

// ---- buttons ---------------------------------------------------------------

$('btn-new').addEventListener('click', () => {
  $('new-cwd').placeholder = S.home ? shortPath(S.home) : 'Home folder';
  $('new-error').hidden = true;
  send({ type: 'agents' });
  renderAgents(); openSheet('sheet-new');
});
$('btn-settings').addEventListener('click', () => openSheet('sheet-settings'));
$('btn-back').addEventListener('click', leaveTerm);
$('btn-stop').addEventListener('click', closeCurrent);
$('btn-dismiss').addEventListener('click', closeCurrent);
$('font-size').addEventListener('input', (e) => applyFont(e.target.value));
$('btn-signout').addEventListener('click', () => {
  closeSheets(); store.del('nami.token'); S.token = null; S.current = null;
  if (S.ws) S.ws.close();
  $('login-error').hidden = true; show('login');
});
$('login-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const t = $('login-token').value.trim();
  if (!t) return;
  S.token = t; store.set('nami.token', t); $('login-token').value = ''; $('login-error').hidden = true;
  connect();
});

// The Android app asks this on its Back button: true means "handled here".
window.namiBack = () => {
  if (document.querySelector('.sheet:not([hidden])')) { closeSheets(); return true; }
  if (!$('screen-term').hidden) { leaveTerm(); return true; }
  return false;
};

// ---- start -----------------------------------------------------------------

function start() {
  buildThemeChips(); applyTheme(S.theme); applyFont(S.font);
  // The link the server prints carries the token once; keep it and take it out of the address bar.
  const fromUrl = new URL(location.href).searchParams.get('t');
  if (fromUrl) { store.set('nami.token', fromUrl); history.replaceState(null, '', location.pathname); }
  S.token = store.get('nami.token');
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => { /* optional */ });
  if (S.token) { show('home'); connect(); } else show('login');
}
start();
