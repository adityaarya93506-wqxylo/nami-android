import { Terminal } from '/vendor/xterm.mjs';
import { FitAddon } from '/vendor/addon-fit.mjs';
import { THEMES, DEFAULT_THEME, themeById, clampFont } from '/themes.js';
import { icon, paintIcons } from '/ui-icons.js';
import { isTerminalReply, keySeq, ctrlify, composeToInput, pasteToInput, scrollLines } from '/keys.js';
import { $, el, store, toast, ago, S, hooks, send, rpc, answerRpc, failAllRpc, shortPath, openSheet, closeSheets, sheetOpen, confirmSheet, askText } from '/core.js';
import { applyTheme, applyFont } from '/theme.js';
import { agentChip } from '/chips.js';
import { uploadOne, watchWorkspace, showWorkspace, updateWorkspacePill, upDir, addMenu, chooseFolder, saveFile, closeFile, fileDirty } from '/ui-files.js';
import { loadLibrary, newItemSheet, closeCard, cardOpen } from '/ui-library.js';
import { openSettings, providerChoices } from '/ui-settings.js';
import { closePreview, openPreviewAt, openQuickStart } from '/ui-tools.js';
import { startChat, onChatMessage, chatOpen, closeChat, openHistory } from '/ui-chat.js';

S.theme = store.get('nami.theme') || DEFAULT_THEME;
S.font = clampFont(store.get('nami.font'), 14);

// ---- screens & tabs ----------------------------------------------------------

const SCREENS = ['login', 'main', 'term', 'file', 'card', 'preview', 'chat'];
function show(name) {
  for (const id of SCREENS) $('screen-' + id).hidden = id !== name;
}
hooks.showScreen = show;

function showTab(name) {
  S.tab = name;
  for (const t of ['sessions', 'work', 'lib']) $('tab-' + t).hidden = t !== name;
  for (const b of document.querySelectorAll('#tabbar button')) b.setAttribute('aria-current', b.dataset.tab === name ? 'page' : 'false');
  $('btn-new').hidden = name !== 'sessions';
  watchWorkspace(name === 'work');
  if (name === 'work') showWorkspace();
  if (name === 'lib') loadLibrary();
}
for (const b of document.querySelectorAll('#tabbar button')) b.addEventListener('click', () => showTab(b.dataset.tab));

// ---- the connection -----------------------------------------------------------

function setConn(state, text) {
  const c = $('conn');
  c.dataset.state = state; c.title = text; c.setAttribute('aria-label', text);
}

function connect() {
  clearTimeout(S.retryTimer);
  if (!S.token) { show('login'); return; }
  if (S.ws && S.ws.readyState <= 1) return;
  setConn('wait', 'Connecting…');
  const ws = new WebSocket(`${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws`);
  S.ws = ws;
  ws.onopen = () => ws.send(JSON.stringify({ type: 'auth', token: S.token }));
  ws.onmessage = (e) => { let m; try { m = JSON.parse(e.data); } catch (_) { return; } onMessage(m); };
  ws.onclose = (e) => {
    if (S.ws !== ws) return;
    S.ws = null; S.ready = false; failAllRpc();
    if (e.code === 4003) { badToken(); return; }
    setConn('wait', 'Reconnecting…');
    S.retry = Math.min(S.retry + 1, 6);
    S.retryTimer = setTimeout(connect, Math.min(8000, 700 * S.retry));
  };
}

// Inside the Android app the app itself knows the token (it reads it from the Linux's files),
// so the page never has to remember it and never has to ask for it.
function nativeToken() {
  try {
    const t = window.NamiNative && window.NamiNative.token ? String(window.NamiNative.token() || '').trim() : '';
    return /^[0-9a-f]{48}$/.test(t) ? t : '';
  } catch (_) { return ''; }
}

function badToken(message = 'That token was not accepted.') {
  const nt = nativeToken();
  if (nt && nt !== S.token) { S.token = nt; store.set('nami.token', nt); S.retry = 0; connect(); return; }
  store.del('nami.token'); S.token = null; S.current = null;
  $('login-error').textContent = message; $('login-error').hidden = false;
  show('login');
}

hooks.signOut = () => {
  closeSheets(); store.del('nami.token'); S.token = null; S.current = null;
  if (S.ws) S.ws.close();
  $('login-error').hidden = true; show('login');
};

// A phone sleeps its tabs. Come back to a live socket as soon as the page does.
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible' && S.token && !S.ready) connect();
});

const afterExit = new Map();   // session id -> function to run when it ends

function onMessage(m) {
  switch (m.type) {
    case 'authed':
      S.ready = true; S.retry = 0;
      S.sessions = m.sessions; S.agents = m.agents; S.home = m.home || ''; S.root = m.root || m.home || ''; S.lan = !!m.lan;
      setConn('ok', 'Connected');
      updateWorkspacePill();
      renderHome();
      if (S.current && S.sessions.some((s) => s.id === S.current)) attach(S.current);
      if (S.current2) { if (S.sessions.some((s) => s.id === S.current2) && S.term2) send({ type: 'attach', id: S.current2, extra: true, cols: S.term2.cols, rows: S.term2.rows }); else closeSplit(); }
      else if (S.current) { S.current = null; show('main'); }
      else if ($('screen-file').hidden && $('screen-card').hidden) show('main');
      showTab(S.tab);
      if (!S.sessions.length) hooks.welcome();
      break;
    case 'denied': badToken(); break;
    case 'rpc': answerRpc(m); break;
    case 'chat.started': case 'chat.failed': case 'chat.line': case 'chat.exit': onChatMessage(m); break;
    case 'sessions':
      notifyFinished(S.sessions, m.sessions);
      S.sessions = m.sessions; renderHome();
      if (S.current) updateTermBar();
      break;
    case 'agents': S.agents = m.agents; break;
    case 'created':
      S.sessions = [...S.sessions.filter((s) => s.id !== m.session.id), m.session];
      closeSheets(); openTerm(m.session.id);
      if (pendingAfter) { afterExit.set(m.session.id, pendingAfter); pendingAfter = null; }
      break;
    case 'snapshot':
      if (m.id === S.current2 && S.term2) { S.term2.reset(); S.term2.write(m.data || ''); break; }
      if (m.id !== S.current || !S.term) break;
      S.term.reset(); S.term.write(m.data || '');
      setEnded(m.exited, m.exitCode);
      if (S.prefill) { send({ type: 'input', id: m.id, data: S.prefill }); S.prefill = null; }
      break;
    case 'data':
      if (m.id === S.current && S.term) S.term.write(m.data);
      else if (m.id === S.current2 && S.term2) S.term2.write(m.data);
      break;
    case 'exit':
      if (m.id === S.current) setEnded(true, m.code);
      if (afterExit.has(m.id)) { const f = afterExit.get(m.id); afterExit.delete(m.id); try { f(); } catch (_) { /* optional */ } }
      break;
    case 'error': toast(m.message || 'Something went wrong.'); break;
    default: break;
  }
}

// ---- sessions tab -------------------------------------------------------------

function renderHome() {
  const list = $('session-list');
  const sorted = [...S.sessions].sort((a, b) => b.startedAt - a.startedAt);
  const running = sorted.filter((s) => !s.exited).length;
  const finished = sorted.length - running;
  $('run-pill').textContent = running ? `${running} ${running === 1 ? 'session' : 'sessions'} running` : (sorted.length ? 'all finished' : 'no sessions yet');
  $('run-pill').dataset.live = running ? '1' : '0';
  $('btn-close-finished').hidden = finished === 0;
  $('empty').hidden = sorted.length > 0;
  list.hidden = sorted.length === 0;
  list.replaceChildren(...sorted.map((s) => {
    const a = S.agents.find((x) => x.id === s.agentId);
    return el('button', { class: 'sess', type: 'button', onclick: () => attach(s.id) },
      agentChip(s.agentId, { size: 'lg' }),
      el('span', { class: 'main' },
        el('strong', { text: s.name }),
        el('small', { text: s.title && !s.exited ? s.title : `${a ? a.name.toLowerCase() : 'terminal'} · ${shortPath(s.cwd)} · ${ago(s.startedAt)}` })),
      el('span', { class: 'status', 'data-state': s.exited ? (s.exitCode ? 'err' : 'done') : 'run', text: s.exited ? (s.exitCode ? (s.note || 'ended') : '✓ done') : 'running',
        title: !s.exited && s.persistent ? 'Keeps running even if the app is closed' : null }));
  }));
}

$('btn-close-finished').addEventListener('click', () => {
  for (const s of S.sessions.filter((x) => x.exited)) send({ type: 'close', id: s.id });
  S.sessions = S.sessions.filter((x) => !x.exited); renderHome();
});

// ---- starting a session -------------------------------------------------------

let pendingAfter = null;
function termDims() { return S.term ? { cols: S.term.cols, rows: S.term.rows } : { cols: 80, rows: 24 }; }

function createSession(req, after) {
  pendingAfter = after || null;
  if (!send({ type: 'create', ...req, ...termDims() })) { pendingAfter = null; toast('Not connected yet.'); }
}

// opts: { agentId, seed, name, cwd, open, afterExit } — with an agentId it starts at once; without, it asks.
hooks.newSession = (opts = {}) => {
  if (opts.agentId) {
    const a = S.agents.find((x) => x.id === opts.agentId);
    createSession({ kind: 'agent', agentId: opts.agentId, cwd: opts.cwd || S.root, name: opts.name, seed: opts.seed, resume: opts.resume || undefined, providerId: opts.providerId }, opts.afterExit);
    if (a && !a.installed) toast(a.name + ' is not installed here yet.');
    return;
  }
  agentPicker(opts);
};

// A shell that types one line for you and runs it (installs, removals).
hooks.runInTerminal = (name, line) => { S.prefill = line + '\r'; createSession({ kind: 'shell', name, cwd: S.home }); };

function agentPicker(opts = {}) {
  send({ type: 'agents' });
  const grid = el('div', { class: 'agent-grid' });
  grid.append(el('button', { class: 'agent-card', type: 'button', onclick: () => startSheet(null, opts) },
    agentChip(null, { size: 'xl' }), el('strong', { text: 'Terminal' }), el('small', { class: 'ready', text: 'a plain shell' })));
  for (const a of S.agents) {
    grid.append(el('button', { class: 'agent-card', type: 'button', onclick: () => (a.installed ? startSheet(a, opts) : installSheet(a)) },
      agentChip(a.id, { size: 'xl' }), el('strong', { text: a.name }),
      el('small', { class: a.installed ? 'ready' : 'setup', text: a.installed ? 'ready' : 'one-click setup' })));
  }
  openSheet('Who runs it?', grid, el('button', { class: 'linkish', type: 'button', text: 'Past chats', onclick: () => openHistory() }), opts.cwd ? el('p', { class: 'note', text: 'In ' + shortPath(opts.cwd) }) : null);
}
$('btn-new').addEventListener('click', () => hooks.newSession());
$('btn-new-empty').addEventListener('click', () => hooks.newSession());

async function startSheet(agent, opts) {
  const cwd = el('input', { type: 'text', value: shortPath(opts.cwd || S.root), autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false', 'aria-label': 'Folder' });
  const title = el('input', { type: 'text', placeholder: agent ? 'e.g. Cut the launch teaser' : 'Terminal', 'aria-label': 'What is the job' });
  let providerId = null;
  const provs = agent ? await providerChoices(agent.id) : [];
  const provRow = provs.length ? el('div', { class: 'field' }, el('span', { text: 'Provider' }),
    el('div', { class: 'chips', role: 'radiogroup', 'aria-label': 'Provider' },
      ...[{ id: null, name: 'Default login' }, ...provs].map((p) => el('button', {
        class: 'chip', type: 'button', role: 'radio', text: p.name, 'data-id': p.id || '', 'aria-checked': String(p.id === null),
        onclick: (e) => { providerId = p.id; for (const c of e.currentTarget.parentNode.children) c.setAttribute('aria-checked', String(c === e.currentTarget)); },
      })))) : null;
  let resume = false; let mode = 'terminal';
  const modeRow = agent && agent.chat && !opts.seed ? el('label', { class: 'field' },
    el('span', { text: 'How' }),
    el('div', { class: 'chips', role: 'radiogroup', 'aria-label': 'How' },
      ...[['Terminal', 'terminal'], ['Chat', 'chat']].map(([label, v]) => el('button', {
        class: 'chip', type: 'button', role: 'radio', text: label, 'aria-checked': String(v === 'terminal'),
        onclick: (e) => { mode = v; for (const c of e.currentTarget.parentNode.children) c.setAttribute('aria-checked', String(c === e.currentTarget)); },
      })))) : null;
  const resumeRow = agent && agent.canResume && !opts.seed ? el('label', { class: 'field' },
    el('span', { text: 'Conversation' }),
    el('div', { class: 'chips', role: 'radiogroup', 'aria-label': 'Conversation' },
      ...[['New', false], ['Continue last one here', true]].map(([label, v]) => el('button', {
        class: 'chip', type: 'button', role: 'radio', text: label, 'aria-checked': String(v === false),
        onclick: (e) => { resume = v; for (const c of e.currentTarget.parentNode.children) c.setAttribute('aria-checked', String(c === e.currentTarget)); },
      })))) : null;
  const go = () => {
    const folder = cwd.value.trim().replace(/^~(?=$|\/)/, S.home);
    if (agent && mode === 'chat') { startChat({ agent, cwd: folder, providerId: providerId || undefined }); closeSheets(); return; }
    createSession(agent
      ? { kind: 'agent', agentId: agent.id, cwd: folder, name: title.value.trim() || undefined, seed: opts.seed, resume: resume || undefined, providerId: providerId || undefined }
      : { kind: 'shell', cwd: folder, name: title.value.trim() || undefined },
    opts.afterExit);
  };
  openSheet(agent ? agent.name : 'Terminal',
    el('form', { class: 'stack', onsubmit: (e) => { e.preventDefault(); go(); } },
      agent ? el('label', { class: 'field' }, el('span', { text: 'The job' }), title) : null,
      el('label', { class: 'field' }, el('span', { text: 'Folder' }), cwd),
      modeRow,
      resumeRow,
      provRow,
      el('div', { class: 'row-end' },
        el('button', { class: 'btn btn-quiet', type: 'button', text: 'Back', onclick: () => agentPicker(opts) }),
        el('button', { class: 'btn btn-primary', type: 'submit', text: agent ? 'Start' : 'Open terminal' }))));
}

function installSheet(a) {
  const runnable = /^(curl|npm|pip|apk|apt)\b/.test(a.install || '');
  openSheet('Set up ' + a.name,
    el('p', { class: 'note-lg', text: runnable ? 'Nami opens a terminal and runs this for you:' : 'There is no one-line install for this one:' }),
    el('pre', { class: 'cmd', text: a.install || '' }),
    runnable ? el('p', { class: 'note', text: 'When it finishes, come back and start a session. You may need to sign in the first time you run the agent.' }) : null,
    el('div', { class: 'row-end' },
      el('button', { class: 'btn btn-quiet', type: 'button', text: 'Back', onclick: () => agentPicker({}) }),
      runnable ? el('button', { class: 'btn btn-primary', type: 'button', text: 'Install', onclick: () => {
        hooks.runInTerminal('Install ' + a.name, a.install);
      } }) : null));
}

// ---- terminal ----------------------------------------------------------------

let fitTimer = 0;
function fitSoon() {
  clearTimeout(fitTimer);
  fitTimer = setTimeout(() => { if (S.fit && !$('screen-term').hidden) { try { S.fit.fit(); } catch (_) { /* not laid out yet */ } } }, 60);
}

// Web addresses in terminal output are tappable: they open in the page preview
// (local ones) or the phone's browser.
function addLinks(term) {
  const re = /https?:\/\/[^\s<>"'`)\]]+/g;
  term.registerLinkProvider({
    provideLinks(y, cb) {
      const line = term.buffer.active.getLine(y - 1);
      if (!line) return cb(undefined);
      const text = line.translateToString(true);
      const out = [];
      for (const m of text.matchAll(re)) {
        const url = m[0].replace(/[.,;:!?]+$/, '');
        out.push({ text: url, range: { start: { x: m.index + 1, y }, end: { x: m.index + url.length, y } },
          activate: () => { if (/^https?:\/\/(localhost|127\.0\.0\.1)[:/]/.test(url)) openPreviewAt(url); else window.open(url, '_blank', 'noopener'); } });
      }
      cb(out.length ? out : undefined);
    },
  });
}

function ensureTerm() {
  if (S.term) return;
  const t = themeById(S.theme);
  const paper = getComputedStyle(document.body).getPropertyValue('--paper').trim();
  const term = new Terminal({
    fontFamily: "'Courier Prime', ui-monospace, monospace", fontSize: S.font, scrollback: 6000, cursorBlink: true,
    allowProposedApi: true, minimumContrastRatio: 4.5, theme: { ...t.xterm, background: paper, cursorAccent: paper },
  });
  const fit = new FitAddon();
  term.loadAddon(fit);
  term.open($('term-host'));
  S.term = term; S.fit = fit;
  addLinks(term);

  term.onData((d) => { if (!isTerminalReply(d)) typeInto(d); });
  // A keyboard opening or a rotation fires several resizes in a row; tell the
  // server once things settle (a tmux session redraws on each one it hears).
  let resizeTimer = 0;
  term.onResize(({ cols, rows }) => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => { if (S.current) send({ type: 'resize', id: S.current, cols, rows }); }, 250);
  });
  setupTouchScroll($('term-host'), 1);
  $('term-host').addEventListener('pointerdown', () => setFocus(1), true);
  new ResizeObserver(fitSoon).observe($('term-host'));
  window.addEventListener('resize', fitSoon);
}

// The first pane is the session you opened; an optional second pane (Split) sits below it.
// The key bar and message box type into whichever pane you touched last.
const sessionById = (id) => S.sessions.find((s) => s.id === id) || null;
const primarySession = () => sessionById(S.current);
const focusedId = () => (S.focus === 2 && S.current2 ? S.current2 : S.current);
function currentSession() { return sessionById(focusedId()); }
const focusedTerm = () => (S.focus === 2 && S.term2 ? S.term2 : S.term);

// ---- scrolling ---------------------------------------------------------------
// A session kept in tmux has its history in tmux, so the page asks the server to
// scroll it. Any other session scrolls xterm's own buffer.

function lineHeightPx(host = $('term-host')) {
  const rows = host.querySelector('.xterm-rows');
  return rows && rows.firstElementChild ? rows.firstElementChild.getBoundingClientRect().height || 16 : 16;
}

function scrollBy(lines) {
  const s = currentSession();
  if (!lines || !s) return;
  if (s.persistent) send({ type: 'scroll', id: s.id, lines });
  else focusedTerm().scrollLines(-lines);
}

function setupTouchScroll(host, paneNo) {
  let y = null; let carry = 0; let pending = 0; let timer = 0;
  const flush = () => { timer = 0; const n = pending; pending = 0; S.focus = paneNo; scrollBy(n); };
  host.addEventListener('touchstart', (e) => { y = e.touches.length === 1 ? e.touches[0].clientY : null; carry = 0; }, { passive: true, capture: true });
  host.addEventListener('touchmove', (e) => {
    if (y === null || e.touches.length !== 1) return;
    const now = e.touches[0].clientY;
    const r = scrollLines(now - y, lineHeightPx(host), carry);
    y = now; carry = r.carry;
    e.preventDefault(); e.stopPropagation();       // ours, not xterm's own (empty) scroll
    pending += r.lines;
    if (!timer) timer = setTimeout(flush, 70);       // many small moves, one message
  }, { passive: false, capture: true });
  host.addEventListener('touchend', () => { y = null; }, { passive: true, capture: true });
}

function typeInto(data) {
  const s = currentSession();
  if (!s || s.exited) return;
  if (S.ctrl) { data = ctrlify(data); setCtrl(false); }
  send({ type: 'input', id: s.id, data });
}

function openTerm(id) {
  S.current = id;
  show('term');
  ensureTerm();
  updateTermBar();
  S.term.reset();
  hooks.loadDraft && hooks.loadDraft();
  fitSoon();
  setTimeout(() => attach(id), 80);
}

function attach(id) {
  S.current = id;
  show('term');
  ensureTerm();
  updateTermBar();
  try { S.fit.fit(); } catch (_) { /* not laid out yet */ }
  send({ type: 'attach', id, ...termDims() });
}

function updateTermBar() {
  const s = primarySession();
  if (!s) return;
  $('term-title').textContent = s.name;
  $('term-sub').textContent = shortPath(s.cwd);
  $('term-chip').replaceChildren(agentChip(s.agentId, { size: 'md' }));
  setEnded(s.exited, s.exitCode);
}

function setEnded(ended, code) {
  $('term-ended').hidden = !ended;
  if (ended) $('term-ended-text').textContent = code ? 'Finished with an error (' + code + ')' : 'Finished';
  $('btn-stop').hidden = !!ended;
  $('compose').hidden = !!ended; $('keybar').hidden = !!ended;
}

function leaveTerm() {
  closeSplit();
  if (S.current) send({ type: 'detach' });
  S.current = null;
  show('main'); renderHome();
}

// ---- split: a second session below the first ----------------------------------

function setFocus(n) {
  S.focus = n;
  $('term-wrap').classList.toggle('focused', n === 1 && !!S.current2);
  $('term-wrap2').classList.toggle('focused', n === 2);
}

function ensureTerm2() {
  if (S.term2) return;
  const t = themeById(S.theme);
  const paper = getComputedStyle(document.body).getPropertyValue('--paper').trim();
  const term = new Terminal({
    fontFamily: "'Courier Prime', ui-monospace, monospace", fontSize: Math.max(10, S.font - 1), scrollback: 3000, cursorBlink: true,
    allowProposedApi: true, minimumContrastRatio: 4.5, theme: { ...t.xterm, background: paper, cursorAccent: paper },
  });
  const fit = new FitAddon();
  term.loadAddon(fit);
  term.open($('term-host2'));
  S.term2 = term; S.fit2 = fit;
  term.onData((d) => { if (isTerminalReply(d)) return; setFocus(2); typeInto(d); });
  let timer = 0;
  term.onResize(({ cols, rows }) => { clearTimeout(timer); timer = setTimeout(() => { if (S.current2) send({ type: 'resize', id: S.current2, cols, rows }); }, 250); });
  setupTouchScroll($('term-host2'), 2);
  $('term-host2').addEventListener('pointerdown', () => setFocus(2), true);
  new ResizeObserver(() => { try { if (S.current2) S.fit2.fit(); } catch (_) { /* not laid out */ } }).observe($('term-host2'));
}

function openSplit(id) {
  if (!id || id === S.current) return;
  closeSplit();
  S.current2 = id;
  $('term-wrap2').hidden = false;
  ensureTerm2();
  S.term2.reset();
  $('split-title').textContent = (sessionById(id) || {}).name || 'Session';
  setFocus(2);
  fitSoon();
  setTimeout(() => {
    try { S.fit2.fit(); } catch (_) { /* not laid out yet */ }
    send({ type: 'attach', id, extra: true, cols: S.term2.cols, rows: S.term2.rows });
    try { S.fit.fit(); } catch (_) { /* fine */ }
  }, 120);
}

function closeSplit() {
  if (!S.current2) return;
  send({ type: 'detach', id: S.current2 });
  S.current2 = null;
  $('term-wrap2').hidden = true;
  setFocus(1);
  $('term-wrap').classList.remove('focused');
  fitSoon();
}

$('btn-split').addEventListener('click', () => {
  if (S.current2) { closeSplit(); return; }
  const others = S.sessions.filter((s) => s.id !== S.current && !s.exited);
  if (!others.length) { toast('Start another session first, then split.'); return; }
  openSheet('Show beside this one',
    el('div', { class: 'menu' }, ...others.map((s) => el('button', { class: 'menu-item', type: 'button', onclick: () => { closeSheets(); openSplit(s.id); } },
      el('span', { text: s.name }), el('small', { text: shortPath(s.cwd) })))));
});
$('split-close').addEventListener('click', closeSplit);

async function closeCurrent() {
  const s = primarySession();
  if (!s) return;
  if (!s.exited && !(await confirmSheet({ title: 'Stop ' + s.name + '?', text: 'Anything it is doing will end.', ok: 'Stop', danger: true }))) return;
  send({ type: 'close', id: s.id });
  S.sessions = S.sessions.filter((x) => x.id !== s.id);
  leaveTerm();
}

// ---- key bar & message box -------------------------------------------------

function setCtrl(on) {
  S.ctrl = on;
  $('key-ctrl').setAttribute('aria-pressed', String(on));
}

$('keybar').addEventListener('pointerdown', (e) => e.preventDefault()); // keep the keyboard where it is
$('keybar').addEventListener('click', async (e) => {
  const b = e.target.closest('button[data-seq]');
  if (!b) return;
  const name = b.dataset.seq;
  if (name === 'ctrl') { setCtrl(!S.ctrl); return; }
  if (name === 'pgup' || name === 'pgdn') {
    const page = Math.max(3, (focusedTerm() ? focusedTerm().rows : 24) - 2);
    scrollBy(name === 'pgup' ? page : -page);
    return;
  }
  if (name === 'live') {
    const s = currentSession();
    if (s && s.persistent) send({ type: 'live', id: s.id }); else if (focusedTerm()) focusedTerm().scrollToBottom();
    return;
  }
  if (name === 'paste') {
    try {
      const text = window.NamiNative && window.NamiNative.paste ? window.NamiNative.paste() : await navigator.clipboard.readText();
      const d = pasteToInput(text, { bracketed: !!focusedTerm()?.modes.bracketedPasteMode });
      if (d) typeInto(d);
    } catch (_) { toast('The browser would not share the clipboard. Long-press the message box to paste.'); }
    return;
  }
  const seq = keySeq(name, { appCursor: !!focusedTerm()?.modes.applicationCursorKeysMode });
  if (seq) { setCtrl(false); typeInto(seq); }
});

const composeText = $('compose-text');
function autosize() {
  composeText.style.height = 'auto';
  composeText.style.height = Math.min(composeText.scrollHeight, 120) + 'px';
}
const draftKey = () => 'nami.draft.' + (S.current || '');
composeText.addEventListener('input', () => { autosize(); try { const k = draftKey(); composeText.value ? store.set(k, composeText.value) : store.del(k); } catch (_) { /* storage unavailable */ } });
hooks.loadDraft = () => { try { composeText.value = store.get(draftKey()) || ''; } catch (_) { composeText.value = ''; } autosize(); };
$('compose').addEventListener('submit', (e) => {
  e.preventDefault();
  const data = composeToInput(composeText.value, { bracketed: !!focusedTerm()?.modes.bracketedPasteMode });
  typeInto(data);
  composeText.value = ''; autosize();
  try { store.set(draftKey(), ''); } catch (_) { /* ignore */ }
});

// A picture goes to the agent as a file path (agents read images by path).
async function attachPicture(file) {
  if (!file) return;
  const isImage = file.type.startsWith('image/');
  toast(isImage ? 'Sending picture…' : 'Sending ' + (file.name || 'file') + '…');
  try {
    // A picture gets a fresh name; anything else keeps its own (the name tells the agent what it is).
    let up = file;
    if (isImage) {
      const ext = (file.type.split('/')[1] || 'png').replace(/[^a-z0-9]/gi, '').slice(0, 5) || 'png';
      up = new File([file], `picture-${Date.now()}.${ext}`, { type: file.type });
    } else if (!file.name) up = new File([file], `file-${Date.now()}`, { type: file.type });
    const r = await uploadOne(up, '', 'attach.put');
    if (r && r.path) { typeInto(r.path + ' '); toast(isImage ? 'Picture added to your message.' : 'File added to your message.'); }
  } catch (e) { toast(e.message); }
}
$('compose-attach').addEventListener('click', () => {
  const input = el('input', { type: 'file', multiple: true });
  input.addEventListener('change', async () => { for (const f of input.files) await attachPicture(f); });
  input.click();
});
composeText.addEventListener('paste', (e) => {
  const f = [...(e.clipboardData?.files || [])].find((x) => x.type.startsWith('image/'));
  if (f) { e.preventDefault(); attachPicture(f); }
});

// Speech to text: the phone's own recogniser (Android), or your own speech key (Settings → Voice).
const mic = $('compose-mic');
{
  const native = !!(window.NamiNative && window.NamiNative.listen);
  const canRecord = !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.MediaRecorder);
  let listening = false, base = '', rec = null;
  const mode = () => store.get('nami.voice') === 'cloud' && canRecord ? 'cloud' : 'device';
  const setMic = (on) => { listening = on; mic.setAttribute('aria-pressed', String(on)); mic.innerHTML = icon(on ? 'stop' : 'mic'); };
  const refresh = () => { mic.hidden = !(native || canRecord); };
  hooks.refreshMic = refresh; refresh();
  window.namiVoice = (kind, text) => {
    if (kind === 'ready') toast('Listening…');
    if (kind === 'partial' || kind === 'final') { composeText.value = (base ? base + ' ' : '') + text; autosize(); }
    if (kind === 'final') setMic(false);
    if (kind === 'error') { setMic(false); toast(text); }
  };
  async function cloudStart() {
    let stream;
    try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); } catch (_) { toast('The microphone is not allowed. Turn it on in Android settings → Apps → Nami.'); return; }
    const type = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/mp4'].find((t) => MediaRecorder.isTypeSupported(t)) || '';
    const chunks = [];
    const r = new MediaRecorder(stream, type ? { mimeType: type } : undefined);
    rec = { r, stream, timer: setTimeout(() => { if (r.state !== 'inactive') r.stop(); }, 60000) };
    r.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };
    r.onstop = async () => {
      clearTimeout(rec.timer); stream.getTracks().forEach((t) => t.stop()); rec = null; setMic(false);
      const blob = new Blob(chunks, { type: r.mimeType || 'audio/webm' });
      if (!blob.size) return;
      toast('Writing it down…');
      try {
        const buf = new Uint8Array(await blob.arrayBuffer());
        let bin = ''; for (let k = 0; k < buf.length; k += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(k, k + 0x8000));
        const out = await rpc('voice.transcribe', { b64: btoa(bin), mime: blob.type });
        if (out.text) { composeText.value = (base ? base + ' ' : '') + out.text; autosize(); composeText.focus(); } else toast('Did not catch that.');
      } catch (e) { toast(e.message); }
    };
    base = composeText.value.trim(); r.start(); setMic(true); toast('Listening… tap again to finish.');
  }
  mic.addEventListener('click', () => {
    if (mode() === 'cloud') { if (listening && rec) rec.r.stop(); else cloudStart(); return; }
    if (!native) { toast('Open Settings → Voice and add a speech key to use the microphone here.'); return; }
    if (listening) { window.NamiNative.stopListening(); setMic(false); return; }
    base = composeText.value.trim(); setMic(true); window.NamiNative.listen();
  });
}

// ---- buttons ---------------------------------------------------------------

$('btn-settings').addEventListener('click', () => openSettings());
$('btn-theme').addEventListener('click', () => {
  const i = THEMES.findIndex((t) => t.id === S.theme);
  applyTheme(THEMES[(i + 1) % THEMES.length].id);
  toast(themeById(S.theme).name + ' desk');
});
$('ws-pill').addEventListener('click', () => chooseFolder());
$('btn-add').addEventListener('click', () => addMenu());
$('btn-lib-new').addEventListener('click', () => newItemSheet());
$('btn-back').addEventListener('click', leaveTerm);
$('btn-stop').addEventListener('click', closeCurrent);
$('btn-dismiss').addEventListener('click', closeCurrent);
$('file-back').addEventListener('click', () => closeFile());
$('file-save').addEventListener('click', () => saveFile());
$('card-back').addEventListener('click', () => closeCard());
$('login-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const t = $('login-token').value.trim();
  if (!t) return;
  S.token = t; store.set('nami.token', t); $('login-token').value = ''; $('login-error').hidden = true;
  connect();
});
document.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === 's' && !$('screen-file').hidden) { e.preventDefault(); saveFile(); }
});

// The Android app asks this on its Back button: true means "handled here".
window.namiBack = () => {
  if (sheetOpen()) { closeSheets(); return true; }
  if (!$('screen-term').hidden) { leaveTerm(); return true; }
  if (!$('screen-file').hidden) { closeFile(); return true; }
  if (!$('screen-card').hidden) { closeCard(); return true; }
  if (!$('screen-preview').hidden) { closePreview(); return true; }
  if (chatOpen()) { $('chat-back').click(); return true; }
  if (!$('screen-main').hidden) {
    if (S.tab === 'work' && upDir()) return true;
    if (S.tab !== 'sessions') { showTab('sessions'); return true; }
  }
  return false;
};

// A session that ends while you are somewhere else (another app, another screen) tells you.
export function notifyFinished(before, after) {
  if (!window.NamiNative || !window.NamiNative.notify) return;
  const was = new Map(before.map((s) => [s.id, s.exited]));
  for (const s of after) {
    if (!s.exited || was.get(s.id) !== false) continue;           // only a running one that just ended
    if (!document.hidden && S.current === s.id) continue;         // you are looking at it
    try { window.NamiNative.notify(s.name, s.exitCode ? 'Ended with an error.' : 'Finished.'); } catch (_) { /* optional */ }
  }
}

// First time only: what to do, in four lines.
function welcome() {
  if (store.get('nami.welcome')) return;
  store.set('nami.welcome', '1');
  openSheet('Welcome to Nami',
    el('ol', { class: 'welcome' },
      el('li', { text: 'Tap + New session and pick an agent (Claude Code, Codex, OpenCode…).' }),
      el('li', { text: 'If it is not installed, tap Install. Nami types the line for you.' }),
      el('li', { text: 'Sign in the first time, or add your own key under Settings → Providers.' }),
      el('li', { text: 'Your files are in the Workspace tab. Sessions keep running when you close the app.' })),
    el('div', { class: 'row-end' }, el('button', { class: 'btn btn-quiet', type: 'button', text: 'Quick start', onclick: () => openQuickStart() }), el('button', { class: 'btn btn-primary', type: 'button', text: 'Got it', onclick: closeSheets })));
}
hooks.welcome = welcome;

paintIcons();

// ---- start -----------------------------------------------------------------

function start() {
  applyTheme(S.theme); applyFont(S.font);
  // The link the server prints carries the token once; keep it and take it out of the address bar.
  const fromUrl = new URL(location.href).searchParams.get('t');
  if (fromUrl) { store.set('nami.token', fromUrl); history.replaceState(null, '', location.pathname); }
  S.token = nativeToken() || store.get('nami.token');
  if (S.token) store.set('nami.token', S.token);
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => { /* optional */ });
  if (S.token) { show('main'); showTab('sessions'); connect(); } else show('login');
}
start();

// ---- terminal menu: copy, paste, select all, search the output ----
function searchTerm(term, q) {
  const buf = term.buffer.active, hits = [];
  for (let y = 0; y < buf.length; y++) { const l = buf.getLine(y); if (l && l.translateToString(true).toLowerCase().includes(q)) hits.push(y); }
  return hits;
}
$('btn-tmenu').addEventListener('click', () => {
  const term = focusedTerm();
  if (!term) return;
  const item = (label, fn) => el('button', { class: 'menu-item', type: 'button', text: label, onclick: async () => { closeSheets(); await fn(); } });
  openSheet('Terminal', el('div', { class: 'menu' },
    item('Copy selection', async () => {
      const t = term.getSelection();
      if (!t) { toast('Select some text first (long-press, then drag).'); return; }
      try { await navigator.clipboard.writeText(t); toast('Copied.'); } catch (_) { toast('Could not copy.'); }
    }),
    item('Copy all output', async () => { term.selectAll(); const t = term.getSelection(); term.clearSelection(); try { await navigator.clipboard.writeText(t); toast('Copied.'); } catch (_) { toast('Could not copy.'); } }),
    item('Paste', async () => {
      let t = '';
      try { t = await navigator.clipboard.readText(); } catch (_) { t = (window.NamiNative && NamiNative.paste && NamiNative.paste()) || ''; }
      if (t) typeInto(composeToInput(t, { bracketed: !!term.modes.bracketedPasteMode })); else toast('Nothing to paste.');
    }),
    item('Search the output', async () => {
      const q = (await askText({ title: 'Search', label: 'Find', ok: 'Find' }) || '').toLowerCase();
      if (!q) return;
      const hits = searchTerm(term, q);
      if (!hits.length) { toast('Not found.'); return; }
      term.scrollToLine(Math.max(0, hits[hits.length - 1] - 2));
      toast(`${hits.length} match${hits.length > 1 ? 'es' : ''} — showing the latest.`);
    }),
    item('Jump to the bottom', () => term.scrollToBottom())));
});
