// Which words in terminal output look like file or folder paths (no DOM, so it can be tested).
// A file or folder path in the output (./src/app.js, ~/notes/todo.md, /root/a/b.txt, lib/util.mjs:42): tap it to open it here.
const PATH_RE = /(?<![\w:/.@\-])((?:~|\.{1,2})?\/[\w.+@\-/]+|[\w.\-]+(?:\/[\w.+@\-]+)+)(?::\d+(?::\d+)?)?/g;
export function pathCandidates(text) {
  const out = [];
  for (const m of text.matchAll(PATH_RE)) {
    const p = m[1].replace(/[.,;:!?]+$/, '');
    if (p.length < 3 || p === '/' || /^\.{1,2}\/?$/.test(p)) continue;
    const base = p.split('/').pop();
    if (!/^(~|\.{1,2})?\//.test(p) && !/\./.test(base)) continue;          // a/b without an extension is too often just words
    out.push({ p, index: m.index, len: p.length });
  }
  return out;
}
