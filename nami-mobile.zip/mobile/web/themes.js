// The desk themes and their terminal palettes, carried over from the desktop
// app (XTERM_THEME_* in src/renderer/app.js). The terminal background is not
// listed: the page fills it from the active desk's sheet colour.

export const THEMES = [
  { id: 'paper', name: 'Paper', xterm: {
    foreground: '#2b2822', cursor: '#4a6b52', selectionBackground: 'rgba(201,169,78,0.38)',
    black: '#5a4b34', red: '#a8482f', green: '#4a7a4a', yellow: '#9a7420', blue: '#3f6088',
    magenta: '#8a5f8a', cyan: '#3f7d82', white: '#6f6553',
    brightBlack: '#8d8065', brightRed: '#b4503c', brightGreen: '#5f8f5f', brightYellow: '#a8792a',
    brightBlue: '#5a7fae', brightMagenta: '#a07aa0', brightCyan: '#5aa0a0', brightWhite: '#2f2b26' } },
  { id: 'operator', name: 'Operator', xterm: {
    foreground: '#ecebe7', cursor: '#ef6461', selectionBackground: 'rgba(239,100,97,0.28)',
    black: '#4f4f4f', red: '#ef6461', green: '#5aa06e', yellow: '#d8a03d', blue: '#6ea8ff',
    magenta: '#c792ea', cyan: '#5ac8c8', white: '#b8b5ae',
    brightBlack: '#8f8d86', brightRed: '#ff8b88', brightGreen: '#66c17e', brightYellow: '#e8b45a',
    brightBlue: '#8fbcff', brightMagenta: '#d7a9f0', brightCyan: '#7adcdc', brightWhite: '#f2f0ee' } },
  { id: 'glass', name: 'Glass', xterm: {
    foreground: '#34353d', cursor: '#ef6461', selectionBackground: 'rgba(239,100,97,0.22)',
    black: '#3c3d45', red: '#d6423e', green: '#2e7d4f', yellow: '#b07c10', blue: '#3763c9',
    magenta: '#a4499d', cyan: '#1f7f86', white: '#8b8c96',
    brightBlack: '#6a6b76', brightRed: '#e0524f', brightGreen: '#3f9b63', brightYellow: '#c98d1a',
    brightBlue: '#5b82d9', brightMagenta: '#bb64b3', brightCyan: '#2f989f', brightWhite: '#1d1d22' } },
  { id: 'graphite', name: 'Graphite', xterm: {
    foreground: '#dcdde6', cursor: '#ff8b88', selectionBackground: 'rgba(239,100,97,0.3)',
    black: '#4a4b55', red: '#ff6b67', green: '#5fca8b', yellow: '#e8b33e', blue: '#6f9dff',
    magenta: '#d580cc', cyan: '#4fc2cc', white: '#a7a8b3',
    brightBlack: '#7c7d88', brightRed: '#ffa19e', brightGreen: '#7fdca3', brightYellow: '#f2c766',
    brightBlue: '#93b5ff', brightMagenta: '#e3a1dc', brightCyan: '#78d8d8', brightWhite: '#f0f0f6' } },
  { id: 'soft', name: 'Soft', xterm: {
    foreground: '#2c2a33', cursor: '#ef6461', selectionBackground: 'rgba(239,100,97,0.22)',
    black: '#3c3d45', red: '#d6423e', green: '#3d7a4a', yellow: '#9a6c14', blue: '#3d6bb3',
    magenta: '#7a4a8a', cyan: '#1f7f86', white: '#8b8c96',
    brightBlack: '#6a6b76', brightRed: '#e0524f', brightGreen: '#4f9b5f', brightYellow: '#c98d1a',
    brightBlue: '#5b82d9', brightMagenta: '#9a64b3', brightCyan: '#2f989f', brightWhite: '#2c2a33' } },
  { id: 'dusk', name: 'Dusk', xterm: {
    foreground: '#e8eaee', cursor: '#ef6461', selectionBackground: 'rgba(239,100,97,0.3)',
    black: '#4a4b55', red: '#ff6b67', green: '#5fca8b', yellow: '#e8b33e', blue: '#6f9dff',
    magenta: '#d580cc', cyan: '#4fc2cc', white: '#a7a8b3',
    brightBlack: '#7c7d88', brightRed: '#ffa19e', brightGreen: '#7fdca3', brightYellow: '#f2c766',
    brightBlue: '#93b5ff', brightMagenta: '#e3a1dc', brightCyan: '#78d8d8', brightWhite: '#e8eaee' } },
];

export const DEFAULT_THEME = 'paper';

export function themeById(id) {
  return THEMES.find((t) => t.id === id) || THEMES.find((t) => t.id === DEFAULT_THEME);
}

export function clampFont(n, fallback = 14) {
  if (n === null || n === undefined || n === '') return fallback;
  const v = Math.round(Number(n));
  if (!Number.isFinite(v)) return fallback;
  return Math.min(20, Math.max(10, v));
}
