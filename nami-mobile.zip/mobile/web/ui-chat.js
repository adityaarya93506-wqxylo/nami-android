// Chat with an agent (ACP): messages, what the agent is doing, and permission buttons.
// Terminal sessions are still there; this is the same agent in a phone-friendly conversation.
// A chat lasts while the app is open (it is not kept in tmux like a terminal session).

import { $, el, S, hooks, send, toast, shortPath, openSheet, closeSheets, confirmSheet } from '/core.js';
import { createChatClient } from '/acp-client.js';
import { agentChip } from '/chips.js';
import { renderMarkdown } from '/lib/md.mjs';

const pending = new Map();      // ref -> { agent, cwd }
let chat = null;                // the open one: { id, agent, cwd, client, ... }

const TOOL_ICON = { read: '📄', edit: '✏️', delete: '🗑', move: '↔', search: '🔎', execute: '▶', think: '💭', fetch: '🌐', other: '•' };

export const chatOpen = () => !$('screen-chat').hidden;

export function startChat({ agent, cwd, providerId }) {
  const ref = Math.random().toString(36).slice(2);
  pending.set(ref, { agent, cwd });
  send({ type: 'chat.start', agentId: agent.id, cwd, providerId, ref });
  toast('Starting ' + agent.name + '…');
}

export function closeChat(stop = true) {
  if (chat && stop) { chat.client.cancel(); send({ type: 'chat.stop', id: chat.id }); }
  chat = null;
  hooks.showScreen('main');
}

// messages from the server
export function onChatMessage(m) {
  if (m.type === 'chat.failed') { pending.delete(m.ref); toast(m.message || 'Could not start the chat.'); return; }
  if (m.type === 'chat.started') {
    const p = pending.get(m.ref); if (!p) { send({ type: 'chat.stop', id: m.id }); return; }
    pending.delete(m.ref);
    openChat(m.id, p);
    return;
  }
  if (!chat || m.id !== chat.id) return;
  if (m.type === 'chat.line') chat.client.handleLine(m.line);
  if (m.type === 'chat.exit') {
    note(m.note ? `The agent stopped.\n${m.note}` : 'The agent stopped.', 'err');
    setBusy(false); chat.dead = true; $('chat-send').disabled = true;
  }
}

function openChat(id, { agent, cwd }) {
  const list = $('chat-list'); list.replaceChildren();
  chat = { id, agent, cwd, tools: new Map(), bubble: null, thought: null, text: '', dead: false, plan: null, stick: true };
  chat.client = createChatClient({ send: (line) => send({ type: 'chat.send', id, line }), onEvent: onEvent });
  $('chat-title').textContent = agent.name;
  $('chat-sub').textContent = shortPath(cwd);
  $('chat-chip').replaceChildren(agentChip(agent.id, { size: 'md' }));
  $('chat-send').disabled = true; $('chat-text').value = '';
  setBusy(false);
  hooks.showScreen('chat');
  note('Starting…', 'dim');
  chat.client.start(cwd);
}

function scrollDown() { const l = $('chat-list'); if (chat && chat.stick) l.scrollTop = l.scrollHeight; }
$('chat-list').addEventListener('scroll', () => { const l = $('chat-list'); if (chat) chat.stick = l.scrollHeight - l.scrollTop - l.clientHeight < 80; });

function note(text, kind = '') {
  $('chat-list').append(el('p', { class: 'chat-note ' + kind, text }));
  scrollDown();
}

function safeMarkdown(text) {
  const box = el('div', { class: 'md-read chat-md' });
  box.innerHTML = renderMarkdown(text, { resolveImage: () => null });   // the agent's words are untrusted: no images, only plain web links
  for (const a of box.querySelectorAll('a')) {
    const href = a.getAttribute('href') || '';
    if (/^https?:/i.test(href)) { a.setAttribute('target', '_blank'); a.setAttribute('rel', 'noopener noreferrer'); } else a.removeAttribute('href');
  }
  return box;
}

let renderTimer = 0;
function flushPaint() {
  clearTimeout(renderTimer); renderTimer = 0;
  if (!chat || !chat.bubble) return;
  chat.bubble.replaceChildren(...safeMarkdown(chat.text).childNodes);
  scrollDown();
}
function paintAgentText() {                  // many small chunks, one repaint
  if (!renderTimer) renderTimer = setTimeout(flushPaint, 80);
}

function setBusy(on) {
  const b = $('chat-send');
  b.textContent = on ? 'Stop' : 'Send';
  b.classList.toggle('btn-danger', on); b.classList.toggle('btn-primary', !on);
  b.dataset.busy = on ? '1' : '';
  if (!on) b.disabled = !chat || !chat.client.ready || chat.dead;
  else b.disabled = false;
}

function onEvent(e) {
  if (!chat) return;
  switch (e.t) {
    case 'ready': $('chat-list').lastElementChild?.remove(); note('Ready. Ask for something.', 'dim'); setBusy(false); break;
    case 'busy': setBusy(e.on); break;
    case 'text':
      if (!chat.bubble) { chat.bubble = el('div', { class: 'msg msg-agent' }); chat.text = ''; $('chat-list').append(chat.bubble); }
      chat.text += e.text; paintAgentText(); break;
    case 'thought':
      if (!chat.thought) { chat.thought = el('details', { class: 'thought' }, el('summary', { text: 'Thinking…' }), el('p', { class: 'thought-text' })); $('chat-list').append(chat.thought); }
      chat.thought.querySelector('.thought-text').textContent += e.text; scrollDown(); break;
    case 'tool': {
      flushPaint(); chat.bubble = null; chat.thought = null;
      const row = el('div', { class: 'tool', 'data-status': e.status }, el('span', { class: 'tool-ico', text: TOOL_ICON[e.kind] || TOOL_ICON.other }), el('span', { class: 'tool-title', text: e.title }), el('span', { class: 'tool-st', text: stateWord(e.status) }));
      chat.tools.set(e.id, row); $('chat-list').append(row); scrollDown(); break;
    }
    case 'toolUpdate': {
      const row = chat.tools.get(e.id); if (!row) break;
      if (e.status) { row.dataset.status = e.status; row.querySelector('.tool-st').textContent = stateWord(e.status); }
      if (e.title) row.querySelector('.tool-title').textContent = e.title;
      break;
    }
    case 'plan': {
      if (!chat.plan) { chat.plan = el('div', { class: 'plan' }); $('chat-list').append(chat.plan); }
      chat.plan.replaceChildren(el('strong', { text: 'Plan' }), ...e.entries.map((p) => el('div', { class: 'plan-row', 'data-status': p.status, text: (p.status === 'completed' || p.status === 'done' ? '☑ ' : '☐ ') + p.text })));
      scrollDown(); break;
    }
    case 'permission': {
      flushPaint(); chat.bubble = null;
      const card = el('div', { class: 'ask' }, el('p', { text: e.title }),
        el('div', { class: 'row-end' }, ...e.options.map((o) => el('button', {
          class: 'btn btn-small ' + (/allow/.test(o.kind) ? 'btn-primary' : 'btn-quiet'), type: 'button', text: o.name,
          onclick: () => { chat.client.answer(e.reqId, o.id); card.replaceChildren(el('p', { class: 'dim', text: `${e.title} → ${o.name}` })); },
        }))));
      $('chat-list').append(card); scrollDown(); break;
    }
    case 'done': flushPaint(); chat.bubble = null; chat.thought = null; chat.plan = null; if (e.stopReason === 'cancelled') note('Stopped.', 'dim'); break;
    case 'error': flushPaint(); chat.bubble = null; note(e.message, 'err'); break;
    default: break;
  }
}
const stateWord = (s) => ({ pending: 'waiting', in_progress: 'working…', completed: 'done', failed: 'failed' }[s] || s || '');

// ---- the message box ----

$('chat-form').addEventListener('submit', (e) => {
  e.preventDefault();
  if (!chat) return;
  if ($('chat-send').dataset.busy) { chat.client.cancel(); return; }
  const text = $('chat-text').value.trim();
  if (!text || !chat.client.ready) return;
  $('chat-text').value = ''; $('chat-text').style.height = 'auto';
  chat.stick = true; flushPaint(); chat.bubble = null; chat.thought = null; chat.plan = null;
  $('chat-list').append(el('div', { class: 'msg msg-user', text }));
  scrollDown();
  chat.client.prompt(text);
});
$('chat-text').addEventListener('input', () => { const t = $('chat-text'); t.style.height = 'auto'; t.style.height = Math.min(t.scrollHeight, 120) + 'px'; });
$('chat-back').addEventListener('click', async () => {
  if (chat && !chat.dead && chat.client.busy && !(await confirmSheet({ title: 'Leave this chat?', text: 'The agent is still working. Leaving ends the chat.', ok: 'Leave', danger: true }))) return;
  closeChat();
});
