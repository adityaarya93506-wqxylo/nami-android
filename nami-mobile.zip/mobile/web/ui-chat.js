// Chat with an agent (ACP): messages, what the agent is doing, and permission buttons.
// Terminal sessions are still there; this is the same agent in a phone-friendly conversation.
// A chat lasts while the app is open (it is not kept in tmux like a terminal session).

import { $, el, S, hooks, send, rpc, toast, store, ago, bytes, shortPath, openSheet, closeSheets, confirmSheet, askText } from '/core.js';
import { createChatClient } from '/acp-client.js';
import { agentChip } from '/chips.js';
import { renderMarkdown } from '/lib/md.mjs';
import { uploadOne } from '/ui-files.js';

const pending = new Map();      // ref -> { agent, cwd }
let chat = null;                // the open one: { id, agent, cwd, client, ... }

// ---- past chats, kept on the phone (the page's own storage) ----
const HIST_KEY = 'nami.chats';
const loadHist = () => { try { const v = JSON.parse(store.get(HIST_KEY) || '[]'); return Array.isArray(v) ? v : []; } catch (_) { return []; } };
function saveHist(entry) {
  let all = loadHist().filter((c) => c.id !== entry.id);
  all.unshift(entry); all = all.slice(0, 30);
  for (let n = all.length; n > 0; n--) { try { store.set(HIST_KEY, JSON.stringify(all.slice(0, n))); if (store.get(HIST_KEY)) break; } catch (_) { /* too big: keep fewer */ } }
}
function remember(role, text) {
  if (!chat || !text) return;
  chat.msgs.push({ r: role, t: String(text).slice(0, 4000) });
  if (chat.msgs.length > 200) chat.msgs.shift();
  saveHist({ id: chat.id, title: chat.title, agentId: chat.agent.id, cwd: chat.cwd, at: Date.now(), msgs: chat.msgs });
}

const TOOL_ICON = { read: '📄', edit: '✏️', delete: '🗑', move: '↔', search: '🔎', execute: '▶', think: '💭', fetch: '🌐', other: '•' };

export const chatOpen = () => !$('screen-chat').hidden;

export function startChat({ agent, cwd, providerId }) {
  const ref = Math.random().toString(36).slice(2);
  pending.set(ref, { agent, cwd });
  send({ type: 'chat.start', agentId: agent.id, cwd, providerId, ref });
  toast('Starting ' + agent.name + '…');
}

export function closeChat(stop = true) {
  if (chat && stop) { chat.client.cancel(); send({ type: 'chat.stop', id: chat.id }); }
  chat = null;
  hooks.showScreen('main');
}

// messages from the server
export function onChatMessage(m) {
  if (m.type === 'chat.failed') { pending.delete(m.ref); toast(m.message || 'Could not start the chat.'); return; }
  if (m.type === 'chat.started') {
    const p = pending.get(m.ref); if (!p) { send({ type: 'chat.stop', id: m.id }); return; }
    pending.delete(m.ref);
    openChat(m.id, p);
    return;
  }
  if (!chat || m.id !== chat.id) return;
  if (m.type === 'chat.line') chat.client.handleLine(m.line);
  if (m.type === 'chat.exit') {
    note(m.note ? `The agent stopped.\n${m.note}` : 'The agent stopped.', 'err');
    setBusy(false); chat.dead = true; $('chat-send').disabled = true;
  }
}

function openChat(id, { agent, cwd }) {
  const list = $('chat-list'); list.replaceChildren();
  chat = { id, agent, cwd, tools: new Map(), bubble: null, thought: null, text: '', dead: false, plan: null, stick: true, title: agent.name, msgs: [], images: [], files: [], commands: [] };
  renderPending(); hideCmds();
  chat.client = createChatClient({ send: (line) => send({ type: 'chat.send', id, line }), onEvent: onEvent });
  $('chat-title').textContent = agent.name;
  $('chat-sub').textContent = shortPath(cwd);
  $('chat-chip').replaceChildren(agentChip(agent.id, { size: 'md' }));
  $('chat-send').disabled = true; $('chat-text').value = '';
  setBusy(false);
  hooks.showScreen('chat');
  note('Starting…', 'dim');
  chat.client.start(cwd);
}

function scrollDown() { const l = $('chat-list'); if (chat && chat.stick) l.scrollTop = l.scrollHeight; }
$('chat-list').addEventListener('scroll', () => { const l = $('chat-list'); if (chat) chat.stick = l.scrollHeight - l.scrollTop - l.clientHeight < 80; });

function note(text, kind = '') {
  $('chat-list').append(el('p', { class: 'chat-note ' + kind, text }));
  scrollDown();
}

function safeMarkdown(text) {
  const box = el('div', { class: 'md-read chat-md' });
  box.innerHTML = renderMarkdown(text, { resolveImage: () => null });   // the agent's words are untrusted: no images, only plain web links
  for (const a of box.querySelectorAll('a')) {
    const href = a.getAttribute('href') || '';
    if (/^https?:/i.test(href)) { a.setAttribute('target', '_blank'); a.setAttribute('rel', 'noopener noreferrer'); } else a.removeAttribute('href');
  }
  return box;
}

let renderTimer = 0;
function flushPaint() {
  clearTimeout(renderTimer); renderTimer = 0;
  if (!chat || !chat.bubble) return;
  if (chat.text !== chat.painted) { chat.painted = chat.text; chat.bubble.replaceChildren(...safeMarkdown(chat.text).childNodes); }
  scrollDown();
}
function paintAgentText() {                  // many small chunks, one repaint
  if (!renderTimer) renderTimer = setTimeout(flushPaint, 80);
}

function setBusy(on) {
  const b = $('chat-send');
  b.textContent = on ? 'Stop' : 'Send';
  b.classList.toggle('btn-danger', on); b.classList.toggle('btn-primary', !on);
  b.dataset.busy = on ? '1' : '';
  if (!on) b.disabled = !chat || !chat.client.ready || chat.dead;
  else b.disabled = false;
}

function closeBubble() {
  flushPaint();
  if (chat.bubble && chat.text) remember('a', chat.text);
  chat.bubble = null; chat.text = ''; chat.painted = '';
}

function onEvent(e) {
  if (!chat) return;
  switch (e.t) {
    case 'commands': chat.commands = e.list; break;
    case 'ready': $('chat-list').lastElementChild?.remove(); note('Ready. Ask for something.', 'dim'); setBusy(false); break;
    case 'busy': setBusy(e.on); break;
    case 'text':
      if (!chat.bubble) { chat.bubble = el('div', { class: 'msg msg-agent' }); chat.text = ''; $('chat-list').append(chat.bubble); }
      chat.text += e.text; paintAgentText(); break;
    case 'thought':
      if (!chat.thought) { chat.thought = el('details', { class: 'thought' }, el('summary', { text: 'Thinking…' }), el('p', { class: 'thought-text' })); $('chat-list').append(chat.thought); }
      chat.thought.querySelector('.thought-text').textContent += e.text; scrollDown(); break;
    case 'tool': {
      closeBubble(); chat.thought = null; remember('t', e.title);
      const row = el('div', { class: 'tool', 'data-status': e.status }, el('span', { class: 'tool-ico', text: TOOL_ICON[e.kind] || TOOL_ICON.other }), el('span', { class: 'tool-title', text: e.title }), el('span', { class: 'tool-st', text: stateWord(e.status) }));
      chat.tools.set(e.id, row); $('chat-list').append(row); scrollDown(); break;
    }
    case 'toolUpdate': {
      const row = chat.tools.get(e.id); if (!row) break;
      if (e.status) { row.dataset.status = e.status; row.querySelector('.tool-st').textContent = stateWord(e.status); }
      if (e.title) row.querySelector('.tool-title').textContent = e.title;
      break;
    }
    case 'plan': {
      if (!chat.plan) { chat.plan = el('div', { class: 'plan' }); $('chat-list').append(chat.plan); }
      chat.plan.replaceChildren(el('strong', { text: 'Plan' }), ...e.entries.map((p) => el('div', { class: 'plan-row', 'data-status': p.status, text: (p.status === 'completed' || p.status === 'done' ? '☑ ' : '☐ ') + p.text })));
      scrollDown(); break;
    }
    case 'permission': {
      closeBubble();
      const card = el('div', { class: 'ask' }, el('p', { text: e.title }),
        el('div', { class: 'row-end' }, ...e.options.map((o) => el('button', {
          class: 'btn btn-small ' + (/allow/.test(o.kind) ? 'btn-primary' : 'btn-quiet'), type: 'button', text: o.name,
          onclick: () => { chat.client.answer(e.reqId, o.id); card.replaceChildren(el('p', { class: 'dim', text: `${e.title} → ${o.name}` })); },
        }))));
      $('chat-list').append(card); scrollDown(); break;
    }
    case 'done': closeBubble(); chat.thought = null; chat.plan = null; if (e.stopReason === 'cancelled') note('Stopped.', 'dim'); break;
    case 'error': closeBubble(); note(e.message, 'err'); break;
    default: break;
  }
}
const stateWord = (s) => ({ pending: 'waiting', in_progress: 'working…', completed: 'done', failed: 'failed' }[s] || s || '');

// ---- the message box ----

$('chat-form').addEventListener('submit', (e) => {
  e.preventDefault();
  if (!chat) return;
  if ($('chat-send').dataset.busy) { chat.client.cancel(); return; }
  let text = $('chat-text').value.trim();
  if ((!text && !chat.images.length && !chat.files.length) || !chat.client.ready) return;
  if (!text) text = chat.images.length && !chat.files.length ? 'What is in this picture?' : 'Please look at what I attached.';
  hideCmds();
  const imgs = chat.images, docs = chat.files; chat.images = []; chat.files = []; renderPending();
  $('chat-text').value = ''; $('chat-text').style.height = 'auto';
  chat.stick = true; closeBubble(); chat.thought = null; chat.plan = null;
  const bubble = el('div', { class: 'msg msg-user' }, ...imgs.map((i) => el('img', { class: 'msg-img', src: i.url, alt: '' })), ...docs.map((d) => el('div', { class: 'msg-file', text: '📄 ' + d.name })), el('span', { text }));
  $('chat-list').append(bubble);
  remember('u', text + (imgs.length ? `  [${imgs.length} picture${imgs.length > 1 ? 's' : ''}]` : '') + (docs.length ? `  [${docs.map((d) => d.name).join(', ')}]` : ''));
  scrollDown();
  sendPrompt(text, imgs, docs);
});
$('chat-text').addEventListener('input', () => { const t = $('chat-text'); t.style.height = 'auto'; t.style.height = Math.min(t.scrollHeight, 120) + 'px'; });
$('chat-back').addEventListener('click', async () => {
  if (chat && !chat.dead && chat.client.busy && !(await confirmSheet({ title: 'Leave this chat?', text: 'The agent is still working. Leaving ends the chat.', ok: 'Leave', danger: true }))) return;
  closeChat();
});

// ---- pictures: sent inside the message if the agent takes them, otherwise as a file path in the text ----

async function sendPrompt(text, imgs, docs = []) {
  const inline = chat.client.canSendImages ? imgs.map((i) => ({ data: i.b64, mimeType: i.mime })) : [];
  let extra = '';
  if (!inline.length && imgs.length) {
    try { extra = '\n' + (await Promise.all(imgs.map(async (i) => (await uploadOne(i.file, '', 'attach.put')).path))).join('\n'); } catch (e) { toast(e.message); }
  }
  if (docs.length) {
    try {
      const paths = await Promise.all(docs.map(async (d) => (await uploadOne(d.file, '', 'attach.put')).path));
      extra += '\nFiles I attached (on this phone):\n' + paths.join('\n');
    } catch (e) { toast(e.message); }
  }
  chat.client.prompt(text + extra, inline);
}

function renderPending() {
  const box = $('chat-pending');
  box.hidden = !chat || !(chat.images.length || chat.files.length);
  if (!chat) { box.replaceChildren(); return; }
  box.replaceChildren(
    ...chat.images.map((i, n) => el('span', { class: 'thumb' }, el('img', { src: i.url, alt: '' }),
      el('button', { type: 'button', 'aria-label': 'Remove', text: '✕', onclick: () => { URL.revokeObjectURL(i.url); chat.images.splice(n, 1); renderPending(); } }))),
    ...chat.files.map((d, n) => el('span', { class: 'filechip' }, el('span', { text: '📄 ' + d.name }), el('small', { text: bytes(d.size) }),
      el('button', { type: 'button', 'aria-label': 'Remove', text: '✕', onclick: () => { chat.files.splice(n, 1); renderPending(); } }))));
}

const MAX_FILE = 200 * 1024 * 1024;
async function addAttachment(file) {
  if (!chat || !file) return;
  if (file.type.startsWith('image/')) return addPicture(file);
  if (file.size > MAX_FILE) { toast('That file is too large (limit 200 MB).'); return; }
  chat.files.push({ name: file.name || 'file', size: file.size, file });
  renderPending();
}

async function addPicture(file) {
  if (!chat || !file || !file.type.startsWith('image/')) { toast('Only pictures can be attached.'); return; }
  if (file.size > 12 * 1024 * 1024) { toast('That picture is too large (limit 12 MB).'); return; }
  const buf = new Uint8Array(await file.arrayBuffer());
  let bin = ''; for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  const ext = (file.type.split('/')[1] || 'png').replace(/[^a-z0-9]/gi, '').slice(0, 5) || 'png';
  chat.images.push({ url: URL.createObjectURL(file), b64: btoa(bin), mime: file.type, file: new File([file], `chat-${Date.now()}-${chat.images.length}.${ext}`, { type: file.type }) });
  renderPending();
}
$('chat-attach').addEventListener('click', () => {
  const input = el('input', { type: 'file', multiple: true });      // any kind: pictures, PDFs, music, video, zips…
  input.addEventListener('change', () => { for (const f of input.files) addAttachment(f); });
  input.click();
});
$('chat-text').addEventListener('paste', (e) => { const fs = [...(e.clipboardData?.files || [])]; if (fs.length) { e.preventDefault(); fs.forEach(addAttachment); } });

// ---- slash commands the agent offers ----

function hideCmds() { $('chat-cmds').hidden = true; $('chat-cmds').replaceChildren(); }
$('chat-text').addEventListener('input', () => {
  if (!chat) return;
  const v = $('chat-text').value;
  const m = /^\/([\w:.-]*)$/.exec(v);
  const list = m ? chat.commands.filter((c) => c.name.startsWith(m[1])).slice(0, 8) : [];
  const box = $('chat-cmds');
  box.hidden = !list.length;
  box.replaceChildren(...list.map((c) => el('button', { class: 'cmd-item', type: 'button', onclick: () => { $('chat-text').value = '/' + c.name + ' '; $('chat-text').focus(); hideCmds(); } },
    el('strong', { text: '/' + c.name }), el('small', { text: c.hint || c.description }))));
});

// ---- the ⋯ menu: rename, continue in a terminal, past chats ----

$('chat-more').addEventListener('click', () => {
  if (!chat) return;
  const item = (label, fn) => el('button', { class: 'menu-item', type: 'button', text: label, onclick: async () => { closeSheets(); await fn(); } });
  openSheet(chat.title, el('div', { class: 'menu' },
    item('Rename this chat', async () => {
      const name = await askText({ title: 'Rename', label: 'Name', value: chat.title, ok: 'Rename' });
      if (!name) return;
      chat.title = name.slice(0, 60); $('chat-title').textContent = chat.title;
      saveHist({ id: chat.id, title: chat.title, agentId: chat.agent.id, cwd: chat.cwd, at: Date.now(), msgs: chat.msgs });
    }),
    item('Continue in a terminal', async () => {
      const { agent, cwd, title } = chat;
      closeChat();
      hooks.newSession({ agentId: agent.id, cwd, name: title, resume: true });
    }),
    item('Past chats', () => openHistory())));
});

export function openHistory() {
  const all = loadHist();
  const list = el('div', { class: 'menu' }, ...(all.length ? all.map((c) => el('button', { class: 'menu-item', type: 'button', onclick: () => viewHistory(c) },
    el('span', { text: c.title }), el('small', { text: `${ago(c.at)} · ${shortPath(c.cwd)}` }))) : [el('p', { class: 'note', text: 'No past chats yet. They are kept on this phone.' })]));
  openSheet('Past chats', list);
}

function viewHistory(c) {
  const rows = c.msgs.map((m) => (m.r === 't' ? el('div', { class: 'tool' }, el('span', { class: 'tool-title', text: m.t })) : el('div', { class: 'msg ' + (m.r === 'u' ? 'msg-user' : 'msg-agent') }, m.r === 'a' ? safeMarkdown(m.t) : el('span', { text: m.t }))));
  const a = S.agents.find((x) => x.id === c.agentId);
  openSheet(c.title, el('div', { class: 'chat-list hist' }, ...rows),
    el('div', { class: 'row-end' },
      el('button', { class: 'btn btn-danger btn-small', type: 'button', text: 'Delete', onclick: () => { store.set(HIST_KEY, JSON.stringify(loadHist().filter((x) => x.id !== c.id))); closeSheets(); toast('Deleted.'); } }),
      a ? el('button', { class: 'btn btn-primary btn-small', type: 'button', text: 'Continue in a terminal', onclick: () => { closeSheets(); hooks.newSession({ agentId: a.id, cwd: c.cwd, name: c.title, resume: true }); } }) : null));
}
