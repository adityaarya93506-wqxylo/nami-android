// Workspace: browse the chosen folder, open, edit and save files, bring files in
// from the phone, send them out. Markdown opens as a page you can read; everything
// else text-like opens in an editor. Nothing outside the workspace folder is reachable.
import { $, el, S, hooks, rpc, toast, rawUrl, bytes, shortPath, baseName, dirOf, openSheet, closeSheets, askText, confirmSheet, store } from '/core.js';
import { fileIcon } from '/chips.js';
import { renderMarkdown } from '/lib/md.mjs';
import { highlightCode, knownLang } from '/lib/md-code.mjs';

const F = {
  dir: '', parent: null, entries: [], hidden: store.get('nami.hidden') === '1', loading: false,
  file: null,       // the open file: { path, name, kind, text, mtime, dirty, mode }
};

const join = (a, b) => (a.endsWith('/') ? a : a + '/') + b;

function normalize(p) {
  const out = [];
  for (const part of p.split('/')) {
    if (!part || part === '.') continue;
    if (part === '..') out.pop(); else out.push(part);
  }
  return '/' + out.join('/');
}

// ---- the folder list ---------------------------------------------------------

export function updateWorkspacePill() {
  $('ws-name').textContent = baseName(S.root) || '/';
}

export async function loadDir(p) {
  F.loading = true;
  try {
    const r = await rpc('fs.ls', { path: p || S.root });
    F.dir = r.path; F.parent = r.parent; F.entries = r.entries;
    if (r.truncated) toast('Only the first 3000 items are shown.');
  } catch (e) {
    toast(e.message);
    if (p && p !== S.root) { F.loading = false; return loadDir(S.root); }
    F.entries = [];
  }
  F.loading = false;
  renderDir();
}

// Back button inside the workspace: go up one folder. False when already at the top.
export function upDir() {
  if (!F.dir || F.dir === S.root || !F.parent) return false;
  loadDir(F.parent);
  return true;
}

// While the Workspace tab is on screen, notice files that appear or change
// (an agent just wrote one) without a pull-to-refresh.
let watchTimer = 0;
export function watchWorkspace(on) {
  clearInterval(watchTimer); watchTimer = 0;
  if (!on) return;
  watchTimer = setInterval(async () => {
    if (document.hidden || S.tab !== 'work' || !S.ready || F.loading || !F.dir) return;
    if (!$('screen-file').hidden || !$('sheet').hidden) return;
    try {
      const r = await rpc('fs.ls', { path: F.dir });
      const sig = (list) => list.map((e) => `${e.name}|${e.size}|${e.mtime}`).join('\n');
      if (r.path === F.dir && sig(r.entries) !== sig(F.entries)) { F.entries = r.entries; F.parent = r.parent; renderDir(); }
    } catch (_) { /* next tick */ }
  }, 5000);
}

export function showWorkspace() {
  if (!F.dir || !F.dir.startsWith(S.root)) loadDir(S.root); else loadDir(F.dir);
}

function crumbs() {
  const rootName = baseName(S.root) || '/';
  const rel = F.dir.slice(S.root.length).split('/').filter(Boolean);
  const parts = [{ label: rootName, path: S.root }];
  let cur = S.root;
  for (const seg of rel) { cur = join(cur, seg); parts.push({ label: seg, path: cur }); }
  const out = [];
  parts.forEach((c, i) => {
    if (i) out.push(el('span', { class: 'crumb-sep', text: '/' }));
    out.push(el('button', { class: 'crumb', type: 'button', text: c.label, 'aria-current': i === parts.length - 1 ? 'page' : null, onclick: () => loadDir(c.path) }));
  });
  return out;
}

function renderDir() {
  const bar = $('work-crumbs');
  bar.replaceChildren(...crumbs());
  bar.scrollLeft = bar.scrollWidth;
  const list = $('work-list');
  const shown = F.entries.filter((e) => F.hidden || !e.name.startsWith('.'));
  $('work-empty').hidden = shown.length > 0;
  $('work-empty').textContent = F.entries.length && !shown.length ? 'Only hidden items here. Turn on "Show hidden" in the ＋ menu.' : 'This folder is empty.';
  list.replaceChildren(...shown.map((e) => {
    const sub = e.type === 'dir' ? 'folder' : bytes(e.size);
    return el('div', { class: 'row', role: 'listitem' },
      el('button', { class: 'row-main', type: 'button', onclick: () => (e.type === 'dir' ? loadDir(join(F.dir, e.name)) : openFile(join(F.dir, e.name))) },
        fileIcon(e.name, e.type),
        el('span', { class: 'main' }, el('strong', { text: e.name }), el('small', { text: sub + (e.link ? ' · link' : '') }))),
      el('button', { class: 'icon-btn row-more', type: 'button', 'aria-label': 'Actions for ' + e.name, text: '⋯', onclick: () => entryMenu(e) }));
  }));
}

function menuItem(label, fn, { danger = false } = {}) {
  return el('button', { class: 'menu-item' + (danger ? ' danger' : ''), type: 'button', text: label, onclick: () => { closeSheets(); fn(); } });
}

function entryMenu(e) {
  const full = join(F.dir, e.name);
  const items = [];
  if (e.type === 'file') items.push(menuItem('Open', () => openFile(full)), menuItem('Download to phone', () => download(full, e.name)));
  else items.push(menuItem('Open folder', () => loadDir(full)), menuItem('Run an agent here', () => hooks.newSession && hooks.newSession({ cwd: full })));
  items.push(
    menuItem('Rename', async () => {
      const name = await askText({ title: 'Rename', label: 'New name', value: e.name, ok: 'Rename' });
      if (!name || name === e.name) return;
      try { await rpc('fs.rename', { path: full, name }); loadDir(F.dir); } catch (err) { toast(err.message); }
    }),
    menuItem('Duplicate', async () => {
      try { await rpc('fs.copy', { path: full }); toast('Copied.'); loadDir(F.dir); } catch (err) { toast(err.message); }
    }),
    menuItem('Move to…', () => moveTo(full, e.name)),
    menuItem('Copy path', () => { try { navigator.clipboard.writeText(full); toast('Path copied.'); } catch (_) { toast(full); } }),
    menuItem('Delete', async () => {
      const ok = await confirmSheet({ title: 'Delete ' + e.name + '?', text: e.type === 'dir' ? 'The folder and everything in it will be deleted. This cannot be undone.' : 'This cannot be undone.', ok: 'Delete', danger: true });
      if (!ok) return;
      try { await rpc('fs.rm', { path: full }); loadDir(F.dir); } catch (err) { toast(err.message); }
    }, { danger: true }));
  openSheet(e.name, el('div', { class: 'menu' }, ...items));
}

// A small folder browser: walk to where it should go, then "Move here".
function moveTo(full, name) {
  const show = async (dir) => {
    let r;
    try { r = await rpc('fs.ls', { path: dir }); } catch (err) { toast(err.message); return; }
    const list = el('div', { class: 'menu' });
    if (r.parent) list.append(el('button', { class: 'menu-item', type: 'button', text: '↑ Up', onclick: () => show(r.parent) }));
    for (const d of r.entries.filter((x) => x.type === 'dir' && join(dir, x.name) !== full && !(join(dir, x.name) + '/').startsWith(full + '/'))) {
      list.append(el('button', { class: 'menu-item', type: 'button', text: '📁 ' + d.name, onclick: () => show(join(dir, d.name)) }));
    }
    openSheet('Move ' + name, el('p', { class: 'note mono', text: shortPath(dir) }), list,
      el('div', { class: 'row-end' }, el('button', { class: 'btn btn-primary', type: 'button', text: 'Move here', onclick: async () => {
        try { await rpc('fs.move', { path: full, to: dir }); closeSheets(); toast('Moved.'); loadDir(F.dir); } catch (err) { toast(err.message); }
      } })));
  };
  show(F.dir || S.root);
}

export function addMenu() {
  openSheet('Add to this folder', el('div', { class: 'menu' },
    menuItem('New file', async () => {
      const name = await askText({ title: 'New file', label: 'File name', placeholder: 'notes.md', ok: 'Create' });
      if (!name) return;
      try { const r = await rpc('fs.touch', { parent: F.dir, name }); await loadDir(F.dir); openFile(r.path); } catch (err) { toast(err.message); }
    }),
    menuItem('New folder', async () => {
      const name = await askText({ title: 'New folder', label: 'Folder name', ok: 'Create' });
      if (!name) return;
      try { await rpc('fs.mkdir', { parent: F.dir, name }); loadDir(F.dir); } catch (err) { toast(err.message); }
    }),
    menuItem('Bring files from your phone', importFiles),
    menuItem('Run an agent in this folder', () => hooks.newSession && hooks.newSession({ cwd: F.dir })),
    menuItem(F.hidden ? 'Hide hidden items' : 'Show hidden items', () => { F.hidden = !F.hidden; store.set('nami.hidden', F.hidden ? '1' : '0'); renderDir(); })));
}

// ---- bringing files in and sending them out -----------------------------------

function importFiles() {
  const input = el('input', { type: 'file', multiple: true });
  input.addEventListener('change', async () => {
    const files = [...input.files];
    for (const f of files) {
      toast('Bringing in ' + f.name + '…');
      try { await uploadOne(f, F.dir); } catch (e) { toast(f.name + ': ' + e.message); return; }
    }
    if (files.length) toast(files.length === 1 ? 'Brought in ' + files[0].name : `Brought in ${files.length} files.`);
    loadDir(F.dir);
  });
  input.click();
}

const PIECE = 1.5 * 1024 * 1024;
export async function uploadOne(file, parent, op = 'fs.put') {
  const name = file.name.replace(/[\/\0]/g, '_');
  if (file.size === 0) { return rpc(op, { parent, name, b64: '', first: true, last: true }); }
  let last = null;
  for (let off = 0; off < file.size; off += PIECE) {
    const buf = new Uint8Array(await file.slice(off, off + PIECE).arrayBuffer());
    let bin = '';
    for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
    last = await rpc(op, { parent, name, b64: btoa(bin), first: off === 0, last: off + PIECE >= file.size });
  }
  return last;
}

function download(path, name) {
  const url = rawUrl(path, true);
  if (window.NamiNative && window.NamiNative.download) {
    try { window.NamiNative.download(location.origin + url, name); toast('Saving ' + name + ' to Downloads…'); return; } catch (_) { /* fall back */ }
  }
  const a = el('a', { href: url, download: name });
  document.body.append(a); a.click(); a.remove();
}

// ---- opening a file ----------------------------------------------------------

function setDirty(d) {
  if (!F.file) return;
  F.file.dirty = d;
  $('file-save').hidden = !(d && F.file.editable);
  $('file-title').textContent = (d ? '● ' : '') + F.file.name;
}

export function fileDirty() { return !!(F.file && F.file.dirty); }

export async function openFile(path) {
  let r;
  try { r = await rpc('fs.read', { path }); } catch (e) { toast(e.message); return; }
  F.file = { ...r, dirty: false, editable: typeof r.text === 'string', mode: r.kind === 'markdown' ? 'read' : 'edit' };
  hooks.showScreen('file');
  $('file-sub').textContent = shortPath(dirOf(r.path));
  setDirty(false);
  renderFile();
}

export async function closeFile(force = false) {
  if (!force && fileDirty()) {
    const ok = await confirmSheet({ title: 'Leave without saving?', text: 'You have changes in ' + F.file.name + ' that are not saved.', ok: 'Leave', danger: true });
    if (!ok) return false;
  }
  F.file = null;
  $('file-body').replaceChildren();
  hooks.showScreen('main');
  loadDir(F.dir || S.root);
  return true;
}

function renderFile() {
  const f = F.file;
  const body = $('file-body');
  const modes = $('file-modes');
  modes.replaceChildren();
  $('file-save').hidden = true;
  if (f.kind === 'image') {
    const img = el('img', { src: rawUrl(f.path), alt: f.name, class: 'viewer-img' });
    img.addEventListener('click', () => img.classList.toggle('actual'));
    body.replaceChildren(el('div', { class: 'viewer' }, img, el('p', { class: 'note', text: bytes(f.size) + ' · tap the picture to zoom' }), downloadRow(f)));
  } else if (f.kind === 'video') {
    body.replaceChildren(el('div', { class: 'viewer' }, el('video', { src: rawUrl(f.path), controls: true, playsinline: true, class: 'viewer-media' }), downloadRow(f)));
  } else if (f.kind === 'audio') {
    body.replaceChildren(el('div', { class: 'viewer' }, el('audio', { src: rawUrl(f.path), controls: true, class: 'viewer-audio' }), downloadRow(f)));
  } else if (!f.editable) {
    const why = f.kind === 'pdf' ? 'PDF files open in your phone’s PDF viewer once downloaded.'
      : f.kind === 'toobig' ? 'This file is too large to edit here.' : 'This is not a text file, so it cannot be shown here.';
    body.replaceChildren(el('div', { class: 'viewer' }, el('p', { class: 'note-lg', text: why }), el('p', { class: 'note', text: bytes(f.size) }), downloadRow(f)));
  } else if (f.kind === 'markdown') {
    modes.replaceChildren(
      el('button', { class: 'seg', type: 'button', text: 'Read', 'aria-pressed': String(f.mode === 'read'), onclick: () => { f.mode = 'read'; renderFile(); } }),
      el('button', { class: 'seg', type: 'button', text: 'Edit', 'aria-pressed': String(f.mode === 'edit'), onclick: () => { f.mode = 'edit'; renderFile(); } }),
      el('button', { class: 'seg', type: 'button', text: 'Both', 'aria-pressed': String(f.mode === 'both'), onclick: () => { f.mode = 'both'; renderFile(); } }),
      ...(f.mode === 'read' || f.mode === 'both' ? sizeButtons() : []));
    if (f.mode === 'read') body.replaceChildren(readView(f));
    else if (f.mode === 'both') {
      // Writing on top, the page as it will read below; the page follows every pause in typing.
      const ta = editor(f); let live = readView(f); let t = 0;
      const pane = el('div', { class: 'both-pane' }, live);
      ta.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => { const next = readView(f); live.replaceWith(next); live = next; }, 250); });
      body.replaceChildren(el('div', { class: 'both' }, mdBar(ta), ta, pane));
    } else { const ta = editor(f); body.replaceChildren(mdBar(ta), ta); }
  } else {
    const ext = (f.name.split('.').pop() || '').toLowerCase();
    const coloured = knownLang(ext);
    const isHtml = ext === 'html' || ext === 'htm';
    if (coloured || isHtml) {
      const seg = (m, label) => el('button', { class: 'seg', type: 'button', text: label, 'aria-pressed': String(f.mode === m), onclick: () => { f.mode = m; renderFile(); } });
      modes.replaceChildren(...(isHtml ? [seg('page', 'Page')] : []), seg('code', 'Colour'), seg('edit', 'Edit'), ...(f.mode === 'code' ? sizeButtons() : []));
      if (f.mode === 'page') body.replaceChildren(el('iframe', { class: 'page-frame', title: f.name, sandbox: '', srcdoc: f.text }));
      else if (f.mode === 'code') body.replaceChildren(el('pre', { class: 'code-read', style: `font-size:${Math.max(11, docSize() - 3)}px`, html: highlightCode(ext, f.text) }));
      else body.replaceChildren(editor(f));
    } else body.replaceChildren(editor(f));
  }
  $('file-save').hidden = !(f.dirty && f.editable);
}

function downloadRow(f) {
  return el('div', { class: 'row-end' }, el('button', { class: 'btn', type: 'button', text: 'Download to phone', onclick: () => download(f.path, f.name) }));
}

// A small formatting bar for Markdown: wraps the selection or the current line.
function mdBar(ta) {
  const wrap = (a, b = a) => { const s = ta.selectionStart, e = ta.selectionEnd, t = ta.value.slice(s, e) || 'text'; ta.setRangeText(a + t + b, s, e, 'select'); ta.dispatchEvent(new Event('input')); ta.focus(); };
  const line = (prefix) => { const s = ta.selectionStart; const i = ta.value.lastIndexOf('\n', s - 1) + 1; ta.setRangeText(prefix, i, i, 'end'); ta.dispatchEvent(new Event('input')); ta.focus(); };
  const table = () => { const s = ta.selectionStart; ta.setRangeText('\n| Column | Column |\n| --- | --- |\n| text | text |\n', s, s, 'end'); ta.dispatchEvent(new Event('input')); ta.focus(); };
  const b = (label, fn, aria) => el('button', { class: 'md-tool', type: 'button', text: label, 'aria-label': aria, onmousedown: (e) => e.preventDefault(), onclick: fn });
  return el('div', { class: 'md-bar' }, b('B', () => wrap('**'), 'Bold'), b('I', () => wrap('*'), 'Italic'), b('H', () => line('## '), 'Heading'), b('•', () => line('- '), 'Bullet'), b('1.', () => line('1. '), 'Numbered'),
    b('☐', () => line('- [ ] '), 'Checkbox'), b('`', () => wrap('`'), 'Code'), b('🔗', () => wrap('[', '](https://)'), 'Link'), b('❝', () => line('> '), 'Quote'), b('▦', () => table(), 'Table'));
}

function editor(f) {
  const ta = el('textarea', { class: 'editor', spellcheck: 'false', autocapitalize: 'off', autocorrect: 'off', 'aria-label': 'Contents of ' + f.name });
  ta.value = f.text;
  ta.addEventListener('input', () => { f.text = ta.value; if (!f.dirty) setDirty(true); });
  ta.addEventListener('keydown', (e) => {
    if (e.key === 'Tab') { e.preventDefault(); const s = ta.selectionStart; ta.setRangeText('  ', s, ta.selectionEnd, 'end'); ta.dispatchEvent(new Event('input')); }
  });
  return ta;
}

// ---- markdown, as a page -------------------------------------------------------

const docSize = () => { const n = Number(store.get('nami.docfont')); return n >= 12 && n <= 28 ? n : 16; };
function sizeButtons() {
  const step = (d) => { store.set('nami.docfont', String(Math.max(12, Math.min(28, docSize() + d)))); renderFile(); };
  return [el('button', { class: 'seg', type: 'button', text: 'A−', 'aria-label': 'Smaller text', onclick: () => step(-2) }), el('button', { class: 'seg', type: 'button', text: 'A+', 'aria-label': 'Larger text', onclick: () => step(2) })];
}

function readView(f) {
  const dir = dirOf(f.path);
  const div = el('article', { class: 'md-read', style: `font-size:${docSize()}px` });
  div.innerHTML = renderMarkdown(f.text, {
    resolveImage: (src) => {
      if (/^[a-z][a-z0-9+.-]*:/i.test(src) || src.startsWith('//')) return null;   // nothing is fetched from the web
      const abs = src.startsWith('/') ? src : normalize(join(dir, decodeURIComponent(src.split('#')[0].split('?')[0])));
      return rawUrl(abs).replace(/"/g, '&quot;');
    },
  });
  for (const a of div.querySelectorAll('a')) {
    const href = a.getAttribute('href') || '';
    if (/^(https?:|mailto:)/i.test(href)) { a.setAttribute('target', '_blank'); a.setAttribute('rel', 'noopener noreferrer'); continue; }
    if (/^[a-z][a-z0-9+.-]*:/i.test(href) || href.startsWith('//')) { a.removeAttribute('href'); continue; }   // javascript:, data:, …
    if (href.startsWith('#')) { a.removeAttribute('href'); continue; }
    const target = href.startsWith('/') ? href : normalize(join(dir, decodeURIComponent(href.split('#')[0].split('?')[0])));
    a.setAttribute('href', '#');
    a.addEventListener('click', async (e) => { e.preventDefault(); if (await closeFileForLink()) openFile(target); });
  }
  for (const img of div.querySelectorAll('img')) {
    if (!(img.getAttribute('src') || '').startsWith('/raw?')) img.remove();
  }
  return div;
}

async function closeFileForLink() {
  if (!fileDirty()) return true;
  const ok = await confirmSheet({ title: 'Leave without saving?', text: 'You have unsaved changes.', ok: 'Leave', danger: true });
  return ok;
}

export async function saveFile() {
  const f = F.file;
  if (!f || !f.editable || !f.dirty) return;
  try {
    const r = await rpc('fs.write', { path: f.path, text: f.text, mtime: f.mtime });
    f.mtime = r.mtime;
    setDirty(false);
    toast('Saved.');
  } catch (e) {
    if (e.code === 'conflict') {
      const ok = await confirmSheet({ title: 'File changed', text: 'An agent or another app changed this file while you were editing. Save over it with your version?', ok: 'Save mine', danger: true });
      if (ok) { try { const r = await rpc('fs.write', { path: f.path, text: f.text }); f.mtime = r.mtime; setDirty(false); toast('Saved.'); } catch (e2) { toast(e2.message); } }
    } else toast(e.message);
  }
}

// ---- choosing the workspace folder ----------------------------------------------

export async function chooseFolder() {
  const input = el('input', { type: 'text', value: S.root, autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false', 'aria-label': 'Folder path' });
  const quick = el('div', { class: 'menu' });
  const body = openSheet('Workspace folder',
    el('p', { class: 'note', text: 'Agents start here, and the Workspace tab shows only this folder.' }),
    el('label', { class: 'field' }, el('span', { text: 'Path' }), input),
    quick,
    el('div', { class: 'row-end' }, el('button', { class: 'btn btn-primary', type: 'button', text: 'Use this folder', onclick: () => apply(input.value.trim()) })));
  async function apply(p) {
    if (!p) return;
    try {
      const r = await rpc('fs.setRoot', { path: p });
      S.root = r.root; F.dir = '';
      closeSheets(); updateWorkspacePill(); toast('Workspace: ' + shortPath(S.root));
      if (S.tab === 'work') showWorkspace();
    } catch (e) { toast(e.message); }
  }
  // folders used before; pin to keep one on top, ✕ to forget it
  try {
    const { recents } = await rpc('fs.recents');
    const shown = recents.filter((r) => r.path !== S.root);
    if (shown.length) quick.append(el('h3', { class: 'group', text: 'Recent' }));
    for (const r of shown) {
      quick.append(el('div', { class: 'row' },
        el('button', { class: 'row-main', type: 'button', onclick: () => { input.value = r.path; apply(r.path); } },
          el('span', { class: 'main' }, el('strong', { text: baseName(r.path) }), el('small', { text: shortPath(r.path) }))),
        el('button', { class: 'icon-btn row-more', type: 'button', 'aria-label': r.pinned ? 'Unpin' : 'Pin', text: r.pinned ? '★' : '☆',
          onclick: async (e) => { await rpc('fs.recentPin', { path: r.path, pinned: !r.pinned }).catch(() => {}); e.currentTarget.textContent = r.pinned ? '☆' : '★'; r.pinned = !r.pinned; } }),
        el('button', { class: 'icon-btn row-more', type: 'button', 'aria-label': 'Forget', text: '✕',
          onclick: async (e) => { await rpc('fs.recentRemove', { path: r.path }).catch(() => {}); e.currentTarget.closest('.row').remove(); } })));
    }
  } catch (_) { /* optional */ }
  const choices = [['Home', S.home], ['Phone storage', '/sdcard'], ['Everything', '/']];
  for (const [label, p] of choices) if (p && p !== S.root) quick.append(el('button', { class: 'menu-item', type: 'button', text: `${label} (${p})`, onclick: () => { input.value = p; apply(p); } }));
  // folders inside the current workspace, as shortcuts
  try {
    const r = await rpc('fs.ls', { path: S.root });
    for (const d of r.entries.filter((x) => x.type === 'dir' && !x.name.startsWith('.')).slice(0, 12)) {
      const p = join(S.root, d.name);
      quick.append(el('button', { class: 'menu-item', type: 'button', text: '📁 ' + d.name, onclick: () => { input.value = p; apply(p); } }));
    }
  } catch (_) { /* optional */ }
  return body;
}
