// Shared by every screen: state, the socket's request/answer helper, small DOM
// helpers, the one bottom sheet, toasts. No screen logic lives here.

export const $ = (id) => document.getElementById(id);

export const store = {
  get(k) { try { return localStorage.getItem(k); } catch (_) { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (_) { /* private mode */ } },
  del(k) { try { localStorage.removeItem(k); } catch (_) { /* private mode */ } },
};

export function el(tag, props = {}, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') n.className = v;
    else if (k === 'text') n.textContent = v;
    else if (k === 'html') n.innerHTML = v;
    else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
    else if (v === true) n.setAttribute(k, '');
    else if (v !== false && v != null) n.setAttribute(k, v);
  }
  for (const kid of kids) if (kid != null) n.append(kid);
  return n;
}

let toastTimer = 0;
export function toast(msg) {
  const t = $('toast');
  t.textContent = msg; t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; }, 3400);
}

export function ago(ms) {
  const s = Math.max(0, Math.round((Date.now() - ms) / 1000));
  if (s < 60) return 'just now';
  if (s < 3600) return Math.floor(s / 60) + ' min ago';
  if (s < 86400) return Math.floor(s / 3600) + ' h ago';
  return Math.floor(s / 86400) + ' d ago';
}

export function bytes(n) {
  if (n < 1024) return n + ' B';
  if (n < 1024 * 1024) return (n / 1024).toFixed(n < 10240 ? 1 : 0) + ' KB';
  return (n / 1024 / 1024).toFixed(1) + ' MB';
}

// ---- state -----------------------------------------------------------------

export const S = {
  token: null, ws: null, ready: false, retry: 0, retryTimer: 0,
  sessions: [], agents: [], home: '', root: '', lan: false,
  current: null,            // id of the session on screen
  ctrl: false,
  prefill: null,
  tab: 'sessions',
  term: null, fit: null,
  term2: null, fit2: null, current2: null, focus: 1,   // the optional second pane
  theme: 'paper', font: 14,
};

// Screens register what the others may call (open a terminal, start a session…).
export const hooks = {};

export function send(obj) {
  if (S.ws && S.ws.readyState === 1) { S.ws.send(JSON.stringify(obj)); return true; }
  return false;
}

// ---- asking the server things (files, library, providers) -------------------

const pending = new Map();
let rpcN = 0;

export function rpc(op, args = {}) {
  return new Promise((resolve, reject) => {
    const id = 'q' + (++rpcN);
    const timer = setTimeout(() => { pending.delete(id); reject(Object.assign(new Error('The server did not answer.'), { code: 'timeout' })); }, 20000);
    pending.set(id, { resolve, reject, timer });
    if (!send({ type: 'rpc', id, op, args })) {
      clearTimeout(timer); pending.delete(id);
      reject(Object.assign(new Error('Not connected yet.'), { code: 'offline' }));
    }
  });
}

export function answerRpc(m) {
  const p = pending.get(m.id);
  if (!p) return;
  pending.delete(m.id); clearTimeout(p.timer);
  if (m.ok) p.resolve(m.data); else p.reject(Object.assign(new Error(m.error || 'Failed.'), { code: m.code }));
}

export function failAllRpc() {
  for (const [id, p] of pending) { clearTimeout(p.timer); p.reject(Object.assign(new Error('Connection lost.'), { code: 'offline' })); pending.delete(id); }
}

// The address of a workspace file for <img>, <video> and downloads.
export function rawUrl(path, download = false) {
  return `/raw?p=${encodeURIComponent(path)}&t=${encodeURIComponent(S.token || '')}${download ? '&download=1' : ''}`;
}

// ---- paths -----------------------------------------------------------------

export function shortPath(p) {
  if (!p) return '';
  if (S.home && p === S.home) return '~';
  if (S.home && p.startsWith(S.home + '/')) return '~' + p.slice(S.home.length);
  return p;
}
export const baseName = (p) => String(p).replace(/\/+$/, '').split('/').pop() || '/';
export const dirOf = (p) => { const i = String(p).replace(/\/+$/, '').lastIndexOf('/'); return i <= 0 ? '/' : p.slice(0, i); };

// ---- the one sheet ---------------------------------------------------------
// openSheet(title, ...nodes) fills it and shows it; returns the body so the
// caller can add to it later. Only one is open at a time.

let sheetClosed = null;

// A sheet fades in and rises on a spring, and sinks away when closed. Closing waits for the sink (170 ms),
// but a sheet opened meanwhile takes over at once, so "close this one, open that one" never stutters.
let closeTimer = 0;
const calm = () => document.body.hasAttribute('data-lite') || (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
export function openSheet(title, ...nodes) {
  const body = $('sheet-body'), sheet = $('sheet');
  clearTimeout(closeTimer); closeTimer = 0;
  const wasOpen = !sheet.hidden && !sheet.classList.contains('closing');
  sheet.classList.remove('closing');
  $('sheet-title').textContent = title;
  body.replaceChildren(...nodes.filter(Boolean));
  sheet.classList.toggle('swap', wasOpen);          // already open: just change the content, no second entrance
  sheet.hidden = false;
  return body;
}
export function closeSheets() {
  const sheet = $('sheet');
  if (sheet.hidden || sheet.classList.contains('closing')) return false;
  const f = sheetClosed; sheetClosed = null;
  const done = () => { closeTimer = 0; sheet.hidden = true; sheet.classList.remove('closing', 'swap'); $('sheet-body').replaceChildren(); };
  if (calm()) done(); else { sheet.classList.add('closing'); closeTimer = setTimeout(done, 170); }
  if (f) f();
  return true;
}
export function onSheetClose(fn) { sheetClosed = fn; }
export const sheetOpen = () => !$('sheet').hidden && !$('sheet').classList.contains('closing');

document.addEventListener('click', (e) => {
  if (e.target.closest('[data-close]') || e.target.id === 'sheet') closeSheets();
});
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeSheets(); });

// A small question with one text box, for "new folder", "rename", and the like.
export function askText({ title, label, value = '', ok = 'OK', placeholder = '' }) {
  return new Promise((resolve) => {
    let settled = false;
    const input = el('input', { type: 'text', value, placeholder, autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false', 'aria-label': label || title });
    const finish = (v) => { if (settled) return; settled = true; closeSheets(); resolve(v); };
    const form = el('form', { class: 'stack', onsubmit: (e) => { e.preventDefault(); finish(input.value.trim() || null); } },
      label ? el('label', { class: 'field' }, el('span', { text: label }), input) : input,
      el('div', { class: 'row-end' },
        el('button', { class: 'btn btn-quiet', type: 'button', text: 'Cancel', onclick: () => finish(null) }),
        el('button', { class: 'btn btn-primary', type: 'submit', text: ok })));
    openSheet(title, form);
    onSheetClose(() => finish(null));
    setTimeout(() => { input.focus(); input.select(); }, 60);
  });
}

export function confirmSheet({ title, text, ok = 'Yes', danger = false }) {
  return new Promise((resolve) => {
    let settled = false;
    const finish = (v) => { if (settled) return; settled = true; closeSheets(); resolve(v); };
    openSheet(title,
      el('p', { class: 'note-lg', text }),
      el('div', { class: 'row-end' },
        el('button', { class: 'btn btn-quiet', type: 'button', text: 'Cancel', onclick: () => finish(false) }),
        el('button', { class: `btn ${danger ? 'btn-danger' : 'btn-primary'}`, type: 'button', text: ok, onclick: () => finish(true) })));
    onSheetClose(() => finish(false));
  });
}
