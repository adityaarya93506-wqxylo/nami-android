// What the key bar and the message box turn into on the wire. No DOM in here,
// so the rules can be tested on their own (tests/web.test.mjs).

export const SEQ = {
  esc: '\x1b',
  tab: '\t',
  enter: '\r',
  'c-c': '\x03',
  'c-d': '\x04',
  up: '\x1b[A',
  down: '\x1b[B',
  right: '\x1b[C',
  left: '\x1b[D',
  // the second row of the key bar
  home: '\x1b[H', end: '\x1b[F', del: '\x1b[3~', ins: '\x1b[2~', btab: '\x1b[Z',
  'c-a': '\x01', 'c-e': '\x05', 'c-u': '\x15', 'c-k': '\x0b', 'c-w': '\x17', 'c-l': '\x0c', 'c-z': '\x1a', 'c-r': '\x12',
  f1: '\x1bOP', f2: '\x1bOQ', f3: '\x1bOR', f4: '\x1bOS', f5: '\x1b[15~', f6: '\x1b[17~',
  f7: '\x1b[18~', f8: '\x1b[19~', f9: '\x1b[20~', f10: '\x1b[21~', f11: '\x1b[23~', f12: '\x1b[24~',
};

// Full-screen programs (and some agent menus) switch the terminal into
// "application cursor keys" mode, where arrows are ESC O A..D, not ESC [ A..D.
export function keySeq(name, { appCursor = false } = {}) {
  const s = SEQ[name];
  if (s === undefined) return null;
  if (appCursor && /^\x1b\[[ABCD]$/.test(s)) return '\x1bO' + s.slice(2);
  return s;
}

// The Ctrl button arms the next character: a..z (and @ [ \ ] ^ _) become the
// matching control code, space becomes NUL. Anything else passes through.
export function ctrlify(data) {
  if (typeof data !== 'string' || data.length !== 1) return data;
  if (data === ' ') return '\x00';
  const c = data.toUpperCase().charCodeAt(0);
  if (c >= 64 && c <= 95) return String.fromCharCode(c - 64);
  return data;
}

// What "Send" types into the agent. An empty box is just Enter, which is how
// you accept a prompt from the key bar's neighbour. One line is typed and
// submitted. Several lines go in as one paste when the program asked for
// bracketed paste, so the line breaks stay inside the message; otherwise they
// are joined with spaces, because a bare line break would submit half of it.
export function composeToInput(text, { bracketed = false } = {}) {
  const body = String(text == null ? '' : text).replace(/\r\n?/g, '\n').replace(/\s+$/, '');
  if (!body) return '\r';
  if (!body.includes('\n')) return body + '\r';
  if (bracketed) return '\x1b[200~' + body + '\x1b[201~' + '\r';
  return body.split('\n').map((l) => l.trim()).filter(Boolean).join(' ') + '\r';
}

// Pasting from the clipboard: same paste rules, no Enter at the end.
export function pasteToInput(text, { bracketed = false } = {}) {
  const body = String(text == null ? '' : text).replace(/\r\n?/g, '\n');
  if (!body) return '';
  if (bracketed) return '\x1b[200~' + body + '\x1b[201~';
  return body.replace(/\n/g, '\r');
}

// Thumb scrolling. Finger travel (px) becomes whole lines; the leftover pixels
// carry to the next move so slow drags still scroll. Dragging down shows older
// lines, which is a positive number of lines "back".
export function scrollLines(dyPx, lineHeightPx, carry = 0) {
  const lh = lineHeightPx > 0 ? lineHeightPx : 16;
  const total = carry + dyPx / lh;
  const lines = total > 0 ? Math.floor(total) : Math.ceil(total);
  return { lines, carry: total - lines };
}

// What a terminal answers when a program asks "what are you?" (device attributes, cursor
// position, colours). These are replies, not typing. With a second pane they would otherwise be
// typed into the shell as text, so they are never sent on as input.
export function isTerminalReply(d) {
  return typeof d === 'string' && /^(\x1b\[[?>=]?[\d;]*c|\x1b\[\??\d+(;\d+)*R|\x1b\[[?]?\d*n|\x1b\][\d;]+;[^\x07\x1b]*(\x07|\x1b\\)|\x1b\[\d+;\d+;\d+t|\x1bP[^\x1b]*\x1b\\)$/.test(d);
}
