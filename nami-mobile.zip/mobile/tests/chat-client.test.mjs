import test from 'node:test';
import assert from 'node:assert/strict';
import { createChatClient } from '../web/acp-client.js';

function rig() {
  const sent = []; const events = [];
  const c = createChatClient({ send: (l) => sent.push(JSON.parse(l)), onEvent: (e) => events.push(e) });
  const agent = (o) => c.handleLine(JSON.stringify({ jsonrpc: '2.0', ...o }));
  return { c, sent, events, agent };
}

test('chat client: starts a session, streams text, tools and plans, ends the turn', async () => {
  const { c, sent, events, agent } = rig();
  const started = c.start('/root');
  assert.equal(sent[0].method, 'initialize');
  agent({ id: sent[0].id, result: { protocolVersion: 1 } });
  await new Promise((r) => setImmediate(r));
  assert.equal(sent[1].method, 'session/new'); assert.equal(sent[1].params.cwd, '/root');
  agent({ id: sent[1].id, result: { sessionId: 'S' } });
  await started;
  assert.equal(c.ready, true); assert.deepEqual(events.at(-1), { t: 'ready' });
  const p = c.prompt('hello');
  assert.equal(sent[2].method, 'session/prompt'); assert.equal(sent[2].params.sessionId, 'S'); assert.equal(sent[2].params.prompt[0].text, 'hello');
  assert.equal(c.busy, true);
  agent({ method: 'session/update', params: { update: { sessionUpdate: 'agent_message_chunk', content: { type: 'text', text: 'Hi ' } } } });
  agent({ method: 'session/update', params: { update: { sessionUpdate: 'tool_call', toolCallId: 'a', title: 'Read file', kind: 'read', status: 'pending' } } });
  agent({ method: 'session/update', params: { update: { sessionUpdate: 'tool_call_update', toolCallId: 'a', status: 'completed' } } });
  agent({ method: 'session/update', params: { update: { sessionUpdate: 'plan', entries: [{ content: 'one', status: 'done' }] } } });
  agent({ method: 'session/update', params: { update: { sessionUpdate: 'something_new', content: 1 } } });
  agent({ id: sent[2].id, result: { stopReason: 'end_turn' } });
  await p;
  assert.deepEqual(events.filter((e) => ['text', 'tool', 'toolUpdate', 'plan', 'done'].includes(e.t)).map((e) => e.t), ['text', 'tool', 'toolUpdate', 'plan', 'done']);
  assert.equal(c.busy, false);
});

test('chat client: permission questions become buttons, and are answered once', async () => {
  const { c, sent, events, agent } = rig();
  c.start('/'); agent({ id: sent[0].id, result: {} }); await new Promise((r) => setImmediate(r)); agent({ id: sent[1].id, result: { sessionId: 'S' } }); await new Promise((r) => setImmediate(r));
  agent({ id: 77, method: 'session/request_permission', params: { toolCall: { title: 'Run rm' }, options: [{ optionId: 'y', name: 'Allow', kind: 'allow_once' }, { optionId: 'n', name: 'No', kind: 'reject_once' }] } });
  const q = events.find((e) => e.t === 'permission');
  assert.equal(q.title, 'Run rm'); assert.deepEqual(q.options.map((o) => o.id), ['y', 'n']);
  c.answer(77, 'y'); c.answer(77, 'n');
  const replies = sent.filter((s) => s.id === 77);
  assert.equal(replies.length, 1); assert.deepEqual(replies[0].result.outcome, { outcome: 'selected', optionId: 'y' });
  // stopping answers a waiting question "cancelled" and tells the agent
  agent({ id: 78, method: 'session/request_permission', params: { options: [] } });
  c.cancel();
  assert.ok(sent.some((s) => s.method === 'session/cancel'));
  assert.deepEqual(sent.find((s) => s.id === 78).result.outcome, { outcome: 'cancelled' });
});

test('chat client: errors surface, unknown requests are declined politely', async () => {
  const { c, sent, events, agent } = rig();
  c.start('/'); agent({ id: sent[0].id, error: { message: 'not signed in' } }); await new Promise((r) => setImmediate(r));
  assert.deepEqual(events.at(-1), { t: 'error', message: 'not signed in' });
  agent({ id: 5, method: 'fs/read_text_file', params: {} });
  assert.equal(sent.find((s) => s.id === 5).error.code, -32601);
  c.handleLine('not json'); c.handleLine('42');       // never throws
});

test('chat client: slash commands, and pictures only when the agent takes them', async () => {
  for (const takes of [true, false]) {
    const { c, sent, events, agent } = rig();
    c.start('/'); agent({ id: sent[0].id, result: { agentCapabilities: { promptCapabilities: { image: takes } } } }); await new Promise((r) => setImmediate(r));
    agent({ id: sent[1].id, result: { sessionId: 'S' } }); await new Promise((r) => setImmediate(r));
    assert.equal(c.canSendImages, takes);
    agent({ method: 'session/update', params: { update: { sessionUpdate: 'available_commands_update', availableCommands: [{ name: 'review', description: 'Review', input: { hint: 'a file' } }, { name: 'bad name!' }] } } });
    assert.deepEqual(events.find((e) => e.t === 'commands').list, [{ name: 'review', description: 'Review', hint: 'a file' }]);
    c.prompt('look', [{ data: 'QUJD', mimeType: 'image/png' }]);
    const blocks = sent.find((m) => m.method === 'session/prompt').params.prompt;
    assert.deepEqual(blocks.map((b) => b.type), takes ? ['image', 'text'] : ['text']);
  }
});
