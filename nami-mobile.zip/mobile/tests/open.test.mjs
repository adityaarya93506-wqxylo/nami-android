import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import http from 'node:http';
const require = createRequire(import.meta.url);
const { createServer } = require('../server/server.js');
const WebSocket = require('ws');

test('xdg-open asks the app to open a link; wrong token and non-web links are refused', async () => {
  const token = 'a'.repeat(48);
  const manager = { list: () => [], home: '/tmp', on() {}, off() {}, shutdown() {} };
  const { server, close } = createServer({ manager, token });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const port = server.address().port;
  const get = (path, tok) => new Promise((res) => http.get({ port, host: '127.0.0.1', path, headers: tok ? { 'x-nami-token': tok } : {} }, (r) => { r.resume(); r.on('end', () => res(r.statusCode)); }));
  assert.equal(await get('/__open?u=https%3A%2F%2Fa.b', 'x'), 403);
  assert.equal(await get('/__open?u=https%3A%2F%2Fa.b', token), 503);       // no page open yet
  const ws = new WebSocket(`ws://127.0.0.1:${port}/ws`);
  const seen = [];
  ws.on('message', (d) => seen.push(JSON.parse(d)));
  await new Promise((r) => ws.on('open', r));
  ws.send(JSON.stringify({ type: 'auth', token }));
  await new Promise((r) => setTimeout(r, 100));
  assert.equal(await get('/__open?u=javascript%3Aalert(1)', token), 400);
  assert.equal(await get('/__open?u=https%3A%2F%2Fexample.com%2Fx%3Fa%3D1', token), 200);
  await new Promise((r) => setTimeout(r, 100));
  assert.ok(seen.some((m) => m.type === 'open-url' && m.url === 'https://example.com/x?a=1'));
  ws.close(); close(); server.close();
});

test('xdg-open script rejects non-web links', () => {
  const r = spawnSync('sh', ['rootfs/xdg-open', 'file:///etc/passwd'], { encoding: 'utf8' });
  assert.notEqual(r.status, 0);
});

test('an rpc that answers later still reaches the page', async () => {
  const token = 'b'.repeat(48);
  const manager = { list: () => [], home: '/tmp', on() {}, off() {}, shutdown() {} };
  const rpc = { handle: (op) => (op === 'slow' ? new Promise((r) => setTimeout(() => r({ v: 1 }), 30)) : op === 'bad' ? Promise.reject(new Error('nope')) : { v: 0 }) };
  const { server, close } = createServer({ manager, token, rpc });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const ws = new WebSocket(`ws://127.0.0.1:${server.address().port}/ws`);
  const got = {};
  ws.on('message', (d) => { const m = JSON.parse(d); if (m.type === 'rpc') got[m.id] = m; if (m.type === 'authed') { ws.send(JSON.stringify({ type: 'rpc', id: 1, op: 'slow' })); ws.send(JSON.stringify({ type: 'rpc', id: 2, op: 'bad' })); ws.send(JSON.stringify({ type: 'rpc', id: 3, op: 'now' })); } });
  await new Promise((r) => ws.on('open', r));
  ws.send(JSON.stringify({ type: 'auth', token }));
  await new Promise((r) => setTimeout(r, 300));
  assert.deepEqual(got[1].data, { v: 1 }); assert.equal(got[2].ok, false); assert.equal(got[2].error, 'nope'); assert.deepEqual(got[3].data, { v: 0 });
  ws.close(); close(); server.close();
});

test('phone api: needs the token, relays text to the page, paste waits for the page', async () => {
  const token = 'c'.repeat(48);
  const manager = { list: () => [], home: '/tmp', on() {}, off() {}, shutdown() {} };
  const { server, close } = createServer({ manager, token });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const port = server.address().port;
  const post = (qs, body, tok) => new Promise((res) => {
    const r = http.request({ port, host: '127.0.0.1', path: '/__phone' + qs, method: 'POST', headers: tok ? { 'x-nami-token': tok } : {} }, (x) => { let d = ''; x.on('data', (c) => { d += c; }); x.on('end', () => res({ code: x.statusCode, body: d })); });
    r.end(body);
  });
  assert.equal((await post('?op=copy', 'x', 'bad')).code, 403);
  assert.equal((await post('?op=copy', 'x', token)).code, 503);                  // no page open
  const ws = new WebSocket(`ws://127.0.0.1:${port}/ws`);
  const seen = [];
  ws.on('message', (d) => { const m = JSON.parse(d); seen.push(m); if (m.type === 'phone' && ['paste', 'location', 'wifi', 'sensor'].includes(m.op)) ws.send(JSON.stringify({ type: 'phone-reply', rid: m.rid, text: m.op === 'paste' ? 'clip ✓' : m.op + ':' + m.text })); });
  await new Promise((r) => ws.on('open', r));
  ws.send(JSON.stringify({ type: 'auth', token }));
  await new Promise((r) => setTimeout(r, 100));
  assert.equal((await post('?op=nope', '', token)).code, 400);
  assert.equal((await post('?op=copy', 'line1\nline2', token)).code, 200);
  assert.equal((await post('?op=notify&title=Hi', 'done', token)).code, 200);
  const loc = await post('?op=location', '', token); assert.equal(loc.body, 'location:');
  const sen = await post('?op=sensor', 'light', token); assert.equal(sen.body, 'sensor:light');
  const p = await post('?op=paste', '', token);
  assert.equal(p.code, 200); assert.equal(p.body, 'clip ✓');
  const c = seen.find((m) => m.type === 'phone' && m.op === 'copy'); assert.equal(c.text, 'line1\nline2');
  const n = seen.find((m) => m.type === 'phone' && m.op === 'notify'); assert.equal(n.title, 'Hi');
  ws.close(); close(); server.close();
});
