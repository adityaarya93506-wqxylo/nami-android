import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const script = path.join(here, '..', 'tools', 'fetch-proot.sh');
const have = (c) => spawnSync('sh', ['-c', `command -v ${c}`]).status === 0;
const T = { skip: ['gcc', 'dpkg-deb', 'readelf', 'curl'].every(have) ? false : 'gcc/dpkg-deb/readelf/curl missing' };

// A pretend Termux repository: proot needs libtalloc.so.2, which comes from its own package.
function fakeRepo() {
  const w = fs.mkdtempSync(path.join(os.tmpdir(), 'nami-repo-'));
  const sh = (cmd) => { const r = spawnSync('sh', ['-c', cmd], { cwd: w, encoding: 'utf8' }); assert.equal(r.status, 0, cmd + '\n' + r.stderr); };
  const P = 'data/data/com.termux/files/usr';
  fs.writeFileSync(path.join(w, 't.c'), 'int talloc_x(void){return 1;}\n');
  fs.writeFileSync(path.join(w, 'p.c'), 'int talloc_x(void); int main(void){return talloc_x()-1;}\n');
  sh('gcc -shared -fPIC -Wl,-soname,libtalloc.so.2 t.c -o libtalloc.so.2.4.2');
  sh('gcc p.c -o proot ./libtalloc.so.2.4.2 -Wl,-rpath,/x');
  fs.writeFileSync(path.join(w, 'l.c'), 'void _start(void){}\n');
  sh('gcc -nostdlib -static -o loader l.c');
  const deb = (name, files, depends) => {
    const root = path.join(w, 'deb-' + name);
    for (const [dest, src, mode] of files) {
      fs.mkdirSync(path.dirname(path.join(root, dest)), { recursive: true });
      fs.copyFileSync(path.join(w, src), path.join(root, dest));
      fs.chmodSync(path.join(root, dest), mode);
    }
    fs.mkdirSync(path.join(root, 'DEBIAN'));
    fs.writeFileSync(path.join(root, 'DEBIAN/control'),
      `Package: ${name}\nVersion: 1\nArchitecture: aarch64\nMaintainer: x\nDescription: x\n${depends ? 'Depends: ' + depends + '\n' : ''}`);
    fs.mkdirSync(path.join(w, 'repo/pool'), { recursive: true });
    sh(`dpkg-deb -b deb-${name} repo/pool/${name}.deb`);
  };
  deb('libtalloc', [[`${P}/lib/libtalloc.so.2.4.2`, 'libtalloc.so.2.4.2', 0o644], [`${P}/lib/libtalloc.so.2`, 'libtalloc.so.2.4.2', 0o644]], null);
  deb('proot', [[`${P}/bin/proot`, 'proot', 0o755], [`${P}/libexec/proot/loader`, 'loader', 0o755]], 'libc++ (>= 1), libtalloc, libandroid-support');
  const idx = (n, dep) => `Package: ${n}\nVersion: 1\nArchitecture: aarch64\nFilename: pool/${n}.deb\n${dep ? 'Depends: ' + dep + '\n' : ''}\n`;
  fs.mkdirSync(path.join(w, 'repo/dists/stable/main/binary-aarch64'), { recursive: true });
  fs.writeFileSync(path.join(w, 'repo/dists/stable/main/binary-aarch64/Packages'),
    idx('proot', 'libc++ (>= 1), libtalloc, libandroid-support') + idx('libtalloc', ''));
  // patchelf stand-in: records what it was asked to do
  fs.mkdirSync(path.join(w, 'bin'));
  fs.writeFileSync(path.join(w, 'bin/patchelf'), '#!/bin/sh\necho "$@" >> "$PATCHLOG"\n', { mode: 0o755 });
  return w;
}

test('fetch-proot collects proot, its loader and its library under lib*.so names', T, () => {
  const w = fakeRepo();
  const out = path.join(w, 'out');
  const r = spawnSync('bash', [script, out, 'file://' + path.join(w, 'repo')], {
    encoding: 'utf8', env: { ...process.env, PATH: path.join(w, 'bin') + ':' + process.env.PATH, PATCHLOG: path.join(w, 'patch.log') },
  });
  assert.equal(r.status, 0, r.stdout + r.stderr);
  assert.deepEqual(fs.readdirSync(out).sort(), ['libproot-loader.so', 'libproot.so', 'libtalloc.so']);
  const log = fs.readFileSync(path.join(w, 'patch.log'), 'utf8');
  assert.match(log, /--replace-needed libtalloc\.so\.2 libtalloc\.so .*libproot\.so/);
  assert.match(r.stdout, /libproot\.so\s+NEEDED: .*libtalloc/);
});

test('fetch-proot fails loudly when the package is missing', T, () => {
  const w = fakeRepo();
  fs.writeFileSync(path.join(w, 'repo/dists/stable/main/binary-aarch64/Packages'), 'Package: other\nFilename: x\n\n');
  const r = spawnSync('bash', [script, path.join(w, 'o'), 'file://' + path.join(w, 'repo')], { encoding: 'utf8', env: { ...process.env, PATH: path.join(w, 'bin') + ':' + process.env.PATH } });
  assert.notEqual(r.status, 0);
  assert.match(r.stderr, /proot not found/);
});
