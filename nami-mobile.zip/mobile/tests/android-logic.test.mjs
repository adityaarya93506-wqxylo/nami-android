import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const src = path.join(here, '..', 'android', 'app', 'src', 'main', 'java', 'app', 'namimobile');
const have = (c) => spawnSync('sh', ['-c', `command -v ${c}`]).status === 0;
const ok = have('javac') && have('java') && have('tar');
const T = { skip: ok ? false : 'javac/java/tar not available' };

const work = fs.mkdtempSync(path.join(os.tmpdir(), 'nami-android-'));
const classes = path.join(work, 'classes');
if (ok) {
  fs.mkdirSync(classes);
  const files = [...fs.readdirSync(src).filter((f) => f.endsWith('.java')).map((f) => path.join(src, f)), path.join(here, 'java', 'ExtractTest.java')];
  const r = spawnSync('javac', ['-d', classes, ...files], { encoding: 'utf8' });
  assert.equal(r.status, 0, r.stderr);
}

function run(archive) {
  const dest = fs.mkdtempSync(path.join(work, 'out-'));
  const r = spawnSync('java', ['-Dsun.jnu.encoding=UTF-8', '-Dfile.encoding=UTF-8', '-cp', classes, 'ExtractTest', archive, dest], { encoding: 'utf8', env: { ...process.env, LC_ALL: 'C.UTF-8' } });
  return { dest, out: r.stdout, err: r.stderr };
}
function tar(dir, args, name = 'a.tar') {
  const f = path.join(work, name);
  const r = spawnSync('tar', ['-C', dir, ...args, '-cf', f, '.'], { encoding: 'utf8' });
  assert.equal(r.status, 0, r.stderr);
  return f;
}
function tree() {
  const d = fs.mkdtempSync(path.join(work, 'src-'));
  fs.mkdirSync(path.join(d, 'bin'));
  fs.mkdirSync(path.join(d, 'etc'));
  fs.writeFileSync(path.join(d, 'etc', 'hello'), 'hi\n');
  fs.writeFileSync(path.join(d, 'bin', 'busybox'), '#!/bin/sh\necho bb\n', { mode: 0o755 });
  fs.symlinkSync('busybox', path.join(d, 'bin', 'sh'));
  fs.symlinkSync('/usr/lib/absolute', path.join(d, 'abs'));
  fs.linkSync(path.join(d, 'bin', 'busybox'), path.join(d, 'bin', 'hardone'));
  return d;
}

test('files, folders, symlinks and hard links come out right', T, () => {
  const f = tar(tree(), ['--format=ustar']);
  const { dest, out } = run(f);
  assert.match(out, /^OK /);
  assert.equal(fs.readFileSync(path.join(dest, 'etc/hello'), 'utf8'), 'hi\n');
  assert.equal(fs.readlinkSync(path.join(dest, 'bin/sh')), 'busybox');
  assert.equal(fs.readlinkSync(path.join(dest, 'abs')), '/usr/lib/absolute');
  assert.equal(fs.readFileSync(path.join(dest, 'bin/hardone'), 'utf8'), '#!/bin/sh\necho bb\n');
  assert.match(out, /hardlinks=1/);
  assert.match(out, /symlinks=2/);
});

test('gzip works, and progress counts the content bytes', T, () => {
  const f = tar(tree(), ['--format=gnu']);
  spawnSync('gzip', ['-kf', f]);
  const { out } = run(f + '.gz');
  assert.match(out, /^OK /);
  assert.match(out, /progress=(\d+)/);
  assert.ok(Number(/progress=(\d+)/.exec(out)[1]) >= 3);
});

test('very long names (GNU and pax) survive', T, () => {
  const d = fs.mkdtempSync(path.join(work, 'long-'));
  const deep = path.join(d, 'a'.repeat(90), 'b'.repeat(90), 'c'.repeat(90));
  fs.mkdirSync(deep, { recursive: true });
  fs.writeFileSync(path.join(deep, 'f'.repeat(120) + '.txt'), 'long');
  fs.symlinkSync('t'.repeat(200), path.join(deep, 'lnk'));
  for (const fmt of ['gnu', 'pax', 'posix']) {
    const f = tar(d, ['--format=' + fmt], `long-${fmt}.tar`);
    const { dest, out } = run(f);
    assert.match(out, /^OK /, fmt + ': ' + out);
    const p = path.join(dest, 'a'.repeat(90), 'b'.repeat(90), 'c'.repeat(90));
    assert.equal(fs.readFileSync(path.join(p, 'f'.repeat(120) + '.txt'), 'utf8'), 'long', fmt);
    assert.equal(fs.readlinkSync(path.join(p, 'lnk')), 't'.repeat(200), fmt);
  }
});

test('unicode names survive in pax archives', T, () => {
  const d = fs.mkdtempSync(path.join(work, 'uni-'));
  fs.writeFileSync(path.join(d, 'नमस्ते-é.txt'), 'x');
  const { dest, out } = run(tar(d, ['--format=pax'], 'uni.tar'));
  assert.match(out, /^OK /);
  assert.equal(fs.readFileSync(path.join(dest, 'नमस्ते-é.txt'), 'utf8'), 'x');
});

test('an archive with .. in a path is refused and nothing escapes', T, () => {
  const d = fs.mkdtempSync(path.join(work, 'evil-'));
  fs.writeFileSync(path.join(d, 'x'), 'pwn');
  const f = path.join(work, 'evil.tar');
  const r = spawnSync('tar', ['-C', d, '--transform', 's,^x$,../escaped,', '-P', '-cf', f, 'x'], { encoding: 'utf8' });
  assert.equal(r.status, 0, r.stderr);
  const { dest, out } = run(f);
  assert.match(out, /^ERR .*\.\./);
  assert.equal(fs.existsSync(path.join(dest, '..', 'escaped')), false);
});

test('nothing is written through a symlink the archive made', T, () => {
  const d = fs.mkdtempSync(path.join(work, 'sl-'));
  fs.symlinkSync('/tmp', path.join(d, 'out'));
  const f1 = path.join(work, 'sl1.tar');
  spawnSync('tar', ['-C', d, '-cf', f1, 'out']);
  fs.writeFileSync(path.join(d, 'payload'), 'x');
  const f2 = path.join(work, 'sl2.tar');
  spawnSync('tar', ['-C', d, '--transform', 's,^payload$,out/pwned,', '-cf', f2, 'payload']);
  const cat = path.join(work, 'sl.tar');
  // concatenate the two archives without the end blocks of the first
  const a = fs.readFileSync(f1), b = fs.readFileSync(f2);
  let end = a.length;
  while (end >= 512 && a.subarray(end - 512, end).every((x) => x === 0)) end -= 512;
  fs.writeFileSync(cat, Buffer.concat([a.subarray(0, end), b]));
  const { out } = run(cat);
  assert.match(out, /^ERR .*symlink/);
  assert.equal(fs.existsSync('/tmp/pwned'), false);
});

test('a cut-off archive is an error, not a silent half install', T, () => {
  const f = tar(tree(), ['--format=gnu']);
  const buf = fs.readFileSync(f);
  fs.writeFileSync(f, buf.subarray(0, 700));
  assert.match(run(f).out, /^ERR /);
});

test('proot command: runs the supervisor as root inside the rootfs', T, () => {
  const { out } = run(tar(tree(), ['--format=gnu']));
  assert.match(out, /PROOT \/lib\/libproot\.so \/usr\/local\/bin\/nami-supervisor/);
  assert.match(out, /SDCARD true false/, "the phone storage is mounted only when asked for");
});
