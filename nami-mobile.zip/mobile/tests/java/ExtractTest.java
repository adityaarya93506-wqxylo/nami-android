import app.namimobile.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.GZIPInputStream;

/** Extracts a (gzipped) tar into a folder with a real filesystem sink and prints one line per thing found. */
public class ExtractTest {
    static final class FsSink implements FileSink {
        final Path root;
        FsSink(Path r) { root = r; }
        Path p(String s) { return root.resolve(s); }
        public void dir(String path, int mode) throws IOException { Files.createDirectories(p(path)); }
        public OutputStream file(String path, int mode) throws IOException {
            Files.createDirectories(p(path).getParent());
            return Files.newOutputStream(p(path));
        }
        public void symlink(String path, String target) throws IOException {
            Files.createDirectories(p(path).getParent());
            Files.deleteIfExists(p(path));
            Files.createSymbolicLink(p(path), Paths.get(target));
        }
        public void hardlink(String path, String target) throws IOException {
            Files.createDirectories(p(path).getParent());
            Files.copy(p(target), p(path), StandardCopyOption.REPLACE_EXISTING);
        }
    }

    public static void main(String[] a) throws Exception {
        InputStream in = new BufferedInputStream(new FileInputStream(a[0]));
        if (a[0].endsWith(".gz")) in = new GZIPInputStream(in);
        long[] last = {0};
        try {
            TarExtractor.Result r = new TarExtractor(new FsSink(Paths.get(a[1])), n -> last[0] = n).extract(in);
            System.out.println("OK files=" + r.files + " dirs=" + r.dirs + " symlinks=" + r.symlinks + " hardlinks=" + r.hardlinks + " skipped=" + r.skipped + " progress=" + last[0]);
        } catch (IOException e) {
            System.out.println("ERR " + e.getMessage());
        }
        List<String> cmd = ProotLauncher.command("/lib", "/root-fs");
        List<String> withSd = ProotLauncher.command("/lib", "/root-fs", "/storage/emulated/0");
        System.out.println("SDCARD " + withSd.contains("/storage/emulated/0:/sdcard") + " " + cmd.contains("/storage/emulated/0:/sdcard"));
        System.out.println("PROOT " + cmd.get(0) + " " + String.join(" ", cmd.subList(cmd.size() - 1, cmd.size())));
    }
}
