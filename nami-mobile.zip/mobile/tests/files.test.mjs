import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';

const require = createRequire(import.meta.url);
const WebSocket = require('ws');
const { createWorkspace } = require('../server/workspace.js');
const library = require('../server/library.js');
const { createKeys } = require('../server/keys.js');
const { createRpc } = require('../server/rpc.js');
const { createServer } = require('../server/server.js');
const { SessionManager } = require('../server/sessions.js');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'nami-files-'));

function fixture() {
  const home = fs.realpathSync(tmp());
  fs.mkdirSync(path.join(home, 'work', 'sub'), { recursive: true });
  fs.writeFileSync(path.join(home, 'work', 'notes.md'), '# Hi\n\ntext');
  fs.writeFileSync(path.join(home, 'work', 'a.txt'), 'plain');
  fs.writeFileSync(path.join(home, 'work', 'pic.png'), Buffer.from([137, 80, 78, 71, 0, 1]));
  fs.writeFileSync(path.join(home, 'work', 'blob.bin'), Buffer.from([1, 2, 0, 3]));
  fs.writeFileSync(path.join(home, 'outside.txt'), 'secret');
  return home;
}

test('ls: folders first, sorted, with kinds', () => {
  const home = fixture();
  const ws = createWorkspace({ root: path.join(home, 'work'), home });
  const r = ws.ls();
  assert.equal(r.entries[0].name, 'sub');
  assert.equal(r.entries[0].type, 'dir');
  assert.deepEqual(r.entries.slice(1).map((e) => e.name), ['a.txt', 'blob.bin', 'notes.md', 'pic.png']);
  assert.equal(r.entries.find((e) => e.name === 'notes.md').kind, 'markdown');
  assert.equal(r.entries.find((e) => e.name === 'pic.png').kind, 'image');
  assert.equal(r.parent, null, 'no way up from the workspace root');
  assert.equal(ws.ls('sub').parent, path.join(home, 'work'));
});

test('read: text, image (no bytes), binary', () => {
  const home = fixture();
  const ws = createWorkspace({ root: path.join(home, 'work'), home });
  assert.equal(ws.read('notes.md').text, '# Hi\n\ntext');
  assert.equal(ws.read('notes.md').kind, 'markdown');
  const img = ws.read('pic.png');
  assert.equal(img.kind, 'image');
  assert.equal(img.text, undefined);
  assert.equal(ws.read('blob.bin').kind, 'binary');
});

test('nothing outside the workspace: .., absolute paths and symlinks are refused', () => {
  const home = fixture();
  fs.symlinkSync(path.join(home, 'outside.txt'), path.join(home, 'work', 'link.txt'));
  fs.symlinkSync(home, path.join(home, 'work', 'homelink'));
  const ws = createWorkspace({ root: path.join(home, 'work'), home });
  for (const p of ['../outside.txt', path.join(home, 'outside.txt'), '/etc/passwd', 'link.txt', 'homelink/outside.txt']) {
    assert.throws(() => ws.read(p), /outside|Not found/, p);
  }
  assert.throws(() => ws.write('../x.txt', 'x'), /outside/);
  assert.throws(() => ws.write('homelink/x.txt', 'x'), /outside/);
  assert.throws(() => ws.remove('..'), /outside/);
  assert.equal(fs.existsSync(path.join(home, 'x.txt')), false);
});

test('write is atomic, keeps the mode, and notices a changed file', () => {
  const home = fixture();
  const ws = createWorkspace({ root: path.join(home, 'work'), home });
  const r0 = ws.read('a.txt');
  const w = ws.write('a.txt', 'new text', r0.mtime);
  assert.equal(fs.readFileSync(path.join(home, 'work', 'a.txt'), 'utf8'), 'new text');
  assert.ok(w.mtime >= r0.mtime);
  fs.utimesSync(path.join(home, 'work', 'a.txt'), new Date(), new Date(Date.now() + 5000));
  assert.throws(() => ws.write('a.txt', 'stale', w.mtime), (e) => e.code === 'conflict');
  assert.deepEqual(fs.readdirSync(path.join(home, 'work')).filter((n) => n.endsWith('.tmp')), [], 'no temp files left');
  ws.write('brand-new.txt', 'x');
  assert.equal(fs.readFileSync(path.join(home, 'work', 'brand-new.txt'), 'utf8'), 'x');
});

test('make, rename and delete', () => {
  const home = fixture();
  const ws = createWorkspace({ root: path.join(home, 'work'), home });
  ws.mkdir('.', 'newdir');
  ws.touch('newdir', 'f.md');
  assert.ok(fs.existsSync(path.join(home, 'work', 'newdir', 'f.md')));
  assert.throws(() => ws.mkdir('.', 'newdir'), /taken/);
  assert.throws(() => ws.touch('.', '../evil'), /not allowed/);
  assert.throws(() => ws.mkdir('.', 'a/b'), /not allowed/);
  ws.rename('newdir/f.md', 'g.md');
  assert.ok(fs.existsSync(path.join(home, 'work', 'newdir', 'g.md')));
  assert.throws(() => ws.rename('newdir', 'sub'), /taken/);
  ws.remove('newdir');
  assert.equal(fs.existsSync(path.join(home, 'work', 'newdir')), false);
  assert.throws(() => ws.remove('.'), /cannot be deleted/);
});

test('put: a file comes in by pieces, never overwrites, and leaves no part file behind', () => {
  const home = fixture();
  const ws = createWorkspace({ root: path.join(home, 'work'), home });
  const data = Buffer.from('hello world from the phone');
  const a = data.subarray(0, 10).toString('base64'); const b = data.subarray(10).toString('base64');
  assert.equal(ws.put('.', 'in.txt', a, { first: true }).done, false);
  const r = ws.put('.', 'in.txt', b, { last: true });
  assert.equal(r.done, true);
  assert.equal(fs.readFileSync(path.join(home, 'work', 'in.txt'), 'utf8'), 'hello world from the phone');
  const again = ws.put('.', 'in.txt', data.toString('base64'), { first: true, last: true });
  assert.equal(path.basename(again.path), 'in (1).txt');
  assert.equal(fs.readFileSync(path.join(home, 'work', 'in.txt'), 'utf8'), 'hello world from the phone');
  assert.deepEqual(fs.readdirSync(path.join(home, 'work')).filter((n) => n.includes('.part')), []);
  assert.throws(() => ws.put('.', 'x.txt', a, { last: true }), /interrupted/);
  assert.throws(() => ws.put('.', '../x.txt', a, { first: true }), /not allowed/);
  assert.throws(() => ws.put('..', 'x.txt', a, { first: true }), /outside/);
});

test('changing the workspace folder', () => {
  const home = fixture();
  const ws = createWorkspace({ root: home, home });
  ws.setRoot(path.join(home, 'work'));
  assert.equal(ws.root, path.join(home, 'work'));
  assert.throws(() => ws.setRoot(path.join(home, 'nope')), /does not exist/);
  assert.throws(() => ws.setRoot(path.join(home, 'work', 'a.txt')), /not a folder/);
  assert.throws(() => ws.read('../outside.txt'), /outside/);
});

test('library: finds claude and codex agents and skills, and creates new ones', () => {
  const home = tmp();
  const proj = path.join(home, 'proj');
  fs.mkdirSync(path.join(home, '.claude', 'agents'), { recursive: true });
  fs.writeFileSync(path.join(home, '.claude', 'agents', 'writer.md'), '---\nname: writer\ndescription: Writes the weekly update\n---\nBody');
  fs.mkdirSync(path.join(home, '.claude', 'skills', 'pdf-tools'), { recursive: true });
  fs.writeFileSync(path.join(home, '.claude', 'skills', 'pdf-tools', 'SKILL.md'), '---\nname: pdf-tools\ndescription: >\n  Handle PDFs\n  well\n---\nx');
  fs.mkdirSync(path.join(home, '.codex', 'agents'), { recursive: true });
  fs.writeFileSync(path.join(home, '.codex', 'agents', 'reviewer.toml'), 'name = "reviewer"\ndescription = "Reviews code"\ndeveloper_instructions = """\nname = "not me"\n"""\n');
  fs.mkdirSync(path.join(proj, '.claude', 'agents'), { recursive: true });
  fs.writeFileSync(path.join(proj, '.claude', 'agents', 'local.md'), 'no frontmatter');
  const items = library.scan({ home, project: proj });
  const by = (n) => items.find((i) => i.name === n);
  assert.equal(by('writer').description, 'Writes the weekly update');
  assert.equal(by('writer').platform, 'claude');
  assert.equal(by('pdf-tools').type, 'skill');
  assert.equal(by('pdf-tools').description, 'Handle PDFs well');
  assert.equal(by('reviewer').platform, 'codex');
  assert.equal(by('reviewer').description, 'Reviews code');
  assert.equal(by('local').scope, 'project');
  assert.equal(items.length, 4);

  const made = library.create({ home, project: proj, platform: 'claude', scope: 'user', type: 'agent', name: 'Client Reporter!', description: 'Friday update' });
  assert.equal(path.basename(made.path), 'client-reporter.md');
  assert.match(fs.readFileSync(made.path, 'utf8'), /^---\nname: client-reporter\ndescription: Friday update\n---/);
  assert.throws(() => library.create({ home, project: proj, platform: 'claude', scope: 'user', type: 'agent', name: 'client reporter' }), /already exists/);
  const sk = library.create({ home, project: proj, platform: 'claude', scope: 'project', type: 'skill', name: 'deploy' });
  assert.ok(sk.path.endsWith(path.join('proj', '.claude', 'skills', 'deploy', 'SKILL.md')));
  const cx = library.create({ home, project: proj, platform: 'codex', scope: 'user', type: 'agent', name: 'planner', description: 'a "quoted" thing' });
  assert.match(fs.readFileSync(cx.path, 'utf8'), /description = "a \\"quoted\\" thing"/);
  assert.throws(() => library.create({ home, project: proj, platform: 'claude', scope: 'user', type: 'agent', name: '!!!' }), /name/);
  assert.equal(library.allowed(made.path, { home, project: proj }), true);
  assert.equal(library.allowed(path.join(home, 'secret.txt'), { home, project: proj }), false);
});

test('keys: saved privately, masked for the page, merged on edit, validated', () => {
  const dir = tmp();
  const file = path.join(dir, 'sub', 'keys.json');
  const keys = createKeys({ file });
  const id = keys.save({ name: 'My proxy', agent: 'claude', env: { ANTHROPIC_BASE_URL: 'https://x.example/v1', ANTHROPIC_AUTH_TOKEN: 'sk-secret-1234567' } });
  assert.equal(fs.statSync(file).mode & 0o777, 0o600);
  const l = keys.list();
  assert.equal(l.length, 1);
  assert.equal(l[0].vars.find((v) => v.name === 'ANTHROPIC_BASE_URL').preview, 'https://x.example/v1');
  assert.equal(l[0].vars.find((v) => v.name === 'ANTHROPIC_AUTH_TOKEN').preview, '•••• 4567');
  assert.ok(!JSON.stringify(l).includes('sk-secret'));
  keys.save({ id, name: 'My proxy 2', env: { ANTHROPIC_BASE_URL: 'https://y.example', ANTHROPIC_AUTH_TOKEN: '' } });
  assert.equal(keys.envFor(id).ANTHROPIC_AUTH_TOKEN, 'sk-secret-1234567', 'empty keeps the saved secret');
  assert.equal(keys.envFor(id).ANTHROPIC_BASE_URL, 'https://y.example');
  for (const bad of [{ 'bad name': 'x' }, { PATH: '/x' }, { A: 'line\nbreak' }, { A: 'ends;' }, {}]) {
    assert.throws(() => keys.save({ name: 'x', env: bad }), Error, JSON.stringify(bad));
  }
  assert.throws(() => keys.save({ name: ' ', env: { A: '1' } }), /name/);
  assert.deepEqual(keys.envFor(null), {});
  assert.throws(() => keys.envFor('nope'), /gone/);
  keys.remove(id);
  assert.equal(keys.list().length, 0);
});

// ---- over the socket -------------------------------------------------------

const TOKEN = 'b'.repeat(48);
async function boot() {
  const home = fixture();
  const made = [];
  const spawn = (file, args, opts) => { const p = { file, args, opts, pid: 1, resizable: true, onData() {}, onExit() {}, write() {}, resize: () => true, kill() {} }; made.push(p); return p; };
  const manager = new SessionManager({ spawnPty: spawn, env: { SHELL: '/bin/sh' }, home });
  const workspace = createWorkspace({ root: home, home });
  const keys = createKeys({ file: path.join(home, '.keys.json') });
  const rpc = createRpc({ workspace, keys, home });
  const app = createServer({ manager, token: TOKEN, listAgentsFn: () => [], rpc, keys, workspace });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  return { app, home, made, keys, port: app.server.address().port };
}

function client(port) {
  const ws = new WebSocket(`ws://127.0.0.1:${port}/ws`);
  const waiters = []; const inbox = [];
  ws.on('message', (raw) => {
    const m = JSON.parse(raw.toString());
    const i = waiters.findIndex((w) => w.pred(m));
    if (i >= 0) waiters.splice(i, 1)[0].resolve(m); else inbox.push(m);
  });
  const next = (pred) => new Promise((resolve, reject) => {
    const j = inbox.findIndex(pred);
    if (j >= 0) return resolve(inbox.splice(j, 1)[0]);
    const t = setTimeout(() => reject(new Error('timeout')), 3000);
    waiters.push({ pred, resolve: (m) => { clearTimeout(t); resolve(m); } });
  });
  let n = 0;
  const call = async (op, args) => { const id = 'r' + ++n; ws.send(JSON.stringify({ type: 'rpc', id, op, args })); return next((m) => m.type === 'rpc' && m.id === id); };
  const open = new Promise((r) => ws.on('open', r));
  return { ws, next, call, open };
}

test('socket: rpc needs the token; files, library and keys answer', async () => {
  const { app, home, port } = await boot();
  const c = client(port);
  await c.open;
  c.ws.send(JSON.stringify({ type: 'rpc', id: 'x', op: 'fs.ls', args: {} }));
  await new Promise((r) => c.ws.on('close', r));            // not signed in: closed, no answer
  const d = client(port);
  await d.open;
  d.ws.send(JSON.stringify({ type: 'auth', token: TOKEN }));
  const authed = await d.next((m) => m.type === 'authed');
  assert.equal(authed.root, home);
  const ls = await d.call('fs.ls', { path: path.join(home, 'work') });
  assert.equal(ls.ok, true);
  assert.ok(ls.data.entries.some((e) => e.name === 'notes.md'));
  const bad = await d.call('fs.read', { path: '/etc/passwd' });
  assert.equal(bad.ok, false);
  assert.match(bad.error, /outside/);
  assert.equal((await d.call('nope.nope', {})).ok, false);
  const w = await d.call('fs.write', { path: path.join(home, 'work', 'a.txt'), text: 'via socket' });
  assert.equal(w.ok, true);
  assert.equal(fs.readFileSync(path.join(home, 'work', 'a.txt'), 'utf8'), 'via socket');
  const sk = await d.call('keys.save', { name: 'P', env: { OPENAI_API_KEY: 'sk-abc12345' } });
  assert.equal(sk.ok, true);
  const list = await d.call('keys.list', {});
  assert.equal(list.data.providers[0].vars[0].preview, '•••• 2345');
  d.ws.close();
  await app.close();
});

test('socket: a session created with a provider gets its variables', async () => {
  const { app, made, keys, port } = await boot();
  const id = keys.save({ name: 'Proxy', env: { ANTHROPIC_BASE_URL: 'https://p.example', ANTHROPIC_AUTH_TOKEN: 'tok' } });
  const c = client(port);
  await c.open;
  c.ws.send(JSON.stringify({ type: 'auth', token: TOKEN }));
  await c.next((m) => m.type === 'authed');
  c.ws.send(JSON.stringify({ type: 'create', kind: 'shell', providerId: id }));
  await c.next((m) => m.type === 'created');
  assert.equal(made.at(-1).opts.env.ANTHROPIC_BASE_URL, 'https://p.example');
  assert.equal(made.at(-1).opts.env.ANTHROPIC_AUTH_TOKEN, 'tok');
  c.ws.send(JSON.stringify({ type: 'create', kind: 'shell', providerId: 'missing' }));
  const err = await c.next((m) => m.type === 'error');
  assert.match(err.message, /gone/);
  c.ws.close();
  await app.close();
});

function get(port, url) {
  return new Promise((resolve, reject) => {
    http.get({ host: '127.0.0.1', port, path: url, headers: { Host: `127.0.0.1:${port}` } }, (res) => {
      const chunks = []; res.on('data', (d) => chunks.push(d)); res.on('end', () => resolve({ res, body: Buffer.concat(chunks) }));
    }).on('error', reject);
  });
}

test('/raw: needs the token, serves images with ranges, never runs html', async () => {
  const { app, home, port } = await boot();
  fs.writeFileSync(path.join(home, 'work', 'page.html'), '<script>1</script>');
  const q = (p, extra = '') => `/raw?p=${encodeURIComponent(path.join(home, 'work', p))}&t=${TOKEN}${extra}`;
  assert.equal((await get(port, `/raw?p=${encodeURIComponent(path.join(home, 'work', 'pic.png'))}`)).res.statusCode, 403);
  assert.equal((await get(port, q('pic.png').replace(TOKEN, 'c'.repeat(48)))).res.statusCode, 403);
  const ok = await get(port, q('pic.png'));
  assert.equal(ok.res.statusCode, 200);
  assert.equal(ok.res.headers['content-type'], 'image/png');
  assert.match(ok.res.headers['content-security-policy'], /sandbox/);
  assert.equal(ok.body.length, 6);
  const part = await new Promise((resolve) => http.get({ host: '127.0.0.1', port, path: q('pic.png'), headers: { Range: 'bytes=1-2' } }, (res) => { const c = []; res.on('data', (d) => c.push(d)); res.on('end', () => resolve({ res, body: Buffer.concat(c) })); }));
  assert.equal(part.res.statusCode, 206);
  assert.equal(part.res.headers['content-range'], 'bytes 1-2/6');
  assert.deepEqual([...part.body], [80, 78]);
  const html = await get(port, q('page.html'));
  assert.equal(html.res.headers['content-type'], 'application/octet-stream', 'html is never rendered from here');
  assert.equal((await get(port, `/raw?p=${encodeURIComponent('/etc/passwd')}&t=${TOKEN}`)).res.statusCode, 404);
  assert.equal((await get(port, q('a.txt', '&download=1'))).res.headers['content-disposition'], 'attachment; filename="a.txt"');
  await app.close();
});

test('a first message reaches the agent as an argument, made safe', async () => {
  const { app, made, port } = await boot();
  const c = client(port);
  await c.open;
  c.ws.send(JSON.stringify({ type: 'auth', token: TOKEN }));
  await c.next((m) => m.type === 'authed');
  const go = async (agentId, seed) => { c.ws.send(JSON.stringify({ type: 'create', kind: 'agent', agentId, seed })); await c.next((m) => m.type === 'created'); return made.at(-1); };
  assert.deepEqual((await go('claude', 'Make an agent; please;')).args, ['Make an agent; please.']);
  assert.deepEqual((await go('codex', '--dangerous do it')).args, ['dangerous do it']);
  assert.deepEqual((await go('opencode', 'hello')).args, ['--prompt', 'hello']);
  assert.deepEqual((await go('hermes', 'hello')).args, [], 'an agent without the option gets nothing');
  assert.deepEqual((await go('claude', '   ')).args, []);
  c.ws.close();
  await app.close();
});
