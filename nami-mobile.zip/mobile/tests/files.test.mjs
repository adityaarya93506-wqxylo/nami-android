import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';

const require = createRequire(import.meta.url);
const WebSocket = require('ws');
const { createWorkspace } = require('../server/workspace.js');
const library = require('../server/library.js');
const { createKeys } = require('../server/keys.js');
const { createRpc } = require('../server/rpc.js');
const { createServer } = require('../server/server.js');
const { SessionManager } = require('../server/sessions.js');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'nami-files-'));

function fixture() {
  const home = fs.realpathSync(tmp());
  fs.mkdirSync(path.join(home, 'work', 'sub'), { recursive: true });
  fs.writeFileSync(path.join(home, 'work', 'notes.md'), '# Hi\n\ntext');
  fs.writeFileSync(path.join(home, 'work', 'a.txt'), 'plain');
  fs.writeFileSync(path.join(home, 'work', 'pic.png'), Buffer.from([137, 80, 78, 71, 0, 1]));
  fs.writeFileSync(path.join(home, 'work', 'blob.bin'), Buffer.from([1, 2, 0, 3]));
  fs.writeFileSync(path.join(home, 'outside.txt'), 'secret');
  return home;
}

test('ls: folders first, sorted, with kinds', () => {
  const home = fixture();
  const ws = createWorkspace({ root: path.join(home, 'work'), home });
  const r = ws.ls();
  assert.equal(r.entries[0].name, 'sub');
  assert.equal(r.entries[0].type, 'dir');
  assert.deepEqual(r.entries.slice(1).map((e) => e.name), ['a.txt', 'blob.bin', 'notes.md', 'pic.png']);
  assert.equal(r.entries.find((e) => e.name === 'notes.md').kind, 'markdown');
  assert.equal(r.entries.find((e) => e.name === 'pic.png').kind, 'image');
  assert.equal(r.parent, null, 'no way up from the workspace root');
  assert.equal(ws.ls('sub').parent, path.join(home, 'work'));
});

test('read: text, image (no bytes), binary', () => {
  const home = fixture();
  const ws = createWorkspace({ root: path.join(home, 'work'), home });
  assert.equal(ws.read('notes.md').text, '# Hi\n\ntext');
  assert.equal(ws.read('notes.md').kind, 'markdown');
  const img = ws.read('pic.png');
  assert.equal(img.kind, 'image');
  assert.equal(img.text, undefined);
  assert.equal(ws.read('blob.bin').kind, 'binary');
});

test('nothing outside the workspace: .., absolute paths and symlinks are refused', () => {
  const home = fixture();
  fs.symlinkSync(path.join(home, 'outside.txt'), path.join(home, 'work', 'link.txt'));
  fs.symlinkSync(home, path.join(home, 'work', 'homelink'));
  const ws = createWorkspace({ root: path.join(home, 'work'), home });
  for (const p of ['../outside.txt', path.join(home, 'outside.txt'), '/etc/passwd', 'link.txt', 'homelink/outside.txt']) {
    assert.throws(() => ws.read(p), /outside|Not found/, p);
  }
  assert.throws(() => ws.write('../x.txt', 'x'), /outside/);
  assert.throws(() => ws.write('homelink/x.txt', 'x'), /outside/);
  assert.throws(() => ws.remove('..'), /outside/);
  assert.equal(fs.existsSync(path.join(home, 'x.txt')), false);
});

test('write is atomic, keeps the mode, and notices a changed file', () => {
  const home = fixture();
  const ws = createWorkspace({ root: path.join(home, 'work'), home });
  const r0 = ws.read('a.txt');
  const w = ws.write('a.txt', 'new text', r0.mtime);
  assert.equal(fs.readFileSync(path.join(home, 'work', 'a.txt'), 'utf8'), 'new text');
  assert.ok(w.mtime >= r0.mtime);
  fs.utimesSync(path.join(home, 'work', 'a.txt'), new Date(), new Date(Date.now() + 5000));
  assert.throws(() => ws.write('a.txt', 'stale', w.mtime), (e) => e.code === 'conflict');
  assert.deepEqual(fs.readdirSync(path.join(home, 'work')).filter((n) => n.endsWith('.tmp')), [], 'no temp files left');
  ws.write('brand-new.txt', 'x');
  assert.equal(fs.readFileSync(path.join(home, 'work', 'brand-new.txt'), 'utf8'), 'x');
});

test('make, rename and delete', () => {
  const home = fixture();
  const ws = createWorkspace({ root: path.join(home, 'work'), home });
  ws.mkdir('.', 'newdir');
  ws.touch('newdir', 'f.md');
  assert.ok(fs.existsSync(path.join(home, 'work', 'newdir', 'f.md')));
  assert.throws(() => ws.mkdir('.', 'newdir'), /taken/);
  assert.throws(() => ws.touch('.', '../evil'), /not allowed/);
  assert.throws(() => ws.mkdir('.', 'a/b'), /not allowed/);
  ws.rename('newdir/f.md', 'g.md');
  assert.ok(fs.existsSync(path.join(home, 'work', 'newdir', 'g.md')));
  assert.throws(() => ws.rename('newdir', 'sub'), /taken/);
  ws.remove('newdir');
  assert.equal(fs.existsSync(path.join(home, 'work', 'newdir')), false);
  assert.throws(() => ws.remove('.'), /cannot be deleted/);
});

test('put: a file comes in by pieces, never overwrites, and leaves no part file behind', () => {
  const home = fixture();
  const ws = createWorkspace({ root: path.join(home, 'work'), home });
  const data = Buffer.from('hello world from the phone');
  const a = data.subarray(0, 10).toString('base64'); const b = data.subarray(10).toString('base64');
  assert.equal(ws.put('.', 'in.txt', a, { first: true }).done, false);
  const r = ws.put('.', 'in.txt', b, { last: true });
  assert.equal(r.done, true);
  assert.equal(fs.readFileSync(path.join(home, 'work', 'in.txt'), 'utf8'), 'hello world from the phone');
  const again = ws.put('.', 'in.txt', data.toString('base64'), { first: true, last: true });
  assert.equal(path.basename(again.path), 'in (1).txt');
  assert.equal(fs.readFileSync(path.join(home, 'work', 'in.txt'), 'utf8'), 'hello world from the phone');
  assert.deepEqual(fs.readdirSync(path.join(home, 'work')).filter((n) => n.includes('.part')), []);
  assert.throws(() => ws.put('.', 'x.txt', a, { last: true }), /interrupted/);
  assert.throws(() => ws.put('.', '../x.txt', a, { first: true }), /not allowed/);
  assert.throws(() => ws.put('..', 'x.txt', a, { first: true }), /outside/);
});

test('changing the workspace folder', () => {
  const home = fixture();
  const ws = createWorkspace({ root: home, home });
  ws.setRoot(path.join(home, 'work'));
  assert.equal(ws.root, path.join(home, 'work'));
  assert.throws(() => ws.setRoot(path.join(home, 'nope')), /does not exist/);
  assert.throws(() => ws.setRoot(path.join(home, 'work', 'a.txt')), /not a folder/);
  assert.throws(() => ws.read('../outside.txt'), /outside/);
});

test('library: finds claude and codex agents and skills, and creates new ones', () => {
  const home = tmp();
  const proj = path.join(home, 'proj');
  fs.mkdirSync(path.join(home, '.claude', 'agents'), { recursive: true });
  fs.writeFileSync(path.join(home, '.claude', 'agents', 'writer.md'), '---\nname: writer\ndescription: Writes the weekly update\n---\nBody');
  fs.mkdirSync(path.join(home, '.claude', 'skills', 'pdf-tools'), { recursive: true });
  fs.writeFileSync(path.join(home, '.claude', 'skills', 'pdf-tools', 'SKILL.md'), '---\nname: pdf-tools\ndescription: >\n  Handle PDFs\n  well\n---\nx');
  fs.mkdirSync(path.join(home, '.codex', 'agents'), { recursive: true });
  fs.writeFileSync(path.join(home, '.codex', 'agents', 'reviewer.toml'), 'name = "reviewer"\ndescription = "Reviews code"\ndeveloper_instructions = """\nname = "not me"\n"""\n');
  fs.mkdirSync(path.join(proj, '.claude', 'agents'), { recursive: true });
  fs.writeFileSync(path.join(proj, '.claude', 'agents', 'local.md'), 'no frontmatter');
  const items = library.scan({ home, project: proj });
  const by = (n) => items.find((i) => i.name === n);
  assert.equal(by('writer').description, 'Writes the weekly update');
  assert.equal(by('writer').platform, 'claude');
  assert.equal(by('pdf-tools').type, 'skill');
  assert.equal(by('pdf-tools').description, 'Handle PDFs well');
  assert.equal(by('reviewer').platform, 'codex');
  assert.equal(by('reviewer').description, 'Reviews code');
  assert.equal(by('local').scope, 'project');
  assert.equal(items.length, 4);

  const made = library.create({ home, project: proj, platform: 'claude', scope: 'user', type: 'agent', name: 'Client Reporter!', description: 'Friday update' });
  assert.equal(path.basename(made.path), 'client-reporter.md');
  assert.match(fs.readFileSync(made.path, 'utf8'), /^---\nname: client-reporter\ndescription: Friday update\n---/);
  assert.throws(() => library.create({ home, project: proj, platform: 'claude', scope: 'user', type: 'agent', name: 'client reporter' }), /already exists/);
  const sk = library.create({ home, project: proj, platform: 'claude', scope: 'project', type: 'skill', name: 'deploy' });
  assert.ok(sk.path.endsWith(path.join('proj', '.claude', 'skills', 'deploy', 'SKILL.md')));
  const cx = library.create({ home, project: proj, platform: 'codex', scope: 'user', type: 'agent', name: 'planner', description: 'a "quoted" thing' });
  assert.match(fs.readFileSync(cx.path, 'utf8'), /description = "a \\"quoted\\" thing"/);
  assert.throws(() => library.create({ home, project: proj, platform: 'claude', scope: 'user', type: 'agent', name: '!!!' }), /name/);
  assert.equal(library.allowed(made.path, { home, project: proj }), true);
  assert.equal(library.allowed(path.join(home, 'secret.txt'), { home, project: proj }), false);
});

test('keys: saved privately, masked for the page, merged on edit, validated', () => {
  const dir = tmp();
  const file = path.join(dir, 'sub', 'keys.json');
  const keys = createKeys({ file });
  const id = keys.save({ name: 'My proxy', agent: 'claude', env: { ANTHROPIC_BASE_URL: 'https://x.example/v1', ANTHROPIC_AUTH_TOKEN: 'sk-secret-1234567' } });
  assert.equal(fs.statSync(file).mode & 0o777, 0o600);
  const l = keys.list();
  assert.equal(l.length, 1);
  assert.equal(l[0].vars.find((v) => v.name === 'ANTHROPIC_BASE_URL').preview, 'https://x.example/v1');
  assert.equal(l[0].vars.find((v) => v.name === 'ANTHROPIC_AUTH_TOKEN').preview, '•••• 4567');
  assert.ok(!JSON.stringify(l).includes('sk-secret'));
  keys.save({ id, name: 'My proxy 2', env: { ANTHROPIC_BASE_URL: 'https://y.example', ANTHROPIC_AUTH_TOKEN: '' } });
  assert.equal(keys.envFor(id).ANTHROPIC_AUTH_TOKEN, 'sk-secret-1234567', 'empty keeps the saved secret');
  assert.equal(keys.envFor(id).ANTHROPIC_BASE_URL, 'https://y.example');
  for (const bad of [{ 'bad name': 'x' }, { PATH: '/x' }, { A: 'line\nbreak' }, { A: 'ends;' }, {}]) {
    assert.throws(() => keys.save({ name: 'x', env: bad }), Error, JSON.stringify(bad));
  }
  assert.throws(() => keys.save({ name: ' ', env: { A: '1' } }), /name/);
  assert.deepEqual(keys.envFor(null), {});
  assert.throws(() => keys.envFor('nope'), /gone/);
  keys.remove(id);
  assert.equal(keys.list().length, 0);
});

// ---- over the socket -------------------------------------------------------

const TOKEN = 'b'.repeat(48);
async function boot() {
  const home = fixture();
  const made = [];
  const spawn = (file, args, opts) => { const p = { file, args, opts, pid: 1, resizable: true, onData() {}, onExit() {}, write() {}, resize: () => true, kill() {} }; made.push(p); return p; };
  const manager = new SessionManager({ spawnPty: spawn, env: { SHELL: '/bin/sh' }, home });
  const workspace = createWorkspace({ root: home, home });
  const keys = createKeys({ file: path.join(home, '.keys.json') });
  const rpc = createRpc({ workspace, keys, home });
  const app = createServer({ manager, token: TOKEN, listAgentsFn: () => [], rpc, keys, workspace });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  return { app, home, made, keys, port: app.server.address().port };
}

function client(port) {
  const ws = new WebSocket(`ws://127.0.0.1:${port}/ws`);
  const waiters = []; const inbox = [];
  ws.on('message', (raw) => {
    const m = JSON.parse(raw.toString());
    const i = waiters.findIndex((w) => w.pred(m));
    if (i >= 0) waiters.splice(i, 1)[0].resolve(m); else inbox.push(m);
  });
  const next = (pred) => new Promise((resolve, reject) => {
    const j = inbox.findIndex(pred);
    if (j >= 0) return resolve(inbox.splice(j, 1)[0]);
    const t = setTimeout(() => reject(new Error('timeout')), 3000);
    waiters.push({ pred, resolve: (m) => { clearTimeout(t); resolve(m); } });
  });
  let n = 0;
  const call = async (op, args) => { const id = 'r' + ++n; ws.send(JSON.stringify({ type: 'rpc', id, op, args })); return next((m) => m.type === 'rpc' && m.id === id); };
  const open = new Promise((r) => ws.on('open', r));
  return { ws, next, call, open };
}

test('socket: rpc needs the token; files, library and keys answer', async () => {
  const { app, home, port } = await boot();
  const c = client(port);
  await c.open;
  c.ws.send(JSON.stringify({ type: 'rpc', id: 'x', op: 'fs.ls', args: {} }));
  await new Promise((r) => c.ws.on('close', r));            // not signed in: closed, no answer
  const d = client(port);
  await d.open;
  d.ws.send(JSON.stringify({ type: 'auth', token: TOKEN }));
  const authed = await d.next((m) => m.type === 'authed');
  assert.equal(authed.root, home);
  const ls = await d.call('fs.ls', { path: path.join(home, 'work') });
  assert.equal(ls.ok, true);
  assert.ok(ls.data.entries.some((e) => e.name === 'notes.md'));
  const bad = await d.call('fs.read', { path: '/etc/passwd' });
  assert.equal(bad.ok, false);
  assert.match(bad.error, /outside/);
  assert.equal((await d.call('nope.nope', {})).ok, false);
  const w = await d.call('fs.write', { path: path.join(home, 'work', 'a.txt'), text: 'via socket' });
  assert.equal(w.ok, true);
  assert.equal(fs.readFileSync(path.join(home, 'work', 'a.txt'), 'utf8'), 'via socket');
  const sk = await d.call('keys.save', { name: 'P', env: { OPENAI_API_KEY: 'sk-abc12345' } });
  assert.equal(sk.ok, true);
  const list = await d.call('keys.list', {});
  assert.equal(list.data.providers[0].vars[0].preview, '•••• 2345');
  d.ws.close();
  await app.close();
});

test('socket: a session created with a provider gets its variables', async () => {
  const { app, made, keys, port } = await boot();
  const id = keys.save({ name: 'Proxy', env: { ANTHROPIC_BASE_URL: 'https://p.example', ANTHROPIC_AUTH_TOKEN: 'tok' } });
  const c = client(port);
  await c.open;
  c.ws.send(JSON.stringify({ type: 'auth', token: TOKEN }));
  await c.next((m) => m.type === 'authed');
  c.ws.send(JSON.stringify({ type: 'create', kind: 'shell', providerId: id }));
  await c.next((m) => m.type === 'created');
  assert.equal(made.at(-1).opts.env.ANTHROPIC_BASE_URL, 'https://p.example');
  assert.equal(made.at(-1).opts.env.ANTHROPIC_AUTH_TOKEN, 'tok');
  c.ws.send(JSON.stringify({ type: 'create', kind: 'shell', providerId: 'missing' }));
  const err = await c.next((m) => m.type === 'error');
  assert.match(err.message, /gone/);
  c.ws.close();
  await app.close();
});

function get(port, url) {
  return new Promise((resolve, reject) => {
    http.get({ host: '127.0.0.1', port, path: url, headers: { Host: `127.0.0.1:${port}` } }, (res) => {
      const chunks = []; res.on('data', (d) => chunks.push(d)); res.on('end', () => resolve({ res, body: Buffer.concat(chunks) }));
    }).on('error', reject);
  });
}

test('/raw: needs the token, serves images with ranges, never runs html', async () => {
  const { app, home, port } = await boot();
  fs.writeFileSync(path.join(home, 'work', 'page.html'), '<script>1</script>');
  const q = (p, extra = '') => `/raw?p=${encodeURIComponent(path.join(home, 'work', p))}&t=${TOKEN}${extra}`;
  assert.equal((await get(port, `/raw?p=${encodeURIComponent(path.join(home, 'work', 'pic.png'))}`)).res.statusCode, 403);
  assert.equal((await get(port, q('pic.png').replace(TOKEN, 'c'.repeat(48)))).res.statusCode, 403);
  const ok = await get(port, q('pic.png'));
  assert.equal(ok.res.statusCode, 200);
  assert.equal(ok.res.headers['content-type'], 'image/png');
  assert.match(ok.res.headers['content-security-policy'], /sandbox/);
  assert.equal(ok.body.length, 6);
  const part = await new Promise((resolve) => http.get({ host: '127.0.0.1', port, path: q('pic.png'), headers: { Range: 'bytes=1-2' } }, (res) => { const c = []; res.on('data', (d) => c.push(d)); res.on('end', () => resolve({ res, body: Buffer.concat(c) })); }));
  assert.equal(part.res.statusCode, 206);
  assert.equal(part.res.headers['content-range'], 'bytes 1-2/6');
  assert.deepEqual([...part.body], [80, 78]);
  const html = await get(port, q('page.html'));
  assert.equal(html.res.headers['content-type'], 'application/octet-stream', 'html is never rendered from here');
  assert.equal((await get(port, `/raw?p=${encodeURIComponent('/etc/passwd')}&t=${TOKEN}`)).res.statusCode, 404);
  assert.equal((await get(port, q('a.txt', '&download=1'))).res.headers['content-disposition'], 'attachment; filename="a.txt"');
  await app.close();
});

test('a first message reaches the agent as an argument, made safe', async () => {
  const { app, made, port } = await boot();
  const c = client(port);
  await c.open;
  c.ws.send(JSON.stringify({ type: 'auth', token: TOKEN }));
  await c.next((m) => m.type === 'authed');
  const go = async (agentId, seed) => { c.ws.send(JSON.stringify({ type: 'create', kind: 'agent', agentId, seed })); await c.next((m) => m.type === 'created'); return made.at(-1); };
  assert.deepEqual((await go('claude', 'Make an agent; please;')).args, ['Make an agent; please.']);
  assert.deepEqual((await go('codex', '--dangerous do it')).args, ['dangerous do it']);
  assert.deepEqual((await go('opencode', 'hello')).args, ['--prompt', 'hello']);
  assert.deepEqual((await go('hermes', 'hello')).args, [], 'an agent without the option gets nothing');
  assert.deepEqual((await go('claude', '   ')).args, []);
  c.ws.close();
  await app.close();
});

test('duplicate and move stay inside the workspace and never overwrite', async () => {
  const { createWorkspace } = await import('../server/workspace.js').then((m) => m.default || m);
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'nami-dm-'));
  const ws = createWorkspace({ root, home: root });
  fs.mkdirSync(path.join(root, 'a')); fs.mkdirSync(path.join(root, 'b'));
  fs.writeFileSync(path.join(root, 'a', 'x.txt'), 'hi');
  const c1 = ws.duplicate(path.join(root, 'a', 'x.txt'));
  assert.equal(path.basename(c1.path), 'x copy.txt');
  assert.equal(path.basename(ws.duplicate(path.join(root, 'a', 'x.txt')).path), 'x copy 2.txt');
  assert.equal(path.basename(ws.duplicate(path.join(root, 'a')).path), 'a copy');
  assert.equal(fs.readFileSync(path.join(root, 'a copy', 'x.txt'), 'utf8'), 'hi');
  ws.move(path.join(root, 'a', 'x.txt'), path.join(root, 'b'));
  assert.ok(fs.existsSync(path.join(root, 'b', 'x.txt')));
  fs.writeFileSync(path.join(root, 'a', 'x.txt'), 'other');
  assert.throws(() => ws.move(path.join(root, 'a', 'x.txt'), path.join(root, 'b')), /taken/);
  assert.throws(() => ws.move(path.join(root, 'a'), path.join(root, 'a', 'sub')), /./);
  fs.mkdirSync(path.join(root, 'a', 'sub'));
  assert.throws(() => ws.move(path.join(root, 'a'), path.join(root, 'a', 'sub')), /inside itself/);
  assert.throws(() => ws.move(path.join(root, 'a'), os.tmpdir()), /./);
  assert.throws(() => ws.duplicate(root), /workspace folder itself/);
});

test('recents, pictures and resume over rpc', async () => {
  const { createRpc } = await import('../server/rpc.js').then((m) => m.default || m);
  const { createWorkspace } = await import('../server/workspace.js').then((m) => m.default || m);
  const agents = await import('../server/agents.js').then((m) => m.default || m);
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'nami-rc-'));
  for (const d of ['p', 'q']) fs.mkdirSync(path.join(root, d));
  let store = {};
  const pasted = fs.mkdtempSync(path.join(os.tmpdir(), 'nami-pp-'));
  const rpc = createRpc({ workspace: createWorkspace({ root, home: root }), keys: { list() { return []; } }, home: root,
    settings: { get: () => store, set: (p) => { store = { ...store, ...p }; } }, attach: createWorkspace({ root: pasted, home: pasted }) });
  rpc.handle('fs.setRoot', { path: path.join(root, 'p') });
  rpc.handle('fs.setRoot', { path: path.join(root, 'q') });
  let r = rpc.handle('fs.recents', {}).recents;
  assert.deepEqual(r.map((x) => path.basename(x.path)), ['q', 'p']);
  rpc.handle('fs.recentPin', { path: path.join(root, 'p'), pinned: true });
  rpc.handle('fs.setRoot', { path: path.join(root, 'q') });
  r = rpc.handle('fs.recents', {}).recents;
  assert.equal(path.basename(r[0].path) === 'q' || path.basename(r[0].path) === 'p', true);
  assert.equal(r.find((x) => path.basename(x.path) === 'p').pinned, true);
  rpc.handle('fs.recentRemove', { path: path.join(root, 'q') });
  assert.equal(rpc.handle('fs.recents', {}).recents.length, 1);
  fs.rmSync(path.join(root, 'p'), { recursive: true });
  assert.equal(rpc.handle('fs.recents', {}).recents.length, 0, 'a folder that is gone is not offered');
  const put = rpc.handle('attach.put', { name: 'my pic (1).png', b64: Buffer.from('png').toString('base64'), first: true, last: true });
  assert.ok(put.path.startsWith(pasted) && !/[ ()]/.test(path.basename(put.path)));
  assert.equal(fs.readFileSync(put.path, 'utf8'), 'png');
  assert.deepEqual(agents.resumeArgs(agents.findAgent('claude')), ['--continue']);
  assert.deepEqual(agents.resumeArgs(agents.findAgent('codex')), ['resume', '--last']);
  assert.deepEqual(agents.resumeArgs(agents.findAgent('hermes')), []);
});

test('connections: written into each agent\'s own settings, kept private, removable, nothing else touched', () => {
  const { createConnections } = require('../server/connections');
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'nami-cn-'));
  const data = fs.mkdtempSync(path.join(os.tmpdir(), 'nami-cd-'));
  fs.mkdirSync(path.join(home, '.codex'));
  fs.writeFileSync(path.join(home, '.codex', 'config.toml'), 'model = "gpt-5"\n');
  fs.writeFileSync(path.join(home, '.claude.json'), JSON.stringify({ theme: 'dark', mcpServers: { mine: { command: 'x' } } }));
  const file = path.join(data, 'connections.json');
  const c = createConnections({ file, home });
  assert.throws(() => c.connect('notion', { token: '' }), /Enter/);
  assert.throws(() => c.connect('nope', {}), /Unknown/);
  assert.throws(() => c.connect('notion', { token: 'a\nb' }), /Enter/);
  const r = c.connect('notion', { token: 'ntn_secret' });
  assert.deepEqual(r.delivered, { claude: true, opencode: true, codex: true });
  const claude = JSON.parse(fs.readFileSync(path.join(home, '.claude.json'), 'utf8'));
  assert.equal(claude.theme, 'dark'); assert.equal(claude.mcpServers.mine.command, 'x');
  assert.equal(claude.mcpServers.notion.env.NOTION_TOKEN, 'ntn_secret');
  const oc = JSON.parse(fs.readFileSync(path.join(home, '.config/opencode/opencode.json'), 'utf8'));
  assert.deepEqual(oc.mcp.notion.command.slice(0, 2), ['npx', '-y']);
  assert.equal(oc.mcp.notion.environment.NOTION_TOKEN, 'ntn_secret');
  let toml = fs.readFileSync(path.join(home, '.codex/config.toml'), 'utf8');
  assert.match(toml, /^model = "gpt-5"/); assert.match(toml, /\[mcp_servers\.notion\]/); assert.match(toml, /NOTION_TOKEN = "ntn_secret"/);
  assert.equal(fs.statSync(file).mode & 0o777, 0o600);
  const list = c.list();
  assert.equal(list.find((x) => x.id === 'notion').connected, true);
  assert.ok(!JSON.stringify(list).includes('ntn_secret'), 'the page never gets a key back');
  c.connect('folder', { folder: '/root/p' });
  assert.equal(c.list().find((x) => x.id === 'folder').fields[0].value, '/root/p');
  c.connect('browser', {});
  assert.ok(JSON.parse(fs.readFileSync(path.join(home, '.claude.json'), 'utf8')).mcpServers.browser.args.includes('--config'));
  assert.match(fs.readFileSync(path.join(home, '.codex/config.toml'), 'utf8'), /\[mcp_servers\.browser\]/);
  c.disconnect('browser');
  c.disconnect('notion');
  assert.equal(JSON.parse(fs.readFileSync(path.join(home, '.claude.json'), 'utf8')).mcpServers.notion, undefined);
  assert.ok(JSON.parse(fs.readFileSync(path.join(home, '.claude.json'), 'utf8')).mcpServers.folder);
  toml = fs.readFileSync(path.join(home, '.codex/config.toml'), 'utf8');
  assert.ok(!toml.includes('notion') && toml.includes('server-filesystem') && toml.startsWith('model = "gpt-5"'));
  c.disconnect('folder');
  toml = fs.readFileSync(path.join(home, '.codex/config.toml'), 'utf8');
  assert.equal(toml.trim(), 'model = "gpt-5"');
  // a settings file we cannot read is left alone
  fs.writeFileSync(path.join(home, '.claude.json'), '{ broken');
  const r2 = c.connect('slack', { token: 'xoxb-1' });
  assert.match(r2.delivered.claude, /left alone/);
  assert.equal(fs.readFileSync(path.join(home, '.claude.json'), 'utf8'), '{ broken');
  assert.equal(r2.delivered.codex, true);
});

test('usage: tokens counted from Claude and Codex records, per day, without double counting', () => {
  const { usage, dayKey } = require('../server/usage');
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'nami-us-'));
  const now = Date.now();
  const iso = (ms) => new Date(ms).toISOString();
  fs.mkdirSync(path.join(home, '.claude/projects/p'), { recursive: true });
  const line = (id, ms, i, o, c) => JSON.stringify({ timestamp: iso(ms), requestId: 'r' + id, message: { id: 'm' + id, usage: { input_tokens: i, output_tokens: o, cache_read_input_tokens: c, cache_creation_input_tokens: 0 } } });
  fs.writeFileSync(path.join(home, '.claude/projects/p/a.jsonl'), [line(1, now - 1000, 10, 5, 100), line(1, now - 900, 10, 5, 100), line(2, now - 2 * 864e5, 7, 3, 0), 'not json "usage"', line(3, now - 30 * 864e5, 99, 99, 0)].join('\n'));
  fs.mkdirSync(path.join(home, '.codex/sessions/2026/10/30'), { recursive: true });
  fs.writeFileSync(path.join(home, '.codex/sessions/2026/10/30/rollout-x.jsonl'),
    [JSON.stringify({ payload: { info: { total_token_usage: { input_tokens: 50, cached_input_tokens: 20, output_tokens: 9 } } } }),
      JSON.stringify({ payload: { info: { total_token_usage: { input_tokens: 80, cached_input_tokens: 30, output_tokens: 12 } } } })].join('\n'));
  const r = usage({ home, now });
  const c = r.agents.find((a) => a.id === 'claude');
  assert.equal(c.days.length, 7);
  assert.deepEqual([c.today.input, c.today.output, c.today.cached, c.today.turns], [10, 5, 100, 1], 'a repeated record counts once');
  assert.equal(c.total.input, 17); assert.equal(c.total.turns, 2, 'the 30-day-old one is left out');
  const x = r.agents.find((a) => a.id === 'codex');
  assert.equal(x.total.input, 50); assert.equal(x.total.output, 12); assert.equal(x.total.cached, 30);
  assert.equal(c.days[6].day, dayKey(now));
  assert.equal(usage({ home: fs.mkdtempSync(path.join(os.tmpdir(), 'nami-us0-')), now }).agents[0].total.turns, 0);
});

test('resume: finds the last conversation in a folder from each agent\'s own records', () => {
  const { resumeFor, canResume } = require('../server/resume');
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'nami-rs-'));
  const cwd = '/root/proj';
  // kimi: two conversations here, the one whose folder was touched last wins
  const k1 = path.join(home, 'k1'), k2 = path.join(home, 'k2'); fs.mkdirSync(k1); fs.mkdirSync(k2);
  fs.utimesSync(k1, new Date(1e9), new Date(1e9)); fs.utimesSync(k2, new Date(2e9), new Date(2e9));
  fs.mkdirSync(path.join(home, '.kimi-code'));
  fs.writeFileSync(path.join(home, '.kimi-code/session_index.jsonl'), [{ sessionId: 'a1', sessionDir: k1, workDir: cwd }, { sessionId: 'b2', sessionDir: k2, workDir: cwd + '/' }, { sessionId: 'zz', sessionDir: k2, workDir: '/other' }, { sessionId: 'bad id!', sessionDir: k2, workDir: cwd }].map((x) => JSON.stringify(x)).join('\n'));
  assert.deepEqual(resumeFor('kimi', { home, cwd }), ['-r', 'b2']);
  assert.deepEqual(resumeFor('kimi', { home, cwd: '/nowhere' }), [], 'nothing to continue');
  // codex: by the session_meta line, falling back to --last
  const day = path.join(home, '.codex/sessions/2026/10/30'); fs.mkdirSync(day, { recursive: true });
  fs.writeFileSync(path.join(day, 'rollout-1.jsonl'), JSON.stringify({ type: 'session_meta', payload: { session_id: 'cx-9', cwd } }) + '\n');
  assert.deepEqual(resumeFor('codex', { home, cwd }), ['resume', 'cx-9']);
  assert.deepEqual(resumeFor('codex', { home, cwd: '/nowhere' }), ['resume', '--last']);
  // grok: one folder per conversation, under the encoded path
  fs.mkdirSync(path.join(home, '.grok/sessions', encodeURIComponent(cwd), 'g-1'), { recursive: true });
  assert.deepEqual(resumeFor('grok', { home, cwd }), ['--resume', 'g-1']);
  // antigravity: a map from folder to conversation
  fs.mkdirSync(path.join(home, '.gemini/antigravity-cli/cache'), { recursive: true });
  fs.writeFileSync(path.join(home, '.gemini/antigravity-cli/cache/last_conversations.json'), JSON.stringify({ [cwd]: 'agy-3', '/x': '../../etc' }));
  assert.deepEqual(resumeFor('antigravity', { home, cwd }), ['--conversation', 'agy-3']);
  assert.deepEqual(resumeFor('antigravity', { home, cwd: '/x' }), [], 'an id that is a path is refused');
  assert.deepEqual(resumeFor('claude', { home, cwd }), ['--continue']);
  assert.equal(canResume('nope'), false); assert.deepEqual(resumeFor('nope', { home, cwd }), []);
});

test('connections: your own server, a .mcpb bundle, and Kie', () => {
  const { createConnections } = require('../server/connections');
  const { spawnSync } = require('node:child_process');
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'nami-cc-'));
  const data = fs.mkdtempSync(path.join(os.tmpdir(), 'nami-cdd-'));
  const c = createConnections({ file: path.join(data, 'connections.json'), home });
  for (const bad of [{ command: 'rm -rf /', args: [] }, { command: 'npx', args: 'x' }, { command: 'npx', args: [], env: { PATH: '/x' } }, { command: 'npx', args: [], env: { A: 'x\ny' } }, { command: '', args: [] }]) assert.throws(() => c.connectCustom('mine', bad), /./, JSON.stringify(bad));
  assert.throws(() => c.connectCustom('Notion!', { command: 'npx', args: [] }), /short name/);
  assert.throws(() => c.connectCustom('notion', { command: 'npx', args: [] }), /short name/, 'a name the list already uses');
  const r = c.connectCustom('mine', { command: 'npx', args: ['-y', 'some-mcp'], env: { TOKEN: 'sek' } });
  assert.deepEqual(r.delivered, { claude: true, opencode: true, codex: true });
  assert.equal(JSON.parse(fs.readFileSync(path.join(home, '.claude.json'), 'utf8')).mcpServers.mine.env.TOKEN, 'sek');
  assert.match(fs.readFileSync(path.join(home, '.codex/config.toml'), 'utf8'), /\[mcp_servers\.mine\]/);
  assert.deepEqual(c.customList(), [{ id: 'mine', command: 'npx', args: ['-y', 'some-mcp'], envNames: ['TOKEN'] }], 'values never come back');
  // a bundle
  const src = fs.mkdtempSync(path.join(os.tmpdir(), 'nami-bd-'));
  fs.writeFileSync(path.join(src, 'manifest.json'), JSON.stringify({ name: 'tool', server: { type: 'node', mcp_config: { command: 'node', args: ['${__dirname}/server.js'], env: { MODE: 'x' } } } }));
  fs.writeFileSync(path.join(src, 'server.js'), '');
  const bundle = path.join(src, 'My Tool.mcpb');
  assert.equal(spawnSync('zip', ['-qj', bundle, path.join(src, 'manifest.json'), path.join(src, 'server.js')]).status, 0);
  const b = c.importBundle(bundle, data);
  assert.equal(b.id, 'my-tool');
  const e = JSON.parse(fs.readFileSync(path.join(home, '.claude.json'), 'utf8')).mcpServers['my-tool'];
  assert.equal(e.args[0], path.join(data, 'bundles', 'my-tool', 'server.js')); assert.ok(fs.existsSync(e.args[0]));
  fs.writeFileSync(path.join(src, 'manifest.json'), JSON.stringify({ server: { mcp_config: { command: 'node', args: ['${user_config.key}'] } } }));
  const bundle2 = path.join(src, 'ask.mcpb'); spawnSync('zip', ['-qj', bundle2, path.join(src, 'manifest.json')]);
  assert.throws(() => c.importBundle(bundle2, data), /settings/);
  fs.writeFileSync(path.join(src, 'x.txt'), 'x'); const bundle3 = path.join(src, 'no.mcpb'); spawnSync('zip', ['-qj', bundle3, path.join(src, 'x.txt')]);
  assert.throws(() => c.importBundle(bundle3, data), /not an MCP bundle/);
  // removing yours takes it out of every agent
  c.disconnect('mine');
  assert.equal(JSON.parse(fs.readFileSync(path.join(home, '.claude.json'), 'utf8')).mcpServers.mine, undefined);
  assert.ok(!fs.readFileSync(path.join(home, '.codex/config.toml'), 'utf8').includes('mcp_servers.mine'));
  // Kie points at the built copy in the home folder
  c.connect('kie', { token: 'kie_x' });
  assert.deepEqual(JSON.parse(fs.readFileSync(path.join(home, '.claude.json'), 'utf8')).mcpServers.kie.args, [`${home}/kie-mcp/dist/index.js`]);
});

test('library: one agent delivered to every tool in its own format, adopted, imported, copied', () => {
  const { createRpc } = require('../server/rpc');
  const { createWorkspace } = require('../server/workspace');
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'nami-lb-'));
  const proj = path.join(home, 'proj'); fs.mkdirSync(path.join(proj, '.claude/agents'), { recursive: true });
  const rpc = createRpc({ workspace: createWorkspace({ root: proj, home }), keys: { list() { return []; } }, home });
  const mine = path.join(proj, '.claude/agents/reviewer.md');
  fs.writeFileSync(mine, '---\nname: reviewer\ndescription: Reviews code\n---\nBe strict.\n');
  const ids = ['claude', 'codex', 'opencode', 'hermes'];
  const a = rpc.handle('lib.adopt', { path: mine, platform: 'claude', agentIds: ids });
  assert.equal(a.slug, 'reviewer');
  assert.ok(fs.existsSync(path.join(proj, 'agents/reviewer.md')), 'the master');
  assert.match(fs.readFileSync(path.join(proj, '.codex/agents/reviewer.toml'), 'utf8'), /developer_instructions = """\nBe strict\./);
  assert.match(fs.readFileSync(path.join(proj, '.opencode/agents/reviewer.md'), 'utf8'), /mode: all/);
  assert.match(fs.readFileSync(mine, 'utf8'), /made by Nami from agents\/reviewer\.md/, 'the original became a marked copy');
  assert.equal(a.delivered.find((d) => d.agent === 'hermes').none, true);
  assert.deepEqual(rpc.handle('lib.state', { slug: 'reviewer', agentIds: ['codex', 'claude'] }).state.map((s) => s.state), ['here', 'here']);
  // a hand-made file of the same name is never overwritten
  fs.mkdirSync(path.join(proj, '.codex/agents'), { recursive: true }); fs.writeFileSync(path.join(proj, '.codex/agents/reviewer.toml'), 'name = "mine"\n');
  assert.equal(rpc.handle('lib.deliver', { agentIds: ['codex'] }).delivered[0].theirs, true);
  assert.equal(fs.readFileSync(path.join(proj, '.codex/agents/reviewer.toml'), 'utf8'), 'name = "mine"\n');
  // import a personal agent from the home folder: read, never written
  fs.mkdirSync(path.join(home, '.claude/agents'), { recursive: true });
  const personal = path.join(home, '.claude/agents/helper.md'); fs.writeFileSync(personal, '---\nname: helper\ndescription: Helps\n---\nHelp.\n');
  const im = rpc.handle('lib.import', { path: personal, agentIds: ['claude'] });
  assert.ok(fs.existsSync(path.join(proj, 'agents/helper.md'))); assert.ok(im.delivered[0].ok);
  assert.equal(fs.readFileSync(personal, 'utf8'), '---\nname: helper\ndescription: Helps\n---\nHelp.\n');
  assert.throws(() => rpc.handle('lib.import', { path: personal, agentIds: [] }), /already exists/);
  assert.throws(() => rpc.handle('lib.import', { path: '/etc/passwd', agentIds: [] }), /not an agent/);
  // duplicate
  assert.equal(path.basename(rpc.handle('lib.duplicate', { path: personal, type: 'agent' }).path), 'helper-copy.md');
  assert.equal(path.basename(rpc.handle('lib.duplicate', { path: personal, type: 'agent' }).path), 'helper-copy-1.md');
  fs.mkdirSync(path.join(home, '.claude/skills/tool'), { recursive: true }); fs.writeFileSync(path.join(home, '.claude/skills/tool/SKILL.md'), '---\nname: tool\ndescription: x\n---\n');
  assert.ok(fs.existsSync(rpc.handle('lib.duplicate', { path: path.join(home, '.claude/skills/tool/SKILL.md'), type: 'skill' }).path));
});

test('setup check reports tools, disk and install plan', async () => {
  const { check } = await import('../server/setup.js');
  const r = check({ home: '/tmp', agents: [{ id: 'x', name: 'X', installed: false, install: 'npm install -g x' }, { id: 'y', name: 'Y', installed: true, install: 'curl a | bash' }] });
  assert.ok(r.tools.find((t) => t.id === 'node').ok);
  assert.equal(r.plan.length, 1);
  assert.equal(typeof r.disk.freeMB, 'number');
});

test('agent sign-in status reads labels only, and Kimi/Hermes first messages go through the gate', async () => {
  const fs = await import('node:fs'); const os = await import('node:os'); const path = await import('node:path');
  const { agentState } = await import('../server/agent-state.js');
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'st-'));
  assert.equal(agentState('codex', { home }).signedIn, false);
  fs.mkdirSync(path.join(home, '.codex'));
  fs.writeFileSync(path.join(home, '.codex/auth.json'), JSON.stringify({ tokens: { account_id: 'a', access_token: 'SECRET' } }));
  const st = agentState('codex', { home });
  assert.equal(st.signedIn, true);
  assert.ok(!JSON.stringify(st).includes('SECRET'));
  assert.equal(st.login, 'codex login');
  const { findAgent, seedArgs, cleanSeed } = await import('../server/agents.js');
  assert.deepEqual(seedArgs(findAgent('grok'), 'hi'), ['--', 'hi']);
  assert.deepEqual(seedArgs(findAgent('antigravity'), 'hi'), ['--prompt-interactive=hi']);
  assert.equal(findAgent('kimi').gated, true);
  assert.equal(cleanSeed('--x hi;'), 'x hi.');
});

test('exit notes and the MCP check', async () => {
  const { exitNote } = await import('../server/exit-note.js');
  assert.equal(exitNote({ code: 0 }), 'finished');
  assert.equal(exitNote({ code: 129 }), 'terminal closed');
  assert.equal(exitNote({ code: 130 }), 'stopped');
  assert.equal(exitNote({ code: 2 }), 'exited · 2');
  const { checkServer } = await import('../server/mcp-check.js');
  const fake = `let b='';process.stdin.on('data',d=>{b+=d;let i;while((i=b.indexOf('\\n'))>=0){const l=b.slice(0,i);b=b.slice(i+1);const m=JSON.parse(l);if(m.method==='initialize')console.log(JSON.stringify({jsonrpc:'2.0',id:m.id,result:{}}));if(m.method==='tools/list')console.log(JSON.stringify({jsonrpc:'2.0',id:m.id,result:{tools:[{},{}]}}))}})`;
  assert.deepEqual(await checkServer({ command: process.execPath, args: ['-e', fake] }), { ok: true, tools: 2 });
  const bad = await checkServer({ command: process.execPath, args: ['-e', 'process.exit(3)'] });
  assert.equal(bad.ok, false);
});

test('Claude limit windows: installs only into an empty status line, reads what the script wrote', async () => {
  const fs = await import('node:fs'); const os = await import('node:os'); const path = await import('node:path');
  const quota = await import('../server/quota.js');
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'q-')); const dir = path.join(home, 'q');
  assert.equal(quota.status({ home, dir }).installed, false);
  const on = quota.install({ home, dir });
  assert.equal(on.installed, true);
  const { spawnSync } = await import('node:child_process');
  const r = spawnSync(process.execPath, [quota.SCRIPT, dir], { input: JSON.stringify({ rate_limits: { five_hour: { used_percentage: 40, resets_at: 1893456000 } } }), encoding: 'utf8' });
  assert.match(r.stdout, /60% left/);
  const st = quota.status({ home, dir });
  assert.equal(st.windows[0].used, 40);
  quota.remove({ home, dir });
  assert.equal(quota.status({ home, dir }).installed, false);
  fs.writeFileSync(path.join(home, '.claude/settings.json'), JSON.stringify({ statusLine: { type: 'command', command: 'mine' } }));
  assert.throws(() => quota.install({ home, dir }), /already have/);
});

test('library delete moves an item to trash and refuses things that are not library items', async () => {
  const fs = await import('node:fs'); const os = await import('node:os'); const path = await import('node:path');
  const { createRpc } = await import('../server/rpc.js');
  const { createWorkspace } = await import('../server/workspace.js');
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'ld-')); const proj = path.join(home, 'proj'); fs.mkdirSync(path.join(proj, '.claude/skills/demo'), { recursive: true });
  fs.writeFileSync(path.join(proj, '.claude/skills/demo/SKILL.md'), '---\nname: demo\ndescription: d\n---\nx');
  fs.writeFileSync(path.join(proj, 'notes.txt'), 'x');
  const ws = createWorkspace({ root: proj });
  const rpc = createRpc({ workspace: ws, keys: null, home, dataDir: path.join(home, 'data') });
  await assert.rejects(async () => rpc.handle ? rpc.handle('lib.delete', { path: path.join(proj, 'notes.txt') }) : rpc('lib.delete', { path: path.join(proj, 'notes.txt') }), /not an agent or skill/);
  const out = await (rpc.handle ? rpc.handle('lib.delete', { path: path.join(proj, '.claude/skills/demo/SKILL.md') }) : rpc('lib.delete', { path: path.join(proj, '.claude/skills/demo/SKILL.md') }));
  assert.ok(fs.existsSync(path.join(out.moved, 'SKILL.md')));
  assert.ok(!fs.existsSync(path.join(proj, '.claude/skills/demo')));
});

test('cloud voice: saves a key privately, sends the clip, never returns the key', async () => {
  const fs = await import('node:fs'); const os = await import('node:os'); const path = await import('node:path'); const http = await import('node:http');
  const { createVoice } = await import('../server/voice.js');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'v-'));
  let seen = null;
  const srv = http.createServer((req, res) => { let n = 0; req.on('data', (d) => { n += d.length; }); req.on('end', () => { seen = { auth: req.headers.authorization, url: req.url, n }; res.setHeader('content-type', 'application/json'); res.end(JSON.stringify({ text: ' hello there ' })); }); });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${srv.address().port}/v1`;
  const v = createVoice({ file: path.join(dir, 'voice.json') });
  assert.equal(v.status().configured, false);
  await assert.rejects(() => v.transcribe({ b64: 'AAAA', mime: 'audio/webm' }), /Settings/);
  assert.throws(() => v.save({ key: 'sk-x', baseUrl: 'http://example.com' }), /https/);
  const st = v.save({ key: 'sk-secret', baseUrl: base });
  assert.equal(st.configured, true);
  assert.ok(!JSON.stringify(st).includes('sk-secret'));
  assert.equal(fs.statSync(path.join(dir, 'voice.json')).mode & 0o777, 0o600);
  const out = await v.transcribe({ b64: Buffer.from('audio').toString('base64'), mime: 'audio/webm;codecs=opus' });
  assert.equal(out.text, 'hello there');
  assert.equal(seen.auth, 'Bearer sk-secret'); assert.equal(seen.url, '/v1/audio/transcriptions');
  await assert.rejects(() => v.transcribe({ b64: 'AAAA', mime: 'video/mp4' }), /not supported/);
  v.clear(); assert.equal(v.status().configured, false);
  srv.close();
});

test('browser connection writes a proot-safe Playwright config and points the agents at it', async () => {
  const fs = await import('node:fs'); const os = await import('node:os'); const path = await import('node:path');
  const { createConnections } = await import('../server/connections.js');
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'br-'));
  const c = createConnections({ file: path.join(home, 'conn.json'), home });
  c.connect('browser', {});
  const cfg = JSON.parse(fs.readFileSync(path.join(home, '.nami-browser.json'), 'utf8'));
  assert.ok(cfg.browser.launchOptions.args.includes('--no-sandbox'));
  assert.equal(cfg.browser.launchOptions.executablePath, '/usr/bin/chromium');
  const claude = JSON.parse(fs.readFileSync(path.join(home, '.claude.json'), 'utf8'));
  assert.deepEqual(claude.mcpServers.browser.args.slice(-2), ['--config', path.join(home, '.nami-browser.json')]);
});

test('storage: info lists the folders, backup writes a tar.gz and keeps only the last three', async () => {
  const storage = require('../server/storage.js');
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'nami-st-'));
  fs.writeFileSync(path.join(home, 'notes.txt'), 'hello');
  fs.mkdirSync(path.join(home, '.cache')); fs.writeFileSync(path.join(home, '.cache', 'junk'), 'x'.repeat(5000));
  const i = await storage.info({ home });
  assert.ok(i.items.find((x) => x.id === 'home'));
  const dir = path.join(home, 'Backups'); fs.mkdirSync(dir);
  for (const n of ['20200101-0000', '20200102-0000', '20200103-0000']) fs.writeFileSync(path.join(dir, `nami-backup-${n}.tar.gz`), 'old');
  const b = await storage.backup({ home });
  assert.ok(fs.existsSync(b.path) && b.name.startsWith('nami-backup-'));
  const left = fs.readdirSync(dir).filter((f) => f.endsWith('.tar.gz'));
  assert.equal(left.length, 3);
  const list = require('node:child_process').execFileSync('tar', ['-tzf', b.path], { encoding: 'utf8' });
  assert.match(list, /notes\.txt/); assert.doesNotMatch(list, /\.cache|Backups/);
  await storage.clean({ home });
  assert.ok(!fs.existsSync(path.join(home, '.cache')));
  assert.ok(fs.existsSync(path.join(home, 'notes.txt')));
});
