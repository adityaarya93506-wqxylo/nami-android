import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const require = createRequire(import.meta.url);
const WebSocket = require('ws');
const { createServer } = require('../server/server.js');
const { SessionManager } = require('../server/sessions.js');
const { Acp } = require('../server/acp.js');
const fake = path.join(path.dirname(fileURLToPath(import.meta.url)), 'fixtures', 'fake-acp.js');
const TOKEN = 'c'.repeat(48);

async function boot() {
  const manager = new SessionManager({ spawnPty: () => { throw new Error('no'); }, env: { SHELL: '/bin/sh' }, home: os.homedir() });
  const acp = new Acp({ env: process.env, home: os.homedir(), launches: { claude: { command: process.execPath, args: [fake] } } });
  const app = createServer({ manager, token: TOKEN, listAgentsFn: () => [], acp });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  const ws = new WebSocket(`ws://127.0.0.1:${app.server.address().port}/ws`);
  const inbox = []; const waiters = [];
  ws.on('message', (raw) => { const m = JSON.parse(raw.toString()); const i = waiters.findIndex((w) => w.pred(m)); if (i >= 0) waiters.splice(i, 1)[0].resolve(m); else inbox.push(m); });
  const next = (pred) => new Promise((resolve, reject) => { const j = inbox.findIndex(pred); if (j >= 0) return resolve(inbox.splice(j, 1)[0]); const t = setTimeout(() => reject(new Error('timeout')), 4000); waiters.push({ pred, resolve: (m) => { clearTimeout(t); resolve(m); } }); });
  await new Promise((r) => ws.on('open', r));
  ws.send(JSON.stringify({ type: 'auth', token: TOKEN }));
  await next((m) => m.type === 'authed');
  return { app, ws, next, acp };
}

test('chat: the page talks ACP to an agent program through the server', async () => {
  const { app, ws, next } = await boot();
  ws.send(JSON.stringify({ type: 'chat.start', agentId: 'claude', ref: 'a' }));
  const started = await next((m) => m.type === 'chat.started');
  const id = started.id;
  const say = (o) => ws.send(JSON.stringify({ type: 'chat.send', id, line: JSON.stringify(o) }));
  const line = async (pred) => { const m = await next((x) => x.type === 'chat.line' && x.id === id && pred(JSON.parse(x.line))); return JSON.parse(m.line); };
  say({ jsonrpc: '2.0', id: 1, method: 'initialize', params: { protocolVersion: 1 } });
  assert.equal((await line((x) => x.id === 1)).result.protocolVersion, 1);
  say({ jsonrpc: '2.0', id: 2, method: 'session/new', params: { cwd: os.homedir(), mcpServers: [] } });
  assert.equal((await line((x) => x.id === 2)).result.sessionId, 's1');
  say({ jsonrpc: '2.0', id: 3, method: 'session/prompt', params: { sessionId: 's1', prompt: [{ type: 'text', text: 'hi' }] } });
  const c1 = await line((x) => x.method === 'session/update');
  assert.equal(c1.params.update.content.text, 'You said: ');
  assert.equal((await line((x) => x.id === 3)).result.stopReason, 'end_turn');
  // a tool that asks first, and is allowed
  say({ jsonrpc: '2.0', id: 4, method: 'session/prompt', params: { sessionId: 's1', prompt: [{ type: 'text', text: 'use a tool' }] } });
  const ask = await line((x) => x.method === 'session/request_permission');
  assert.equal(ask.params.options[0].optionId, 'allow');
  say({ jsonrpc: '2.0', id: ask.id, result: { outcome: { outcome: 'selected', optionId: 'allow' } } });
  const done = await line((x) => x.params && x.params.update && x.params.update.sessionUpdate === 'tool_call_update');
  assert.equal(done.params.update.status, 'completed');
  assert.equal((await line((x) => x.id === 4)).result.stopReason, 'end_turn');
  // a line that is not one line is refused, not sent
  ws.send(JSON.stringify({ type: 'chat.send', id, line: 'a\nb' }));
  ws.send(JSON.stringify({ type: 'chat.stop', id }));
  ws.close(); app.server.close();
});

test('chat: only a known agent, a real folder, a few at a time; closing the page stops them', async () => {
  const { app, ws, next, acp } = await boot();
  ws.send(JSON.stringify({ type: 'chat.start', agentId: 'rm -rf', ref: 'b' }));
  assert.match((await next((m) => m.type === 'chat.failed')).message, /no chat mode/);
  ws.send(JSON.stringify({ type: 'chat.start', agentId: 'claude', cwd: '/nope/nope', ref: 'c' }));
  assert.match((await next((m) => m.type === 'chat.failed')).message, /does not exist/);
  for (let i = 0; i < 3; i++) { ws.send(JSON.stringify({ type: 'chat.start', agentId: 'claude' })); await next((m) => m.type === 'chat.started'); }
  ws.send(JSON.stringify({ type: 'chat.start', agentId: 'claude', ref: 'd' }));
  assert.match((await next((m) => m.type === 'chat.failed')).message, /At most 3/);
  assert.equal(acp.procs.size, 3);
  ws.close();
  await new Promise((r) => setTimeout(r, 400));
  assert.equal(acp.procs.size, 0, 'a chat does not outlive its page');
  app.server.close();
});
