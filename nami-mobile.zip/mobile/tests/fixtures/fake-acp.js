// A stand-in ACP agent for tests: answers initialize / session/new / session/prompt like a real one.
const rl = require('node:readline').createInterface({ input: process.stdin });
const out = (o) => process.stdout.write(JSON.stringify(o) + '\n');
let waiting = null;
rl.on('line', (line) => {
  const m = JSON.parse(line);
  if (m.id !== undefined && !m.method) {                         // an answer to our permission request
    if (waiting) { out({ jsonrpc: '2.0', method: 'session/update', params: { sessionId: 's1', update: { sessionUpdate: 'tool_call_update', toolCallId: 't1', status: JSON.stringify(m.result.outcome).includes('allow') ? 'completed' : 'failed' } } }); out({ jsonrpc: '2.0', id: waiting, result: { stopReason: 'end_turn' } }); waiting = null; }
    return;
  }
  if (m.method === 'initialize') out({ jsonrpc: '2.0', id: m.id, result: { protocolVersion: 1, agentCapabilities: {} } });
  else if (m.method === 'session/new') out({ jsonrpc: '2.0', id: m.id, result: { sessionId: 's1' } });
  else if (m.method === 'session/prompt') {
    const text = m.params.prompt[0].text;
    const chunk = (t) => out({ jsonrpc: '2.0', method: 'session/update', params: { sessionId: 's1', update: { sessionUpdate: 'agent_message_chunk', content: { type: 'text', text: t } } } });
    chunk('You said: '); chunk(text);
    if (text.includes('tool')) {
      out({ jsonrpc: '2.0', method: 'session/update', params: { sessionId: 's1', update: { sessionUpdate: 'tool_call', toolCallId: 't1', title: 'Run ls', kind: 'execute', status: 'pending' } } });
      waiting = m.id;
      out({ jsonrpc: '2.0', id: 900, method: 'session/request_permission', params: { sessionId: 's1', toolCall: { toolCallId: 't1', title: 'Run ls' }, options: [{ optionId: 'allow', name: 'Allow', kind: 'allow_once' }, { optionId: 'deny', name: 'Deny', kind: 'reject_once' }] } });
    } else out({ jsonrpc: '2.0', id: m.id, result: { stopReason: 'end_turn' } });
  }
});
