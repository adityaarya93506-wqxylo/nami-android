import sys,os,tty,termios,time
mode=sys.argv[1]
sys.stdout.write('\x1b[?1049h'); 
if mode=='mouse': sys.stdout.write('\x1b[?1000h\x1b[?1006h')
sys.stdout.write('ready'); sys.stdout.flush()
fd=0; old=termios.tcgetattr(fd); tty.setraw(fd)
out=open(sys.argv[2],'w'); t=time.time()
while time.time()-t<8:
    import select
    if select.select([0],[],[],0.2)[0]:
        d=os.read(0,4096); out.write(repr(d)+'\n'); out.flush()
