import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import http from 'node:http';
import os from 'node:os';
import fs from 'node:fs';
import path from 'node:path';
import { EventEmitter } from 'node:events';

const require = createRequire(import.meta.url);
const WebSocket = require('ws');
const { createServer, sameToken, hostName, loadOrCreateToken } = require('../server/server.js');
const { SessionManager, MAX_SESSIONS } = require('../server/sessions.js');
const { createSpawner, shQuote } = require('../server/pty-adapter.js');
const { withUserPaths, findAgent, AGENTS } = require('../server/agents.js');

const TOKEN = 'a'.repeat(48);

// A pty stand-in: records writes, lets the test push output and end it.
function fakeSpawner() {
  const made = [];
  const spawn = (file, args, opts) => {
    const dataCbs = []; const exitCbs = [];
    const p = {
      file, args, opts, pid: 1000 + made.length, resizable: true, written: [], killed: false, resized: [],
      onData: (cb) => dataCbs.push(cb),
      onExit: (cb) => exitCbs.push(cb),
      write: (d) => p.written.push(d),
      resize: (c, r) => { p.resized.push([c, r]); return true; },
      kill: () => { p.killed = true; },
      emit: (d) => dataCbs.forEach((cb) => cb(d)),
      end: (code = 0) => exitCbs.forEach((cb) => cb(code)),
    };
    made.push(p);
    return p;
  };
  spawn.made = made;
  return spawn;
}

async function start({ lan = false } = {}) {
  const spawn = fakeSpawner();
  const manager = new SessionManager({ spawnPty: spawn, env: { SHELL: '/bin/sh' }, home: os.homedir() });
  const app = createServer({ manager, token: TOKEN, lan, listAgentsFn: () => [{ id: 'claude', name: 'Claude Code', installed: false }] });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  const port = app.server.address().port;
  return { app, manager, spawn, port, stop: () => app.close() };
}

function connect(port, { origin, host } = {}) {
  const headers = {};
  if (origin) headers.Origin = origin;
  if (host) headers.Host = host;
  const ws = new WebSocket(`ws://127.0.0.1:${port}/ws`, { headers });
  const inbox = [];
  const waiters = [];
  ws.on('message', (raw) => {
    const m = JSON.parse(raw.toString());
    const i = waiters.findIndex((w) => w.pred(m));
    if (i >= 0) waiters.splice(i, 1)[0].resolve(m); else inbox.push(m);
  });
  ws.next = (pred = () => true, ms = 3000) => new Promise((resolve, reject) => {
    const i = inbox.findIndex(pred);
    if (i >= 0) return resolve(inbox.splice(i, 1)[0]);
    const w = { pred, resolve };
    waiters.push(w);
    setTimeout(() => { const j = waiters.indexOf(w); if (j >= 0) { waiters.splice(j, 1); reject(new Error('timed out waiting for message')); } }, ms);
  });
  ws.opened = new Promise((resolve, reject) => { ws.on('open', resolve); ws.on('error', reject); ws.on('unexpected-response', (_r, res) => reject(Object.assign(new Error('rejected'), { status: res.statusCode }))); });
  ws.closed = new Promise((resolve) => ws.on('close', (code) => resolve(code)));
  return ws;
}

function get(port, urlPath, headers = {}) {
  return new Promise((resolve, reject) => {
    http.get({ host: '127.0.0.1', port, path: urlPath, headers }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, body: Buffer.concat(chunks).toString(), headers: res.headers }));
    }).on('error', reject);
  });
}

test('sameToken accepts the right token and refuses others', () => {
  assert.equal(sameToken(TOKEN, TOKEN), true);
  assert.equal(sameToken(TOKEN, 'b'.repeat(48)), false);
  assert.equal(sameToken(TOKEN, ''), false);
  assert.equal(sameToken(TOKEN, undefined), false);
});

test('hostName strips the port and understands IPv6 literals', () => {
  assert.equal(hostName('127.0.0.1:7878'), '127.0.0.1');
  assert.equal(hostName('Localhost:80'), 'localhost');
  assert.equal(hostName('[::1]:7878'), '[::1]');
  assert.equal(hostName(undefined), '');
});

test('the token is made once, stored owner-only, and reused', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'nami-mobile-'));
  process.env.NAMI_MOBILE_HOME = dir;
  try {
    const a = loadOrCreateToken('/nowhere');
    const b = loadOrCreateToken('/nowhere');
    assert.match(a.token, /^[0-9a-f]{48}$/);
    assert.equal(a.token, b.token);
    assert.equal(fs.statSync(a.file).mode & 0o777, 0o600);
  } finally { delete process.env.NAMI_MOBILE_HOME; fs.rmSync(dir, { recursive: true, force: true }); }
});

test('shQuote survives quotes and spaces', () => {
  assert.equal(shQuote("it's here"), `'it'\\''s here'`);
});

test('the usual agent install folders are on the PATH, once', () => {
  const env = withUserPaths({ PATH: '/usr/bin:/home/me/.local/bin' }, '/home/me');
  const parts = env.PATH.split(':');
  assert.equal(parts.filter((p) => p === '/home/me/.local/bin').length, 1);
  assert.ok(parts.includes('/home/me/.claude/local'));
  assert.equal(parts[0], '/usr/bin', 'what was there stays first');
  assert.equal(withUserPaths({}, '/h').PATH.startsWith('/h/'), true, 'works with no PATH at all');
});

test('agent commands are plain program names, nothing a shell could expand', () => {
  for (const a of AGENTS) assert.match(a.bin, /^[a-z][a-z0-9-]*$/, a.id);
  assert.equal(findAgent('claude').bin, 'claude');
  assert.equal(findAgent('constructor'), null);
});

// ---- sessions ---------------------------------------------------------------

test('a session keeps bounded scrollback and forwards input', () => {
  const spawn = fakeSpawner();
  const m = new SessionManager({ spawnPty: spawn, env: { SHELL: '/bin/sh' }, scrollback: 10 });
  const s = m.create({ kind: 'shell' });
  spawn.made[0].emit('0123456789ABCDEF');
  assert.equal(m.snapshot(s.id), '6789ABCDEF');
  assert.equal(m.write(s.id, 'ls\r'), true);
  assert.deepEqual(spawn.made[0].written, ['ls\r']);
  assert.equal(m.write(s.id, 'x'.repeat(70000)), false, 'oversized input is refused');
});

test('an agent session runs only a command from the table', () => {
  const spawn = fakeSpawner();
  const m = new SessionManager({ spawnPty: spawn, env: { SHELL: '/bin/sh' } });
  const s = m.create({ kind: 'agent', agentId: 'claude' });
  assert.equal(spawn.made[0].file, 'claude');
  assert.equal(s.agentId, 'claude');
  assert.throws(() => m.create({ kind: 'agent', agentId: 'rm -rf /' }), /Unknown agent/);
  assert.throws(() => m.create({ kind: 'agent' }), /Unknown agent/);
});

test('a folder that does not exist is refused', () => {
  const m = new SessionManager({ spawnPty: fakeSpawner(), env: { SHELL: '/bin/sh' } });
  assert.throws(() => m.create({ kind: 'shell', cwd: '/definitely/not/here' }), /does not exist/);
  const ok = m.create({ kind: 'shell', cwd: os.tmpdir() });
  assert.equal(ok.cwd, os.tmpdir());
});

test('sessions are capped, and closing frees a place', () => {
  const m = new SessionManager({ spawnPty: fakeSpawner(), env: { SHELL: '/bin/sh' } });
  const ids = [];
  for (let i = 0; i < MAX_SESSIONS; i++) ids.push(m.create({ kind: 'shell' }).id);
  assert.throws(() => m.create({ kind: 'shell' }), /At most/);
  assert.equal(m.close(ids[0]), true);
  assert.doesNotThrow(() => m.create({ kind: 'shell' }));
});

test('closing a running session kills it; a finished one stays until closed', () => {
  const spawn = fakeSpawner();
  const m = new SessionManager({ spawnPty: spawn, env: { SHELL: '/bin/sh' } });
  const a = m.create({ kind: 'shell' });
  const b = m.create({ kind: 'shell' });
  m.close(a.id);
  assert.equal(spawn.made[0].killed, true);
  spawn.made[1].end(3);
  assert.equal(m.get(b.id).exited, true);
  assert.equal(m.get(b.id).exitCode, 3);
  assert.equal(m.write(b.id, 'x'), false, 'no input to a finished session');
  assert.equal(m.list().length, 1);
});

test('size requests are clamped', () => {
  const spawn = fakeSpawner();
  const m = new SessionManager({ spawnPty: spawn, env: { SHELL: '/bin/sh' } });
  const s = m.create({ kind: 'shell', cols: 99999, rows: -4 });
  assert.deepEqual([spawn.made[0].opts.cols, spawn.made[0].opts.rows], [300, 5]);
  m.resize(s.id, 1, 1);
  assert.deepEqual(spawn.made[0].resized.at(-1), [20, 5]);
});

// ---- the door ---------------------------------------------------------------

test('a socket that sends anything but auth first is closed', async () => {
  const t = await start();
  try {
    const ws = connect(t.port);
    await ws.opened;
    ws.send(JSON.stringify({ type: 'create', kind: 'shell' }));
    assert.equal(await ws.closed, 4001);
    assert.equal(t.manager.list().length, 0, 'nothing was started');
  } finally { await t.stop(); }
});

test('a wrong token is denied and starts nothing', async () => {
  const t = await start();
  try {
    const ws = connect(t.port);
    await ws.opened;
    ws.send(JSON.stringify({ type: 'auth', token: 'b'.repeat(48) }));
    assert.equal((await ws.next()).type, 'denied');
    assert.equal(await ws.closed, 4003);
  } finally { await t.stop(); }
});

test('repeated wrong tokens lock that address out for a while', async () => {
  const t = await start();
  try {
    for (let i = 0; i < 6; i++) {
      const ws = connect(t.port);
      await ws.opened;
      ws.send(JSON.stringify({ type: 'auth', token: 'wrong' }));
      await ws.closed;
    }
    const ws = connect(t.port);
    await assert.rejects(ws.opened, (e) => e.status === 429);
    const good = connect(t.port);
    await assert.rejects(good.opened, (e) => e.status === 429, 'even the right token waits out the lockout');
  } finally { await t.stop(); }
});

test('the right token opens the door and shows sessions and agents', async () => {
  const t = await start();
  try {
    const ws = connect(t.port);
    await ws.opened;
    ws.send(JSON.stringify({ type: 'auth', token: TOKEN }));
    const hello = await ws.next((m) => m.type === 'authed');
    assert.deepEqual(hello.sessions, []);
    assert.equal(hello.agents[0].id, 'claude');
    ws.close();
  } finally { await t.stop(); }
});

test('a web page on another origin cannot open the socket', async () => {
  const t = await start();
  try {
    const ws = connect(t.port, { origin: 'https://evil.example' });
    await assert.rejects(ws.opened, (e) => e.status === 403);
  } finally { await t.stop(); }
});

test('a hostname that is not this phone is refused (DNS rebinding)', async () => {
  const t = await start();
  try {
    const page = await get(t.port, '/healthz', { Host: 'evil.example' });
    assert.equal(page.status, 421);
    const ws = connect(t.port, { host: 'evil.example' });
    await assert.rejects(ws.opened, (e) => e.status === 403);
  } finally { await t.stop(); }
});

test('create, type, see output, and catch up after reconnecting', async () => {
  const t = await start();
  try {
    const a = connect(t.port);
    await a.opened;
    a.send(JSON.stringify({ type: 'auth', token: TOKEN }));
    await a.next((m) => m.type === 'authed');
    a.send(JSON.stringify({ type: 'create', kind: 'shell', cols: 80, rows: 24 }));
    const created = await a.next((m) => m.type === 'created');
    const id = created.session.id;
    await a.next((m) => m.type === 'snapshot');

    a.send(JSON.stringify({ type: 'input', id, data: 'echo hi\r' }));
    await new Promise((r) => setTimeout(r, 30));
    assert.deepEqual(t.spawn.made[0].written, ['echo hi\r']);

    t.spawn.made[0].emit('hi\r\n');
    assert.equal((await a.next((m) => m.type === 'data')).data, 'hi\r\n');
    a.close();
    await a.closed;

    // The agent keeps working while the phone is away.
    t.spawn.made[0].emit('more work\r\n');

    const b = connect(t.port);
    await b.opened;
    b.send(JSON.stringify({ type: 'auth', token: TOKEN }));
    const hello = await b.next((m) => m.type === 'authed');
    assert.equal(hello.sessions.length, 1);
    b.send(JSON.stringify({ type: 'attach', id, cols: 60, rows: 30 }));
    const snap = await b.next((m) => m.type === 'snapshot');
    assert.equal(snap.data, 'hi\r\nmore work\r\n');
    assert.deepEqual(t.spawn.made[0].resized.at(-1), [60, 30]);
    b.close();
  } finally { await t.stop(); }
});

test('output goes only to the socket looking at that session', async () => {
  const t = await start();
  try {
    const a = connect(t.port); const b = connect(t.port);
    await Promise.all([a.opened, b.opened]);
    for (const ws of [a, b]) { ws.send(JSON.stringify({ type: 'auth', token: TOKEN })); await ws.next((m) => m.type === 'authed'); }
    a.send(JSON.stringify({ type: 'create', kind: 'shell' }));
    await a.next((m) => m.type === 'created');
    t.spawn.made[0].emit('secret output');
    assert.equal((await a.next((m) => m.type === 'data')).data, 'secret output');
    await assert.rejects(b.next((m) => m.type === 'data', 150), /timed out/);
    a.close(); b.close();
  } finally { await t.stop(); }
});

test('exit and list changes reach every signed-in socket', async () => {
  const t = await start();
  try {
    const a = connect(t.port); const b = connect(t.port);
    await Promise.all([a.opened, b.opened]);
    for (const ws of [a, b]) { ws.send(JSON.stringify({ type: 'auth', token: TOKEN })); await ws.next((m) => m.type === 'authed'); }
    a.send(JSON.stringify({ type: 'create', kind: 'shell' }));
    await b.next((m) => m.type === 'sessions' && m.sessions.length === 1);
    t.spawn.made[0].end(0);
    assert.equal((await b.next((m) => m.type === 'exit')).code, 0);
    assert.equal((await b.next((m) => m.type === 'sessions' && m.sessions[0]?.exited === true)).sessions[0].exitCode, 0);
    a.close(); b.close();
  } finally { await t.stop(); }
});

// ---- the page ---------------------------------------------------------------

test('the page and the terminal files are served; nothing else from vendor', async () => {
  const t = await start();
  try {
    const page = await get(t.port, '/');
    assert.equal(page.status, 200);
    assert.match(page.headers['content-type'], /text\/html/);
    assert.equal((await get(t.port, '/vendor/xterm.mjs')).status, 200);
    assert.equal((await get(t.port, '/vendor/xterm.css')).status, 200);
    assert.equal((await get(t.port, '/vendor/addon-fit.mjs')).status, 200);
    assert.equal((await get(t.port, '/vendor/markdown-editor.mjs')).status, 404, 'not on the allow list');
    assert.equal((await get(t.port, '/vendor/%2e%2e/%2e%2e/package.json')).status, 404);
    assert.equal((await get(t.port, '/%2e%2e/server/server.js')).status, 404);
    assert.equal((await get(t.port, '/server/server.js')).status, 404);
    assert.equal((await get(t.port, '/package.json')).status, 404, 'no stray files from the page folder');
  } finally { await t.stop(); }
});

// ---- a real terminal, no mocks ----------------------------------------------

test('the script fallback runs a real shell and reports its exit', { skip: !fs.existsSync('/usr/bin/script') && !fs.existsSync('/bin/script') }, async () => {
  const spawn = createSpawner({ forceScript: true });
  const m = new SessionManager({ spawnPty: spawn, env: { ...process.env, SHELL: '/bin/sh' } });
  const s = m.create({ kind: 'shell', cols: 80, rows: 24 });
  const seen = new EventEmitter();
  let out = '';
  m.on('data', (_id, d) => { out += d; seen.emit('d'); });
  const done = new Promise((r) => m.on('exit', (_id, code) => r(code)));
  m.write(s.id, 'echo nami-$((40+2))\r');
  m.write(s.id, 'exit 7\r');
  const code = await Promise.race([done, new Promise((_, rej) => setTimeout(() => rej(new Error('shell did not exit')), 5000))]);
  assert.match(out, /nami-42/);
  assert.equal(code, 7);
  assert.equal(m.get(s.id).resizable, false);
});

test('killing a script session takes the program with it, not just script', { skip: !fs.existsSync('/usr/bin/script') && !fs.existsSync('/bin/script') }, async () => {
  const spawn = createSpawner({ forceScript: true });
  const pty = spawn('/bin/sh', ['-c', 'echo pid=$$; exec sleep 300'], { cwd: os.tmpdir(), env: process.env, cols: 80, rows: 24 });
  let out = '';
  pty.onData((d) => { out += d; });
  const ended = new Promise((r) => pty.onExit(r));
  const deadline = Date.now() + 4000;
  while (!/pid=\d+/.test(out) && Date.now() < deadline) await new Promise((r) => setTimeout(r, 30));
  const pid = Number(/pid=(\d+)/.exec(out)[1]);
  // A process that has died but is not yet collected by its parent still answers
  // kill(pid, 0); what matters is that it is no longer running.
  const running = () => { try { return !/^\s*[ZX]/.test(fs.readFileSync(`/proc/${pid}/status`, 'utf8').match(/State:\s*(.*)/)[1]); } catch (_) { return false; } };
  assert.equal(running(), true, 'the program is running');
  pty.kill();
  await Promise.race([ended, new Promise((_, rej) => setTimeout(() => rej(new Error('script did not end')), 4000))]);
  await new Promise((r) => setTimeout(r, 200));
  assert.equal(running(), false, 'the program is gone too');
});
