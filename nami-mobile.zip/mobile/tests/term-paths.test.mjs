import test from 'node:test';
import assert from 'node:assert/strict';
import { pathCandidates } from '../web/term-paths.js';

const found = (t) => pathCandidates(t).map((c) => c.p);

test('paths in terminal output are found, URLs and plain words are not', () => {
  assert.deepEqual(found('wrote ./src/app.js and ~/notes/todo.md'), ['./src/app.js', '~/notes/todo.md']);
  assert.deepEqual(found('see /root/proj/README.md.'), ['/root/proj/README.md']);
  assert.deepEqual(found('src/lib/util.mjs:42:7: error'), ['src/lib/util.mjs']);
  assert.deepEqual(found('open https://example.com/a/b.png now'), []);
  assert.deepEqual(found('either/or and/or choose'), []);          // no extension, not a path
  assert.deepEqual(found('cd ../docs'), ['../docs']);
  const c = pathCandidates('x ./a/b.txt')[0];
  assert.equal('x ./a/b.txt'.slice(c.index, c.index + c.len), './a/b.txt');
});
