import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { needsYou, looksLikeAsk } = require('../server/needs-you.js');

test('questions an agent asks are recognised, ordinary output is not', () => {
  assert.ok(looksLikeAsk('Run this command?\n\x1b[1mnpm test\x1b[0m\nProceed? (y/n) '));
  assert.ok(looksLikeAsk('Do you want to make this edit to app.js?\n❯ 1. Yes\n  2. Yes, allow all edits\n  3. No'));
  assert.ok(looksLikeAsk('Press Enter to continue'));
  assert.ok(looksLikeAsk('Allow this tool to run?'));
  assert.ok(!looksLikeAsk('Compiling...\nDone in 3s\n$ '));
  assert.ok(!looksLikeAsk('I will ask whether (y/n) things work, but this line is old\n' + 'x\n'.repeat(15)));
});

test('needs you only when quiet, unanswered and asking', () => {
  const buf = 'Overwrite file? (y/n) ';
  const t = 100000;
  assert.equal(needsYou({ lastDataAt: t - 1000, buf }, t), false);           // still printing
  assert.equal(needsYou({ lastDataAt: t - 5000, buf }, t), true);
  assert.equal(needsYou({ lastDataAt: t - 5000, lastInputAt: t - 4000, buf }, t), false); // you answered
  assert.equal(needsYou({ lastDataAt: t - 5000, buf: 'all done\n$ ' }, t), false);
  assert.equal(needsYou(null, t), false);
});
