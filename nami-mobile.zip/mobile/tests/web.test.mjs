import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { SEQ, keySeq, ctrlify, composeToInput, pasteToInput, scrollLines } from '../web/keys.js';
import { THEMES, DEFAULT_THEME, themeById, clampFont } from '../web/themes.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const web = path.join(here, '..', 'web');

test('arrows follow the terminal mode', () => {
  assert.equal(keySeq('up'), '\x1b[A');
  assert.equal(keySeq('up', { appCursor: true }), '\x1bOA');
  assert.equal(keySeq('left', { appCursor: true }), '\x1bOD');
  assert.equal(keySeq('esc', { appCursor: true }), '\x1b', 'only arrows change');
  assert.equal(keySeq('nope'), null);
  assert.equal(SEQ['c-c'], '\x03');
});

test('Ctrl turns letters into control codes and leaves the rest alone', () => {
  assert.equal(ctrlify('c'), '\x03');
  assert.equal(ctrlify('C'), '\x03');
  assert.equal(ctrlify('d'), '\x04');
  assert.equal(ctrlify('['), '\x1b');
  assert.equal(ctrlify(' '), '\x00');
  assert.equal(ctrlify('5'), '5');
  assert.equal(ctrlify('ab'), 'ab', 'a pasted string is not a keystroke');
  assert.equal(ctrlify('\x1b[A'), '\x1b[A');
});

test('an empty message box is Enter', () => {
  assert.equal(composeToInput(''), '\r');
  assert.equal(composeToInput('   \n '), '\r');
});

test('one line is typed and submitted', () => {
  assert.equal(composeToInput('fix the login bug'), 'fix the login bug\r');
  assert.equal(composeToInput('hi  \n'), 'hi\r', 'trailing blanks are dropped');
});

test('several lines stay one message when the program takes bracketed paste', () => {
  assert.equal(composeToInput('a\nb', { bracketed: true }), '\x1b[200~a\nb\x1b[201~\r');
  assert.equal(composeToInput('a\r\nb', { bracketed: true }), '\x1b[200~a\nb\x1b[201~\r');
});

test('several lines are joined, never submitted half-way, without bracketed paste', () => {
  assert.equal(composeToInput('a\n  b\n\nc'), 'a b c\r');
});

test('pasting from the clipboard adds no Enter', () => {
  assert.equal(pasteToInput('hello'), 'hello');
  assert.equal(pasteToInput('a\nb', { bracketed: true }), '\x1b[200~a\nb\x1b[201~');
  assert.equal(pasteToInput('a\nb'), 'a\rb');
  assert.equal(pasteToInput(''), '');
});

test('six desks, each with a full terminal palette', () => {
  assert.deepEqual(THEMES.map((t) => t.id), ['paper', 'operator', 'glass', 'graphite', 'soft', 'dusk']);
  for (const t of THEMES) {
    for (const k of ['foreground', 'cursor', 'black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white',
      'brightBlack', 'brightRed', 'brightGreen', 'brightYellow', 'brightBlue', 'brightMagenta', 'brightCyan', 'brightWhite']) {
      assert.match(t.xterm[k], /^(#[0-9a-f]{6}|rgba\(.+\))$/i, `${t.id}.${k}`);
    }
  }
  assert.equal(themeById('nope').id, DEFAULT_THEME);
});

test('every desk has its colours in the stylesheet', () => {
  const css = fs.readFileSync(path.join(web, 'style.css'), 'utf8');
  for (const t of THEMES) assert.ok(css.includes(`body[data-theme="${t.id}"]`), t.id);
});

test('text size stays in range', () => {
  assert.equal(clampFont(3), 10);
  assert.equal(clampFont(99), 20);
  assert.equal(clampFont('15'), 15);
  assert.equal(clampFont('x', 14), 14);
  assert.equal(clampFont(null, 14), 14, 'nothing saved yet');
  assert.equal(clampFont(undefined, 14), 14);
});

test('every id the script looks up exists in the page', () => {
  const html = fs.readFileSync(path.join(web, 'index.html'), 'utf8');
  const js = ['app.js', 'core.js', 'ui-files.js', 'ui-library.js', 'ui-settings.js', 'theme.js', 'chips.js']
    .map((f) => fs.readFileSync(path.join(web, f), 'utf8')).join('\n');
  const ids = new Set([...js.matchAll(/\$\('([\w-]+)'\)/g)].map((m) => m[1]));
  for (const id of ids) assert.ok(new RegExp(`id="${id}"`).test(html), `#${id} is missing from index.html`);
  assert.ok(ids.size > 20);
});

test('the manifest points at icons that exist', () => {
  const m = JSON.parse(fs.readFileSync(path.join(web, 'manifest.webmanifest'), 'utf8'));
  assert.ok(m.icons.length >= 2);
  for (const icon of m.icons) {
    const f = path.join(web, icon.src.replace(/^\//, ''));
    const png = fs.readFileSync(f);
    assert.deepEqual([...png.subarray(0, 4)], [137, 80, 78, 71], icon.src + ' is a PNG');
    assert.equal(png.readUInt32BE(16), Number(icon.sizes.split('x')[0]), icon.src + ' has the size it claims');
  }
});

test('thumb scrolling turns pixels into whole lines and keeps the remainder', () => {
  assert.deepEqual(scrollLines(32, 16, 0), { lines: 2, carry: 0 });
  let r = scrollLines(10, 16, 0);
  assert.equal(r.lines, 0);
  r = scrollLines(10, 16, r.carry);          // 20px in two slow moves
  assert.equal(r.lines, 1);
  assert.ok(Math.abs(r.carry - 0.25) < 1e-9);
  assert.equal(scrollLines(-40, 16, 0).lines, -2, 'dragging up goes forward');
  assert.equal(scrollLines(5, 0, 0).lines, 0, 'a bad line height does not divide by zero');
});

test('the scroll buttons exist in the page', () => {
  const html = fs.readFileSync(path.join(web, 'index.html'), 'utf8');
  for (const k of ['pgup', 'pgdn', 'live']) assert.ok(html.includes(`data-seq="${k}"`), k);
});
