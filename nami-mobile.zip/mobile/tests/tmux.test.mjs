import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { spawnSync } from 'node:child_process';
import os from 'node:os';
import fs from 'node:fs';
import path from 'node:path';

const require = createRequire(import.meta.url);
const { createTmux, clean } = require('../server/tmux.js');
const { SessionManager } = require('../server/sessions.js');
const { createSpawner } = require('../server/pty-adapter.js');

const HAVE_TMUX = spawnSync('tmux', ['-V']).status === 0 && (fs.existsSync('/usr/bin/script') || fs.existsSync('/bin/script'));
const opts = { skip: !HAVE_TMUX && 'tmux and script are needed' };

// Everything here talks to a real tmux, on a socket of its own.
function rig() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'nami-tmux-'));
  const socket = `nami-test-${process.pid}-${Math.random().toString(36).slice(2, 8)}`;
  const make = () => {
    const tmux = createTmux({ socket, confPath: path.join(dir, 'tmux.conf') });
    const m = new SessionManager({
      spawnPty: createSpawner({ forceScript: true }), env: { ...process.env, SHELL: '/bin/sh' }, tmux, pollMs: 100,
    });
    let out = {}; // session id -> everything written so far
    m.on('data', (id, d) => { out[id] = (out[id] || '') + d; });
    return { m, tmux, text: (id) => out[id] || '', clear: (id) => { out[id] = ''; } };
  };
  return { make, socket, cleanup: () => { try { createTmux({ socket }).killServer(); } catch (_) { /* gone */ } fs.rmSync(dir, { recursive: true, force: true }); } };
}

async function until(fn, ms = 6000, what = 'condition') {
  const end = Date.now() + ms;
  for (;;) {
    const v = fn();
    if (v) return v;
    if (Date.now() > end) throw new Error('timed out waiting for ' + what);
    await new Promise((r) => setTimeout(r, 40));
  }
}

test('clean() leaves nothing a tmux command line could act on', () => {
  assert.equal(clean('a;b|c\\d\n e'), 'a b c d  e');
  assert.equal(clean(undefined), '');
  assert.equal(clean('x'.repeat(500)).length, 200);
});

test('a session runs in tmux and shows up on screen', opts, async () => {
  const r = rig();
  try {
    const { m, text } = r.make();
    const s = m.create({ kind: 'shell', cols: 80, rows: 24 });
    assert.equal(s.persistent, true);
    await until(() => text(s.id).length > 0, 6000, 'a prompt');
    m.write(s.id, 'echo nami-$((6*7))\r');
    await until(() => text(s.id).includes('nami-42'), 6000, 'the echo');
    m.shutdown();
  } finally { r.cleanup(); }
});

test('provider variables reach the program inside tmux', opts, async () => {
  const r = rig();
  try {
    const { m, text } = r.make();
    const s = m.create({ kind: 'shell', cols: 80, rows: 24, env: { ANTHROPIC_BASE_URL: 'https://p.example/v1', NAMI_TEST_KEY: 'k-123' } });
    await until(() => text(s.id).length > 0, 6000, 'a prompt');
    m.write(s.id, 'echo got-$NAMI_TEST_KEY-$ANTHROPIC_BASE_URL\r');
    await until(() => text(s.id).includes('got-k-123-https://p.example/v1'), 6000, 'the variables');
    m.shutdown();
  } finally { r.cleanup(); }
});

test('the session survives the server stopping, and the next server takes it back', opts, async () => {
  const r = rig();
  try {
    const a = r.make();
    const s = a.m.create({ kind: 'shell', name: 'My work', cols: 80, rows: 24 });
    await until(() => a.text(s.id).length > 0, 6000, 'a prompt');
    a.m.write(s.id, 'export KEPT=still-here; echo marker-$((1+1))\r');
    await until(() => a.text(s.id).includes('marker-2'), 6000, 'the marker');
    a.m.shutdown();                                   // the server goes away

    const b = r.make();                               // a new server, fresh memory
    assert.equal(b.m.adopt(), 1);
    const back = b.m.list()[0];
    assert.equal(back.id, s.id);
    assert.equal(back.name, 'My work', 'the name came back from tmux');
    assert.equal(back.exited, false);
    assert.equal(back.persistent, true);

    // It is the same shell: the variable set before the restart is still there.
    b.m.redraw(back.id);
    b.m.write(back.id, 'echo "$KEPT"\r');
    await until(() => b.text(back.id).includes('still-here'), 6000, 'the same shell to answer');
    assert.equal(b.m.adopt(), 0, 'adopting twice does not duplicate');
    b.m.shutdown();
  } finally { r.cleanup(); }
});

test('Stop ends the tmux session for good; the next server finds nothing', opts, async () => {
  const r = rig();
  try {
    const a = r.make();
    const s = a.m.create({ kind: 'shell' });
    await until(() => a.text(s.id).length > 0, 6000, 'a prompt');
    assert.equal(a.m.close(s.id), true);
    assert.equal(a.m.list().length, 0);
    const b = r.make();
    assert.equal(b.m.adopt(), 0);
    assert.equal(b.tmux.list().length, 0);
  } finally { r.cleanup(); }
});

test('a program that ends reports its own exit status', opts, async () => {
  const r = rig();
  try {
    const { m, text } = r.make();
    const exits = [];
    m.on('exit', (id, code) => exits.push([id, code]));
    const s = m.create({ kind: 'shell' });
    await until(() => text(s.id).length > 0, 6000, 'a prompt');
    m.write(s.id, 'exit 5\r');
    await until(() => exits.length > 0, 6000, 'the exit');
    assert.deepEqual(exits[0], [s.id, 5]);
    assert.equal(m.get(s.id).exited, true);
    assert.equal(m.get(s.id).exitCode, 5);
    assert.equal(m.write(s.id, 'x'), false, 'no input to a finished session');
    m.shutdown();

    // Still finished (not "running") after a restart.
    const b = r.make();
    b.m.adopt();
    assert.equal(b.m.list()[0].exited, true);
    assert.equal(b.m.list()[0].exitCode, 5);
    b.m.close(s.id);
  } finally { r.cleanup(); }
});

test('the history that scrolled off is there to scroll back to', opts, async () => {
  const r = rig();
  try {
    const { m, text } = r.make();
    const s = m.create({ kind: 'shell', cols: 80, rows: 10 });
    await until(() => text(s.id).length > 0, 6000, 'a prompt');
    m.write(s.id, 'seq 1 80; echo done-printing\r');
    await until(() => text(s.id).includes('done-printing'), 6000, 'the output');
    const snap = m.snapshot(s.id);
    const lines = snap.split('\r\n');
    assert.ok(lines.includes('1'), 'the first line is in the history');
    assert.ok(lines.includes('40'));
    assert.ok(snap.endsWith('\x1b[2J\x1b[H'), 'and the screen is cleared for the redraw that follows');
    m.shutdown();
  } finally { r.cleanup(); }
});

test('the page size reaches the program, including after it changes', opts, async () => {
  const r = rig();
  try {
    const { m, text, clear } = r.make();
    const s = m.create({ kind: 'shell', cols: 70, rows: 20 });
    await until(() => text(s.id).length > 0, 6000, 'a prompt');
    m.write(s.id, 'stty size\r');
    await until(() => /\b20 70\b/.test(text(s.id)), 6000, 'the first size');

    clear(s.id);
    m.resize(s.id, 55, 15);                // a rotated phone, or the keyboard opening
    await new Promise((res) => setTimeout(res, 300));
    m.write(s.id, 'stty size\r');
    await until(() => /\b15 55\b/.test(text(s.id)), 6000, 'the new size');
    m.shutdown();
  } finally { r.cleanup(); }
});

test('scrolling with a thumb goes back, and typing comes back to the prompt', opts, async () => {
  const r = rig();
  try {
    const { m, text, clear } = r.make();
    const s = m.create({ kind: 'shell', cols: 60, rows: 10 });
    await until(() => text(s.id).length > 0, 6000, 'a prompt');
    m.write(s.id, 'seq 1 100; echo end-of-output\r');
    await until(() => text(s.id).includes('end-of-output'), 6000, 'the output');

    clear(s.id);
    assert.equal(m.scroll(s.id, 40), true);
    // The view moved back in time: tmux draws its position marker, "[40/<history>]",
    // and lines from far above the bottom, not the last line of output.
    await until(() => /\[40\/\d+\]/.test(text(s.id)), 6000, 'the scroll position marker');
    assert.match(text(s.id), /5\d/, 'older lines are drawn');
    assert.ok(!text(s.id).includes('end-of-output'), 'the bottom of the output is out of view');

    clear(s.id);
    m.write(s.id, 'echo back-live\r');     // typing leaves scrolling first
    await until(() => text(s.id).includes('back-live'), 6000, 'the prompt again');

    assert.equal(m.scroll('nope', 5), false);
    assert.equal(m.live(s.id), true);
    m.shutdown();
  } finally { r.cleanup(); }
});

test('two terminals are never attached to one session', opts, async () => {
  const r = rig();
  try {
    const { m, tmux, text } = r.make();
    const s = m.create({ kind: 'shell' });
    await until(() => text(s.id).length > 0, 6000, 'a prompt');
    for (let i = 0; i < 4; i++) { m.redraw(s.id); await new Promise((res) => setTimeout(res, 120)); }
    const clients = spawnSync('tmux', ['-L', tmux.socket, 'list-clients', '-F', '#{client_name}'], { encoding: 'utf8' }).stdout.trim().split('\n').filter(Boolean);
    assert.equal(clients.length, 1, 'redrawing replaces the terminal, it does not add one');
    m.shutdown();
  } finally { r.cleanup(); }
});

test('a session killed from outside disappears instead of hanging around', opts, async () => {
  const r = rig();
  try {
    const { m, tmux, text } = r.make();
    const s = m.create({ kind: 'shell' });
    await until(() => text(s.id).length > 0, 6000, 'a prompt');
    const gone = new Promise((res) => m.on('exit', (id) => res(id)));
    tmux.kill('nami-' + s.id);
    assert.equal(await Promise.race([gone, new Promise((_, rej) => setTimeout(() => rej(new Error('still listed')), 6000))]), s.id);
    assert.equal(m.list().length, 0);
  } finally { r.cleanup(); }
});

test('without tmux, sessions work as before and end with the server', async () => {
  const spawned = [];
  const m = new SessionManager({
    spawnPty: (file, args, o) => { const p = { file, killed: false, onData() {}, onExit() {}, write() {}, resize: () => false, kill() { p.killed = true; }, resizable: false }; spawned.push(p); return p; },
    env: { SHELL: '/bin/sh' }, tmux: null,
  });
  const s = m.create({ kind: 'shell' });
  assert.equal(s.persistent, false);
  assert.equal(m.adopt(), 0);
  assert.equal(m.redraw(s.id), false);
  assert.equal(m.scroll(s.id, 5), false);
  m.shutdown();
  assert.equal(spawned[0].killed, true);
});
