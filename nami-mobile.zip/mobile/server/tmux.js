'use strict';
// Sessions that outlive everything: the server, the page, the app.
//
// Each Nami session runs inside its own tmux session on a private tmux server
// (`tmux -L nami`, with its own config, so the user's own tmux is untouched).
// The Nami server only ever *attaches* to it. Stop the server, close the app,
// let Android kill Termux's foreground: the agent keeps going in tmux, and the
// next server start adopts it again. What Nami needs to remember (name, kind,
// agent, folder, start time) is kept as tmux user options on the session
// itself, so there is no second file to fall out of step.

const { spawnSync, execFile } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const PREFIX = 'nami-';
const NAME_RE = /^nami-[0-9a-f]{12}$/;
// tmux turns a tab in a format into "_", so fields are split on | instead. Fields a
// user can type (name, folder) come last, and clean() takes | out of the name.
const SEP = '|';

const CONF = `# Written by Nami for Android. Only the private "nami" tmux server reads this.
set -g default-terminal "screen-256color"
set -ga terminal-overrides ",xterm-256color:Tc"
set -g history-limit 20000
set -s escape-time 0
set -g status off
set -g mouse off
set -g remain-on-exit on
set -g set-clipboard off
`;

// Runs the program and writes its exit code into the session before the pane
// is marked dead. tmux's own pane_dead_status is not reliable for this: it was
// measured staying empty for good on roughly one exit in five. All values arrive
// as arguments, never spliced into the script text.
const WRAP = 'S=$1; N=$2; shift 2; "$@"; c=$?; tmux -L "$S" set-option -t "$N" @nami_exit "$c" >/dev/null 2>&1; exit "$c"';

// Text that ends up inside a tmux command line: no separators, no control codes.
function clean(s, max = 200) {
  return String(s == null ? '' : s).replace(/[;|\\\x00-\x1f\x7f]/g, ' ').trim().slice(0, max);
}

function createTmux({ socket = 'nami', bin = 'tmux', env = process.env, confPath = null } = {}) {
  const base = ['-L', socket];
  if (confPath) {
    try {
      fs.mkdirSync(path.dirname(confPath), { recursive: true, mode: 0o700 });
      fs.writeFileSync(confPath, CONF, { mode: 0o600 });
      base.push('-f', confPath);
    } catch (_) { /* run with tmux's own defaults */ }
  }
  const run = (args) => spawnSync(bin, [...base, ...args], { encoding: 'utf8', timeout: 5000, maxBuffer: 16 * 1024 * 1024, env });
  const fire = (args, done) => execFile(bin, [...base, ...args], { timeout: 5000, env }, () => { if (done) done(); });
  const ok = (r) => !!r && r.status === 0;

  return {
    socket,

    available() {
      try { return spawnSync(bin, ['-V'], { encoding: 'utf8', timeout: 3000, env }).status === 0; } catch (_) { return false; }
    },

    // The command that shows a session on a terminal.
    attachCommand(name) { return { file: bin, args: [...base, 'attach-session', '-t', name] }; },

    // Starts `file args` in a new tmux session. Throws with a plain message on failure.
    create({ id, cwd, cols, rows, file, args = [], name, kind, agentId, started, env = {} }) {
      if (/;/.test(cwd)) throw new Error('Folder names with ; are not supported here.');
      const tname = PREFIX + id;
      const r = run([
        'new-session', '-d', '-s', tname, '-x', String(cols), '-y', String(rows), '-c', cwd,
        ...Object.entries(env).flatMap(([k, v]) => ['-e', `${k}=${v}`]), '--',
        'sh', '-c', WRAP, 'nami-run', socket, tname, file, ...args,
        ';', 'set-option', '-t', tname, '@nami_name', clean(name, 60),
        ';', 'set-option', '-t', tname, '@nami_kind', clean(kind, 10),
        ';', 'set-option', '-t', tname, '@nami_agent', clean(agentId || '', 20),
        ';', 'set-option', '-t', tname, '@nami_cwd', cwd,
        ';', 'set-option', '-t', tname, '@nami_started', String(started),
      ]);
      if (!ok(r)) throw new Error('Could not start the session: ' + String((r && (r.stderr || r.error)) || 'tmux failed').trim().slice(0, 160));
      return tname;
    },

    has(name) { return ok(run(['has-session', '-t', '=' + name])); },

    // [{ name, title, kind, agentId, cwd, startedAt, cols, rows }] for every Nami session still alive.
    list() {
      const fmt = ['#{session_name}', '#{@nami_kind}', '#{@nami_agent}', '#{@nami_started}', '#{window_width}', '#{window_height}', '#{@nami_name}', '#{@nami_cwd}'].join(SEP);
      const r = run(['list-sessions', '-F', fmt]);
      if (!ok(r)) return [];
      const out = [];
      for (const line of r.stdout.split('\n')) {
        const f = line.split(SEP);
        if (f.length < 8 || !NAME_RE.test(f[0])) continue;
        out.push({
          name: f[0], kind: f[1] === 'agent' ? 'agent' : 'shell', agentId: f[2] || null,
          startedAt: Number(f[3]) || Date.now(), cols: Number(f[4]) || 80, rows: Number(f[5]) || 24,
          title: f[6], cwd: f.slice(7).join(SEP),
        });
      }
      return out;
    },

    // name -> the title the program set for itself (agents put what they are doing there).
    titles() {
      const r = run(['list-panes', '-a', '-F', ['#{session_name}', '#{pane_title}'].join(SEP)]);
      const out = new Map();
      if (!ok(r)) return out;
      const host = require('node:os').hostname();
      for (const line of r.stdout.split('\n')) {
        const i = line.indexOf(SEP);
        if (i < 0) continue;
        const t = line.slice(i + SEP.length).replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 80);
        if (t && t !== host && !/^(sh|bash|ash|zsh|tmux)$/.test(t)) out.set(line.slice(0, i), t);
      }
      return out;
    },

    // name -> exit status, for every session whose program has ended.
    // The wrapper's @nami_exit is the answer. If a program died without it
    // (killed by a signal, wrapper killed), fall back to what tmux saw:
    // pane_dead_status, or 128 + signal. null means "ended, status not known".
    deadPanes() {
      const fmt = ['#{session_name}', '#{pane_dead}', '#{@nami_exit}', '#{pane_dead_status}', '#{pane_dead_signal}'].join(SEP);
      const r = run(['list-panes', '-a', '-F', fmt]);
      const dead = new Map();
      if (!ok(r)) return dead;
      const num = (v) => (v !== '' && v != null && Number.isFinite(Number(v)) ? Number(v) : null);
      for (const line of r.stdout.split('\n')) {
        const [n, d, mine, st, sig] = line.split(SEP);
        if (!n || d !== '1') continue;
        const code = num(mine) ?? num(st) ?? (num(sig) > 0 ? 128 + num(sig) : null);
        dead.set(n, code);
      }
      return dead;
    },

    // What scrolled off the top of the pane, as terminal text ready to write to xterm.
    history(name, max = 3000) {
      const info = run(['display-message', '-p', '-t', name, '#{history_size}']);
      const h = ok(info) ? Number(info.stdout.trim()) || 0 : 0;
      if (h <= 0) return '';
      const r = run(['capture-pane', '-p', '-e', '-J', '-t', name, '-S', '-' + Math.min(h, max), '-E', '-1']);
      return ok(r) ? r.stdout.replace(/\n/g, '\r\n') : '';
    },

    // Scrolling the way a thumb expects: into tmux's copy mode and back out at the bottom.
    scrollUp(name, n, done) { fire(['copy-mode', '-e', '-t', name, ';', 'send-keys', '-t', name, '-X', '-N', String(n), 'scroll-up'], done); },
    scrollDown(name, n, done) { fire(['send-keys', '-t', name, '-X', '-N', String(n), 'scroll-down'], done); },
    cancelCopyMode(name) { run(['send-keys', '-t', name, '-X', 'cancel']); },

    // Is the program a full-screen one (less, a coding agent's own screen), and does it want the mouse wheel?
    paneMode(name) {
      const r = run(['display-message', '-p', '-t', name, ['#{alternate_on}', '#{mouse_any_flag}', '#{mouse_sgr_flag}', '#{pane_in_mode}'].join(SEP)]);
      if (!ok(r)) return { alt: false, mouse: false, sgr: false, inMode: false };
      const [a, m, g, i] = r.stdout.trim().split(SEP);
      return { alt: a === '1', mouse: m === '1', sgr: g === '1', inMode: i === '1' };
    },
    // The wheel for a full-screen program: real wheel events if it asked for the mouse, otherwise Page Up / Page Down.
    wheel(name, up, n, mode, done) {
      const ticks = Math.max(1, Math.min(40, n));
      if (mode.mouse) {
        const seq = mode.sgr ? `\x1b[<${up ? 64 : 65};40;12M` : `\x1b[M${String.fromCharCode(up ? 96 : 97, 32 + 40, 32 + 12)}`;
        fire(['send-keys', '-t', name, '-l', seq.repeat(ticks)], done);
      } else {
        fire(['send-keys', '-t', name, '-N', String(Math.max(1, Math.min(10, Math.round(n / 8)))), up ? 'PageUp' : 'PageDown'], done);
      }
    },

    kill(name) { return ok(run(['kill-session', '-t', '=' + name])); },
    killServer() { return ok(run(['kill-server'])); },
  };
}

module.exports = { createTmux, clean, PREFIX, NAME_RE };
