'use strict';
// Optional cloud speech-to-text: the page records a short clip, this sends it to an
// OpenAI-compatible /audio/transcriptions endpoint with the key you saved, and returns the text.
// The key lives in one file only its owner can read and is never sent back to the page.
const fs = require('node:fs');
const path = require('node:path');

const DEFAULT_BASE = 'https://api.openai.com/v1';
const MAX_B64 = 3 * 1024 * 1024;
const MIME_EXT = { 'audio/webm': 'webm', 'audio/ogg': 'ogg', 'audio/mp4': 'm4a', 'audio/mpeg': 'mp3', 'audio/wav': 'wav', 'audio/x-wav': 'wav' };

function createVoice({ file, fetchImpl = globalThis.fetch }) {
  const load = () => { try { const d = JSON.parse(fs.readFileSync(file, 'utf8')); return d && typeof d === 'object' ? d : {}; } catch (_) { return {}; } };
  const store = (d) => {
    fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
    const tmp = file + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(d), { mode: 0o600 }); fs.renameSync(tmp, file);
  };
  const okBase = (u) => { try { const x = new URL(u); return x.protocol === 'https:' || (x.protocol === 'http:' && ['127.0.0.1', 'localhost'].includes(x.hostname)); } catch (_) { return false; } };
  return {
    status() { const d = load(); return { configured: !!d.key, model: d.model || 'whisper-1', baseUrl: d.baseUrl || DEFAULT_BASE }; },
    save({ key, model, baseUrl }) {
      const d = load();
      if (typeof key === 'string' && key.trim()) { if (/[\0\r\n]/.test(key) || key.length > 500) throw new Error('That key does not look right.'); d.key = key.trim(); }
      if (!d.key) throw new Error('Enter your API key.');
      if (typeof model === 'string' && model.trim()) d.model = model.trim().slice(0, 60);
      if (typeof baseUrl === 'string' && baseUrl.trim()) { if (!okBase(baseUrl.trim())) throw new Error('The address must start with https://.'); d.baseUrl = baseUrl.trim().replace(/\/+$/, ''); }
      store(d); return this.status();
    },
    clear() { try { fs.unlinkSync(file); } catch (_) { /* none */ } return this.status(); },
    async transcribe({ b64, mime }) {
      const d = load();
      if (!d.key) throw new Error('Add your speech key in Settings → Voice first.');
      if (typeof b64 !== 'string' || !b64 || b64.length > MAX_B64) throw new Error('That recording is too long. Keep it under a minute.');
      const type = String(mime || 'audio/webm').split(';')[0].trim().toLowerCase();
      const ext = MIME_EXT[type];
      if (!ext) throw new Error('That audio type is not supported.');
      const form = new FormData();
      form.append('file', new Blob([Buffer.from(b64, 'base64')], { type }), `clip.${ext}`);
      form.append('model', d.model || 'whisper-1');
      let res;
      try { res = await fetchImpl((d.baseUrl || DEFAULT_BASE) + '/audio/transcriptions', { method: 'POST', headers: { authorization: 'Bearer ' + d.key }, body: form, signal: AbortSignal.timeout(45000) }); }
      catch (e) { throw new Error('Could not reach the speech service: ' + (e.name === 'TimeoutError' ? 'timed out' : 'check your connection')); }
      if (!res.ok) {
        let msg = ''; try { msg = (await res.json()).error?.message || ''; } catch (_) { /* not json */ }
        throw new Error(res.status === 401 ? 'The speech key was refused.' : 'Speech service said: ' + (String(msg).slice(0, 160) || res.status));
      }
      const out = await res.json();
      return { text: String(out.text || '').trim() };
    },
  };
}
module.exports = { createVoice };
