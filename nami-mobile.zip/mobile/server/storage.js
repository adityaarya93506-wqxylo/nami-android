'use strict';
// What the Linux takes up on the phone, a cache clean-up, and a backup of /root (your files, agents,
// settings) as one .tar.gz inside /root/Backups, which Files can download.

const fs = require('node:fs');
const path = require('node:path');
const { execFile } = require('node:child_process');

const run = (file, args, opts = {}) => new Promise((resolve) => {
  execFile(file, args, { timeout: 120000, maxBuffer: 1 << 20, ...opts }, (err, stdout, stderr) => resolve({ err, stdout: String(stdout || ''), stderr: String(stderr || '') }));
});

async function sizeMB(p) {
  if (!fs.existsSync(p)) return 0;
  const r = await run('du', ['-sk', p]);
  const n = parseInt(r.stdout, 10);
  return Number.isFinite(n) ? Math.round(n / 1024) : 0;
}

const freeMB = (home) => { try { const s = fs.statfsSync(home); return Math.floor(s.bavail * s.bsize / 1048576); } catch (_) { return null; } };

const cacheDirs = (home) => [path.join(home, '.npm'), path.join(home, '.cache'), '/var/cache/apt', '/var/lib/apt/lists'];

async function info({ home }) {
  const backups = path.join(home, 'Backups');
  const [mine, system, caches, bk] = await Promise.all([
    sizeMB(home), sizeMB('/usr'),
    Promise.all(cacheDirs(home).map(sizeMB)).then((a) => a.reduce((x, y) => x + y, 0)),
    sizeMB(backups),
  ]);
  return { freeMB: freeMB(home), items: [
    { id: 'home', label: 'Your files and settings (/root)', mb: mine },
    { id: 'system', label: 'Programs installed in the Linux (/usr)', mb: system },
    { id: 'backups', label: 'Backups', mb: bk },
    { id: 'caches', label: 'Caches you can clear', mb: caches },
  ] };
}

async function clean({ home }) {
  const before = (await Promise.all(cacheDirs(home).map(sizeMB))).reduce((x, y) => x + y, 0);
  for (const d of [path.join(home, '.npm'), path.join(home, '.cache')]) {
    try { fs.rmSync(d, { recursive: true, force: true }); } catch (_) { /* in use: skip */ }
  }
  await run('apt-get', ['clean']);
  for (const d of ['/var/lib/apt/lists']) {
    try { for (const f of fs.readdirSync(d)) fs.rmSync(path.join(d, f), { recursive: true, force: true }); } catch (_) { /* not there */ }
  }
  const after = (await Promise.all(cacheDirs(home).map(sizeMB))).reduce((x, y) => x + y, 0);
  return { freedMB: Math.max(0, before - after) };
}

const stamp = (d = new Date()) => {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}`;
};

async function backup({ home, keep = 3 }) {
  const dir = path.join(home, 'Backups');
  fs.mkdirSync(dir, { recursive: true });
  const free = freeMB(home);
  if (free !== null && free < 300) throw new Error(`Only ${free} MB free. Clear caches first, then try again.`);
  const file = path.join(dir, `nami-backup-${stamp()}.tar.gz`);
  const r = await run('tar', ['-czf', file, '--exclude=./Backups', '--exclude=./.npm', '--exclude=./.cache', '--exclude=./.nvm/.cache', '-C', home, '.'], { timeout: 15 * 60 * 1000 });
  // tar exits 1 when a file changed while it was read: that still leaves a usable archive.
  if (r.err && !(r.err.code === 1 && fs.existsSync(file))) { try { fs.rmSync(file, { force: true }); } catch (_) { /* ignore */ } throw new Error('The backup failed: ' + (r.stderr.trim().split('\n')[0] || r.err.message)); }
  const old = fs.readdirSync(dir).filter((f) => /^nami-backup-.*\.tar\.gz$/.test(f)).sort().reverse().slice(keep);
  for (const f of old) { try { fs.rmSync(path.join(dir, f), { force: true }); } catch (_) { /* ignore */ } }
  return { path: file, name: path.basename(file), mb: Math.max(1, Math.round(fs.statSync(file).size / 1048576)) };
}

module.exports = { info, clean, backup };
