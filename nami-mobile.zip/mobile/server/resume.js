'use strict';
// "Continue where it stopped": find the conversation an agent last had in a folder, from the records
// the agent keeps itself. Best effort: anything unreadable means "not found", never an error.
// Where each agent keeps them (checked against the desktop app's agent-resume.js):
//   kimi ~/.kimi-code/session_index.jsonl · codex ~/.codex/sessions/Y/M/D/rollout-*.jsonl
//   grok ~/.grok/sessions/<encoded folder>/<id>/ · agy ~/.gemini/antigravity-cli/cache/last_conversations.json
//   hermes ~/.hermes/state.db (SQLite) · claude and opencode have a "continue" flag of their own.

const fs = require('node:fs');
const path = require('node:path');

const ID = /^[\w.-]+$/;
const stat = (p) => { try { return fs.statSync(p); } catch (_) { return null; } };
const list = (p) => { try { return fs.readdirSync(p); } catch (_) { return []; } };
const readText = (p, max = 2 * 1024 * 1024) => {
  try { const st = fs.statSync(p); const fd = fs.openSync(p, 'r'); try { const len = Math.min(st.size, max); const b = Buffer.alloc(len); fs.readSync(fd, b, 0, len, st.size - len); return b.toString('utf8'); } finally { fs.closeSync(fd); } } catch (_) { return ''; }
};
const same = (a, b) => { const n = (x) => String(x || '').replace(/\/+$/, ''); return n(a) === n(b); };

const finders = {
  kimi(home, cwd) {
    let best = null;
    for (const line of readText(path.join(home, '.kimi-code', 'session_index.jsonl')).split('\n')) {
      let r; try { r = JSON.parse(line); } catch (_) { continue; }
      if (!r || !same(r.workDir, cwd) || !ID.test(String(r.sessionId))) continue;
      const st = stat(r.sessionDir); const t = st ? st.mtimeMs : 0;
      if (!best || t >= best.t) best = { id: String(r.sessionId), t };
    }
    return best && best.id;
  },
  codex(home, cwd) {
    const root = path.join(home, '.codex', 'sessions');
    const files = [];
    for (const y of list(root).sort().reverse().slice(0, 3)) for (const m of list(path.join(root, y)).sort().reverse().slice(0, 4)) for (const d of list(path.join(root, y, m)).sort().reverse().slice(0, 8)) {
      for (const f of list(path.join(root, y, m, d))) if (f.startsWith('rollout-') && f.endsWith('.jsonl')) { const p = path.join(root, y, m, d, f); const st = stat(p); if (st) files.push({ p, t: st.mtimeMs }); }
    }
    files.sort((a, b) => b.t - a.t);
    for (const { p } of files.slice(0, 60)) {
      const first = readText(p, 16 * 1024).split('\n')[0];
      try { const r = JSON.parse(first); const pl = r.payload || {}; const sid = pl.session_id || pl.id; if (same(pl.cwd, cwd) && ID.test(String(sid))) return String(sid); } catch (_) { /* cut line */ }
    }
    return null;
  },
  grok(home, cwd) {
    const dir = path.join(home, '.grok', 'sessions', encodeURIComponent(cwd));
    let best = null;
    for (const id of list(dir)) { const st = stat(path.join(dir, id)); if (st && st.isDirectory() && ID.test(id) && (!best || st.mtimeMs > best.t)) best = { id, t: st.mtimeMs }; }
    return best && best.id;
  },
  agy(home, cwd) {
    try { const m = JSON.parse(readText(path.join(home, '.gemini', 'antigravity-cli', 'cache', 'last_conversations.json'))); const id = m[cwd]; return ID.test(String(id)) ? String(id) : null; } catch (_) { return null; }
  },
  hermes(home, cwd) {
    let sqlite; try { sqlite = require('node:sqlite'); } catch (_) { return null; }
    const f = path.join(home, '.hermes', 'state.db');
    if (!stat(f)) return null;
    let db; try { db = new sqlite.DatabaseSync(f, { readOnly: true }); } catch (_) { return null; }
    try { const r = db.prepare('SELECT id FROM sessions WHERE cwd = ? ORDER BY started_at DESC LIMIT 1').get(cwd); return r && ID.test(String(r.id)) ? String(r.id) : null; } catch (_) { return null; } finally { try { db.close(); } catch (_) { /* fine */ } }
  },
};

// agent flags once the id is known; `fallback` is used when no conversation was found
const COMMANDS = {
  claude: { fallback: ['--continue'] },
  opencode: { fallback: ['--continue'] },
  codex: { withId: (s) => ['resume', s], fallback: ['resume', '--last'] },
  kimi: { withId: (s) => ['-r', s] },
  grok: { withId: (s) => ['--resume', s] },
  antigravity: { finder: 'agy', withId: (s) => ['--conversation', s] },
  hermes: { withId: (s) => ['--resume', s] },
};

function canResume(agentId) { return Object.prototype.hasOwnProperty.call(COMMANDS, agentId); }

// -> argument list, or [] when there is nothing to continue
function resumeFor(agentId, { home, cwd }) {
  if (!canResume(agentId)) return [];
  const c = COMMANDS[agentId];
  const find = finders[c.finder || agentId];
  const id = find ? find(home, cwd) : null;
  if (id && c.withId) return c.withId(id);
  return c.fallback ? c.fallback.slice() : [];
}

module.exports = { resumeFor, canResume, finders };
