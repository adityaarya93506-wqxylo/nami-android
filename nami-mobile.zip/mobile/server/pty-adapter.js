'use strict';
// One way to start a program on a terminal, whatever the phone can offer.
//
// Termux is the target. node-pty needs a native build there (python, make, clang)
// and sometimes fails, so this tries it first and falls back to `script`, which
// ships with util-linux and gives the child a real tty without compiling
// anything. The fallback cannot resize a running terminal (its tty keeps the
// size it started with), and it says so through `resizable: false`.

const { spawn } = require('node:child_process');

function loadNodePty() {
  for (const name of ['node-pty', '@lydell/node-pty']) {
    try { return require(name); } catch (_) { /* try the next one */ }
  }
  return null;
}

// POSIX single-quote: safe to hand to `sh -c`.
function shQuote(s) {
  return "'" + String(s).replace(/'/g, `'\\''`) + "'";
}

function spawnWithNodePty(nodePty, file, args, { cwd, env, cols, rows }) {
  const p = nodePty.spawn(file, args, { name: 'xterm-256color', cols, rows, cwd, env });
  return {
    pid: p.pid,
    resizable: true,
    onData: (cb) => { p.onData(cb); },
    onExit: (cb) => { p.onExit(({ exitCode }) => cb(exitCode)); },
    write: (d) => { p.write(d); },
    resize: (c, r) => { try { p.resize(c, r); return true; } catch (_) { return false; } },
    kill: () => { try { p.kill(); } catch (_) { /* already gone */ } },
  };
}

function spawnWithScript(file, args, { cwd, env, cols, rows }) {
  const line = [file, ...args].map(shQuote).join(' ');
  // script's tty starts with no size at all (its own stdin is a pipe), so give
  // it the one the page asked for before the program looks.
  const inner = `stty cols ${Math.floor(Number(cols)) || 80} rows ${Math.floor(Number(rows)) || 24} 2>/dev/null; exec ${line}`;
  const child = spawn('script', ['-qefc', inner, '/dev/null'], {   // -e: exit with the child's own status
    cwd,
    env: { ...env, COLUMNS: String(cols), LINES: String(rows) },
    stdio: ['pipe', 'pipe', 'pipe'],
  });
  const dataCbs = [];
  const exitCbs = [];
  let exited = false;
  const feed = (buf) => { const s = buf.toString('utf8'); for (const cb of dataCbs) cb(s); };
  child.stdout.on('data', feed);
  child.stderr.on('data', feed);
  child.stdin.on('error', () => { /* the child ended first */ });
  child.on('error', (err) => {
    feed(Buffer.from(`\r\n[could not start: ${err.message}]\r\n`));
    if (!exited) { exited = true; for (const cb of exitCbs) cb(127); }
  });
  child.on('close', (code) => {
    if (exited) return;
    exited = true;
    for (const cb of exitCbs) cb(code == null ? 0 : code);
  });
  return {
    pid: child.pid,
    resizable: false,
    onData: (cb) => { dataCbs.push(cb); },
    onExit: (cb) => { exitCbs.push(cb); },
    write: (d) => { if (!exited) child.stdin.write(d); },
    resize: () => false,
    // SIGHUP to `script` ends script and leaves the program it started running
    // (measured: a tmux client and a shell both outlived it). SIGTERM makes
    // script take the program down with it; SIGKILL is the backstop.
    kill: () => {
      if (exited) return;
      try { child.kill('SIGTERM'); } catch (_) { return; }
      const t = setTimeout(() => { if (!exited) { try { child.kill('SIGKILL'); } catch (_) { /* gone */ } } }, 1500);
      t.unref();
    },
  };
}

// Returns spawn(file, args, opts) -> { pid, resizable, onData, onExit, write, resize, kill }.
function createSpawner({ nodePty = loadNodePty(), forceScript = false } = {}) {
  if (nodePty && !forceScript) {
    return (file, args, opts) => {
      try { return spawnWithNodePty(nodePty, file, args, opts); } catch (_) { return spawnWithScript(file, args, opts); }
    };
  }
  return (file, args, opts) => spawnWithScript(file, args, opts);
}

module.exports = { createSpawner, loadNodePty, shQuote };
