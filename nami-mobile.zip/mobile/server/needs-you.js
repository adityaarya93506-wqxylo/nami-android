'use strict';
// Is an agent stopped and waiting for the person? A guess from the end of its output: it has gone quiet
// and the last lines look like a question (approve this? yes/no, press enter). Wrong guesses are cheap
// (a badge that goes away on the next key), so it errs towards saying nothing.

const ANSI = /\x1b\[[0-?]*[ -/]*[@-~]|\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)|\x1b[()][A-Za-z0-9]|\x1b[=>78]|[\x00-\x08\x0b\x0c\x0e-\x1f]/g;
const strip = (s) => String(s || '').replace(ANSI, '').replace(/\r/g, '\n');

const ASK = [
  /\((?:y\/n|Y\/n|y\/N|yes\/no)\)/,
  /\[(?:y\/n|Y\/n|y\/N|yes\/no)\]/,
  /do you want to (?:proceed|make this edit|create|run|allow|continue|overwrite|apply)/i,
  /(?:^|\n)\s*[❯>]\s*1\.\s*(?:yes|allow|approve)/i,
  /\ballow (?:this|once|always|the)\b.*\?/i,
  /\b(?:approve|permission|confirm)\b.*\?\s*$/im,
  /press (?:enter|return|any key) to (?:continue|confirm|proceed)/i,
  /(?:enter|return) to confirm.*esc to cancel|esc to cancel.*(?:enter|return) to confirm/i,
  /waiting for (?:your |user )?(?:input|approval|confirmation|response)/i,
];

// text: the end of the session's raw output. Only the last few lines are looked at.
function looksLikeAsk(text) {
  const lines = strip(text).split('\n').map((l) => l.replace(/\s+$/, '')).filter((l) => l.trim());
  const tail = lines.slice(-10).join('\n');
  return ASK.some((re) => re.test(tail));
}

// s: { lastDataAt, lastInputAt, buf }; quietMs: how long the output must have been still.
function needsYou(s, now = Date.now(), quietMs = 4000) {
  if (!s || !s.lastDataAt) return false;
  if (now - s.lastDataAt < quietMs) return false;                  // still working
  if ((s.lastInputAt || 0) >= s.lastDataAt) return false;          // you answered; nothing new since
  return looksLikeAsk(String(s.buf || '').slice(-2500));
}

module.exports = { needsYou, looksLikeAsk, strip };
