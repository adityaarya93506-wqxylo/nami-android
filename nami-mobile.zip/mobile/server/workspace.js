'use strict';
// The files part of the desk: list, read, edit, make, rename and delete, all
// inside one chosen folder (the "workspace"), like the desktop app's "access
// limited to one chosen folder". A path that points outside it, by ".." or by
// a symlink, is refused.

const fs = require('node:fs');
const path = require('node:path');

const MAX_TEXT = 2 * 1024 * 1024;
const MAX_ENTRIES = 3000;
const MAX_UPLOAD = 200 * 1024 * 1024;

const EXT = {
  image: ['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'bmp', 'ico', 'avif'],
  video: ['mp4', 'webm', 'mov', 'm4v'],
  audio: ['mp3', 'wav', 'm4a', 'aac', 'ogg', 'oga', 'flac'],
  pdf: ['pdf'],
};
const MIME = {
  png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', svg: 'image/svg+xml',
  bmp: 'image/bmp', ico: 'image/x-icon', avif: 'image/avif', mp4: 'video/mp4', webm: 'video/webm', mov: 'video/quicktime',
  m4v: 'video/mp4', mp3: 'audio/mpeg', wav: 'audio/wav', m4a: 'audio/mp4', aac: 'audio/aac', ogg: 'audio/ogg', oga: 'audio/ogg',
  flac: 'audio/flac', pdf: 'application/pdf',
};

function extOf(name) {
  const i = String(name).lastIndexOf('.');
  return i > 0 ? String(name).slice(i + 1).toLowerCase() : '';
}

function kindOf(name) {
  const e = extOf(name);
  for (const [k, list] of Object.entries(EXT)) if (list.includes(e)) return k;
  if (['md', 'markdown', 'mdx'].includes(e)) return 'markdown';
  return 'text';
}

class WorkspaceError extends Error {
  constructor(message, code = 'bad') { super(message); this.code = code; }
}

function createWorkspace({ root, home = root }) {
  let base = path.resolve(root);
  const realBase = () => { try { return fs.realpathSync(base); } catch (_) { return base; } };

  // Resolves p inside the workspace, or throws. `exists:false` allows a path
  // that is about to be created: its parent must exist and be inside.
  function inside(p, { exists = true } = {}) {
    if (typeof p !== 'string' || !p || p.includes('\0')) throw new WorkspaceError('Bad path.');
    const abs = path.resolve(base, p.replace(/^~(?=$|\/)/, home));
    const rb = realBase();
    const within = (x) => x === rb || x.startsWith(rb + path.sep);
    if (!(abs === base || abs.startsWith(base + path.sep))) throw new WorkspaceError('That is outside the workspace folder.', 'outside');
    if (exists) {
      let real;
      try { real = fs.realpathSync(abs); } catch (_) { throw new WorkspaceError('Not found.', 'missing'); }
      if (!within(real)) throw new WorkspaceError('That is outside the workspace folder.', 'outside');
    } else {
      let real;
      try { real = fs.realpathSync(path.dirname(abs)); } catch (_) { throw new WorkspaceError('The folder does not exist.', 'missing'); }
      if (!within(real)) throw new WorkspaceError('That is outside the workspace folder.', 'outside');
    }
    return abs;
  }

  function validName(name) {
    if (typeof name !== 'string' || !name.trim() || name.length > 200 || /[\/\0]/.test(name) || name === '.' || name === '..') {
      throw new WorkspaceError('That name is not allowed.');
    }
    return name.trim();
  }

  return {
    get root() { return base; },
    setRoot(p) {
      const abs = path.resolve(String(p || '').replace(/^~(?=$|\/)/, home));
      let st;
      try { st = fs.statSync(abs); } catch (_) { throw new WorkspaceError('That folder does not exist.', 'missing'); }
      if (!st.isDirectory()) throw new WorkspaceError('That is not a folder.');
      base = abs;
      return base;
    },
    inside,

    ls(p = base) {
      const dir = inside(p);
      let names;
      try { names = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { throw new WorkspaceError('Cannot open this folder.', e.code === 'ENOTDIR' ? 'notdir' : 'bad'); }
      const out = [];
      for (const d of names.slice(0, MAX_ENTRIES)) {
        let st; let isDir = d.isDirectory(); let link = d.isSymbolicLink();
        try { st = fs.statSync(path.join(dir, d.name)); isDir = st.isDirectory(); } catch (_) { st = null; }
        out.push({ name: d.name, type: isDir ? 'dir' : 'file', size: st && !isDir ? st.size : 0, mtime: st ? Math.round(st.mtimeMs) : 0, link, kind: isDir ? 'dir' : kindOf(d.name) });
      }
      out.sort((a, b) => (a.type === b.type ? a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' }) : a.type === 'dir' ? -1 : 1));
      return { path: dir, parent: dir === base ? null : path.dirname(dir), entries: out, truncated: names.length > MAX_ENTRIES };
    },

    read(p) {
      const file = inside(p);
      const st = fs.statSync(file);
      if (st.isDirectory()) throw new WorkspaceError('That is a folder.', 'isdir');
      const kind = kindOf(file);
      const info = { path: file, name: path.basename(file), kind, size: st.size, mtime: Math.round(st.mtimeMs) };
      if (kind === 'image' || kind === 'video' || kind === 'audio' || kind === 'pdf') return info;
      if (st.size > MAX_TEXT) return { ...info, kind: 'toobig' };
      const buf = fs.readFileSync(file);
      if (buf.includes(0)) return { ...info, kind: 'binary' };
      return { ...info, text: buf.toString('utf8') };
    },

    write(p, text, expectMtime) {
      if (typeof text !== 'string' || Buffer.byteLength(text) > MAX_TEXT) throw new WorkspaceError('That file is too large to save here.');
      const file = inside(p, { exists: false });
      let cur = null;
      try { cur = fs.statSync(file); } catch (_) { /* a new file */ }
      if (cur && cur.isDirectory()) throw new WorkspaceError('That is a folder.', 'isdir');
      if (cur && Number.isFinite(expectMtime) && Math.round(cur.mtimeMs) !== expectMtime) {
        throw new WorkspaceError('This file changed while you were editing it.', 'conflict');
      }
      const tmp = path.join(path.dirname(file), `.nami-${process.pid}-${Date.now()}.tmp`);
      fs.writeFileSync(tmp, text, { mode: cur ? cur.mode & 0o777 : 0o644 });
      fs.renameSync(tmp, file);
      return { path: file, mtime: Math.round(fs.statSync(file).mtimeMs), size: Buffer.byteLength(text) };
    },

    mkdir(parent, name) {
      const dir = inside(parent);
      const target = path.join(dir, validName(name));
      inside(target, { exists: false });
      try { fs.mkdirSync(target); } catch (e) { throw new WorkspaceError(e.code === 'EEXIST' ? 'That name is already taken.' : 'Could not create the folder.'); }
      return { path: target };
    },

    touch(parent, name, text = '') {
      const dir = inside(parent);
      const target = path.join(dir, validName(name));
      inside(target, { exists: false });
      try { fs.writeFileSync(target, String(text), { flag: 'wx', mode: 0o644 }); } catch (e) { throw new WorkspaceError(e.code === 'EEXIST' ? 'That name is already taken.' : 'Could not create the file.'); }
      return { path: target };
    },

    rename(from, newName) {
      const src = inside(from);
      if (src === base) throw new WorkspaceError('The workspace folder itself cannot be renamed here.');
      const target = path.join(path.dirname(src), validName(newName));
      inside(target, { exists: false });
      if (fs.existsSync(target)) throw new WorkspaceError('That name is already taken.');
      fs.renameSync(src, target);
      return { path: target };
    },

    // A copy next to the original: "name copy", "name copy 2"…
    duplicate(p) {
      const src = inside(p);
      if (src === base) throw new WorkspaceError('The workspace folder itself cannot be copied here.');
      const ext = fs.statSync(src).isDirectory() ? '' : path.extname(src);
      const stem = path.basename(src).slice(0, path.basename(src).length - ext.length);
      let target = path.join(path.dirname(src), `${stem} copy${ext}`);
      for (let n = 2; fs.existsSync(target); n++) target = path.join(path.dirname(src), `${stem} copy ${n}${ext}`);
      inside(target, { exists: false });
      fs.cpSync(src, target, { recursive: true, errorOnExist: true, force: false, dereference: false, verbatimSymlinks: true });
      return { path: target };
    },

    // Into another folder of the workspace, never over something already there.
    move(from, toDir) {
      const src = inside(from);
      if (src === base) throw new WorkspaceError('The workspace folder itself cannot be moved.');
      const dir = inside(toDir);
      if (!fs.statSync(dir).isDirectory()) throw new WorkspaceError('That is not a folder.');
      if (dir === src || dir.startsWith(src + path.sep)) throw new WorkspaceError('A folder cannot go inside itself.');
      const target = path.join(dir, path.basename(src));
      inside(target, { exists: false });
      if (fs.existsSync(target)) throw new WorkspaceError('That name is already taken there.');
      fs.renameSync(src, target);
      return { path: target };
    },

    remove(p) {
      const target = inside(p);
      if (target === base) throw new WorkspaceError('The workspace folder itself cannot be deleted.');
      fs.rmSync(target, { recursive: true, force: true });
      return { path: target };
    },

    // Bringing a file in from the phone, in pieces (a message is at most a few MB).
    // The first piece starts a hidden .part file; the last one gives it its name,
    // changed to "name (1).ext" if that name is taken. Nothing is ever overwritten.
    put(parent, name, b64, { first = false, last = false } = {}) {
      const dir = inside(parent);
      const clean = validName(name);
      const part = path.join(dir, `.nami-upload-${clean}.part`);
      inside(part, { exists: false });
      const chunk = Buffer.from(String(b64 || ''), 'base64');
      if (first) { try { fs.rmSync(part, { force: true }); } catch (_) { /* fine */ } }
      else if (!fs.existsSync(part)) throw new WorkspaceError('The upload was interrupted. Try again.');
      if (chunk.length > 3 * 1024 * 1024) throw new WorkspaceError('Piece too large.');
      if ((fs.existsSync(part) ? fs.statSync(part).size : 0) + chunk.length > MAX_UPLOAD) {
        fs.rmSync(part, { force: true });
        throw new WorkspaceError('That file is too large to bring in (limit 200 MB).');
      }
      fs.appendFileSync(part, chunk, { mode: 0o644 });
      if (!last) return { done: false };
      const ext = path.extname(clean);
      const stem = clean.slice(0, clean.length - ext.length);
      let target = path.join(dir, clean);
      for (let n = 1; fs.existsSync(target); n++) target = path.join(dir, `${stem} (${n})${ext}`);
      fs.renameSync(part, target);
      return { done: true, path: target };
    },

    // Where a raw download of this file would come from, with its mime type; null if it is not served raw.
    rawInfo(p) {
      const file = inside(p);
      const st = fs.statSync(file);
      if (!st.isFile()) return null;
      const m = MIME[extOf(file)];
      return { file, size: st.size, mime: m || 'application/octet-stream', inline: Boolean(m) };
    },
  };
}

module.exports = { createWorkspace, WorkspaceError, kindOf, MIME, extOf };
