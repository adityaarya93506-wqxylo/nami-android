'use strict';
// The agent CLIs Nami knows, trimmed to what a phone needs: a name, the command
// to run, and the one line that installs it. Mirrors KNOWN_AGENTS in
// src/main/agents-detect.js. Commands are fixed here and never taken from a
// client, so a client can pick an agent but cannot make the server run
// arbitrary text through this list.

const { spawnSync } = require('node:child_process');

const AGENTS = [
  { id: 'claude', name: 'Claude Code', bin: 'claude', sub: 'your Claude subscription', seed: (p) => [p], resume: ['--continue'],
    install: 'npm install -g @anthropic-ai/claude-code', uninstall: 'npm uninstall -g @anthropic-ai/claude-code' },
  { id: 'codex', name: 'Codex', bin: 'codex', sub: "OpenAI's coding agent", seed: (p) => [p], resume: ['resume', '--last'],
    install: 'npm install -g @openai/codex', uninstall: 'npm uninstall -g @openai/codex' },
  { id: 'opencode', name: 'OpenCode', bin: 'opencode', sub: 'open-source coding agent', seed: (p) => ['--prompt', p], resume: ['--continue'],
    install: 'npm install -g opencode-ai', uninstall: 'npm uninstall -g opencode-ai' },
  { id: 'kimi', name: 'Kimi Code', bin: 'kimi', sub: "Moonshot's coding agent",
    install: 'see https://www.kimi.com/code' },
  { id: 'hermes', name: 'Hermes', bin: 'hermes', sub: 'Nous Research agent',
    install: 'see the Hermes docs' },
];

const BY_ID = new Map(AGENTS.map((a) => [a.id, a]));

// Agents usually install into the user's own folders, which a server started
// from a plain shell may not have on its PATH. Add the usual ones.
function withUserPaths(env, home = require('node:os').homedir()) {
  const extra = ['.local/bin', '.claude/local', '.npm-global/bin', '.bun/bin', '.cargo/bin'].map((d) => `${home}/${d}`);
  const have = String(env.PATH || '').split(':').filter(Boolean);
  const add = extra.filter((d) => !have.includes(d));
  return { ...env, PATH: [...have, ...add].join(':') };
}

function findAgent(id) {
  return BY_ID.get(id) || null;
}

// `command -v` through sh: a PATH lookup, nothing executed from the agent.
// bin comes from the table above, never from a client.
function isInstalled(bin, { env = process.env } = {}) {
  try {
    const r = spawnSync('sh', ['-c', `command -v ${bin}`], { env, encoding: 'utf8', timeout: 4000 });
    return r.status === 0 && r.stdout.trim().length > 0;
  } catch (_) {
    return false;
  }
}

function listAgents(opts) {
  return AGENTS.map((a) => ({ id: a.id, name: a.name, sub: a.sub, install: a.install, canResume: Array.isArray(a.resume), chat: ['claude', 'codex', 'opencode'].includes(a.id), uninstall: a.uninstall || null, installed: isInstalled(a.bin, opts) }));
}

// A first message for an agent, passed as an argument (never typed through a shell). Returns [] when
// this agent has no such option. A leading "-" or a trailing ";" would be read as something else, so
// the text is made safe first.
function seedArgs(agent, text) {
  if (!agent || typeof agent.seed !== 'function') return [];
  let t = String(text == null ? '' : text).replace(/\0/g, '').trim().slice(0, 4000);
  if (!t) return [];
  t = t.replace(/^-+\s*/, '').replace(/;+\s*$/, '.');
  return t ? agent.seed(t) : [];
}

// Picking up where the last conversation in this folder stopped. Only for agents with a known flag.
function resumeArgs(agent) {
  return agent && Array.isArray(agent.resume) ? agent.resume.slice() : [];
}

module.exports = { resumeArgs, seedArgs, AGENTS, findAgent, listAgents, isInstalled, withUserPaths };
