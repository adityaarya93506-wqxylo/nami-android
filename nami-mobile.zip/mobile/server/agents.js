'use strict';
// The agent CLIs Nami knows, trimmed to what a phone needs: a name, the command
// to run, and the one line that installs it. Mirrors KNOWN_AGENTS in
// src/main/agents-detect.js. Commands are fixed here and never taken from a
// client, so a client can pick an agent but cannot make the server run
// arbitrary text through this list.

const { spawnSync } = require('node:child_process');

const AGENTS = [
  { id: 'claude', name: 'Claude Code', bin: 'claude', sub: 'your Claude subscription',
    install: 'npm install -g @anthropic-ai/claude-code' },
  { id: 'codex', name: 'Codex', bin: 'codex', sub: "OpenAI's coding agent",
    install: 'npm install -g @openai/codex' },
  { id: 'opencode', name: 'OpenCode', bin: 'opencode', sub: 'open-source coding agent',
    install: 'npm install -g opencode-ai' },
  { id: 'kimi', name: 'Kimi Code', bin: 'kimi', sub: "Moonshot's coding agent",
    install: 'see https://www.kimi.com/code' },
  { id: 'hermes', name: 'Hermes', bin: 'hermes', sub: 'Nous Research agent',
    install: 'see the Hermes docs' },
];

const BY_ID = new Map(AGENTS.map((a) => [a.id, a]));

// Agents usually install into the user's own folders, which a server started
// from a plain shell may not have on its PATH. Add the usual ones.
function withUserPaths(env, home = require('node:os').homedir()) {
  const extra = ['.local/bin', '.claude/local', '.npm-global/bin', '.bun/bin', '.cargo/bin'].map((d) => `${home}/${d}`);
  const have = String(env.PATH || '').split(':').filter(Boolean);
  const add = extra.filter((d) => !have.includes(d));
  return { ...env, PATH: [...have, ...add].join(':') };
}

function findAgent(id) {
  return BY_ID.get(id) || null;
}

// `command -v` through sh: a PATH lookup, nothing executed from the agent.
// bin comes from the table above, never from a client.
function isInstalled(bin, { env = process.env } = {}) {
  try {
    const r = spawnSync('sh', ['-c', `command -v ${bin}`], { env, encoding: 'utf8', timeout: 4000 });
    return r.status === 0 && r.stdout.trim().length > 0;
  } catch (_) {
    return false;
  }
}

function listAgents(opts) {
  return AGENTS.map((a) => ({ id: a.id, name: a.name, sub: a.sub, install: a.install, installed: isInstalled(a.bin, opts) }));
}

module.exports = { AGENTS, findAgent, listAgents, isInstalled, withUserPaths };
