'use strict';
// The page's questions about files, the library and providers. One function:
// handle(op, args) returns data or throws an Error with a plain message.

const fs = require('node:fs');
const path = require('node:path');
const library = require('./library');
const master = require('./agent-master');
const { usage } = require('./usage');
const setupCheck = require('./setup');
const { WorkspaceError } = require('./workspace');

const MAX_LIB_TEXT = 512 * 1024;

function createRpc({ workspace, keys, home, saveRoot = () => {}, settings = null, attach = null, connections = null, dataDir = home }) {
  const MAX_RECENTS = 12;
  const getRecents = () => (settings && Array.isArray(settings.get().recents) ? settings.get().recents : []);
  const setRecents = (list) => { if (settings) settings.set({ recents: list }); };
  const noteRecent = (p) => {
    const list = getRecents().filter((r) => r && typeof r.path === 'string');
    const cur = list.find((r) => r.path === p);
    const rest = list.filter((r) => r.path !== p);
    const entry = { path: p, pinned: cur ? !!cur.pinned : false, at: Date.now() };
    const pinned = rest.filter((r) => r.pinned);
    const loose = rest.filter((r) => !r.pinned);
    setRecents([entry, ...pinned, ...loose].filter((r, i, a) => r.pinned || a.slice(0, i + 1).filter((x) => !x.pinned).length <= MAX_RECENTS));
  };
  const libCtx = () => ({ home, project: workspace.root });

  const ops = {
    'fs.root': () => ({ root: workspace.root, home }),
    'fs.setRoot': ({ path: p }) => { const r = workspace.setRoot(p); saveRoot(r); noteRecent(r); return { root: r, home }; },
    'fs.ls': ({ path: p }) => workspace.ls(p || workspace.root),
    'fs.read': ({ path: p }) => workspace.read(p),
    'fs.write': ({ path: p, text, mtime }) => workspace.write(p, text, mtime),
    'fs.mkdir': ({ parent, name }) => workspace.mkdir(parent, name),
    'fs.touch': ({ parent, name }) => workspace.touch(parent, name),
    'fs.rename': ({ path: p, name }) => workspace.rename(p, name),
    'fs.copy': ({ path: p }) => workspace.duplicate(p),
    'fs.move': ({ path: p, to }) => workspace.move(p, to),
    'fs.recents': () => ({ recents: getRecents().filter((r) => { try { return fs.statSync(r.path).isDirectory(); } catch (_) { return false; } }) }),
    'fs.recentPin': ({ path: p, pinned }) => { setRecents(getRecents().map((r) => (r.path === p ? { ...r, pinned: !!pinned } : r))); return {}; },
    'fs.recentRemove': ({ path: p }) => { setRecents(getRecents().filter((r) => r.path !== p)); return {}; },
    'attach.put': ({ name, b64, first, last }) => {
      if (!attach) throw new WorkspaceError('Not available.');
      const clean = String(name || 'image').replace(/[^\w.-]+/g, '_').replace(/^\.+/, '').slice(0, 80) || 'image';
      return attach.put(attach.root, clean, b64, { first: !!first, last: !!last });
    },
    'fs.rm': ({ path: p }) => workspace.remove(p),
    'fs.put': ({ parent, name, b64, first, last }) => workspace.put(parent, name, b64, { first: !!first, last: !!last }),

    'lib.scan': () => ({ items: library.scan(libCtx()) }),
    'lib.read': ({ path: p }) => {
      if (!library.allowed(p, libCtx())) throw new WorkspaceError('That is not an agent or skill.');
      const st = fs.statSync(p);
      if (st.size > MAX_LIB_TEXT) throw new WorkspaceError('That file is too large to open here.');
      return { path: p, text: fs.readFileSync(p, 'utf8'), mtime: Math.round(st.mtimeMs) };
    },
    'lib.write': ({ path: p, text, mtime }) => {
      if (!library.allowed(p, libCtx())) throw new WorkspaceError('That is not an agent or skill.');
      if (typeof text !== 'string' || Buffer.byteLength(text) > MAX_LIB_TEXT) throw new WorkspaceError('Too large to save.');
      const cur = fs.statSync(p);
      if (Number.isFinite(mtime) && Math.round(cur.mtimeMs) !== mtime) throw new WorkspaceError('This file changed while you were editing it.', 'conflict');
      const tmp = path.join(path.dirname(p), `.nami-${process.pid}-${Date.now()}.tmp`);
      fs.writeFileSync(tmp, text, { mode: cur.mode & 0o777 });
      fs.renameSync(tmp, p);
      return { path: p, mtime: Math.round(fs.statSync(p).mtimeMs) };
    },
    // One agent written once in agents/ and delivered to every tool, each in its own format.
    'lib.deliver': ({ agentIds }) => ({ delivered: master.deliverAgents({ projectPath: workspace.root, agentIds: agentIds || [], homeDir: home }) }),
    'lib.state': ({ slug, agentIds }) => ({ state: master.deliveryState({ projectPath: workspace.root, slug: String(slug || ''), agentIds: agentIds || [], homeDir: home }) }),
    'lib.adopt': ({ path: p, platform, agentIds }) => {
      if (!library.allowed(p, libCtx())) throw new WorkspaceError('That is not an agent or skill.');
      const res = master.liftToMaster({ filePath: p, platform, projectPath: workspace.root });
      if (!res.ok) throw new WorkspaceError(res.error);
      return { ...res, delivered: master.deliverAgents({ projectPath: workspace.root, agentIds: agentIds || [], homeDir: home }) };
    },
    'lib.import': ({ path: p, agentIds }) => {
      if (!library.allowed(p, libCtx())) throw new WorkspaceError('That is not an agent or skill.');
      const res = master.importToMaster({ filePath: p, projectPath: workspace.root });
      if (!res.ok) throw new WorkspaceError(res.error);
      return { ...res, delivered: master.deliverAgents({ projectPath: workspace.root, agentIds: agentIds || [], homeDir: home }) };
    },
    'lib.duplicate': ({ path: p, type }) => {
      if (!library.allowed(p, libCtx())) throw new WorkspaceError('That is not an agent or skill.');
      const root = workspace.root;
      const free = (base, make) => { let s = base, d = make(s); for (let n = 0; fs.existsSync(d); n++) { s = base + (n ? '-copy-' + n : '-copy'); d = make(s); } return d; };
      if (type === 'skill') {
        const src = path.dirname(p);
        const dest = free(path.basename(src), (s) => path.join(root, 'skills', s));
        fs.mkdirSync(path.dirname(dest), { recursive: true });
        fs.cpSync(src, dest, { recursive: true, dereference: true });
        return { path: path.join(dest, 'SKILL.md') };
      }
      if (!p.endsWith('.md')) throw new WorkspaceError('Only markdown agents can be copied here; this one is ' + path.extname(p) + '.');
      const dest = free(path.basename(p, '.md'), (s) => path.join(root, '.claude', 'agents', s + '.md'));
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.copyFileSync(p, dest);
      return { path: dest };
    },
    'lib.create': (a) => library.create({ ...libCtx(), platform: a.platform, scope: a.scope, type: a.type, name: a.name, description: a.description, body: a.body }),

    'usage.read': () => usage({ home }),
    'setup.check': () => setupCheck.check({ home, agents: require('./agents').listAgents({ env: process.env }) }),
    'conn.list': () => { if (!connections) throw new WorkspaceError('Not available.'); return { services: connections.list() }; },
    'conn.connect': ({ id, values }) => { if (!connections) throw new WorkspaceError('Not available.'); return connections.connect(id, values); },
    'conn.custom': () => { if (!connections) throw new WorkspaceError('Not available.'); return { servers: connections.customList() }; },
    'conn.connectCustom': ({ id, command, args, env }) => { if (!connections) throw new WorkspaceError('Not available.'); return connections.connectCustom(String(id || ''), { command, args, env }); },
    'conn.importBundle': ({ path: p }) => { if (!connections) throw new WorkspaceError('Not available.'); const info = workspace.rawInfo(p); if (!info) throw new WorkspaceError('That is not a file.'); return connections.importBundle(info.file, dataDir); },
    'conn.disconnect': ({ id }) => { if (!connections) throw new WorkspaceError('Not available.'); return connections.disconnect(id); },

    'keys.list': () => ({ providers: keys.list() }),
    'keys.get': ({ id }) => { const p = keys.get(id); if (!p) throw new WorkspaceError('Not found.', 'missing'); return p; },
    'keys.save': (a) => ({ id: keys.save({ id: a.id, name: a.name, agent: a.agent, note: a.note, env: a.env }) }),
    'keys.remove': ({ id }) => { keys.remove(id); return {}; },
  };

  return {
    handle(op, args) {
      const fn = Object.prototype.hasOwnProperty.call(ops, op) ? ops[op] : null;
      if (!fn) throw new Error('Unknown request.');
      return fn(args && typeof args === 'object' ? args : {});
    },
  };
}

module.exports = { createRpc };
