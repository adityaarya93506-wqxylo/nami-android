'use strict';
// The page's questions about files, the library and providers. One function:
// handle(op, args) returns data or throws an Error with a plain message.

const fs = require('node:fs');
const path = require('node:path');
const library = require('./library');
const { WorkspaceError } = require('./workspace');

const MAX_LIB_TEXT = 512 * 1024;

function createRpc({ workspace, keys, home, saveRoot = () => {} }) {
  const libCtx = () => ({ home, project: workspace.root });

  const ops = {
    'fs.root': () => ({ root: workspace.root, home }),
    'fs.setRoot': ({ path: p }) => { const r = workspace.setRoot(p); saveRoot(r); return { root: r, home }; },
    'fs.ls': ({ path: p }) => workspace.ls(p || workspace.root),
    'fs.read': ({ path: p }) => workspace.read(p),
    'fs.write': ({ path: p, text, mtime }) => workspace.write(p, text, mtime),
    'fs.mkdir': ({ parent, name }) => workspace.mkdir(parent, name),
    'fs.touch': ({ parent, name }) => workspace.touch(parent, name),
    'fs.rename': ({ path: p, name }) => workspace.rename(p, name),
    'fs.rm': ({ path: p }) => workspace.remove(p),
    'fs.put': ({ parent, name, b64, first, last }) => workspace.put(parent, name, b64, { first: !!first, last: !!last }),

    'lib.scan': () => ({ items: library.scan(libCtx()) }),
    'lib.read': ({ path: p }) => {
      if (!library.allowed(p, libCtx())) throw new WorkspaceError('That is not an agent or skill.');
      const st = fs.statSync(p);
      if (st.size > MAX_LIB_TEXT) throw new WorkspaceError('That file is too large to open here.');
      return { path: p, text: fs.readFileSync(p, 'utf8'), mtime: Math.round(st.mtimeMs) };
    },
    'lib.write': ({ path: p, text, mtime }) => {
      if (!library.allowed(p, libCtx())) throw new WorkspaceError('That is not an agent or skill.');
      if (typeof text !== 'string' || Buffer.byteLength(text) > MAX_LIB_TEXT) throw new WorkspaceError('Too large to save.');
      const cur = fs.statSync(p);
      if (Number.isFinite(mtime) && Math.round(cur.mtimeMs) !== mtime) throw new WorkspaceError('This file changed while you were editing it.', 'conflict');
      const tmp = path.join(path.dirname(p), `.nami-${process.pid}-${Date.now()}.tmp`);
      fs.writeFileSync(tmp, text, { mode: cur.mode & 0o777 });
      fs.renameSync(tmp, p);
      return { path: p, mtime: Math.round(fs.statSync(p).mtimeMs) };
    },
    'lib.create': (a) => library.create({ ...libCtx(), platform: a.platform, scope: a.scope, type: a.type, name: a.name, description: a.description, body: a.body }),

    'keys.list': () => ({ providers: keys.list() }),
    'keys.get': ({ id }) => { const p = keys.get(id); if (!p) throw new WorkspaceError('Not found.', 'missing'); return p; },
    'keys.save': (a) => ({ id: keys.save({ id: a.id, name: a.name, agent: a.agent, note: a.note, env: a.env }) }),
    'keys.remove': ({ id }) => { keys.remove(id); return {}; },
  };

  return {
    handle(op, args) {
      const fn = Object.prototype.hasOwnProperty.call(ops, op) ? ops[op] : null;
      if (!fn) throw new Error('Unknown request.');
      return fn(args && typeof args === 'object' ? args : {});
    },
  };
}

module.exports = { createRpc };
