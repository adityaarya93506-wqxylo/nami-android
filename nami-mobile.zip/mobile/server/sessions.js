'use strict';
// Sessions outlive the phone's connection. A browser tab that goes to the
// background drops its socket; the agent keeps working and the output is kept
// so the tab can catch up when it comes back.
//
// Two ways a session can be kept:
//   - with tmux (server/tmux.js): the program lives in a tmux session. This
//     server only attaches to it, so stopping the server, closing the app or
//     Android killing Termux's foreground does not end the agent, and the next
//     start adopts it again. History is read back from tmux.
//   - without tmux: the program is a child of this server and keeps a bounded
//     scrollback in memory. It ends when the server does.

const { EventEmitter } = require('node:events');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const { findAgent, seedArgs, resumeArgs } = require('./agents');

const MAX_SESSIONS = 12;
const DEFAULT_SCROLLBACK = 256 * 1024;
const MAX_REATTACH = 3;

function clampSize(n, lo, hi, fallback) {
  const v = Number.isFinite(n) ? Math.floor(n) : fallback;
  return Math.min(hi, Math.max(lo, v));
}

function defaultShell(env) {
  if (env.SHELL && fs.existsSync(env.SHELL)) return env.SHELL;
  for (const p of ['/data/data/com.termux/files/usr/bin/bash', '/bin/bash', '/bin/sh']) {
    if (fs.existsSync(p)) return p;
  }
  return 'sh';
}

class SessionManager extends EventEmitter {
  constructor({ spawnPty, env = process.env, home = os.homedir(), scrollback = DEFAULT_SCROLLBACK, tmux = null, pollMs = 1500 }) {
    super();
    this.spawnPty = spawnPty;
    this.env = env;
    this.home = home;
    this.scrollback = scrollback;
    this.tmux = tmux;
    this.sessions = new Map();
    this.poller = null;
    this.pollMs = pollMs;
  }

  // { kind: 'shell' | 'agent', agentId?, cwd?, cols?, rows?, name? }
  create(req = {}) {
    if (this.sessions.size >= MAX_SESSIONS) throw new Error(`At most ${MAX_SESSIONS} sessions at once. Close one first.`);
    const kind = req.kind === 'agent' ? 'agent' : 'shell';
    let file; const args = []; let title; let resumeWanted = null;
    if (kind === 'agent') {
      const agent = findAgent(req.agentId);
      if (!agent) throw new Error('Unknown agent.');
      file = agent.bin; title = agent.name;
      if (req.resume === true && !req.seed) resumeWanted = agent;
      else args.push(...seedArgs(agent, req.seed));
    } else {
      file = defaultShell(this.env); title = 'Terminal';
    }
    let cwd = this.home;
    if (typeof req.cwd === 'string' && req.cwd.trim()) {
      const want = req.cwd.trim().replace(/^~(?=$|\/)/, this.home);
      let isDir = false;
      try { isDir = fs.statSync(want).isDirectory(); } catch (_) { /* reported below */ }
      if (!isDir) throw new Error('That folder does not exist.');
      cwd = want;
    }
    if (resumeWanted) args.push(...resumeArgs(resumeWanted, { home: this.home, cwd }));
    const cols = clampSize(req.cols, 20, 300, 80);
    const rows = clampSize(req.rows, 5, 200, 24);
    const name = typeof req.name === 'string' && req.name.trim() ? req.name.trim().slice(0, 60) : title;
    const env = { ...this.env, TERM: 'xterm-256color', COLORTERM: 'truecolor' };
    const id = crypto.randomBytes(6).toString('hex');
    const startedAt = Date.now();

    const s = {
      id, name, kind, agentId: kind === 'agent' ? req.agentId : null, cwd,
      startedAt, exitCode: null, cols, rows, buf: '',
      tmuxName: null, gen: 0, reattaches: 0, scrolled: false, scrollPending: 0, scrollBusy: false, pty: null,
    };
    if (this.tmux) {
      s.tmuxName = this.tmux.create({ id, cwd, cols, rows, file, args, name, kind, agentId: s.agentId, started: startedAt, env: req.env || {} });
      this._attachTmux(s);
    } else {
      s.pty = this.spawnPty(file, args, { cwd, env: { ...env, ...(req.env || {}) }, cols, rows });
      s.pty.onData((data) => this._data(s, data));
      s.pty.onExit((code) => this._ended(s, code));
    }
    this.sessions.set(id, s);
    this._watch();
    this.emit('change');
    return this.summary(s);
  }

  // Take back every Nami session still alive in tmux (after a server restart).
  adopt() {
    if (!this.tmux) return 0;
    const dead = this.tmux.deadPanes();
    let n = 0;
    for (const t of this.tmux.list()) {
      const id = t.name.slice('nami-'.length);
      if (this.sessions.has(id) || this.sessions.size >= MAX_SESSIONS) continue;
      const s = {
        id, name: t.title || (t.kind === 'agent' ? 'Agent' : 'Terminal'), kind: t.kind, agentId: t.agentId, cwd: t.cwd || this.home,
        startedAt: t.startedAt, exitCode: dead.has(t.name) ? (dead.get(t.name) ?? 1) : null,
        cols: clampSize(t.cols, 20, 300, 80), rows: clampSize(t.rows, 5, 200, 24), buf: '',
        tmuxName: t.name, gen: 0, reattaches: 0, scrolled: false, scrollPending: 0, scrollBusy: false, pty: null,
      };
      this._attachTmux(s);
      this.sessions.set(id, s);
      n++;
    }
    if (n) { this._watch(); this.emit('change'); }
    return n;
  }

  _data(s, data) {
    s.buf += data;
    if (s.buf.length > this.scrollback) s.buf = s.buf.slice(s.buf.length - this.scrollback);
    this.emit('data', s.id, data);
  }

  _ended(s, code) {
    s.exitCode = code == null ? 0 : code;
    this.emit('exit', s.id, s.exitCode);
    this.emit('change');
  }

  // Start (or restart) the terminal that shows a tmux session. A restart is
  // also how the page asks for a clean full redraw, and how the size changes
  // when the pty cannot be resized in place.
  _attachTmux(s) {
    const gen = ++s.gen;
    if (s.pty) { try { s.pty.kill(); } catch (_) { /* already gone */ } }   // one terminal per session, never two
    const cmd = this.tmux.attachCommand(s.tmuxName);
    const env = { ...this.env, TERM: 'xterm-256color', COLORTERM: 'truecolor' };
    delete env.TMUX; // we may have been started from inside a tmux of the user's own
    const pty = this.spawnPty(cmd.file, cmd.args, { cwd: this.home, env, cols: s.cols, rows: s.rows });
    s.pty = pty;
    pty.onData((d) => { if (s.gen === gen) this._data(s, d); });
    pty.onExit(() => { if (s.gen === gen) this._attachLost(s); });
  }

  _attachLost(s) {
    if (!this.sessions.has(s.id)) return;
    if (!this.tmux.has(s.tmuxName)) {   // ended from outside, e.g. `tmux kill-session`
      this.sessions.delete(s.id);
      this.emit('exit', s.id, s.exitCode == null ? 0 : s.exitCode);
      this.emit('change');
      return;
    }
    if (s.reattaches++ < MAX_REATTACH) this._attachTmux(s);
  }

  // Programs ending inside tmux do not end the attach terminal (the pane stays,
  // marked dead), so ask tmux now and then.
  _watch() {
    if (!this.tmux || this.poller) return;
    this.poller = setInterval(() => this._poll(), this.pollMs);
    this.poller.unref();
  }

  _poll() {
    const live = [...this.sessions.values()].filter((s) => s.tmuxName && s.exitCode === null);
    if (!live.length) return;
    const dead = this.tmux.deadPanes();
    const titles = this.tmux.titles();
    let changed = false;
    for (const s of live) {
      const t = titles.get(s.tmuxName) || '';
      if (t !== (s.title || '')) { s.title = t; changed = true; }
    }
    if (changed) this.emit('change');
    for (const s of live) {
      if (!dead.has(s.tmuxName)) { s.deadTries = 0; continue; }
      const code = dead.get(s.tmuxName);
      if (code !== null) { this._ended(s, code); continue; }
      // Dead with no status at all (the program was killed from outside). A few
      // polls in case tmux is still filling it in, then settle for "failed".
      if ((s.deadTries = (s.deadTries || 0) + 1) >= 5) this._ended(s, 1);
    }
  }

  summary(s) {
    return {
      id: s.id, name: s.name, kind: s.kind, agentId: s.agentId, cwd: s.cwd,
      startedAt: s.startedAt, exited: s.exitCode !== null, exitCode: s.exitCode,
      resizable: s.tmuxName ? true : !!s.pty.resizable,
      persistent: !!s.tmuxName, title: s.title || '',
    };
  }

  list() {
    return [...this.sessions.values()].map((s) => this.summary(s));
  }

  // What the page should show first when it opens a session.
  // tmux: only what has scrolled off the top (so there is something to scroll
  // back to); the screen itself arrives from redraw(). Otherwise: the
  // retained output.
  snapshot(id) {
    const s = this.sessions.get(id);
    if (!s) return null;
    if (!s.tmuxName) return s.buf;
    const h = this.tmux.history(s.tmuxName);
    return h ? h + '\r\n'.repeat(s.rows) + '\x1b[2J\x1b[H' : '';
  }

  // Ask for the whole screen again, at the page's current size (tmux only).
  redraw(id) {
    const s = this.sessions.get(id);
    if (!s || !s.tmuxName) return false;
    s.reattaches = 0;
    this._attachTmux(s);   // the old terminal's exit is ignored: its generation is stale
    return true;
  }

  get(id) {
    const s = this.sessions.get(id);
    return s ? this.summary(s) : null;
  }

  write(id, data) {
    const s = this.sessions.get(id);
    if (!s || s.exitCode !== null || typeof data !== 'string') return false;
    // One keystroke or one pasted message; not a way to flood the server.
    if (data.length > 64 * 1024) return false;
    if (s.scrolled && s.tmuxName) { this.tmux.cancelCopyMode(s.tmuxName); s.scrolled = false; }
    s.pty.write(data);
    return true;
  }

  // `redraw: false` is for a caller that is about to call redraw() itself.
  resize(id, cols, rows, { redraw = true } = {}) {
    const s = this.sessions.get(id);
    if (!s) return false;
    const c = clampSize(cols, 20, 300, s.cols);
    const r = clampSize(rows, 5, 200, s.rows);
    if (c === s.cols && r === s.rows) return true;
    s.cols = c; s.rows = r;
    if (s.exitCode !== null && !s.tmuxName) return false;
    if (s.pty.resizable) return s.pty.resize(c, r);
    if (s.tmuxName) { if (redraw) this._attachTmux(s); return true; }   // new terminal, new size; tmux follows it
    return false;
  }

  // Thumb scrolling (tmux only): lines > 0 goes back in time, < 0 forward.
  scroll(id, lines) {
    const s = this.sessions.get(id);
    if (!s || !s.tmuxName || !Number.isFinite(lines) || lines === 0) return false;
    s.scrollPending += Math.max(-300, Math.min(300, Math.round(lines)));
    s.scrolled = true;
    if (!s.scrollBusy) this._flushScroll(s);
    return true;
  }

  _flushScroll(s) {
    const n = s.scrollPending;
    s.scrollPending = 0;
    if (!n) { s.scrollBusy = false; return; }
    s.scrollBusy = true;
    const again = () => this._flushScroll(s);
    if (n > 0) this.tmux.scrollUp(s.tmuxName, n, again); else this.tmux.scrollDown(s.tmuxName, -n, again);
  }

  // Back to the live screen.
  live(id) {
    const s = this.sessions.get(id);
    if (!s || !s.tmuxName) return false;
    this.tmux.cancelCopyMode(s.tmuxName);
    s.scrolled = false; s.scrollPending = 0;
    return true;
  }

  // Stops a running session, or removes one that has already finished.
  close(id) {
    const s = this.sessions.get(id);
    if (!s) return false;
    if (s.tmuxName) {
      s.gen++;
      this.tmux.kill(s.tmuxName);
      try { s.pty.kill(); } catch (_) { /* already gone */ }
    } else if (s.exitCode === null) {
      try { s.pty.kill(); } catch (_) { /* already gone */ }
    }
    this.sessions.delete(id);
    this.emit('change');
    return true;
  }

  // The server is stopping. tmux sessions keep running (we only let go of
  // them); anything else ends with us.
  shutdown() {
    if (this.poller) { clearInterval(this.poller); this.poller = null; }
    for (const s of this.sessions.values()) {
      s.gen++;
      if (s.exitCode === null || s.tmuxName) { try { s.pty.kill(); } catch (_) { /* already gone */ } }
    }
    this.sessions.clear();
  }

  // Ends everything, tmux sessions included.
  closeAll() {
    for (const id of [...this.sessions.keys()]) this.close(id);
    if (this.poller) { clearInterval(this.poller); this.poller = null; }
  }
}

module.exports = { SessionManager, MAX_SESSIONS };
