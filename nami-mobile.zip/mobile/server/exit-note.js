'use strict';
// What to tell the person when a session's process goes away. A raw 129 reads as a crash
// but is the most ordinary thing there is (the terminal was closed), so say who ended it.
const SIGNALS = { 1: 'SIGHUP', 2: 'SIGINT', 3: 'SIGQUIT', 9: 'SIGKILL', 15: 'SIGTERM' };

function exitNote({ code, deliberate } = {}) {
  if (deliberate) return 'session closed';
  const n = Number(code);
  if (n > 128 && n < 160) {
    const sig = SIGNALS[n - 128] || ('signal ' + (n - 128));
    if (sig === 'SIGINT') return 'stopped';
    if (sig === 'SIGHUP') return 'terminal closed';
    return 'stopped · ' + sig;
  }
  if (n === 0) return 'finished';
  return 'exited · ' + (code === undefined || code === null ? '?' : code);
}
module.exports = { exitNote };
