'use strict';
// How much your agents have been used, counted from the records they keep on this phone:
// Claude Code (~/.claude/projects/**/*.jsonl) and Codex (~/.codex/sessions/**/rollout-*.jsonl).
// This is tokens used, not what is left of a plan: the plan's own limit lives with the provider
// (use /usage inside the agent for that). Reads are bounded: recent files only, big files from the end.

const fs = require('node:fs');
const path = require('node:path');

const DAY = 864e5;
const MAX_FILES = 400;
const MAX_READ = 24 * 1024 * 1024;

function walk(dir, test, out, depth = 0) {
  if (depth > 6 || out.length > 5000) return;
  let names; try { names = fs.readdirSync(dir, { withFileTypes: true }); } catch (_) { return; }
  for (const d of names) {
    const p = path.join(dir, d.name);
    if (d.isDirectory()) walk(p, test, out, depth + 1);
    else if (d.isFile() && test(d.name)) out.push(p);
  }
}

const dayKey = (ms) => { const d = new Date(ms); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };

function readText(file, size) {
  const fd = fs.openSync(file, 'r');
  try {
    const len = Math.min(size, MAX_READ);
    const buf = Buffer.alloc(len);
    fs.readSync(fd, buf, 0, len, size - len);
    return buf.toString('utf8');
  } finally { fs.closeSync(fd); }
}

function recentFiles(root, test, since) {
  const all = []; walk(root, test, all);
  return all.map((f) => { try { const st = fs.statSync(f); return { f, size: st.size, mtime: st.mtimeMs }; } catch (_) { return null; } })
    .filter((x) => x && x.mtime >= since).sort((a, b) => b.mtime - a.mtime).slice(0, MAX_FILES);
}

function claude(home, since) {
  const days = new Map();
  const seen = new Set();
  for (const { f, size } of recentFiles(path.join(home, '.claude', 'projects'), (n) => n.endsWith('.jsonl'), since)) {
    for (const line of readText(f, size).split('\n')) {
      if (line.indexOf('"usage"') < 0) continue;
      let r; try { r = JSON.parse(line); } catch (_) { continue; }
      const u = r && r.message && r.message.usage; const t = Date.parse(r && r.timestamp);
      if (!u || !Number.isFinite(t) || t < since) continue;
      const key = (r.message.id || '') + ':' + (r.requestId || '');
      if (key.length > 1) { if (seen.has(key)) continue; seen.add(key); }
      const d = dayKey(t);
      const row = days.get(d) || { input: 0, output: 0, cached: 0, turns: 0 };
      row.input += (u.input_tokens || 0) + (u.cache_creation_input_tokens || 0);
      row.cached += u.cache_read_input_tokens || 0;
      row.output += u.output_tokens || 0;
      row.turns += 1;
      days.set(d, row);
    }
  }
  return days;
}

function codex(home, since) {
  const days = new Map();
  for (const { f, size, mtime } of recentFiles(path.join(home, '.codex', 'sessions'), (n) => n.startsWith('rollout-') && n.endsWith('.jsonl'), since)) {
    // a rollout keeps running totals; the last one is the session's
    let last = null;
    for (const line of readText(f, size).split('\n')) {
      if (line.indexOf('total_token_usage') < 0) continue;
      try { const r = JSON.parse(line); const u = r.payload && r.payload.info && r.payload.info.total_token_usage; if (u) last = u; } catch (_) { /* partial first line */ }
    }
    if (!last) continue;
    const d = dayKey(mtime);
    const row = days.get(d) || { input: 0, output: 0, cached: 0, turns: 0 };
    row.input += Math.max(0, (last.input_tokens || 0) - (last.cached_input_tokens || 0));
    row.cached += last.cached_input_tokens || 0;
    row.output += last.output_tokens || 0;
    row.turns += 1;
    days.set(d, row);
  }
  return days;
}

function usage({ home, now = Date.now(), daysBack = 7 }) {
  const since = now - daysBack * DAY;
  const keys = Array.from({ length: daysBack }, (_, i) => dayKey(now - (daysBack - 1 - i) * DAY));
  const make = (id, name, map) => {
    const rows = keys.map((k) => ({ day: k, ...(map.get(k) || { input: 0, output: 0, cached: 0, turns: 0 }) }));
    const sum = (f) => rows.reduce((a, r) => a + r[f], 0);
    return { id, name, days: rows, today: rows[rows.length - 1], total: { input: sum('input'), output: sum('output'), cached: sum('cached'), turns: sum('turns') } };
  };
  return { daysBack, agents: [make('claude', 'Claude Code', claude(home, since)), make('codex', 'Codex', codex(home, since))] };
}

module.exports = { usage, dayKey };
