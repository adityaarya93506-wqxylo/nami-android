'use strict';
// Agents and skills on file, across the tools Nami runs: Claude Code, Codex and
// OpenCode. Read-only discovery plus creating a new one from a template. Mirrors
// the idea of src/main/library.js in the desktop app, trimmed to what a phone needs.

const fs = require('node:fs');
const path = require('node:path');

function frontmatter(file) {
  try {
    const txt = fs.readFileSync(file, 'utf8').slice(0, 4000);
    const m = txt.match(/^---\r?\n([\s\S]*?)\r?\n---/);
    const out = {};
    if (!m) return out;
    const lines = m[1].split(/\r?\n/);
    for (let i = 0; i < lines.length; i++) {
      const mm = lines[i].match(/^([A-Za-z_][\w-]*):\s?(.*)$/);
      if (!mm) continue;
      let val = mm[2].trim();
      if (/^[>|][+-]?$/.test(val)) {
        const parts = [];
        while (i + 1 < lines.length && (/^\s/.test(lines[i + 1]) || lines[i + 1] === '')) { i++; parts.push(lines[i].trim()); }
        val = parts.filter(Boolean).join(' ');
      }
      out[mm[1]] = val.replace(/^["']|["']$/g, '').trim();
    }
    return out;
  } catch (_) { return {}; }
}

function tomlMeta(file) {
  try {
    const raw = fs.readFileSync(file, 'utf8').slice(0, 4000);
    const cut = Math.min(...[raw.indexOf('"""'), raw.search(/^\s*\[/m)].filter((i) => i >= 0), raw.length);
    const txt = raw.slice(0, cut);
    const out = {};
    for (const key of ['name', 'description']) {
      const m = txt.match(new RegExp('^' + key + '\\s*=\\s*"((?:[^"\\\\]|\\\\.)*)"', 'm'));
      if (m) out[key] = m[1].replace(/\\(["\\])/g, '$1');
    }
    return out;
  } catch (_) { return {}; }
}

function listFiles(dir, ext) {
  try { return fs.readdirSync(dir).filter((f) => f.endsWith(ext) && !f.startsWith('.')).map((f) => path.join(dir, f)); } catch (_) { return []; }
}

function listSkills(dir) {
  let ents = [];
  try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch (_) { return []; }
  const out = [];
  for (const e of ents) {
    if (e.name === 'node_modules' || e.name === '.git') continue;
    const full = path.join(dir, e.name);
    let isDir = e.isDirectory();
    if (e.isSymbolicLink()) { try { isDir = fs.statSync(full).isDirectory(); } catch (_) { isDir = false; } }
    if (!isDir) continue;
    const md = path.join(full, 'SKILL.md');
    if (fs.existsSync(md)) out.push(md);
  }
  return out;
}

// Where each tool keeps things. `scope` is "user" (home) or "project" (the workspace folder).
function sources(home, project) {
  const list = [];
  const add = (platform, scope, base, o) => list.push({ platform, scope, base, ...o });
  for (const [scope, root] of [['user', home], ['project', project]]) {
    if (!root) continue;
    add('claude', scope, path.join(root, '.claude', 'agents'), { type: 'agent', ext: '.md', meta: frontmatter });
    add('claude', scope, path.join(root, '.claude', 'skills'), { type: 'skill', skills: true });
    add('codex', scope, path.join(root, '.codex', 'agents'), { type: 'agent', ext: '.toml', meta: tomlMeta });
    add('codex', scope, path.join(root, '.codex', 'skills'), { type: 'skill', skills: true });
    add('opencode', scope, path.join(root, '.opencode', 'agent'), { type: 'agent', ext: '.md', meta: frontmatter });
    add('opencode', scope, path.join(root, '.opencode', 'agents'), { type: 'agent', ext: '.md', meta: frontmatter });
  }
  add('opencode', 'user', path.join(home, '.config', 'opencode', 'agent'), { type: 'agent', ext: '.md', meta: frontmatter });
  add('opencode', 'user', path.join(home, '.config', 'opencode', 'agents'), { type: 'agent', ext: '.md', meta: frontmatter });
  return list;
}

function scan({ home, project }) {
  const seen = new Set();
  const items = [];
  for (const src of sources(home, project)) {
    const files = src.skills ? listSkills(src.base) : listFiles(src.base, src.ext);
    for (const file of files) {
      let real = file;
      try { real = fs.realpathSync(file); } catch (_) { /* keep */ }
      const key = src.platform + '|' + real;
      if (seen.has(key)) continue;
      seen.add(key);
      const meta = src.skills ? frontmatter(file) : src.meta(file);
      const stem = src.skills ? path.basename(path.dirname(file)) : path.basename(file, src.ext);
      items.push({
        id: Buffer.from(file).toString('base64url'),
        platform: src.platform, scope: src.scope, type: src.type,
        name: meta.name || stem, slug: stem, description: meta.description || '', path: file,
      });
    }
  }
  items.sort((a, b) => a.type.localeCompare(b.type) || a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }));
  return items;
}

const SLUG = /^[a-z0-9][a-z0-9-]{0,48}$/;

function slugify(name) {
  return String(name || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 48);
}

// A starter file for a new agent or skill. The person (or their agent) fills in the instructions.
function template({ platform, type, name, description, body }) {
  const slug = slugify(name);
  if (!SLUG.test(slug)) throw new Error('Give it a name with letters or numbers.');
  const desc = String(description || '').replace(/\r?\n/g, ' ').slice(0, 300);
  const text = String(body || '').trim() || (type === 'skill' ? 'Describe when to use this skill and what to do.' : 'Describe what this agent does and how it should work.');
  if (platform === 'codex' && type === 'agent') {
    const esc = (s) => s.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    return { slug, ext: '.toml', content: `name = "${esc(slug)}"\ndescription = "${esc(desc)}"\ndeveloper_instructions = """\n${text.replace(/"""/g, '"\\""')}\n"""\n` };
  }
  const fm = `---\nname: ${slug}\ndescription: ${desc || name}\n---\n\n${text}\n`;
  return { slug, ext: '.md', content: fm };
}

function create({ home, project, platform, scope, type, name, description, body }) {
  if (!['claude', 'codex', 'opencode'].includes(platform)) throw new Error('Unknown tool.');
  if (!['agent', 'skill'].includes(type)) throw new Error('Unknown kind.');
  if (type === 'skill' && platform === 'opencode') throw new Error('OpenCode has no skills folder here.');
  const root = scope === 'project' ? project : home;
  if (!root) throw new Error('No folder to put it in.');
  const { slug, ext, content } = template({ platform, type, name, description, body });
  const dotdir = platform === 'claude' ? '.claude' : platform === 'codex' ? '.codex' : '.opencode';
  let file;
  if (type === 'skill') {
    file = path.join(root, dotdir, 'skills', slug, 'SKILL.md');
  } else {
    file = path.join(root, dotdir, platform === 'opencode' ? 'agent' : 'agents', slug + ext);
  }
  if (fs.existsSync(file)) throw new Error('One with that name already exists.');
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, content, { flag: 'wx', mode: 0o644 });
  return { path: file, slug };
}

// Only files the scan would list may be read or saved through the library calls.
function allowed(file, { home, project }) {
  if (typeof file !== 'string' || file.includes('\0')) return false;
  const abs = path.resolve(file);
  return scan({ home, project }).some((i) => i.path === abs);
}

module.exports = { scan, create, allowed, slugify, frontmatter };
