'use strict';
// Checks what this phone's Linux has, so installs fail early with a clear reason.
const { execFileSync } = require('node:child_process');
const fs = require('node:fs');

const TOOLS = [
  { id: 'node', args: ['--version'], need: 'runs Nami and npm-installed agents' },
  { id: 'npm', args: ['--version'], need: 'installs Claude Code, Codex, OpenCode' },
  { id: 'git', args: ['--version'], need: 'projects, agents that read repositories' },
  { id: 'curl', args: ['--version'], need: 'installers for Grok, Antigravity, Hermes' },
  { id: 'tmux', args: ['-V'], need: 'keeps sessions alive' },
  { id: 'unzip', args: ['-h'], need: 'importing .mcpb bundles' },
];

function probe(t) {
  try {
    const out = execFileSync(t.id, t.args, { encoding: 'utf8', timeout: 4000, stdio: ['ignore', 'pipe', 'pipe'] });
    return { id: t.id, ok: true, version: String(out).split('\n')[0].slice(0, 60), need: t.need };
  } catch (e) {
    // busybox applets print usage on stderr and exit non-zero: that still means "present"
    if (e && e.stderr && !/not found|ENOENT/i.test(String(e.stderr) + String(e.code))) return { id: t.id, ok: true, version: 'installed', need: t.need };
    return { id: t.id, ok: false, version: '', need: t.need };
  }
}

function disk(home) {
  try { const s = fs.statfsSync(home); return { freeMB: Math.floor(s.bavail * s.bsize / 1048576) }; } catch (_) { return { freeMB: null }; }
}

// agents: [{id,name,install,installed}] -> what blocks each install
function check({ home, agents = [] }) {
  const tools = TOOLS.map(probe);
  const have = new Set(tools.filter((t) => t.ok).map((t) => t.id));
  const d = disk(home);
  const plan = agents.filter((a) => !a.installed && a.install).map((a) => {
    const missing = [];
    if (/^npm /.test(a.install)) { if (!have.has('node')) missing.push('node'); if (!have.has('npm')) missing.push('npm'); }
    if (/curl /.test(a.install) && !have.has('curl')) missing.push('curl');
    return { id: a.id, name: a.name, ready: missing.length === 0, missing, line: a.install };
  });
  return { tools, disk: d, lowDisk: d.freeMB !== null && d.freeMB < 500, plan };
}

module.exports = { check };
