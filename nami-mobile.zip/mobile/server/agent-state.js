'use strict';
// Who is signed in to each agent CLI. Reads the small status files the CLIs keep
// (or asks `claude auth status`) and hands them to the parser, which only ever
// returns labels, never a token or key.
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { parseAgentStatus } = require('./agent-status');

const LIFE = {
  claude:   { cmd: ['claude', 'auth', 'status', '--json'], login: 'claude auth login', logout: 'claude auth logout' },
  codex:    { files: ['.codex/auth.json'], login: 'codex login', logout: 'codex logout' },
  opencode: { files: ['.local/share/opencode/auth.json'], login: 'opencode auth login', logout: 'opencode auth logout' },
  grok:     { files: ['.grok/auth.json'], login: 'grok login', logout: 'grok logout' },
  hermes:   { files: ['.hermes/auth.json', '.hermes/config.yaml'], login: 'hermes login', logout: 'hermes auth logout' },
};

function readIf(p) { try { const st = fs.statSync(p); return st.size < 512 * 1024 ? fs.readFileSync(p, 'utf8') : ''; } catch (_) { return undefined; } }

function agentState(id, { home, env = process.env, hasApiKey = false, run = spawnSync } = {}) {
  const lc = LIFE[id];
  const blank = { id, signedIn: null, label: '', rows: [], login: lc ? lc.login : null, logout: lc ? lc.logout : null };
  if (!lc) return blank;
  try {
    let payload;
    if (lc.cmd) {
      const r = run(lc.cmd[0], lc.cmd.slice(1), { encoding: 'utf8', timeout: 8000, env });
      if (r.error || r.status === null) return blank;
      payload = { stdout: r.stdout };
    } else {
      const files = {};
      for (const rel of lc.files) { const abs = path.join(home, rel); files[abs] = readIf(abs); }
      payload = { files };
      if (id !== 'grok' && Object.values(files)[0] === undefined) return { ...blank, signedIn: false, label: 'signed out' };   // no sign-in file yet
    }
    if (id === 'grok') payload.hasApiKey = !!hasApiKey;
    return { ...blank, ...parseAgentStatus(id, payload) };
  } catch (_) { return blank; }
}

module.exports = { agentState, LIFE };
