'use strict';
// Providers: named sets of environment variables (an API key, a base URL, a model)
// that Nami puts into a session when you pick one. This is how a Claude Code or
// Codex session can talk to a provider other than the default, the same way you
// would `export` them in a terminal, but saved once. Stored in one file readable
// only by its owner. Values are never sent back to the page in full.

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const NAME_RE = /^[A-Za-z_][A-Za-z0-9_]{0,63}$/;
const BLOCKED = new Set(['PATH', 'HOME', 'LD_PRELOAD', 'LD_LIBRARY_PATH', 'SHELL', 'TMUX', 'TERM']);
const MAX_PROVIDERS = 40;

function mask(v) {
  const s = String(v);
  if (s.length <= 8) return '•'.repeat(s.length);
  return '•••• ' + s.slice(-4);
}

function createKeys({ file }) {
  function load() {
    try {
      const d = JSON.parse(fs.readFileSync(file, 'utf8'));
      return Array.isArray(d.providers) ? d.providers : [];
    } catch (_) { return []; }
  }
  function store(list) {
    fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
    const tmp = file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify({ providers: list }, null, 2), { mode: 0o600 });
    fs.renameSync(tmp, file);
  }
  const clean = (env) => {
    if (!env || typeof env !== 'object' || Array.isArray(env)) throw new Error('Add at least one variable.');
    const out = {};
    for (const [k, v] of Object.entries(env)) {
      if (!NAME_RE.test(k)) throw new Error(`"${k}" is not a valid variable name.`);
      if (BLOCKED.has(k.toUpperCase())) throw new Error(`${k} cannot be set here.`);
      const val = String(v);
      if (/[\0\r\n]/.test(val)) throw new Error(`${k}: no line breaks, please.`);
      if (val.endsWith(';')) throw new Error(`${k}: remove the trailing ";".`);
      if (val.length > 4000) throw new Error(`${k} is too long.`);
      out[k] = val;
    }
    if (!Object.keys(out).length) throw new Error('Add at least one variable.');
    return out;
  };

  return {
    // For the page: values hidden.
    list() {
      return load().map((p) => ({
        id: p.id, name: p.name, agent: p.agent || 'any', note: p.note || '',
        vars: Object.entries(p.env).map(([name, value]) => ({ name, preview: /KEY|TOKEN|SECRET|PASSWORD/i.test(name) ? mask(value) : value })),
      }));
    },
    // For editing: the real values of one provider.
    get(id) {
      const p = load().find((x) => x.id === id);
      return p ? { id: p.id, name: p.name, agent: p.agent || 'any', note: p.note || '', env: p.env } : null;
    },
    save({ id, name, agent = 'any', note = '', env }) {
      const nm = String(name || '').trim().slice(0, 40);
      if (!nm) throw new Error('Give it a name.');
      const list = load();
      let cur = id ? list.find((x) => x.id === id) : null;
      // An empty value on an existing variable means "keep what is saved".
      const merged = {};
      for (const [k, v] of Object.entries(env || {})) merged[k] = v === '' && cur && cur.env[k] != null ? cur.env[k] : v;
      const rec = { id: cur ? cur.id : crypto.randomBytes(5).toString('hex'), name: nm, agent: String(agent).slice(0, 20), note: String(note).slice(0, 120), env: clean(merged) };
      if (cur) list[list.indexOf(cur)] = rec;
      else { if (list.length >= MAX_PROVIDERS) throw new Error('That is a lot of providers. Delete one first.'); list.push(rec); }
      store(list);
      return rec.id;
    },
    remove(id) {
      const list = load();
      const next = list.filter((x) => x.id !== id);
      if (next.length !== list.length) store(next);
    },
    // The variables to put into a new session.
    envFor(id) {
      if (!id) return {};
      const p = load().find((x) => x.id === id);
      if (!p) throw new Error('That provider is gone.');
      return { ...p.env };
    },
  };
}

module.exports = { createKeys, NAME_RE };
