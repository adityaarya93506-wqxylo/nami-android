'use strict';
// Start an MCP server once over stdio, shake hands, count its tools, stop it.
// "Connected" in the page means this said yes, not that a file was written.
const { spawn } = require('node:child_process');

function checkServer({ command, args = [], env = {}, parentEnv = process.env, timeoutMs = 20000, spawnFn = spawn }) {
  return new Promise((resolve) => {
    let child;
    try { child = spawnFn(command, args, { env: { ...parentEnv, ...env }, stdio: ['pipe', 'pipe', 'pipe'] }); }
    catch (e) { resolve({ ok: false, error: 'could not start: ' + e.message }); return; }
    let buf = '', done = false, id = 0, said = '';
    const finish = (out) => { if (done) return; done = true; clearTimeout(timer); try { child.kill(); } catch (_) { /* gone */ } resolve(out); };
    const timer = setTimeout(() => finish({ ok: false, error: 'no answer within ' + Math.round(timeoutMs / 1000) + 's' }), timeoutMs);
    const send = (method, params) => { id += 1; try { child.stdin.write(JSON.stringify({ jsonrpc: '2.0', id, method, params }) + '\n'); } catch (_) { /* closed */ } return id; };
    let initId = null, listId = null;
    child.on('error', (e) => finish({ ok: false, error: 'could not start: ' + e.message }));
    if (child.stderr) child.stderr.on('data', (d) => { said = (said + d.toString()).slice(-1000); });
    child.on('close', (code) => finish({ ok: false, error: (said.split(/\r?\n/).map((l) => l.trim()).filter(Boolean).pop() || 'it stopped before answering (exit ' + code + ')').slice(0, 300) }));
    child.stdout.on('data', (d) => {
      buf += d.toString();
      let nl;
      while ((nl = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, nl); buf = buf.slice(nl + 1);
        let msg; try { msg = JSON.parse(line); } catch (_) { continue; }
        if (msg.id === initId) { try { child.stdin.write(JSON.stringify({ jsonrpc: '2.0', method: 'notifications/initialized' }) + '\n'); } catch (_) { /* closed */ } listId = send('tools/list', {}); }
        else if (msg.id === listId) finish({ ok: true, tools: msg.result && Array.isArray(msg.result.tools) ? msg.result.tools.length : 0 });
      }
    });
    initId = send('initialize', { protocolVersion: '2025-06-18', capabilities: {}, clientInfo: { name: 'nami', version: '1.0' } });
  });
}
module.exports = { checkServer };
