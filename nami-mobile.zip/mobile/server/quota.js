'use strict';
// Claude's own limit windows (5-hour, 7-day). Claude Code hands them to its status-line command;
// installing that command is a choice the person makes, and an existing status line is never replaced.
const fs = require('node:fs');
const path = require('node:path');

const SCRIPT = path.join(__dirname, 'statusline.js');
const q = (s) => `'${String(s).replace(/'/g, "'\\''")}'`;

function settingsFile(home) { return path.join(home, '.claude', 'settings.json'); }
function readSettings(home) {
  try { const d = JSON.parse(fs.readFileSync(settingsFile(home), 'utf8')); return d && typeof d === 'object' && !Array.isArray(d) ? d : {}; }
  catch (e) { return e.code === 'ENOENT' ? {} : null; }
}

function status({ home, dir }) {
  const s = readSettings(home);
  const cmd = s && s.statusLine && s.statusLine.command;
  const ours = typeof cmd === 'string' && cmd.includes(SCRIPT);
  let data = null;
  try { data = JSON.parse(fs.readFileSync(path.join(dir, 'claude.json'), 'utf8')); } catch (_) { /* none yet */ }
  const names = { five_hour: '5-hour window', seven_day: '7-day window', spend_limit: 'Spend limit' };
  const windows = data && data.rate_limits ? Object.entries(data.rate_limits).map(([k, w]) => ({
    id: k, label: names[k] || k, used: Math.round(w.used_percentage), resetsAt: typeof w.resets_at === 'number' ? (w.resets_at < 1e12 ? w.resets_at * 1000 : w.resets_at) : null,
  })) : [];
  return { installed: ours, blocked: s === null ? 'unreadable' : (!ours && s.statusLine ? 'other' : null), at: data ? data.at : null, windows };
}

function install({ home, dir }) {
  const s = readSettings(home);
  if (s === null) throw new Error('Claude settings could not be read, so they were left alone.');
  if (s.statusLine && !(s.statusLine.command || '').includes(SCRIPT)) throw new Error('You already have a Claude status line, so it was left alone.');
  s.statusLine = { type: 'command', command: `node ${q(SCRIPT)} ${q(dir)}` };
  fs.mkdirSync(path.dirname(settingsFile(home)), { recursive: true });
  const tmp = settingsFile(home) + '.nami-' + process.pid;
  fs.writeFileSync(tmp, JSON.stringify(s, null, 2) + '\n'); fs.renameSync(tmp, settingsFile(home));
  return status({ home, dir });
}

function remove({ home, dir }) {
  const s = readSettings(home);
  if (s && s.statusLine && (s.statusLine.command || '').includes(SCRIPT)) {
    delete s.statusLine;
    const tmp = settingsFile(home) + '.nami-' + process.pid;
    fs.writeFileSync(tmp, JSON.stringify(s, null, 2) + '\n'); fs.renameSync(tmp, settingsFile(home));
  }
  return status({ home, dir });
}

module.exports = { status, install, remove, SCRIPT };
