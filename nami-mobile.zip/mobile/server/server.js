#!/usr/bin/env node
'use strict';
// Nami for Android: the server half. Runs inside the app's Linux, serves the phone UI and a
// WebSocket that drives agent sessions.
//
// A session is a shell on this phone, so the door has three locks:
//   1. it listens on 127.0.0.1 unless you ask for --lan;
//   2. every socket must present the secret token before it can do anything;
//   3. a browser page from some other site cannot open the socket (Host and
//      Origin are checked), so a web page you happen to visit cannot reach it.

const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { WebSocketServer } = require('ws');
const { SessionManager } = require('./sessions');
const { createSpawner } = require('./pty-adapter');
const { listAgents, withUserPaths } = require('./agents');
const { createTmux } = require('./tmux');

const WEB_DIR = path.join(__dirname, '..', 'web');
// The terminal files ship beside the server (mobile/vendor), copied from the desktop
// app's src/renderer/vendor. Inside the full repo the desktop copy is the fallback.
const VENDOR_DIR = [path.join(__dirname, '..', 'vendor'), path.join(__dirname, '..', '..', 'src', 'renderer', 'vendor')]
  .find((d) => fs.existsSync(path.join(d, 'xterm.mjs'))) || path.join(__dirname, '..', 'vendor');
// Only what the phone UI needs.
const VENDOR_ALLOWED = /^(xterm\.mjs|xterm\.css|addon-fit\.mjs|fonts\/[A-Za-z0-9._-]+\.woff2)$/;

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.webmanifest': 'application/manifest+json',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.woff2': 'font/woff2',
};

const AUTH_TIMEOUT_MS = 5000;
const MAX_FAILS = 6;
const FAIL_WINDOW_MS = 60 * 1000;

function loadOrCreateToken(home) {
  const dir = process.env.NAMI_MOBILE_HOME || path.join(home, '.nami-mobile');
  const file = path.join(dir, 'token');
  try {
    const t = fs.readFileSync(file, 'utf8').trim();
    if (/^[0-9a-f]{48}$/.test(t)) return { token: t, file };
  } catch (_) { /* first run */ }
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const token = crypto.randomBytes(24).toString('hex');
  fs.writeFileSync(file, token + '\n', { mode: 0o600 });
  return { token, file };
}

function sameToken(a, b) {
  const ha = crypto.createHash('sha256').update(String(a)).digest();
  const hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
}

function hostName(hostHeader) {
  if (!hostHeader) return '';
  const h = String(hostHeader).toLowerCase();
  if (h.startsWith('[')) return h.slice(0, h.indexOf(']') + 1);
  return h.split(':')[0];
}

function createServer({ manager, token, host = '127.0.0.1', lan = false, listAgentsFn = listAgents }) {
  const fails = new Map(); // ip -> [timestamps]
  const tooManyFails = (ip) => {
    const now = Date.now();
    const recent = (fails.get(ip) || []).filter((t) => now - t < FAIL_WINDOW_MS);
    fails.set(ip, recent);
    return recent.length >= MAX_FAILS;
  };
  const noteFail = (ip) => { fails.set(ip, [...(fails.get(ip) || []), Date.now()]); };

  const hostOk = (req) => {
    if (lan) return true;
    return ['localhost', '127.0.0.1', '[::1]'].includes(hostName(req.headers.host));
  };

  const server = http.createServer((req, res) => {
    if (!hostOk(req)) { res.writeHead(421); res.end('Wrong host'); return; }
    let pathname;
    try { pathname = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch (_) { res.writeHead(400); res.end(); return; }
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); res.end(); return; }
    if (pathname === '/healthz') { res.writeHead(200, { 'content-type': 'text/plain' }); res.end('ok'); return; }

    let file = null;
    if (pathname.startsWith('/vendor/')) {
      const rel = pathname.slice('/vendor/'.length);
      if (VENDOR_ALLOWED.test(rel) && !rel.includes('..')) file = path.join(VENDOR_DIR, rel);
    } else {
      const rel = pathname === '/' ? 'index.html' : pathname.slice(1);
      const full = path.resolve(WEB_DIR, rel);
      if (full.startsWith(WEB_DIR + path.sep)) file = full;
    }
    // Only page assets: no stray package.json or dotfiles, whatever sits in the folder.
    if (!file || !MIME[path.extname(file)] || path.basename(file).startsWith('.')) { res.writeHead(404); res.end('Not found'); return; }
    fs.readFile(file, (err, body) => {
      if (err) { res.writeHead(404); res.end('Not found'); return; }
      res.writeHead(200, {
        'content-type': MIME[path.extname(file)] || 'application/octet-stream',
        'cache-control': 'no-store',
        'x-content-type-options': 'nosniff',
        'referrer-policy': 'no-referrer',
      });
      res.end(req.method === 'HEAD' ? undefined : body);
    });
  });

  const wss = new WebSocketServer({ noServer: true, maxPayload: 128 * 1024 });
  const authed = new Set(); // sockets that passed auth

  server.on('upgrade', (req, socket, head) => {
    const ip = req.socket.remoteAddress || '?';
    let pathname = '';
    try { pathname = new URL(req.url, 'http://x').pathname; } catch (_) { /* rejected below */ }
    const origin = req.headers.origin;
    const originOk = !origin || (() => { try { return new URL(origin).host.toLowerCase() === String(req.headers.host || '').toLowerCase(); } catch (_) { return false; } })();
    if (pathname !== '/ws' || !hostOk(req) || !originOk) { socket.write('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n'); socket.destroy(); return; }
    if (tooManyFails(ip)) { socket.write('HTTP/1.1 429 Too Many Requests\r\nConnection: close\r\n\r\n'); socket.destroy(); return; }
    wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req));
  });

  const send = (ws, obj) => { if (ws.readyState === 1) ws.send(JSON.stringify(obj)); };

  wss.on('connection', (ws, req) => {
    const ip = req.socket.remoteAddress || '?';
    ws.attached = null;
    const timer = setTimeout(() => { if (!authed.has(ws)) ws.close(4001, 'auth timeout'); }, AUTH_TIMEOUT_MS);
    ws.on('close', () => { clearTimeout(timer); authed.delete(ws); });
    ws.on('error', () => { /* the close handler cleans up */ });

    ws.on('message', (raw) => {
      let m;
      try { m = JSON.parse(raw.toString('utf8')); } catch (_) { return; }
      if (!m || typeof m.type !== 'string') return;

      if (!authed.has(ws)) {
        if (m.type !== 'auth') { ws.close(4001, 'auth required'); return; }
        if (typeof m.token === 'string' && sameToken(m.token, token)) {
          authed.add(ws); clearTimeout(timer);
          send(ws, { type: 'authed', sessions: manager.list(), agents: listAgentsFn(), lan, home: manager.home });
        } else {
          noteFail(ip);
          send(ws, { type: 'denied' });
          ws.close(4003, 'bad token');
        }
        return;
      }

      switch (m.type) {
        case 'list': send(ws, { type: 'sessions', sessions: manager.list() }); break;
        case 'agents': send(ws, { type: 'agents', agents: listAgentsFn() }); break;
        case 'create': {
          try {
            const s = manager.create({ kind: m.kind, agentId: m.agentId, cwd: m.cwd, name: m.name, cols: m.cols, rows: m.rows });
            ws.attached = s.id;
            send(ws, { type: 'created', session: s });
            send(ws, { type: 'snapshot', id: s.id, data: manager.snapshot(s.id) || '', exited: false, exitCode: null });
          } catch (e) { send(ws, { type: 'error', message: e.message }); }
          break;
        }
        case 'attach': {
          const s = manager.get(m.id);
          if (!s) { send(ws, { type: 'error', message: 'That session is gone.' }); break; }
          if (Number.isFinite(m.cols) && Number.isFinite(m.rows)) manager.resize(s.id, m.cols, m.rows, { redraw: false });
          send(ws, { type: 'snapshot', id: s.id, data: manager.snapshot(s.id) || '', exited: s.exited, exitCode: s.exitCode });
          ws.attached = s.id;
          manager.redraw(s.id);   // tmux: the screen itself, at this size, right after the history
          break;
        }
        case 'detach': ws.attached = null; break;
        case 'input': if (typeof m.id === 'string') manager.write(m.id, m.data); break;
        case 'resize': if (typeof m.id === 'string') manager.resize(m.id, m.cols, m.rows); break;
        case 'scroll': if (typeof m.id === 'string') manager.scroll(m.id, Number(m.lines)); break;
        case 'live': if (typeof m.id === 'string') manager.live(m.id); break;
        case 'close': if (typeof m.id === 'string') { manager.close(m.id); if (ws.attached === m.id) ws.attached = null; } break;
        default: break;
      }
    });
  });

  manager.on('data', (id, data) => {
    for (const ws of authed) if (ws.attached === id) send(ws, { type: 'data', id, data });
  });
  manager.on('exit', (id, code) => {
    for (const ws of authed) send(ws, { type: 'exit', id, code });
  });
  manager.on('change', () => {
    const sessions = manager.list();
    for (const ws of authed) send(ws, { type: 'sessions', sessions });
  });

  const close = () => new Promise((resolve) => {
    for (const ws of wss.clients) ws.terminate();
    manager.shutdown();   // tmux-backed sessions keep running; the next start adopts them
    server.close(() => resolve());
  });
  return { server, wss, close };
}

function parseArgs(argv) {
  const out = { port: Number(process.env.NAMI_MOBILE_PORT) || 7878, lan: false, forceScript: false, noTmux: false };
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--lan') out.lan = true;
    else if (argv[i] === '--no-tmux') out.noTmux = true;
    else if (argv[i] === '--no-pty') out.forceScript = true;
    else if (argv[i] === '--port') out.port = Number(argv[++i]) || out.port;
  }
  return out;
}

function lanAddresses() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const i of list || []) if (i.family === 'IPv4' && !i.internal) out.push(i.address);
  }
  return out;
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  const host = opts.lan ? '0.0.0.0' : '127.0.0.1';
  const { token, file } = loadOrCreateToken(os.homedir());
  const spawnPty = createSpawner({ forceScript: opts.forceScript });
  const env = withUserPaths(process.env);
  const dataDir = path.dirname(file);
  const tmuxApi = createTmux({ socket: process.env.NAMI_TMUX_SOCKET || 'nami', env, confPath: path.join(dataDir, 'tmux.conf') });
  const tmux = !opts.noTmux && tmuxApi.available() ? tmuxApi : null;
  const manager = new SessionManager({ spawnPty, env, tmux });
  const adopted = manager.adopt();
  const { server, close } = createServer({ manager, token, host, lan: opts.lan, listAgentsFn: () => listAgents({ env }) });
  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.error(`Port ${opts.port} is already in use. Nami is probably already running; open the link again, or use --port.`);
      process.exit(2);
    }
    throw err;
  });
  server.listen(opts.port, host, () => {
    console.log('Nami for Android is running.\n');
    console.log(tmux
      ? `  Sessions are kept in tmux: they keep running if this server stops${adopted ? ` (picked up ${adopted} from before)` : ''}.`
      : '  tmux not found, so sessions end when this server stops. Install it: pkg install tmux');
    console.log(`  Open on this phone:  http://127.0.0.1:${opts.port}/?t=${token}`);
    if (opts.lan) {
      for (const ip of lanAddresses()) console.log(`  On your network:     http://${ip}:${opts.port}/?t=${token}`);
      console.log('\n  --lan lets other devices on your Wi-Fi reach this. The link is the only lock,');
      console.log('  and the traffic is not encrypted. Use it on a network you trust.');
    }
    console.log(`\n  Token file: ${file}`);
    console.log(tmux ? '  Press Ctrl+C to stop the server. Your sessions keep running.' : '  Press Ctrl+C to stop. Running sessions stop with it.');
  });
  const stop = () => { close().then(() => process.exit(0)); setTimeout(() => process.exit(0), 1500).unref(); };
  process.on('SIGINT', stop);
  process.on('SIGTERM', stop);
}

if (require.main === module) main();

module.exports = { createServer, loadOrCreateToken, sameToken, hostName };
