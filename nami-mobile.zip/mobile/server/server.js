#!/usr/bin/env node
'use strict';
// Nami for Android: the server half. Runs inside the app's Linux, serves the phone UI and a
// WebSocket that drives agent sessions.
//
// A session is a shell on this phone, so the door has three locks:
//   1. it listens on 127.0.0.1 unless you ask for --lan;
//   2. every socket must present the secret token before it can do anything;
//   3. a browser page from some other site cannot open the socket (Host and
//      Origin are checked), so a web page you happen to visit cannot reach it.

const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { WebSocketServer } = require('ws');
const { SessionManager } = require('./sessions');
const { createSpawner } = require('./pty-adapter');
const { listAgents, withUserPaths } = require('./agents');
const { createTmux } = require('./tmux');
const { createWorkspace } = require('./workspace');
const { createConnections } = require('./connections');
const { Acp } = require('./acp');
const { createKeys } = require('./keys');
const { createVoice } = require('./voice');
const { createRpc } = require('./rpc');

const WEB_DIR = path.join(__dirname, '..', 'web');
// The terminal files ship beside the server (mobile/vendor), copied from the desktop
// app's src/renderer/vendor. Inside the full repo the desktop copy is the fallback.
const VENDOR_DIR = [path.join(__dirname, '..', 'vendor'), path.join(__dirname, '..', '..', 'src', 'renderer', 'vendor')]
  .find((d) => fs.existsSync(path.join(d, 'xterm.mjs'))) || path.join(__dirname, '..', 'vendor');
// Only what the phone UI needs.
const VENDOR_ALLOWED = /^(xterm\.mjs|xterm\.css|addon-fit\.mjs|fonts\/[A-Za-z0-9._-]+\.woff2)$/;

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.webmanifest': 'application/manifest+json',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.woff2': 'font/woff2',
};

const AUTH_TIMEOUT_MS = 5000;
const MAX_FAILS = 6;
const FAIL_WINDOW_MS = 60 * 1000;

// The first time only: a short "Start here.md" in the home folder (like the desktop app's welcome note).
// Written once, never again, and never over a file of that name.
function writeStartNote(home, dataDir) {
  const mark = path.join(dataDir, 'start-note');
  try {
    if (fs.existsSync(mark)) return;
    fs.writeFileSync(mark, '1\n');
    const file = path.join(home, 'Start here.md');
    if (fs.existsSync(file)) return;
    fs.writeFileSync(file, [
      '# Start here', '',
      'This is Nami on your phone. Everything runs inside this app, in its own Linux.', '',
      '- **Sessions** keep running when you close the app. Tap **+** for a new one: pick an agent (Claude Code, Codex, OpenCode) or a plain shell.',
      '- **Sign in** the first time, or add your own key under **Settings → Providers**.',
      '- **Files** live in the Workspace tab. Tap a path in the terminal to open it; the star pins a file to your desk.',
      '- **Beside the terminal**: the split button shows another session or a pinned file next to this one.',
      '- Type `nami-help` in a shell to see the phone commands (copy, paste, notify, share, battery…).', '',
      'You can delete or edit this file. It will not come back.', '',
    ].join('\n'));
  } catch (_) { /* a note is not worth failing for */ }
}

function loadOrCreateToken(home) {
  const dir = process.env.NAMI_MOBILE_HOME || path.join(home, '.nami-mobile');
  const file = path.join(dir, 'token');
  try {
    const t = fs.readFileSync(file, 'utf8').trim();
    if (/^[0-9a-f]{48}$/.test(t)) return { token: t, file };
  } catch (_) { /* first run */ }
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const token = crypto.randomBytes(24).toString('hex');
  fs.writeFileSync(file, token + '\n', { mode: 0o600 });
  return { token, file };
}

function sameToken(a, b) {
  const ha = crypto.createHash('sha256').update(String(a)).digest();
  const hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
}

function hostName(hostHeader) {
  if (!hostHeader) return '';
  const h = String(hostHeader).toLowerCase();
  if (h.startsWith('[')) return h.slice(0, h.indexOf(']') + 1);
  return h.split(':')[0];
}

function createServer({ manager, token, host = '127.0.0.1', lan = false, listAgentsFn = listAgents, rpc = null, keys = null, workspace = null, acp = null }) {
  const fails = new Map(); // ip -> [timestamps]
  const tooManyFails = (ip) => {
    const now = Date.now();
    const recent = (fails.get(ip) || []).filter((t) => now - t < FAIL_WINDOW_MS);
    fails.set(ip, recent);
    return recent.length >= MAX_FAILS;
  };
  const noteFail = (ip) => { fails.set(ip, [...(fails.get(ip) || []), Date.now()]); };

  const hostOk = (req) => {
    if (lan) return true;
    return ['localhost', '127.0.0.1', '[::1]'].includes(hostName(req.headers.host));
  };

  // A file from the workspace, for <img>, <video>, the PDF viewer and Download. The token rides in the
  // address because those elements cannot send headers; the address never leaves this phone.
  function serveRaw(req, res) {
    const url = new URL(req.url, 'http://x');
    const t = url.searchParams.get('t') || '';
    if (!workspace || !sameToken(t, token)) { res.writeHead(403); res.end('Forbidden'); return; }
    let info;
    try { info = workspace.rawInfo(url.searchParams.get('p') || ''); } catch (_) { info = null; }
    if (!info) { res.writeHead(404); res.end('Not found'); return; }
    const download = url.searchParams.get('download') === '1';
    const headers = {
      'content-type': info.inline && !download ? info.mime : 'application/octet-stream',
      'x-content-type-options': 'nosniff', 'cache-control': 'no-store', 'referrer-policy': 'no-referrer',
      'content-security-policy': "sandbox; default-src 'none'; style-src 'unsafe-inline'; img-src data:; media-src 'self'",
      'accept-ranges': 'bytes',
    };
    if (download) headers['content-disposition'] = `attachment; filename="${path.basename(info.file).replace(/[^\w. -]/g, '_')}"`;
    let start = 0; let end = info.size - 1; let status = 200;
    const range = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || '');
    if (range && info.size > 0) {
      if (range[1] === '' && range[2] !== '') { start = Math.max(0, info.size - Number(range[2])); }
      else { start = Number(range[1]); if (range[2] !== '') end = Math.min(end, Number(range[2])); }
      if (start > end || start >= info.size) { res.writeHead(416, { 'content-range': `bytes */${info.size}` }); res.end(); return; }
      status = 206; headers['content-range'] = `bytes ${start}-${end}/${info.size}`;
    }
    headers['content-length'] = info.size === 0 ? 0 : end - start + 1;
    res.writeHead(status, headers);
    if (req.method === 'HEAD' || info.size === 0) { res.end(); return; }
    const stream = fs.createReadStream(info.file, { start, end });
    stream.on('error', () => res.destroy());
    stream.pipe(res);
  }

  // Commands inside the Linux that reach the phone (nami-copy, nami-paste, nami-notify, nami-toast, nami-vibrate,
  // nami-share). The body is the text; ?op= says what to do. Same token as everything else.
  const askers = new Map();                    // paste requests waiting for the page's answer
  const OPS = new Set(['copy', 'paste', 'notify', 'toast', 'vibrate', 'share', 'battery', 'info', 'speak', 'torch', 'download', 'location', 'wifi', 'sensor', 'camera']);
  const ASKS = new Set(['paste', 'battery', 'info', 'location', 'wifi', 'sensor']);      // these answer with text
  function phoneApi(req, res) {
    const q = new URL(req.url, 'http://x').searchParams;
    if (req.method !== 'POST') { res.writeHead(405); res.end(); return; }
    if (!sameToken(String(req.headers['x-nami-token'] || ''), token)) { res.writeHead(403); res.end('Forbidden'); return; }
    const op = q.get('op') || '';
    if (!OPS.has(op)) { res.writeHead(400); res.end('Unknown op'); return; }
    const chunks = []; let size = 0;
    req.on('data', (c) => { size += c.length; if (size <= 1 << 20) chunks.push(c); });
    req.on('end', () => {
      if (size > 1 << 20) { res.writeHead(413); res.end('Too big (1 MB at most)'); return; }
      const text = Buffer.concat(chunks).toString('utf8');
      const targets = [...authed];
      if (!targets.length) { res.writeHead(503); res.end('The app is not open'); return; }
      const msg = { type: 'phone', op, text, title: (q.get('title') || '').slice(0, 120), ms: Math.min(2000, Math.max(10, Number(q.get('ms')) || 200)) };
      if (ASKS.has(op)) {
        const rid = crypto.randomBytes(6).toString('hex');
        const timer = setTimeout(() => { askers.delete(rid); res.writeHead(504); res.end('The app did not answer'); }, 4000);
        askers.set(rid, (t) => { clearTimeout(timer); res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8' }); res.end(t); });
        for (const ws of targets) send(ws, { ...msg, rid });
        return;
      }
      for (const ws of targets) send(ws, msg);
      res.writeHead(200, { 'content-type': 'text/plain' }); res.end('ok');
    });
  }

  const server = http.createServer((req, res) => {
    if (!hostOk(req)) { res.writeHead(421); res.end('Wrong host'); return; }
    let pathname;
    try { pathname = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch (_) { res.writeHead(400); res.end(); return; }
    if (pathname === '/__phone') { phoneApi(req, res); return; }
    // The widget or Tasker asks for a command to be run: a new session shows it. Same token as everything else.
    if (pathname === '/__run') {
      if (req.method !== 'POST') { res.writeHead(405); res.end(); return; }
      if (!sameToken(String(req.headers['x-nami-token'] || ''), token)) { res.writeHead(403); res.end('Forbidden'); return; }
      const chunks = []; let size = 0;
      req.on('data', (c) => { size += c.length; if (size <= 16384) chunks.push(c); });
      req.on('end', () => {
        if (size > 16384) { res.writeHead(413); res.end('Too big'); return; }
        try {
          const cmd = Buffer.concat(chunks).toString('utf8').trim();
          if (!cmd) { res.writeHead(400); res.end('Empty command'); return; }
          const s = manager.create({ kind: 'shell', cmd });
          res.writeHead(200, { 'content-type': 'text/plain' }); res.end(s.id);
        } catch (e) { res.writeHead(500); res.end(String(e.message || e)); }
      });
      return;
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); res.end(); return; }
    if (pathname === '/healthz') { res.writeHead(200, { 'content-type': 'text/plain' }); res.end('ok'); return; }

    // A program inside the Linux (xdg-open, $BROWSER) asks the app to open a link. Needs the token, http(s) only.
    if (pathname === '/__open') {
      const u = new URL(req.url, 'http://x').searchParams.get('u') || '';
      if (!sameToken(String(req.headers['x-nami-token'] || ''), token)) { res.writeHead(403); res.end('Forbidden'); return; }
      if (!/^https?:\/\/[^\s]+$/i.test(u) || u.length > 4000) { res.writeHead(400); res.end('Not a web link'); return; }
      let n = 0; for (const ws of authed) { send(ws, { type: 'open-url', url: u }); n++; }
      res.writeHead(n ? 200 : 503, { 'content-type': 'text/plain' }); res.end(n ? 'ok' : 'The app is not open'); return;
    }

    if (pathname === '/raw') { serveRaw(req, res); return; }

    let file = null;
    if (pathname.startsWith('/vendor/')) {
      const rel = pathname.slice('/vendor/'.length);
      if (VENDOR_ALLOWED.test(rel) && !rel.includes('..')) file = path.join(VENDOR_DIR, rel);
    } else {
      const rel = pathname === '/' ? 'index.html' : pathname.slice(1);
      const full = path.resolve(WEB_DIR, rel);
      if (full.startsWith(WEB_DIR + path.sep)) file = full;
    }
    // Only page assets: no stray package.json or dotfiles, whatever sits in the folder.
    if (!file || !MIME[path.extname(file)] || path.basename(file).startsWith('.')) { res.writeHead(404); res.end('Not found'); return; }
    fs.readFile(file, (err, body) => {
      if (err) { res.writeHead(404); res.end('Not found'); return; }
      res.writeHead(200, {
        'content-type': MIME[path.extname(file)] || 'application/octet-stream',
        'cache-control': 'no-store',
        'x-content-type-options': 'nosniff',
        'referrer-policy': 'no-referrer',
      });
      res.end(req.method === 'HEAD' ? undefined : body);
    });
  });

  const wss = new WebSocketServer({ noServer: true, maxPayload: 4 * 1024 * 1024 });
  const authed = new Set(); // sockets that passed auth

  server.on('upgrade', (req, socket, head) => {
    const ip = req.socket.remoteAddress || '?';
    let pathname = '';
    try { pathname = new URL(req.url, 'http://x').pathname; } catch (_) { /* rejected below */ }
    const origin = req.headers.origin;
    const originOk = !origin || (() => { try { return new URL(origin).host.toLowerCase() === String(req.headers.host || '').toLowerCase(); } catch (_) { return false; } })();
    if (pathname !== '/ws' || !hostOk(req) || !originOk) { socket.write('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n'); socket.destroy(); return; }
    if (tooManyFails(ip)) { socket.write('HTTP/1.1 429 Too Many Requests\r\nConnection: close\r\n\r\n'); socket.destroy(); return; }
    wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req));
  });

  const send = (ws, obj) => { if (ws.readyState === 1) ws.send(JSON.stringify(obj)); };

  wss.on('connection', (ws, req) => {
    const ip = req.socket.remoteAddress || '?';
    ws.attached = null;
    const timer = setTimeout(() => { if (!authed.has(ws)) ws.close(4001, 'auth timeout'); }, AUTH_TIMEOUT_MS);
    ws.on('close', () => { clearTimeout(timer); clearTimeout(ws.flushTimer); authed.delete(ws); if (ws.chats && acp) for (const id of ws.chats) acp.stop(id); });
    ws.on('error', () => { /* the close handler cleans up */ });

    ws.on('message', (raw) => {
      let m;
      try { m = JSON.parse(raw.toString('utf8')); } catch (_) { return; }
      if (!m || typeof m.type !== 'string') return;

      if (!authed.has(ws)) {
        if (m.type !== 'auth') { ws.close(4001, 'auth required'); return; }
        if (typeof m.token === 'string' && sameToken(m.token, token)) {
          authed.add(ws); clearTimeout(timer);
          send(ws, { type: 'authed', sessions: manager.list(), agents: listAgentsFn(), lan, home: manager.home, root: workspace ? workspace.root : manager.home });
        } else {
          noteFail(ip);
          send(ws, { type: 'denied' });
          ws.close(4003, 'bad token');
        }
        return;
      }

      switch (m.type) {
        case 'rpc': {
          const id = m.id;
          const fail = (e) => send(ws, { type: 'rpc', id, ok: false, error: (e && e.message) || 'Failed.', code: (e && e.code) || 'bad' });
          try {
            if (!rpc) throw new Error('Not available here.');
            const out = rpc.handle(String(m.op), m.args);
            // Some answers take a while (a browser check, a backup, a voice upload): wait for them.
            if (out && typeof out.then === 'function') out.then((data) => send(ws, { type: 'rpc', id, ok: true, data }), fail);
            else send(ws, { type: 'rpc', id, ok: true, data: out });
          } catch (e) {
            fail(e);
          }
          break;
        }
        case 'phone-reply': { const f = askers.get(m.rid); if (f) { askers.delete(m.rid); f(String(m.text || '').slice(0, 1 << 20)); } break; }
        case 'list': send(ws, { type: 'sessions', sessions: manager.list() }); break;
        case 'agents': send(ws, { type: 'agents', agents: listAgentsFn() }); break;
        case 'create': {
          try {
            const s = manager.create({ kind: m.kind, agentId: m.agentId, cwd: m.cwd, name: m.name, cols: m.cols, rows: m.rows, seed: m.seed, resume: m.resume === true,
            env: m.providerId && keys ? keys.envFor(String(m.providerId)) : undefined });
            ws.attached = s.id; dropPending(ws, s.id);
            send(ws, { type: 'created', session: s });
            send(ws, { type: 'snapshot', id: s.id, data: manager.snapshot(s.id) || '', exited: false, exitCode: null });
          } catch (e) { send(ws, { type: 'error', message: e.message }); }
          break;
        }
        case 'attach': {
          const s = manager.get(m.id);
          if (!s) { send(ws, { type: 'error', message: 'That session is gone.' }); break; }
          if (Number.isFinite(m.cols) && Number.isFinite(m.rows)) manager.resize(s.id, m.cols, m.rows, { redraw: false });
          dropPending(ws, s.id);
          send(ws, { type: 'snapshot', id: s.id, data: manager.snapshot(s.id) || '', exited: s.exited, exitCode: s.exitCode });
          if (m.extra === true) { (ws.watching = ws.watching || new Set()).add(s.id); } else ws.attached = s.id;   // extra: a second pane beside the first
          manager.redraw(s.id);   // tmux: the screen itself, at this size, right after the history
          break;
        }
        case 'chat.start': {
          try {
            if (!acp) throw new Error('Chat is not available here.');
            const id = acp.start({ agentId: String(m.agentId), cwd: m.cwd, env: m.providerId && keys ? keys.envFor(String(m.providerId)) : undefined });
            (ws.chats = ws.chats || new Set()).add(id);
            send(ws, { type: 'chat.started', id, ref: m.ref });
          } catch (e) { send(ws, { type: 'chat.failed', ref: m.ref, message: e.message }); }
          break;
        }
        case 'chat.send': if (acp && ws.chats && ws.chats.has(m.id) && typeof m.line === 'string') acp.write(m.id, m.line); break;
        case 'chat.stop': if (acp && ws.chats && ws.chats.has(m.id)) { acp.stop(m.id); ws.chats.delete(m.id); } break;
        case 'detach': if (typeof m.id === 'string' && ws.watching) ws.watching.delete(m.id); else ws.attached = null; break;
        case 'input': if (typeof m.id === 'string') manager.write(m.id, m.data); break;
        case 'resize': if (typeof m.id === 'string') manager.resize(m.id, m.cols, m.rows); break;
        case 'scroll': if (typeof m.id === 'string') manager.scroll(m.id, Number(m.lines)); break;
        case 'live': if (typeof m.id === 'string') manager.live(m.id); break;
        case 'close': if (typeof m.id === 'string') { manager.close(m.id); if (ws.attached === m.id) ws.attached = null; if (ws.watching) ws.watching.delete(m.id); } break;
        default: break;
      }
    });
  });

  if (acp) {
    acp.on('line', (id, line) => { for (const ws of authed) if (ws.chats && ws.chats.has(id)) send(ws, { type: 'chat.line', id, line }); });
    acp.on('exit', (id, code, note) => { for (const ws of authed) if (ws.chats && ws.chats.has(id)) { ws.chats.delete(id); send(ws, { type: 'chat.exit', id, code, note: note || '' }); } });
  }

  // Terminal output arrives in many tiny pieces (a busy agent redraws constantly). Pieces for one
  // session are joined and sent about 60 times a second at most: far fewer messages for the phone to
  // parse and the terminal to paint, with no visible delay.
  const FLUSH_MS = 16;
  function flushData(ws) {
    ws.flushTimer = null;
    const p = ws.pend; ws.pend = null;
    if (p) for (const id of Object.keys(p)) send(ws, { type: 'data', id, data: p[id] });
  }
  const dropPending = (ws, id) => { if (ws.pend) delete ws.pend[id]; };
  manager.on('data', (id, data) => {
    for (const ws of authed) {
      if (!(ws.attached === id || (ws.watching && ws.watching.has(id)))) continue;
      ws.pend = ws.pend || {};
      ws.pend[id] = (ws.pend[id] || '') + data;
      if (!ws.flushTimer) ws.flushTimer = setTimeout(() => flushData(ws), FLUSH_MS);
    }
  });
  manager.on('exit', (id, code) => {
    for (const ws of authed) { if (ws.flushTimer) { clearTimeout(ws.flushTimer); flushData(ws); } send(ws, { type: 'exit', id, code }); }
  });
  manager.on('change', () => {
    const sessions = manager.list();
    for (const ws of authed) send(ws, { type: 'sessions', sessions });
  });

  const close = () => new Promise((resolve) => {
    for (const ws of wss.clients) ws.terminate();
    manager.shutdown();   // tmux-backed sessions keep running; the next start adopts them
    server.close(() => resolve());
  });
  return { server, wss, close };
}

function parseArgs(argv) {
  const out = { port: Number(process.env.NAMI_MOBILE_PORT) || 7878, lan: false, forceScript: false, noTmux: false };
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--lan') out.lan = true;
    else if (argv[i] === '--no-tmux') out.noTmux = true;
    else if (argv[i] === '--no-pty') out.forceScript = true;
    else if (argv[i] === '--test-acp') { out.acpLaunches = { claude: { command: process.execPath, args: [argv[++i]] } }; }   // tests only: a stand-in agent
    else if (argv[i] === '--port') out.port = Number(argv[++i]) || out.port;
  }
  return out;
}

function lanAddresses() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const i of list || []) if (i.family === 'IPv4' && !i.internal) out.push(i.address);
  }
  return out;
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  const host = opts.lan ? '0.0.0.0' : '127.0.0.1';
  const { token, file } = loadOrCreateToken(os.homedir());
  const spawnPty = createSpawner({ forceScript: opts.forceScript });
  const env = withUserPaths(process.env);
  const dataDir = path.dirname(file);
  const tmuxApi = createTmux({ socket: process.env.NAMI_TMUX_SOCKET || 'nami', env, confPath: path.join(dataDir, 'tmux.conf') });
  const tmux = !opts.noTmux && tmuxApi.available() ? tmuxApi : null;
  const manager = new SessionManager({ spawnPty, env, tmux });
  const adopted = manager.adopt();
  const settingsFile = path.join(dataDir, 'settings.json');
  let saved = {};
  try { saved = JSON.parse(fs.readFileSync(settingsFile, 'utf8')); } catch (_) { /* first run */ }
  const home = os.homedir();
  const workspace = createWorkspace({ root: home, home });
  writeStartNote(home, dataDir);
  if (saved.root) { try { workspace.setRoot(saved.root); } catch (_) { /* folder gone: stay at home */ } }
  // Pictures sent from the message box land here (outside the workspace), and are tidied after a week.
  const pastedDir = path.join(dataDir, 'pasted');
  fs.mkdirSync(pastedDir, { recursive: true, mode: 0o700 });
  try { for (const f of fs.readdirSync(pastedDir)) { const p = path.join(pastedDir, f); if (Date.now() - fs.statSync(p).mtimeMs > 7 * 864e5) fs.rmSync(p, { force: true }); } } catch (_) { /* best effort */ }
  const attach = createWorkspace({ root: pastedDir, home });
  const connections = createConnections({ file: path.join(dataDir, 'connections.json'), home });
  const keys = createKeys({ file: path.join(dataDir, 'keys.json') });
  const rpc = createRpc({
    workspace, keys, home, attach, connections, dataDir, voice: createVoice({ file: path.join(dataDir, 'voice.json') }),
    settings: { get: () => saved, set: (patch) => { try { saved = { ...saved, ...patch }; fs.writeFileSync(settingsFile, JSON.stringify(saved), { mode: 0o600 }); } catch (_) { /* best effort */ } } },
    saveRoot: (r) => { try { fs.writeFileSync(settingsFile, JSON.stringify({ ...saved, root: r }), { mode: 0o600 }); saved.root = r; } catch (_) { /* best effort */ } },
  });
  const { server, close } = createServer({ manager, token, host, lan: opts.lan, listAgentsFn: () => listAgents({ env }), rpc, keys, workspace, acp: new Acp({ env, home, launches: opts.acpLaunches }) });
  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.error(`Port ${opts.port} is already in use. Nami is probably already running; open the link again, or use --port.`);
      process.exit(2);
    }
    throw err;
  });
  server.listen(opts.port, host, () => {
    console.log('Nami for Android is running.\n');
    console.log(tmux
      ? `  Sessions are kept in tmux: they keep running if this server stops${adopted ? ` (picked up ${adopted} from before)` : ''}.`
      : '  tmux not found, so sessions end when this server stops. Install it: pkg install tmux');
    console.log(`  Open on this phone:  http://127.0.0.1:${opts.port}/?t=${token}`);
    if (opts.lan) {
      for (const ip of lanAddresses()) console.log(`  On your network:     http://${ip}:${opts.port}/?t=${token}`);
      console.log('\n  --lan lets other devices on your Wi-Fi reach this. The link is the only lock,');
      console.log('  and the traffic is not encrypted. Use it on a network you trust.');
    }
    console.log(`\n  Token file: ${file}`);
    console.log(tmux ? '  Press Ctrl+C to stop the server. Your sessions keep running.' : '  Press Ctrl+C to stop. Running sessions stop with it.');
  });
  const stop = () => { close().then(() => process.exit(0)); setTimeout(() => process.exit(0), 1500).unref(); };
  process.on('SIGINT', stop);
  process.on('SIGTERM', stop);
}

if (require.main === module) main();

module.exports = { createServer, loadOrCreateToken, sameToken, hostName };
