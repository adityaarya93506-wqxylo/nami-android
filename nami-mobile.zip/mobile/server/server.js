#!/usr/bin/env node
'use strict';
// Nami for Android: the server half. Runs inside the app's Linux, serves the phone UI and a
// WebSocket that drives agent sessions.
//
// A session is a shell on this phone, so the door has three locks:
//   1. it listens on 127.0.0.1 unless you ask for --lan;
//   2. every socket must present the secret token before it can do anything;
//   3. a browser page from some other site cannot open the socket (Host and
//      Origin are checked), so a web page you happen to visit cannot reach it.

const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { WebSocketServer } = require('ws');
const { SessionManager } = require('./sessions');
const { createSpawner } = require('./pty-adapter');
const { listAgents, withUserPaths } = require('./agents');
const { createTmux } = require('./tmux');
const { createWorkspace } = require('./workspace');
const { createConnections } = require('./connections');
const { Acp } = require('./acp');
const { createKeys } = require('./keys');
const { createRpc } = require('./rpc');

const WEB_DIR = path.join(__dirname, '..', 'web');
// The terminal files ship beside the server (mobile/vendor), copied from the desktop
// app's src/renderer/vendor. Inside the full repo the desktop copy is the fallback.
const VENDOR_DIR = [path.join(__dirname, '..', 'vendor'), path.join(__dirname, '..', '..', 'src', 'renderer', 'vendor')]
  .find((d) => fs.existsSync(path.join(d, 'xterm.mjs'))) || path.join(__dirname, '..', 'vendor');
// Only what the phone UI needs.
const VENDOR_ALLOWED = /^(xterm\.mjs|xterm\.css|addon-fit\.mjs|fonts\/[A-Za-z0-9._-]+\.woff2)$/;

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.webmanifest': 'application/manifest+json',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.woff2': 'font/woff2',
};

const AUTH_TIMEOUT_MS = 5000;
const MAX_FAILS = 6;
const FAIL_WINDOW_MS = 60 * 1000;

function loadOrCreateToken(home) {
  const dir = process.env.NAMI_MOBILE_HOME || path.join(home, '.nami-mobile');
  const file = path.join(dir, 'token');
  try {
    const t = fs.readFileSync(file, 'utf8').trim();
    if (/^[0-9a-f]{48}$/.test(t)) return { token: t, file };
  } catch (_) { /* first run */ }
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const token = crypto.randomBytes(24).toString('hex');
  fs.writeFileSync(file, token + '\n', { mode: 0o600 });
  return { token, file };
}

function sameToken(a, b) {
  const ha = crypto.createHash('sha256').update(String(a)).digest();
  const hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
}

function hostName(hostHeader) {
  if (!hostHeader) return '';
  const h = String(hostHeader).toLowerCase();
  if (h.startsWith('[')) return h.slice(0, h.indexOf(']') + 1);
  return h.split(':')[0];
}

function createServer({ manager, token, host = '127.0.0.1', lan = false, listAgentsFn = listAgents, rpc = null, keys = null, workspace = null, acp = null }) {
  const fails = new Map(); // ip -> [timestamps]
  const tooManyFails = (ip) => {
    const now = Date.now();
    const recent = (fails.get(ip) || []).filter((t) => now - t < FAIL_WINDOW_MS);
    fails.set(ip, recent);
    return recent.length >= MAX_FAILS;
  };
  const noteFail = (ip) => { fails.set(ip, [...(fails.get(ip) || []), Date.now()]); };

  const hostOk = (req) => {
    if (lan) return true;
    return ['localhost', '127.0.0.1', '[::1]'].includes(hostName(req.headers.host));
  };

  // A file from the workspace, for <img>, <video>, the PDF viewer and Download. The token rides in the
  // address because those elements cannot send headers; the address never leaves this phone.
  function serveRaw(req, res) {
    const url = new URL(req.url, 'http://x');
    const t = url.searchParams.get('t') || '';
    if (!workspace || !sameToken(t, token)) { res.writeHead(403); res.end('Forbidden'); return; }
    let info;
    try { info = workspace.rawInfo(url.searchParams.get('p') || ''); } catch (_) { info = null; }
    if (!info) { res.writeHead(404); res.end('Not found'); return; }
    const download = url.searchParams.get('download') === '1';
    const headers = {
      'content-type': info.inline && !download ? info.mime : 'application/octet-stream',
      'x-content-type-options': 'nosniff', 'cache-control': 'no-store', 'referrer-policy': 'no-referrer',
      'content-security-policy': "sandbox; default-src 'none'; style-src 'unsafe-inline'; img-src data:; media-src 'self'",
      'accept-ranges': 'bytes',
    };
    if (download) headers['content-disposition'] = `attachment; filename="${path.basename(info.file).replace(/[^\w. -]/g, '_')}"`;
    let start = 0; let end = info.size - 1; let status = 200;
    const range = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || '');
    if (range && info.size > 0) {
      if (range[1] === '' && range[2] !== '') { start = Math.max(0, info.size - Number(range[2])); }
      else { start = Number(range[1]); if (range[2] !== '') end = Math.min(end, Number(range[2])); }
      if (start > end || start >= info.size) { res.writeHead(416, { 'content-range': `bytes */${info.size}` }); res.end(); return; }
      status = 206; headers['content-range'] = `bytes ${start}-${end}/${info.size}`;
    }
    headers['content-length'] = info.size === 0 ? 0 : end - start + 1;
    res.writeHead(status, headers);
    if (req.method === 'HEAD' || info.size === 0) { res.end(); return; }
    const stream = fs.createReadStream(info.file, { start, end });
    stream.on('error', () => res.destroy());
    stream.pipe(res);
  }

  const server = http.createServer((req, res) => {
    if (!hostOk(req)) { res.writeHead(421); res.end('Wrong host'); return; }
    let pathname;
    try { pathname = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch (_) { res.writeHead(400); res.end(); return; }
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); res.end(); return; }
    if (pathname === '/healthz') { res.writeHead(200, { 'content-type': 'text/plain' }); res.end('ok'); return; }

    if (pathname === '/raw') { serveRaw(req, res); return; }

    let file = null;
    if (pathname.startsWith('/vendor/')) {
      const rel = pathname.slice('/vendor/'.length);
      if (VENDOR_ALLOWED.test(rel) && !rel.includes('..')) file = path.join(VENDOR_DIR, rel);
    } else {
      const rel = pathname === '/' ? 'index.html' : pathname.slice(1);
      const full = path.resolve(WEB_DIR, rel);
      if (full.startsWith(WEB_DIR + path.sep)) file = full;
    }
    // Only page assets: no stray package.json or dotfiles, whatever sits in the folder.
    if (!file || !MIME[path.extname(file)] || path.basename(file).startsWith('.')) { res.writeHead(404); res.end('Not found'); return; }
    fs.readFile(file, (err, body) => {
      if (err) { res.writeHead(404); res.end('Not found'); return; }
      res.writeHead(200, {
        'content-type': MIME[path.extname(file)] || 'application/octet-stream',
        'cache-control': 'no-store',
        'x-content-type-options': 'nosniff',
        'referrer-policy': 'no-referrer',
      });
      res.end(req.method === 'HEAD' ? undefined : body);
    });
  });

  const wss = new WebSocketServer({ noServer: true, maxPayload: 4 * 1024 * 1024 });
  const authed = new Set(); // sockets that passed auth

  server.on('upgrade', (req, socket, head) => {
    const ip = req.socket.remoteAddress || '?';
    let pathname = '';
    try { pathname = new URL(req.url, 'http://x').pathname; } catch (_) { /* rejected below */ }
    const origin = req.headers.origin;
    const originOk = !origin || (() => { try { return new URL(origin).host.toLowerCase() === String(req.headers.host || '').toLowerCase(); } catch (_) { return false; } })();
    if (pathname !== '/ws' || !hostOk(req) || !originOk) { socket.write('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n'); socket.destroy(); return; }
    if (tooManyFails(ip)) { socket.write('HTTP/1.1 429 Too Many Requests\r\nConnection: close\r\n\r\n'); socket.destroy(); return; }
    wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req));
  });

  const send = (ws, obj) => { if (ws.readyState === 1) ws.send(JSON.stringify(obj)); };

  wss.on('connection', (ws, req) => {
    const ip = req.socket.remoteAddress || '?';
    ws.attached = null;
    const timer = setTimeout(() => { if (!authed.has(ws)) ws.close(4001, 'auth timeout'); }, AUTH_TIMEOUT_MS);
    ws.on('close', () => { clearTimeout(timer); authed.delete(ws); if (ws.chats && acp) for (const id of ws.chats) acp.stop(id); });
    ws.on('error', () => { /* the close handler cleans up */ });

    ws.on('message', (raw) => {
      let m;
      try { m = JSON.parse(raw.toString('utf8')); } catch (_) { return; }
      if (!m || typeof m.type !== 'string') return;

      if (!authed.has(ws)) {
        if (m.type !== 'auth') { ws.close(4001, 'auth required'); return; }
        if (typeof m.token === 'string' && sameToken(m.token, token)) {
          authed.add(ws); clearTimeout(timer);
          send(ws, { type: 'authed', sessions: manager.list(), agents: listAgentsFn(), lan, home: manager.home, root: workspace ? workspace.root : manager.home });
        } else {
          noteFail(ip);
          send(ws, { type: 'denied' });
          ws.close(4003, 'bad token');
        }
        return;
      }

      switch (m.type) {
        case 'rpc': {
          const id = m.id;
          try {
            if (!rpc) throw new Error('Not available here.');
            send(ws, { type: 'rpc', id, ok: true, data: rpc.handle(String(m.op), m.args) });
          } catch (e) {
            send(ws, { type: 'rpc', id, ok: false, error: e.message || 'Failed.', code: e.code || 'bad' });
          }
          break;
        }
        case 'list': send(ws, { type: 'sessions', sessions: manager.list() }); break;
        case 'agents': send(ws, { type: 'agents', agents: listAgentsFn() }); break;
        case 'create': {
          try {
            const s = manager.create({ kind: m.kind, agentId: m.agentId, cwd: m.cwd, name: m.name, cols: m.cols, rows: m.rows, seed: m.seed, resume: m.resume === true,
            env: m.providerId && keys ? keys.envFor(String(m.providerId)) : undefined });
            ws.attached = s.id;
            send(ws, { type: 'created', session: s });
            send(ws, { type: 'snapshot', id: s.id, data: manager.snapshot(s.id) || '', exited: false, exitCode: null });
          } catch (e) { send(ws, { type: 'error', message: e.message }); }
          break;
        }
        case 'attach': {
          const s = manager.get(m.id);
          if (!s) { send(ws, { type: 'error', message: 'That session is gone.' }); break; }
          if (Number.isFinite(m.cols) && Number.isFinite(m.rows)) manager.resize(s.id, m.cols, m.rows, { redraw: false });
          send(ws, { type: 'snapshot', id: s.id, data: manager.snapshot(s.id) || '', exited: s.exited, exitCode: s.exitCode });
          if (m.extra === true) { (ws.watching = ws.watching || new Set()).add(s.id); } else ws.attached = s.id;   // extra: a second pane beside the first
          manager.redraw(s.id);   // tmux: the screen itself, at this size, right after the history
          break;
        }
        case 'chat.start': {
          try {
            if (!acp) throw new Error('Chat is not available here.');
            const id = acp.start({ agentId: String(m.agentId), cwd: m.cwd, env: m.providerId && keys ? keys.envFor(String(m.providerId)) : undefined });
            (ws.chats = ws.chats || new Set()).add(id);
            send(ws, { type: 'chat.started', id, ref: m.ref });
          } catch (e) { send(ws, { type: 'chat.failed', ref: m.ref, message: e.message }); }
          break;
        }
        case 'chat.send': if (acp && ws.chats && ws.chats.has(m.id) && typeof m.line === 'string') acp.write(m.id, m.line); break;
        case 'chat.stop': if (acp && ws.chats && ws.chats.has(m.id)) { acp.stop(m.id); ws.chats.delete(m.id); } break;
        case 'detach': if (typeof m.id === 'string' && ws.watching) ws.watching.delete(m.id); else ws.attached = null; break;
        case 'input': if (typeof m.id === 'string') manager.write(m.id, m.data); break;
        case 'resize': if (typeof m.id === 'string') manager.resize(m.id, m.cols, m.rows); break;
        case 'scroll': if (typeof m.id === 'string') manager.scroll(m.id, Number(m.lines)); break;
        case 'live': if (typeof m.id === 'string') manager.live(m.id); break;
        case 'close': if (typeof m.id === 'string') { manager.close(m.id); if (ws.attached === m.id) ws.attached = null; if (ws.watching) ws.watching.delete(m.id); } break;
        default: break;
      }
    });
  });

  if (acp) {
    acp.on('line', (id, line) => { for (const ws of authed) if (ws.chats && ws.chats.has(id)) send(ws, { type: 'chat.line', id, line }); });
    acp.on('exit', (id, code, note) => { for (const ws of authed) if (ws.chats && ws.chats.has(id)) { ws.chats.delete(id); send(ws, { type: 'chat.exit', id, code, note: note || '' }); } });
  }

  manager.on('data', (id, data) => {
    for (const ws of authed) if (ws.attached === id || (ws.watching && ws.watching.has(id))) send(ws, { type: 'data', id, data });
  });
  manager.on('exit', (id, code) => {
    for (const ws of authed) send(ws, { type: 'exit', id, code });
  });
  manager.on('change', () => {
    const sessions = manager.list();
    for (const ws of authed) send(ws, { type: 'sessions', sessions });
  });

  const close = () => new Promise((resolve) => {
    for (const ws of wss.clients) ws.terminate();
    manager.shutdown();   // tmux-backed sessions keep running; the next start adopts them
    server.close(() => resolve());
  });
  return { server, wss, close };
}

function parseArgs(argv) {
  const out = { port: Number(process.env.NAMI_MOBILE_PORT) || 7878, lan: false, forceScript: false, noTmux: false };
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--lan') out.lan = true;
    else if (argv[i] === '--no-tmux') out.noTmux = true;
    else if (argv[i] === '--no-pty') out.forceScript = true;
    else if (argv[i] === '--test-acp') { out.acpLaunches = { claude: { command: process.execPath, args: [argv[++i]] } }; }   // tests only: a stand-in agent
    else if (argv[i] === '--port') out.port = Number(argv[++i]) || out.port;
  }
  return out;
}

function lanAddresses() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const i of list || []) if (i.family === 'IPv4' && !i.internal) out.push(i.address);
  }
  return out;
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  const host = opts.lan ? '0.0.0.0' : '127.0.0.1';
  const { token, file } = loadOrCreateToken(os.homedir());
  const spawnPty = createSpawner({ forceScript: opts.forceScript });
  const env = withUserPaths(process.env);
  const dataDir = path.dirname(file);
  const tmuxApi = createTmux({ socket: process.env.NAMI_TMUX_SOCKET || 'nami', env, confPath: path.join(dataDir, 'tmux.conf') });
  const tmux = !opts.noTmux && tmuxApi.available() ? tmuxApi : null;
  const manager = new SessionManager({ spawnPty, env, tmux });
  const adopted = manager.adopt();
  const settingsFile = path.join(dataDir, 'settings.json');
  let saved = {};
  try { saved = JSON.parse(fs.readFileSync(settingsFile, 'utf8')); } catch (_) { /* first run */ }
  const home = os.homedir();
  const workspace = createWorkspace({ root: home, home });
  if (saved.root) { try { workspace.setRoot(saved.root); } catch (_) { /* folder gone: stay at home */ } }
  // Pictures sent from the message box land here (outside the workspace), and are tidied after a week.
  const pastedDir = path.join(dataDir, 'pasted');
  fs.mkdirSync(pastedDir, { recursive: true, mode: 0o700 });
  try { for (const f of fs.readdirSync(pastedDir)) { const p = path.join(pastedDir, f); if (Date.now() - fs.statSync(p).mtimeMs > 7 * 864e5) fs.rmSync(p, { force: true }); } } catch (_) { /* best effort */ }
  const attach = createWorkspace({ root: pastedDir, home });
  const connections = createConnections({ file: path.join(dataDir, 'connections.json'), home });
  const keys = createKeys({ file: path.join(dataDir, 'keys.json') });
  const rpc = createRpc({
    workspace, keys, home, attach, connections, dataDir,
    settings: { get: () => saved, set: (patch) => { try { saved = { ...saved, ...patch }; fs.writeFileSync(settingsFile, JSON.stringify(saved), { mode: 0o600 }); } catch (_) { /* best effort */ } } },
    saveRoot: (r) => { try { fs.writeFileSync(settingsFile, JSON.stringify({ ...saved, root: r }), { mode: 0o600 }); saved.root = r; } catch (_) { /* best effort */ } },
  });
  const { server, close } = createServer({ manager, token, host, lan: opts.lan, listAgentsFn: () => listAgents({ env }), rpc, keys, workspace, acp: new Acp({ env, home, launches: opts.acpLaunches }) });
  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.error(`Port ${opts.port} is already in use. Nami is probably already running; open the link again, or use --port.`);
      process.exit(2);
    }
    throw err;
  });
  server.listen(opts.port, host, () => {
    console.log('Nami for Android is running.\n');
    console.log(tmux
      ? `  Sessions are kept in tmux: they keep running if this server stops${adopted ? ` (picked up ${adopted} from before)` : ''}.`
      : '  tmux not found, so sessions end when this server stops. Install it: pkg install tmux');
    console.log(`  Open on this phone:  http://127.0.0.1:${opts.port}/?t=${token}`);
    if (opts.lan) {
      for (const ip of lanAddresses()) console.log(`  On your network:     http://${ip}:${opts.port}/?t=${token}`);
      console.log('\n  --lan lets other devices on your Wi-Fi reach this. The link is the only lock,');
      console.log('  and the traffic is not encrypted. Use it on a network you trust.');
    }
    console.log(`\n  Token file: ${file}`);
    console.log(tmux ? '  Press Ctrl+C to stop the server. Your sessions keep running.' : '  Press Ctrl+C to stop. Running sessions stop with it.');
  });
  const stop = () => { close().then(() => process.exit(0)); setTimeout(() => process.exit(0), 1500).unref(); };
  process.on('SIGINT', stop);
  process.on('SIGTERM', stop);
}

if (require.main === module) main();

module.exports = { createServer, loadOrCreateToken, sameToken, hostName };
