'use strict';
// Connections: tools your agents can use (Notion, Slack, Telegram, a folder), set up once here and
// written into each agent's own settings. A trimmed phone version of src/main/connections.js: the
// same recipes, delivered to Claude Code (~/.claude.json), OpenCode and Codex.
//
// The key you type is kept in connections.json (owner-only) and written, as the agent needs it, into
// that agent's config, the same as running its own "add MCP server" command. The page only ever gets
// "connected or not", never the key back.

const fs = require('node:fs');
const path = require('node:path');

// Chromium under proot has no sandbox, GPU or big shared memory, so it starts with these.
const BROWSER_ARGS = ['--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage', '--no-zygote', '--single-process', '--disable-setuid-sandbox'];
const browserConfig = () => ({ browser: { browserName: 'chromium', isolated: true, launchOptions: { executablePath: '/usr/bin/chromium', headless: true, args: BROWSER_ARGS } } });

const CATALOG = [
  { id: 'notion', name: 'Notion', desc: 'your notes and docs', fields: [{ id: 'token', label: 'Notion secret key', placeholder: 'ntn_...' }],
    help: 'https://www.notion.so/profile/integrations',
    entry: (v) => ({ command: 'npx', args: ['-y', '@notionhq/notion-mcp-server'], env: { NOTION_TOKEN: v.token } }) },
  { id: 'slack', name: 'Slack', desc: 'your team chat', fields: [{ id: 'token', label: 'Slack bot token', placeholder: 'xoxb-...' }],
    help: 'https://api.slack.com/apps',
    entry: (v) => ({ command: 'npx', args: ['-y', 'slack-mcp-server@latest', '--transport', 'stdio'], env: { SLACK_MCP_XOXB_TOKEN: v.token } }) },
  { id: 'telegram', name: 'Telegram', desc: 'updates on your phone', fields: [{ id: 'token', label: 'Bot token (from @BotFather)', placeholder: '123456:ABC...' }],
    help: 'https://core.telegram.org/bots#how-do-i-create-a-bot',
    entry: (v) => ({ command: 'npx', args: ['-y', '@node2flow/telegram-bot-mcp'], env: { TELEGRAM_BOT_TOKEN: v.token } }) },
  // A real browser the agent can drive (Playwright's MCP server, with Alpine's Chromium). Chromium is
  // installed from the page's button (apk add chromium), not shipped inside the app.
  { id: 'browser', name: 'A browser', desc: 'let the agent open and read web pages', fields: [], experimental: true,
    entry: (v, ctx) => ({ command: 'npx', args: ['-y', '@playwright/mcp@latest', '--config', `${ctx.home}/.nami-browser.json`] }) },
  // Creative models (images, video, music). Built from source into ~/kie-mcp from a button.
  { id: 'kie', name: 'Creative models', desc: 'make images, video, music', fields: [{ id: 'token', label: 'KIE key', placeholder: 'kie_...' }], help: 'https://kie.ai',
    entry: (v, ctx) => ({ command: 'node', args: [`${ctx.home}/kie-mcp/dist/index.js`], env: { KIE_API_KEY: v.token } }) },
  { id: 'folder', name: 'A folder', desc: 'read and edit one chosen folder', fields: [{ id: 'folder', label: 'Folder path', placeholder: '/root/projects', secret: false }],
    entry: (v) => ({ command: 'npx', args: ['-y', '@modelcontextprotocol/server-filesystem', v.folder] }) },
];
const BY_ID = new Map(CATALOG.map((c) => [c.id, c]));

const ID_RE = /^[a-z0-9][a-z0-9_-]{0,30}$/;
const ENV_NAME = /^[A-Za-z_][A-Za-z0-9_]{0,63}$/;
const BLOCKED_ENV = new Set(['PATH', 'HOME', 'LD_PRELOAD', 'LD_LIBRARY_PATH', 'SHELL', 'TMUX', 'TERM', 'NODE_OPTIONS']);
const PROGRAM = /^[\w@%+=:,./-]{1,200}$/;                // a program name or path: no spaces, quotes or shell characters

// your own server: a program, its arguments, and variables
function cleanCustom(c) {
  const bad = (m) => { throw new ConnectionError(m); };
  if (!c || typeof c !== 'object') bad('Fill in the server.');
  if (!PROGRAM.test(String(c.command || ''))) bad('The program must be one word, like npx or /root/tool/run.');
  const args = Array.isArray(c.args) ? c.args.map(String) : bad('Arguments are missing.');
  if (args.length > 40 || args.some((a) => a.length > 500 || /[\0\r\n]/.test(a))) bad('Those arguments are not valid.');
  const env = {};
  for (const [k, v] of Object.entries(c.env && typeof c.env === 'object' ? c.env : {})) {
    if (!ENV_NAME.test(k) || BLOCKED_ENV.has(k)) bad(`${k} cannot be used as a variable name.`);
    if (typeof v !== 'string' || /[\0\r\n]/.test(v) || v.length > 2000) bad(`The value of ${k} is not valid.`);
    env[k] = v;
  }
  return { command: String(c.command), args, ...(Object.keys(env).length ? { env } : {}) };
}

const BEGIN = '# >>> nami connections (managed; edit in Nami)';
const END = '# <<< nami connections';
const tomlStr = (s) => JSON.stringify(String(s));          // JSON strings are valid TOML basic strings

class ConnectionError extends Error { constructor(msg, code) { super(msg); this.code = code || 'bad'; } }

function createConnections({ file, home }) {
  const targets = {
    claude: path.join(home, '.claude.json'),
    opencode: path.join(home, '.config', 'opencode', 'opencode.json'),
    codex: path.join(home, '.codex', 'config.toml'),
  };

  const readMasters = () => { try { const d = JSON.parse(fs.readFileSync(file, 'utf8')); return d && typeof d === 'object' ? d : {}; } catch (_) { return {}; } };
  const writeAtomic = (f, text, mode) => {
    fs.mkdirSync(path.dirname(f), { recursive: true });
    const tmp = `${f}.nami-${process.pid}.tmp`;
    fs.writeFileSync(tmp, text, { mode });
    fs.renameSync(tmp, f);
  };
  const writeMasters = (m) => writeAtomic(file, JSON.stringify(m, null, 2) + '\n', 0o600);

  // Reads a JSON settings file: null if it is not there, throws if it is there but not JSON
  // (we never overwrite a file we could not read).
  function readJson(f) {
    let text;
    try { text = fs.readFileSync(f, 'utf8'); } catch (e) { if (e.code === 'ENOENT') return null; throw e; }
    if (!text.trim()) return null;
    try { const d = JSON.parse(text); if (d && typeof d === 'object' && !Array.isArray(d)) return d; } catch (_) { /* below */ }
    throw new ConnectionError(path.basename(f) + ' could not be read, so it was left alone.');
  }
  const mode = (f) => { try { return fs.statSync(f).mode & 0o777; } catch (_) { return 0o600; } };

  function deliver(masters, gone = []) {
    const out = {};
    const custom = masters._custom && typeof masters._custom === 'object' ? masters._custom : {};
    const ids = [...Object.keys(masters).filter((id) => BY_ID.has(id)), ...Object.keys(custom)];
    const entries = Object.fromEntries(ids.map((id) => [id, custom[id] || BY_ID.get(id).entry(masters[id], { home })]));
    const managedAll = [...CATALOG.map((c) => c.id), ...Object.keys(custom), ...gone];

    try { // Claude Code
      const doc = readJson(targets.claude) || {};
      doc.mcpServers = doc.mcpServers && typeof doc.mcpServers === 'object' ? doc.mcpServers : {};
      for (const id of managedAll) { if (entries[id]) doc.mcpServers[id] = { type: 'stdio', ...entries[id] }; else delete doc.mcpServers[id]; }
      writeAtomic(targets.claude, JSON.stringify(doc, null, 2) + '\n', mode(targets.claude));
      out.claude = true;
    } catch (e) { out.claude = e.message; }

    try { // OpenCode
      const doc = readJson(targets.opencode) || { $schema: 'https://opencode.ai/config.json' };
      doc.mcp = doc.mcp && typeof doc.mcp === 'object' ? doc.mcp : {};
      for (const id of managedAll) {
        const e = entries[id];
        if (e) doc.mcp[id] = { type: 'local', command: [e.command, ...(e.args || [])], ...(e.env ? { environment: e.env } : {}), enabled: true };
        else delete doc.mcp[id];
      }
      writeAtomic(targets.opencode, JSON.stringify(doc, null, 2) + '\n', mode(targets.opencode));
      out.opencode = true;
    } catch (e) { out.opencode = e.message; }

    try { // Codex: one managed block in config.toml, the rest of the file untouched
      let text = '';
      try { text = fs.readFileSync(targets.codex, 'utf8'); } catch (e) { if (e.code !== 'ENOENT') throw e; }
      const a = text.indexOf(BEGIN), b = text.indexOf(END);
      if ((a >= 0) !== (b >= 0) || b < a) throw new ConnectionError('config.toml has a broken Nami block, so it was left alone.');
      const rest = a >= 0 ? [text.slice(0, a).trim(), text.slice(b + END.length).trim()].filter(Boolean).join('\n\n') : text.trim();
      let block = '';
      if (ids.length) {
        block = [BEGIN];
        for (const id of ids) {
          const e = entries[id];
          block.push(`[mcp_servers.${id}]`, `command = ${tomlStr(e.command)}`, `args = [${(e.args || []).map(tomlStr).join(', ')}]`);
          if (e.env) block.push(`env = { ${Object.entries(e.env).map(([k, v]) => `${k} = ${tomlStr(v)}`).join(', ')} }`);
        }
        block.push(END); block = block.join('\n');
      }
      writeAtomic(targets.codex, [rest, block].filter(Boolean).join('\n\n') + '\n', 0o600);
      out.codex = true;
    } catch (e) { out.codex = e.message; }
    return out;
  }

  const status = () => {
    const m = readMasters();
    return CATALOG.map((c) => ({ id: c.id, name: c.name, desc: c.desc, help: c.help || null, experimental: !!c.experimental, connected: Boolean(m[c.id]),
      fields: c.fields.map((f) => ({ id: f.id, label: f.label, placeholder: f.placeholder, secret: f.secret !== false,
        // a folder is not a secret, so the page may show it
        value: f.secret === false && m[c.id] ? m[c.id][f.id] : undefined })) }));
  };

  const customList = () => {
    const c = readMasters()._custom || {};
    return Object.keys(c).sort().map((id) => ({ id, command: c[id].command, args: c[id].args, envNames: Object.keys(c[id].env || {}) }));
  };

  // A .mcpb bundle (a zip with a manifest.json): unpacked under the data folder and registered like your own server.
  function importBundle(file, dataDir) {
    const { spawnSync } = require('node:child_process');
    let stem = path.basename(file).replace(/\.mcpb$/i, '').toLowerCase().replace(/[^a-z0-9_-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 30);
    if (!ID_RE.test(stem) || BY_ID.has(stem)) stem = 'bundle-' + (stem || 'x').slice(0, 20);
    const dir = path.join(dataDir, 'bundles', stem);
    // unzip refuses to write outside dir (it strips ../ and absolute paths); a link entry could still point out, so none are kept
    fs.rmSync(dir, { recursive: true, force: true });
    fs.mkdirSync(dir, { recursive: true });
    const r = spawnSync('unzip', ['-q', '-o', file, '-d', dir], { encoding: 'utf8', timeout: 60000 });
    if (r.error || r.status > 1) throw new ConnectionError('That file could not be unpacked' + (r.error ? ' (unzip is not installed).' : '.'));
    const walk = (d) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isSymbolicLink()) fs.rmSync(p); else if (e.isDirectory()) walk(p); } };
    walk(dir);
    let manifest;
    try { manifest = JSON.parse(fs.readFileSync(path.join(dir, 'manifest.json'), 'utf8')); } catch (_) { throw new ConnectionError('This is not an MCP bundle (no manifest.json).'); }
    const mc = manifest && manifest.server && manifest.server.mcp_config;
    if (!mc || typeof mc.command !== 'string') throw new ConnectionError('This bundle does not say how to start its server.');
    const fill = (x) => String(x).replace(/\$\{__dirname\}/g, dir);
    const args = (Array.isArray(mc.args) ? mc.args : []).map(fill);
    const env = Object.fromEntries(Object.entries(mc.env || {}).map(([k, v]) => [k, fill(v)]));
    if ([mc.command, ...args, ...Object.values(env)].some((x) => /\$\{/.test(String(x)))) throw new ConnectionError('This bundle asks for settings (user_config) that Nami cannot fill in yet.');
    const id = stem;
    return { id, entry: { command: fill(mc.command), args, env } };
  }

  return {
    list: status,
    customList,
    connectCustom(id, value) {
      if (!ID_RE.test(String(id || '')) || BY_ID.has(id)) throw new ConnectionError('Give it a short name: lowercase letters, numbers, - or _.');
      const entry = cleanCustom(value);
      const m = readMasters(); m._custom = { ...(m._custom || {}), [id]: entry }; writeMasters(m);
      return { delivered: deliver(m) };
    },
    importBundle(file, dataDir) {
      const { id, entry } = importBundle(file, dataDir);
      const m = readMasters(); m._custom = { ...(m._custom || {}), [id]: entry }; writeMasters(m);
      return { id, delivered: deliver(m) };
    },
    connect(id, values) {
      const c = BY_ID.get(id);
      if (!c) throw new ConnectionError('Unknown service.');
      const v = {};
      for (const f of c.fields) {
        const x = values && typeof values[f.id] === 'string' ? values[f.id].trim() : '';
        if (!x || /[\r\n\0]/.test(x) || x.length > 2000) throw new ConnectionError(`Enter ${f.label.toLowerCase()}.`);
        v[f.id] = x;
      }
      const m = readMasters(); m[id] = v; writeMasters(m);
      if (id === 'browser') writeAtomic(path.join(home, '.nami-browser.json'), JSON.stringify(browserConfig(), null, 2) + '\n', 0o600);
      return { delivered: deliver(m) };
    },
    disconnect(id) {
      const m = readMasters();
      if (m._custom && m._custom[id]) { delete m._custom[id]; writeMasters(m); return { delivered: deliver(m, [id]) }; }
      if (!BY_ID.has(id)) throw new ConnectionError('Unknown service.');
      delete m[id]; writeMasters(m);
      return { delivered: deliver(m) };
    },
    // The command a service runs, for the "does it answer?" check (null if it is not connected)
    entryFor(id) {
      const m = readMasters();
      if (m._custom && m._custom[id]) return m._custom[id];
      if (!BY_ID.has(id) || !m[id]) return null;
      return BY_ID.get(id).entry(m[id], { home });
    },
    CATALOG,
  };
}

module.exports = { BROWSER_ARGS, createConnections, ConnectionError, BEGIN, END };
