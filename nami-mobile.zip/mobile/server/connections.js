'use strict';
// Connections: tools your agents can use (Notion, Slack, Telegram, a folder), set up once here and
// written into each agent's own settings. A trimmed phone version of src/main/connections.js: the
// same recipes, delivered to Claude Code (~/.claude.json), OpenCode and Codex.
//
// The key you type is kept in connections.json (owner-only) and written, as the agent needs it, into
// that agent's config, the same as running its own "add MCP server" command. The page only ever gets
// "connected or not", never the key back.

const fs = require('node:fs');
const path = require('node:path');

const CATALOG = [
  { id: 'notion', name: 'Notion', desc: 'your notes and docs', fields: [{ id: 'token', label: 'Notion secret key', placeholder: 'ntn_...' }],
    help: 'https://www.notion.so/profile/integrations',
    entry: (v) => ({ command: 'npx', args: ['-y', '@notionhq/notion-mcp-server'], env: { NOTION_TOKEN: v.token } }) },
  { id: 'slack', name: 'Slack', desc: 'your team chat', fields: [{ id: 'token', label: 'Slack bot token', placeholder: 'xoxb-...' }],
    help: 'https://api.slack.com/apps',
    entry: (v) => ({ command: 'npx', args: ['-y', 'slack-mcp-server@latest', '--transport', 'stdio'], env: { SLACK_MCP_XOXB_TOKEN: v.token } }) },
  { id: 'telegram', name: 'Telegram', desc: 'updates on your phone', fields: [{ id: 'token', label: 'Bot token (from @BotFather)', placeholder: '123456:ABC...' }],
    help: 'https://core.telegram.org/bots#how-do-i-create-a-bot',
    entry: (v) => ({ command: 'npx', args: ['-y', '@node2flow/telegram-bot-mcp'], env: { TELEGRAM_BOT_TOKEN: v.token } }) },
  // A real browser the agent can drive (Playwright's MCP server, with Alpine's Chromium). Chromium is
  // installed from the page's button (apk add chromium), not shipped inside the app.
  { id: 'browser', name: 'A browser', desc: 'let the agent open and read web pages', fields: [], experimental: true,
    entry: () => ({ command: 'npx', args: ['-y', '@playwright/mcp@latest', '--headless', '--no-sandbox', '--isolated', '--executable-path', '/usr/bin/chromium'] }) },
  { id: 'folder', name: 'A folder', desc: 'read and edit one chosen folder', fields: [{ id: 'folder', label: 'Folder path', placeholder: '/root/projects', secret: false }],
    entry: (v) => ({ command: 'npx', args: ['-y', '@modelcontextprotocol/server-filesystem', v.folder] }) },
];
const BY_ID = new Map(CATALOG.map((c) => [c.id, c]));

const BEGIN = '# >>> nami connections (managed; edit in Nami)';
const END = '# <<< nami connections';
const tomlStr = (s) => JSON.stringify(String(s));          // JSON strings are valid TOML basic strings

class ConnectionError extends Error { constructor(msg, code) { super(msg); this.code = code || 'bad'; } }

function createConnections({ file, home }) {
  const targets = {
    claude: path.join(home, '.claude.json'),
    opencode: path.join(home, '.config', 'opencode', 'opencode.json'),
    codex: path.join(home, '.codex', 'config.toml'),
  };

  const readMasters = () => { try { const d = JSON.parse(fs.readFileSync(file, 'utf8')); return d && typeof d === 'object' ? d : {}; } catch (_) { return {}; } };
  const writeAtomic = (f, text, mode) => {
    fs.mkdirSync(path.dirname(f), { recursive: true });
    const tmp = `${f}.nami-${process.pid}.tmp`;
    fs.writeFileSync(tmp, text, { mode });
    fs.renameSync(tmp, f);
  };
  const writeMasters = (m) => writeAtomic(file, JSON.stringify(m, null, 2) + '\n', 0o600);

  // Reads a JSON settings file: null if it is not there, throws if it is there but not JSON
  // (we never overwrite a file we could not read).
  function readJson(f) {
    let text;
    try { text = fs.readFileSync(f, 'utf8'); } catch (e) { if (e.code === 'ENOENT') return null; throw e; }
    if (!text.trim()) return null;
    try { const d = JSON.parse(text); if (d && typeof d === 'object' && !Array.isArray(d)) return d; } catch (_) { /* below */ }
    throw new ConnectionError(path.basename(f) + ' could not be read, so it was left alone.');
  }
  const mode = (f) => { try { return fs.statSync(f).mode & 0o777; } catch (_) { return 0o600; } };

  function deliver(masters) {
    const out = {};
    const ids = Object.keys(masters).filter((id) => BY_ID.has(id));
    const entries = Object.fromEntries(ids.map((id) => [id, BY_ID.get(id).entry(masters[id])]));
    const managedAll = CATALOG.map((c) => c.id);

    try { // Claude Code
      const doc = readJson(targets.claude) || {};
      doc.mcpServers = doc.mcpServers && typeof doc.mcpServers === 'object' ? doc.mcpServers : {};
      for (const id of managedAll) { if (entries[id]) doc.mcpServers[id] = { type: 'stdio', ...entries[id] }; else delete doc.mcpServers[id]; }
      writeAtomic(targets.claude, JSON.stringify(doc, null, 2) + '\n', mode(targets.claude));
      out.claude = true;
    } catch (e) { out.claude = e.message; }

    try { // OpenCode
      const doc = readJson(targets.opencode) || { $schema: 'https://opencode.ai/config.json' };
      doc.mcp = doc.mcp && typeof doc.mcp === 'object' ? doc.mcp : {};
      for (const id of managedAll) {
        const e = entries[id];
        if (e) doc.mcp[id] = { type: 'local', command: [e.command, ...(e.args || [])], ...(e.env ? { environment: e.env } : {}), enabled: true };
        else delete doc.mcp[id];
      }
      writeAtomic(targets.opencode, JSON.stringify(doc, null, 2) + '\n', mode(targets.opencode));
      out.opencode = true;
    } catch (e) { out.opencode = e.message; }

    try { // Codex: one managed block in config.toml, the rest of the file untouched
      let text = '';
      try { text = fs.readFileSync(targets.codex, 'utf8'); } catch (e) { if (e.code !== 'ENOENT') throw e; }
      const a = text.indexOf(BEGIN), b = text.indexOf(END);
      if ((a >= 0) !== (b >= 0) || b < a) throw new ConnectionError('config.toml has a broken Nami block, so it was left alone.');
      const rest = a >= 0 ? [text.slice(0, a).trim(), text.slice(b + END.length).trim()].filter(Boolean).join('\n\n') : text.trim();
      let block = '';
      if (ids.length) {
        block = [BEGIN];
        for (const id of ids) {
          const e = entries[id];
          block.push(`[mcp_servers.${id}]`, `command = ${tomlStr(e.command)}`, `args = [${(e.args || []).map(tomlStr).join(', ')}]`);
          if (e.env) block.push(`env = { ${Object.entries(e.env).map(([k, v]) => `${k} = ${tomlStr(v)}`).join(', ')} }`);
        }
        block.push(END); block = block.join('\n');
      }
      writeAtomic(targets.codex, [rest, block].filter(Boolean).join('\n\n') + '\n', 0o600);
      out.codex = true;
    } catch (e) { out.codex = e.message; }
    return out;
  }

  const status = () => {
    const m = readMasters();
    return CATALOG.map((c) => ({ id: c.id, name: c.name, desc: c.desc, help: c.help || null, experimental: !!c.experimental, connected: Boolean(m[c.id]),
      fields: c.fields.map((f) => ({ id: f.id, label: f.label, placeholder: f.placeholder, secret: f.secret !== false,
        // a folder is not a secret, so the page may show it
        value: f.secret === false && m[c.id] ? m[c.id][f.id] : undefined })) }));
  };

  return {
    list: status,
    connect(id, values) {
      const c = BY_ID.get(id);
      if (!c) throw new ConnectionError('Unknown service.');
      const v = {};
      for (const f of c.fields) {
        const x = values && typeof values[f.id] === 'string' ? values[f.id].trim() : '';
        if (!x || /[\r\n\0]/.test(x) || x.length > 2000) throw new ConnectionError(`Enter ${f.label.toLowerCase()}.`);
        v[f.id] = x;
      }
      const m = readMasters(); m[id] = v; writeMasters(m);
      return { delivered: deliver(m) };
    },
    disconnect(id) {
      if (!BY_ID.has(id)) throw new ConnectionError('Unknown service.');
      const m = readMasters(); delete m[id]; writeMasters(m);
      return { delivered: deliver(m) };
    },
    CATALOG,
  };
}

module.exports = { createConnections, ConnectionError, BEGIN, END };
