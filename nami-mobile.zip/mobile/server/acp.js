'use strict';
// Chat with an agent through ACP (the Agent Client Protocol): the agent runs as a program that
// speaks newline-delimited JSON-RPC on stdin/stdout, and the page is the client. This file only
// starts the program and passes lines between it and the page; the protocol itself lives in the
// page (web/ui-chat.js). Commands come from the table below, never from the page.

const { spawn } = require('node:child_process');
const crypto = require('node:crypto');
const fs = require('node:fs');
const { EventEmitter } = require('node:events');

const MAX_CHATS = 3;
const MAX_LINE = 4 * 1024 * 1024;

const LAUNCHES = {
  claude: { command: 'npx', args: ['-y', '@agentclientprotocol/claude-agent-acp'] },
  codex: { command: 'npx', args: ['-y', '@zed-industries/codex-acp'] },
  opencode: { command: 'opencode', args: ['acp'] },
};

class Acp extends EventEmitter {
  constructor({ env, home, launches = LAUNCHES }) {
    super();
    this.env = env; this.home = home; this.launches = launches;
    this.procs = new Map();
  }

  static supports(agentId) { return Object.prototype.hasOwnProperty.call(LAUNCHES, agentId); }

  // -> id of the new chat
  start({ agentId, cwd, env: extraEnv }) {
    if (!Object.prototype.hasOwnProperty.call(this.launches, agentId)) throw new Error('This agent has no chat mode yet.');
    if (this.procs.size >= MAX_CHATS) throw new Error(`At most ${MAX_CHATS} chats at once. Close one first.`);
    let dir = this.home;
    if (typeof cwd === 'string' && cwd.trim()) {
      const want = cwd.trim().replace(/^~(?=$|\/)/, this.home);
      let ok = false; try { ok = fs.statSync(want).isDirectory(); } catch (_) { /* below */ }
      if (!ok) throw new Error('That folder does not exist.');
      dir = want;
    }
    const l = this.launches[agentId];
    const id = crypto.randomBytes(6).toString('hex');
    const proc = spawn(l.command, l.args, { cwd: dir, env: { ...this.env, ...(extraEnv || {}) }, stdio: ['pipe', 'pipe', 'pipe'] });
    const rec = { proc, buf: '', err: '' };
    this.procs.set(id, rec);
    proc.stdout.setEncoding('utf8');
    proc.stdout.on('data', (d) => {
      rec.buf += d;
      let i;
      while ((i = rec.buf.indexOf('\n')) >= 0) {
        const line = rec.buf.slice(0, i).trim(); rec.buf = rec.buf.slice(i + 1);
        if (line) this.emit('line', id, line);
      }
      if (rec.buf.length > MAX_LINE) { rec.buf = ''; this.emit('exit', id, null, 'The agent sent a message that was too large.'); this.stop(id); }
    });
    proc.stderr.setEncoding('utf8');
    proc.stderr.on('data', (d) => { rec.err = (rec.err + d).slice(-800); });
    proc.on('error', (e) => { this.procs.delete(id); this.emit('exit', id, null, e.code === 'ENOENT' ? 'Could not start it. Is it installed?' : e.message); });
    proc.on('exit', (code) => { if (this.procs.delete(id)) this.emit('exit', id, code, rec.err.trim().split('\n').slice(-3).join('\n')); });
    return id;
  }

  write(id, line) {
    const rec = this.procs.get(id);
    if (!rec || typeof line !== 'string' || line.length > MAX_LINE || /[\r\n]/.test(line)) return false;
    try { rec.proc.stdin.write(line + '\n'); return true; } catch (_) { return false; }
  }

  stop(id) {
    const rec = this.procs.get(id);
    if (!rec) return;
    this.procs.delete(id);
    try { rec.proc.kill('SIGTERM'); } catch (_) { /* gone */ }
    setTimeout(() => { try { rec.proc.kill('SIGKILL'); } catch (_) { /* gone */ } }, 3000).unref();
  }

  stopAll() { for (const id of [...this.procs.keys()]) this.stop(id); }
}

module.exports = { Acp, LAUNCHES };
