# Nami for Android

Nami's desk on your phone, with no PC and **no Termux**. One app: install it, open it, your agents are there.

```
Nami app (APK)
 ├─ Linux inside the app: Debian (apt, glibc) + Node + tmux, run by proot (nothing to install)
 │    └─ Nami server (server/) ─▶ your agents, kept in tmux
 └─ the phone UI (web/), shown in the app
```

## What you get

- **Open the app and you are in.** The first time, it unpacks its own Linux (a minute or two, with a progress bar). After that it starts in seconds. No pairing, no connecting.
- **Everything is kept.** Each session lives in tmux inside the app's Linux, which stays alive in the background (you will see a "Nami is running" notification; that is what keeps Android from stopping it). Close the app and come back: the session, its shell state and its history are there. Your files and installed agents live in the Linux's `/root` and survive app updates. "Stop" ends one session; "Stop Nami" in the notification ends everything.
- A real terminal per session (the desktop app's xterm.js) with a key bar: Esc, Tab, Ctrl, arrows, ^C, ^D, scroll, Paste. Scroll with your thumb; **Live** returns to the bottom.
- A message box built for phone keyboards. **Send** types your message into the agent and presses Enter.
- New session: a plain terminal, or Claude Code, Codex, OpenCode, Kimi, Hermes. One that is not installed shows its install line, typed at a prompt for you to run (for example `npm install -g @anthropic-ai/claude-code`).
- The six desks (Paper, Operator, Glass, Graphite, Soft, Dusk) and text size, with the desktop app's logo and brand icons for each agent.
- **Workspace**: browse a folder, open, edit and save text files (a changed file is noticed, not overwritten), read Markdown as a page, view images, make folders and files, rename, delete, import files from the phone, download to `Download/Nami`. It cannot leave the folder you choose.
- **Library**: your Claude Code and Codex agents and skills, found in the workspace and your home folder. Open one, edit it, run it in a session, or create a new one ("Build it with my agent" starts a session that writes it for you).
- **Providers**: add your own API key and base URL (any OpenAI/Anthropic-compatible endpoint). Pick it when you start a session and Nami sets the variables for that agent. Keys stay in the Linux (private file), the page only sees them masked.
- **Also**: duplicate and move files, recent and pinned workspace folders, "Continue last conversation" for Claude Code, Codex and OpenCode, the agent's own title shown on its session card, the file list refreshing by itself when an agent writes a file, and a 📎 button (or pasting) to send a picture to the agent as a file path.
- **Connections** (Settings): Notion, Slack, Telegram, or a folder, written into Claude Code, OpenCode and Codex for you. Keys stay on the phone, owner-only, and the page never gets one back.
- **Microphone** button in the message box (the phone's own speech recogniser; asks for the microphone permission the first time).

- **Phone storage**: the phone's files (Downloads, Pictures, Documents) appear inside the Linux as `/sdcard`, and the Workspace folder picker has a "Phone storage" shortcut. Allow the files permission when the app asks; after allowing it, use "Stop Nami" in the notification and open the app again.

- **Usage** (Settings → Tools): tokens Claude Code and Codex used on this phone over the last 7 days, per day, counted from the records they keep. This is use, not what is left of your plan (Claude Code shows that with `/usage`).
- **Preview a page** (Settings → Tools): shows a site your agent is serving on the phone (for example `3000` or `localhost:5173`) inside the app, with reload and "open in browser". It cannot show Nami itself.

- **Agents** (Settings): remove an installed agent (runs its uninstall line in a terminal). **Gmail** and **Google Drive** connections are guided: Nami starts Claude Code and it walks you through Google's sign-in setup. A short welcome appears the first time, when nothing has been started.

- **Finished notification**: when an agent's session ends while you are in another app or screen, Nami notifies you (tap to open).

- **Split**: the ◫ button in a terminal shows a second session below the first. The key bar and message box type into whichever pane you touched last.
- **Chat mode** (Claude Code, Codex, OpenCode): choose "Chat" instead of "Terminal" when you start. A phone-style conversation over ACP: your messages, the agent's reply as formatted text, what it is doing, a plan, and Allow / No buttons when it asks permission. A chat lasts while the app is open (terminal sessions are the ones kept in the background). It uses `npx` to fetch the ACP adapter the first time (needs network).
- **A browser for your agent** (Settings → Connections → A browser): installs Chromium in the Linux (`apt install chromium`, about 300 MB, from a button), checks that it starts with phone-safe flags, and connects Playwright's MCP server so Claude Code, Codex and OpenCode can open and read web pages. Experimental: Chromium under proot may not start on every phone.

Not here yet: update check (your build comes from your own GitHub, so there is nothing to compare with).

## Get the app (no PC)

GitHub builds the APK for you:

1. Put this repository's `mobile/` folder at the top level of your own GitHub repository, with `mobile/android/ci/nami-android.yml` copied to `.github/workflows/nami-android.yml`.
2. On your phone: GitHub in the browser → **Actions** → **Nami Android APK** → **Run workflow**. It takes 15 to 40 minutes (the Linux is built for arm64 under emulation).
3. Open the finished run, download the artifact **nami-android-apk**, unzip it, install `app-debug.apk` (allow installs from your browser or files app when asked).

Needs an arm64 phone (nearly all of them) and about 400 MB free. The APK is roughly 60 to 100 MB.

## Things to know

- **Android 12 and newer can kill background Linux programs** ("phantom process killer"). If sessions disappear while the app is in the background, either turn on Developer options → "Disable child process restrictions" (Android 14+), or on Android 12/13 it needs an `adb` setting that cannot be done from the phone alone. Also set the app's battery use to **Unrestricted**. Without this, Android may stop the Linux after a while; the app starts it again when opened, but running sessions are lost.
- It is slower than a native app: proot translates system calls. Fine for agents that mostly wait on the network; heavy builds will be slow.
- The Linux is real Debian 12 (arm64, glibc): `apt install` works. No root-only features (systemd, Docker, kernel modules) because it runs under proot.
- If something fails, the app shows the last lines of its logs with **Copy log**. Send that text and the problem can be found. **Reset** deletes the Linux and sets it up again (this erases agents and files inside it).

## What was tested, and what was not

Tested here, on Linux: the server and its locks; sessions kept in tmux; stopping the server and starting it again (the page reconnects and the same shell comes back, variables included); exit codes; history; scrolling by buttons and touch drag in a real browser at phone size; the tar reader that unpacks the Linux (real GNU tar archives: long names, pax, symlinks, hard links, unicode, truncated archives, path-escape attempts); the proot command line; the script that gathers proot from the Termux package repository (against a pretend repository). 87 automated tests, plus a browser run of the new screens at phone size (Sessions, Workspace, Markdown, Library, agent picker, Settings).

**Not tested: anything on a real phone.** The newest Kotlin additions (download to Downloads, the import file picker) have never been compiled or run on a phone, and the Kotlin app (`MainActivity.kt`, `NamiService.kt`) was only ever compiled by your GitHub build; this machine has no Android SDK, because the machine this was written on has no Android SDK. The arm64 Linux image has not been built, and proot has never been run with it. The most likely places for a first failure: the GitHub build (a small Kotlin mistake), proot starting on your Android version, tmux inside proot. Each one shows up as readable text (the GitHub log, or the app's error screen). Send it back and it gets fixed.

## Safety

A Nami session is a shell on your phone, so:

- The server listens on `127.0.0.1` only. Another app or website cannot reach it without the token, and requests whose `Host` or `Origin` is not this phone are refused, so a web page you open cannot talk to it.
- The token is created on first run inside the app's Linux (`/root/.nami-mobile/token`, owner-only). The app reads it itself, so there is nothing to type.
- Six wrong tokens from one address lock it out for a minute.
- The app talks to `http://127.0.0.1` only (plain http, allowed for that address and nothing else). Links to other sites open in your browser, never inside the app. The only thing the page can ask of the app is to read the clipboard when you tap Paste.
- `npm start -- --lan` lets other devices on your Wi-Fi in. That traffic is **not encrypted**. Use it only on a network you trust, or not at all.
- Agent commands come from a fixed list in `server/agents.js`; a browser cannot make the server run arbitrary programs through the New session sheet. A terminal session is, by design, a shell.
- The app needs no special permissions beyond the network (for this phone only) and a background-service notification. Install it only from a build you made yourself.
- tmux sessions keep running after the server stops. To end them all: use **Stop Nami** in the notification.

## Develop

```bash
npm install
npm test                    # 59 tests: server, sockets, tmux, keys, themes, page, tar reader, proot fetch
npm start -- --port 8000    # another port
npm start -- --no-tmux      # sessions end when the server stops
npm start -- --no-pty       # force the `script` fallback instead of node-pty
node tools/make-icons.mjs   # redraw the web app icons
```

`node-pty` is used if installed; otherwise the server uses `script`. With `script` a running terminal cannot be resized, so for tmux sessions the server re-attaches at the new size (a quick redraw when the phone rotates or the keyboard opens).

## License

Apache-2.0, like Nami. The terminal files in `vendor/` are xterm.js (MIT) and Courier Prime (SIL OFL, see `vendor/fonts/OFL.txt`), copied from the desktop app.
Built from Nami by Dainami AI. Do not present a build of this as the official Nami app.

## 0.10.0

- Agents: Grok and Antigravity in the list; Kimi, Grok, Antigravity, Hermes and Codex can continue their last conversation.
- Library: adopt / import / deliver / duplicate from the card menu.
- Connections: your own MCP server, .mcpb bundles, Kie.
- Chat: attach a picture, slash-command suggestions, rename, continue in a terminal, past chats (kept on the phone).
- Terminal: web addresses in the output are tappable (local ones open in Preview); the message you were typing is kept per session.
- Setup check (Settings → Tools): shows which of node, npm, git, curl, tmux, unzip are present, free space, and what blocks each agent install.
- Preview: bookmarks and recent pages. Terminal ⋯ menu: copy selection / all output, paste, search the output, jump to bottom.
- Not on a phone: multi-window, open-with, reveal in folder, browser profiles/import/annotation, update check.

## 0.10.1

- Depth for every desk: frosted slabs and a lit aurora on Glass/Graphite, extruded clay on Soft/Dusk, stacked sheets with grain on Paper, lit edges on Operator.

## 0.11.0

- Settings → Agents shows who is signed in (read from each CLI's own files, never a key), with Sign in / Sign out / Remove. Grok: sign out to use your API key.
- A first message now reaches Grok, Antigravity, Kimi and Hermes too (Kimi and Hermes get it typed in once their prompt is empty).
- Library: Delete (moves to a trash folder) and Improve with my agent.
- Session end notes say who ended it ("terminal closed", "stopped") instead of a bare exit code.
- Usage: your Claude plan limit windows, if you turn the status-line feed on (never replaces a status line you already have).
- Connections: "Test my connections" starts each server once and counts its tools.

## 0.12.0

- Files: code files get a coloured view; HTML files get a Page view (no scripts run); Markdown gets a formatting bar; A− / A+ sets the reading size.
- Quick start checklist (Settings → Tools) that ticks itself off.
- Removing an agent says which sign-in and settings stay.

## 0.13.0

- Voice: use your own OpenAI-compatible speech key instead of Android's recogniser (Settings → Voice). The key is stored owner-only and never shown again.
- Markdown: Read and Edit side by side ("Both"), a table button.
- Preview: back, forward, "show this page to an agent".
- A browser for your agent: a "check that it starts" step and a Playwright config made for Chromium under proot.

## 0.13.1

- Chat and the message box can attach any file (PDF, music, video, zip, documents…), several at once, up to 200 MB each. Pictures still go inside the message when the agent takes them; everything else is saved on the phone and its path goes with your message. Attached files are tidied away after a week.

## 0.13.2

- Buttons in the bars (back, menu, split, Stop, mic, attach, preview tools) are real objects with depth on every desk, and use drawn icons instead of emoji so they match the theme.

## 0.14.0 — lighter on the phone

- Effects (Settings → Look): Full, Balanced (the default inside the app: every shadow, gradient and lit edge stays, only live blur and endless animation go) or Light (flatter still, for slow phones).
- Terminal output is joined and sent at most about 60 times a second instead of in every tiny piece.
- While the app is not on screen, terminal output stops being sent; the screen is fetched again on return. The WebView stops painting too.
- Slower background checks (sessions every 3 s, the Files tab every 5 s); the server's own memory is capped at 160 MB (agents are not limited).

## 0.14.1

- The premium look is back by default: Balanced keeps all the depth and only drops the live blur, which looks nearly the same and is much easier on the phone.

## 0.15.0 — the full look, with real motion

- Full effects are the default again. Screens slide in and settle back, sheets rise on a spring and sink away, tabs fade up, messages and toasts pop in, buttons spring when pressed. Only transform and opacity move, so it stays smooth.
- Live blur stays on the bars and sheets; the many cards in a list use a solid frosted tint (same look over a soft background, much smoother scrolling).

## 0.16.0: real Debian Linux

The Linux inside the app is now Debian 12 (arm64, glibc) instead of Alpine. `apt install`, `apt update`, `python3`, `pip`, `man`, `vim`, `sudo`, `wget`, `zip`/`unzip` and the usual coreutils behave as on a normal Debian machine. You are root, the prompt is `root@nami`. Still not possible under proot: systemd, Docker, kernel modules. The first start unpacks a larger image, so it takes longer once.

### 0.16.1
The Linux no longer sets `NPM_CONFIG_PREFIX`, so `nvm` works (global npm installs go to /usr/local, you are root). With the Debian image `nvm install` gets the normal arm64 Node builds; the Alpine image could only fetch x86 musl builds, which cannot run on a phone.

## 0.17.0: links from the terminal

Programs in the Linux that open a browser (`xdg-open`, `open`, `$BROWSER`: `claude login`, `gh auth login`, `npm login` and similar) now hand the link to the app. Web links open in the phone browser, `localhost` links open in Nami's preview. If the app is not open, the link is printed so you can open it yourself. Tapping a link in the terminal still works as before.

### 0.17.1: your installs survive updates

An app update unpacks a fresh Linux and keeps only `/root`. Nami now saves the list of what you added (`npm install -g` packages and `apt install` packages) in `/root/.nami-mobile/globals-*.txt` every two minutes and reinstalls them on the first start after an update (needs internet; progress is in `/root/.nami-mobile/restore.log`). Versions are not pinned: you get the latest. Anything installed in the last two minutes before an update can be missed.

## 0.18.0: storage, backup, and a fix

Settings → Tools → **Storage and backup**: shows what the Linux takes (your files, installed programs, backups, caches) and the free space on the phone, clears the npm/apt caches, and packs `/root` (without caches) into `/root/Backups/nami-backup-DATE.tar.gz` with a Download-to-phone button. The last three backups are kept.

Fix: answers that take a while (browser check in Connections, cloud voice, backup) were computed but never reached the page. They do now.

### 0.18.1
Terminal: pinch with two fingers to change the text size (10 to 20 px, same as Settings). Key bar: new `/ - | ~ _` keys, which are buried on phone keyboards.

## 0.19.0: session tabs

With two or more running sessions, a thin strip of tabs appears under the terminal bar. Tap one to jump to that session without going back to the list.

## 0.20.0: "needs you"

When an agent goes quiet on a question (an approve/deny prompt, `(y/n)`, "Press Enter to continue"), its row shows **needs you** in amber, the pill on the Sessions tab says `N needs you`, the session tab gets a dot, and you get a notification if you are looking elsewhere. It is a guess from the last lines of output, so it can miss an unusual prompt; it goes away as soon as you answer.

## 0.21.0: desk, key bar choices, keyboard shortcuts

- **Pin to desk:** the star in a file's top bar pins it; pinned files show under "On your desk" at the top of the Sessions tab.
- **Key bar:** Settings → Look lets you hide the symbol keys, ^C ^D, Scroll and Live, or Paste. Esc, Tab, Ctrl, arrows and Enter always stay.
- **A keyboard plugged into the phone:** Alt+N new session, Alt+K agents, Alt+O folder, Alt+1/2/3 tabs, Ctrl+S save.

## 0.22.0: select and copy in the terminal, numbered sessions

- **Long-press a word** in the terminal to select it (a short buzz), drag to extend the selection (it can run over several lines), lift your finger: a small bar offers **Copy, Paste, Select all, More**. **More** also has: open a link, send the selection to the message box, share, copy the cursor line or all output, search, text bigger/smaller, clear the screen. Tap elsewhere to let go. Copy goes through Android's own clipboard.
- **Sessions are numbered** (Terminal 1, Terminal 2, Claude Code 1...) and the tab strip under the terminal bar is always there, with a ＋ that starts another session of the same kind (a terminal, or the same agent) in the same folder.

## 0.23.0: a terminal that goes past Termux

Same Debian Linux as before (nothing taken away), plus:

- **Phone commands inside the Linux** (a few of what Termux:API does): `nami-copy` (text or a pipe to the phone's clipboard), `nami-paste`, `nami-notify [-t title] message`, `nami-toast`, `nami-vibrate [ms]`, `nami-share` (Android's share sheet), and `xdg-open <link>`. `nami-help` lists them. The Nami app must be open (background is fine). They talk to the app over the same token as everything else.
- **Second key row** (the `⋯` at the end of the key bar): Alt (latches like Ctrl), Home, End, Del, Ins, ⇧Tab, ^A ^E ^U ^K ^W ^L ^Z ^R, F1 to F12, and every symbol a keyboard hides (`\ $ & * " ' { } [ ] < > = + # % ^ ` @ ! ? ; : , . ( )`).
- **Better shell:** colours for `ls` and `grep`, `ll`, `la`, `..`, tab completion that ignores case and lists choices, up/down arrows search history for what you typed, shared history across sessions (50,000 lines), and the git branch in the prompt.
- **Faster Linux (experimental)** in Settings → Look: lets proot skip checking every system call, as Termux's proot does. Off by default; if it makes the Linux stop at once, Nami switches it off by itself.
- Fix: the Linux no longer sets `NPM_CONFIG_PREFIX` in the process environment either (it was still passed in by the app, which made `nvm` complain).

## 0.24.0: more phone commands

`nami-battery` (level, charging, temperature as JSON), `nami-info` (model, Android version, RAM, free storage as JSON), `nami-tts [text]` (read aloud), `nami-torch [on|off]` (the flash as a torch), and `nami-download <file>` (save a file from your workspace into the phone's Downloads). `nami-help` lists them all. They need the Nami app open.

## 0.25.0: FreeLLMAPI in one command

`freellmapi-start` clones your FreeLLMAPI fork, installs it, makes the encryption key, builds it and starts it at `http://127.0.0.1:3001` (first run: 10 to 20 minutes on a phone). `freellmapi-start -d` runs it in the background (log in `~/freellmapi/server.log`), `freellmapi-stop` stops it. Settings → Providers → New provider has two presets, **FreeLLMAPI · Claude Code** and **FreeLLMAPI · Codex / OpenCode**, with the address and model already filled in: only paste the unified key. Also fixed: picking a preset now moves the "Shown for" choice with it.

## 0.26.0: selection handles, and Android's own bar stays away

After a long-press in the terminal there are now **two round handles**, one at each end of the selection. Grab one and drag it left, right, up or down to fix exactly what is selected; the Copy / Paste / Select all / More bar follows. Android's own selection bar (Translate, Cut, Copy, Paste) no longer shows over it: the app refuses that bar while Nami's own selection is up and lets go as soon as the selection ends. (Dragging past the top or bottom edge does not scroll yet.)

## 0.27.0

- File and folder paths in terminal output are tappable (`./src/app.js`, `~/notes/todo.md`, `lib/util.mjs:42`, even when a long path wraps over several rows on a phone). A file opens in Nami's viewer/editor; a folder becomes the workspace. Long web addresses that wrap are tappable too.
- New `fs.resolve` call on the server resolves a path against the session's folder.

## 0.28.0

- **File beside the session**: the split button now also offers your pinned files. The file stays next to the terminal and refreshes by itself while an agent edits it. Tapping a path in the terminal opens it there while that pane is showing.
- **Own zoom for the second pane**: pinch the lower pane to change only its text size.
- **"Start here.md"**: a short welcome note is written once in the home folder (never again, never over an existing file).
- **Check for update** (Settings): compares the version on your GitHub's main branch with the installed one.

## 0.29.0

- New phone commands: `nami-location` (GPS position, Android asks permission once), `nami-wifi` (name, signal, speed, IP), `nami-sensor <accel|gyro|light|proximity|pressure|magnetic>`.
- **Start Nami after restart** (Settings): off by default; when on, the phone's start brings the Linux and your sessions back.

## 0.30.0

- **Home-screen widget**: long-press the home screen, add the Nami widget. Set its label and command in Settings; a tap runs the command in a new session (starting the Linux first if needed).
- **Tasker and other automation**: broadcast `app.namimobile.RUN` with extras `cmd` and `token` (copy the token from Settings). Without the token nothing runs.
- `nami-camera` opens the camera; the photo is saved in Pictures/Nami.
