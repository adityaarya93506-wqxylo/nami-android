# Nami for Android

Nami's desk on your phone, with no PC and **no Termux**. One app: install it, open it, your agents are there.

```
Nami app (APK)
 ├─ Linux inside the app: Alpine + Node + tmux, run by proot (nothing to install)
 │    └─ Nami server (server/) ─▶ your agents, kept in tmux
 └─ the phone UI (web/), shown in the app
```

## What you get

- **Open the app and you are in.** The first time, it unpacks its own Linux (a minute or two, with a progress bar). After that it starts in seconds. No pairing, no connecting.
- **Everything is kept.** Each session lives in tmux inside the app's Linux, which stays alive in the background (you will see a "Nami is running" notification; that is what keeps Android from stopping it). Close the app and come back: the session, its shell state and its history are there. Your files and installed agents live in the Linux's `/root` and survive app updates. "Stop" ends one session; "Stop Nami" in the notification ends everything.
- A real terminal per session (the desktop app's xterm.js) with a key bar: Esc, Tab, Ctrl, arrows, ^C, ^D, scroll, Paste. Scroll with your thumb; **Live** returns to the bottom.
- A message box built for phone keyboards. **Send** types your message into the agent and presses Enter.
- New session: a plain terminal, or Claude Code, Codex, OpenCode, Kimi, Hermes. One that is not installed shows its install line, typed at a prompt for you to run (for example `npm install -g @anthropic-ai/claude-code`).
- The six desks (Paper, Operator, Glass, Graphite, Soft, Dusk) and text size, with the desktop app's logo and brand icons for each agent.
- **Workspace**: browse a folder, open, edit and save text files (a changed file is noticed, not overwritten), read Markdown as a page, view images, make folders and files, rename, delete, import files from the phone, download to `Download/Nami`. It cannot leave the folder you choose.
- **Library**: your Claude Code and Codex agents and skills, found in the workspace and your home folder. Open one, edit it, run it in a session, or create a new one ("Build it with my agent" starts a session that writes it for you).
- **Providers**: add your own API key and base URL (any OpenAI/Anthropic-compatible endpoint). Pick it when you start a session and Nami sets the variables for that agent. Keys stay in the Linux (private file), the page only sees them masked.

Not here yet: the desktop app's built-in browser pane, usage panel, connections (Notion, Gmail, Slack), voice, side-by-side tiles; access to your phone's shared storage from inside the Linux.

## Get the app (no PC)

GitHub builds the APK for you:

1. Put this repository's `mobile/` folder at the top level of your own GitHub repository, with `mobile/android/ci/nami-android.yml` copied to `.github/workflows/nami-android.yml`.
2. On your phone: GitHub in the browser → **Actions** → **Nami Android APK** → **Run workflow**. It takes 15 to 40 minutes (the Linux is built for arm64 under emulation).
3. Open the finished run, download the artifact **nami-android-apk**, unzip it, install `app-debug.apk` (allow installs from your browser or files app when asked).

Needs an arm64 phone (nearly all of them) and about 400 MB free. The APK is roughly 60 to 100 MB.

## Things to know

- **Android 12 and newer can kill background Linux programs** ("phantom process killer"). If sessions disappear while the app is in the background, either turn on Developer options → "Disable child process restrictions" (Android 14+), or on Android 12/13 it needs an `adb` setting that cannot be done from the phone alone. Also set the app's battery use to **Unrestricted**. Without this, Android may stop the Linux after a while; the app starts it again when opened, but running sessions are lost.
- It is slower than a native app: proot translates system calls. Fine for agents that mostly wait on the network; heavy builds will be slow.
- Agents built only for glibc Linux may not run on Alpine (musl). Node-based ones (Claude Code, Codex, OpenCode via npm) are the target.
- If something fails, the app shows the last lines of its logs with **Copy log**. Send that text and the problem can be found. **Reset** deletes the Linux and sets it up again (this erases agents and files inside it).

## What was tested, and what was not

Tested here, on Linux: the server and its locks; sessions kept in tmux; stopping the server and starting it again (the page reconnects and the same shell comes back, variables included); exit codes; history; scrolling by buttons and touch drag in a real browser at phone size; the tar reader that unpacks the Linux (real GNU tar archives: long names, pax, symlinks, hard links, unicode, truncated archives, path-escape attempts); the proot command line; the script that gathers proot from the Termux package repository (against a pretend repository). 73 automated tests, plus a browser run of the new screens at phone size (Sessions, Workspace, Markdown, Library, agent picker, Settings).

**Not tested: anything on a real phone.** The newest Kotlin additions (download to Downloads, the import file picker) have never been compiled or run on a phone, and the Kotlin app (`MainActivity.kt`, `NamiService.kt`) was only ever compiled by your GitHub build; this machine has no Android SDK, because the machine this was written on has no Android SDK. The arm64 Linux image has not been built, and proot has never been run with it. The most likely places for a first failure: the GitHub build (a small Kotlin mistake), proot starting on your Android version, tmux inside proot. Each one shows up as readable text (the GitHub log, or the app's error screen). Send it back and it gets fixed.

## Safety

A Nami session is a shell on your phone, so:

- The server listens on `127.0.0.1` only. Another app or website cannot reach it without the token, and requests whose `Host` or `Origin` is not this phone are refused, so a web page you open cannot talk to it.
- The token is created on first run inside the app's Linux (`/root/.nami-mobile/token`, owner-only). The app reads it itself, so there is nothing to type.
- Six wrong tokens from one address lock it out for a minute.
- The app talks to `http://127.0.0.1` only (plain http, allowed for that address and nothing else). Links to other sites open in your browser, never inside the app. The only thing the page can ask of the app is to read the clipboard when you tap Paste.
- `npm start -- --lan` lets other devices on your Wi-Fi in. That traffic is **not encrypted**. Use it only on a network you trust, or not at all.
- Agent commands come from a fixed list in `server/agents.js`; a browser cannot make the server run arbitrary programs through the New session sheet. A terminal session is, by design, a shell.
- The app needs no special permissions beyond the network (for this phone only) and a background-service notification. Install it only from a build you made yourself.
- tmux sessions keep running after the server stops. To end them all: use **Stop Nami** in the notification.

## Develop

```bash
npm install
npm test                    # 59 tests: server, sockets, tmux, keys, themes, page, tar reader, proot fetch
npm start -- --port 8000    # another port
npm start -- --no-tmux      # sessions end when the server stops
npm start -- --no-pty       # force the `script` fallback instead of node-pty
node tools/make-icons.mjs   # redraw the web app icons
```

`node-pty` is used if installed; otherwise the server uses `script`. With `script` a running terminal cannot be resized, so for tmux sessions the server re-attaches at the new size (a quick redraw when the phone rotates or the keyboard opens).

## License

Apache-2.0, like Nami. The terminal files in `vendor/` are xterm.js (MIT) and Courier Prime (SIL OFL, see `vendor/fonts/OFL.txt`), copied from the desktop app.
Built from Nami by Dainami AI. Do not present a build of this as the official Nami app.
