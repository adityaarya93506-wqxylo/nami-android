plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.namimobile"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.namimobile"
        minSdk = 24
        // 28 on purpose: from 29 on, Android forbids running programs from the app's own
        // data folder, which the Linux inside Nami (via proot) relies on. This app is
        // installed from a file, not from Play, so the lower target is allowed.
        targetSdk = 28
        versionCode = 3
        versionName = "0.3"
        ndk { abiFilters += "arm64-v8a" }
    }

    // proot is shipped as lib*.so (CI puts it in src/main/jniLibs/arm64-v8a). Android only
    // unpacks them to disk, where they can be run, with legacy packaging.
    packaging { jniLibs { useLegacyPackaging = true } }

    // The Linux (src/main/assets/rootfs.tar.gz, made by CI) is read in place, so keep it uncompressed in the APK.
    androidResources { noCompress.add("gz") }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
// No library dependencies on purpose: one Activity, one Service, the system WebView.
