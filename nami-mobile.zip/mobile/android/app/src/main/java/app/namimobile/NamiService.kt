package app.namimobile

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import java.io.File
import kotlin.concurrent.thread

/**
 * Keeps Nami's Linux (proot) running in the background. It is a foreground service
 * so Android leaves it alone while you are in other apps; the notification is the
 * price for that. If proot ends, it is started again. Output goes to proot.log.
 */
class NamiService : Service() {

    companion object {
        const val ACTION_STOP = "app.namimobile.STOP"
        const val CHANNEL = "nami"
        const val NOTE_ID = 1
        const val MAX_LOG = 1_000_000L
    }

    @Volatile private var proc: Process? = null
    @Volatile private var stopping = false
    private var worker: Thread? = null
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopping = true
            killProc()
            stopForeground(true)
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTE_ID, notification())
        if (wake == null) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nami:proot").also { it.acquire() }
        }
        if (worker?.isAlive != true) {
            stopping = false
            worker = thread(name = "nami-proot") { loop() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        stopping = true
        killProc()
        try { wake?.release() } catch (e: Exception) { /* already released */ }
        wake = null
        super.onDestroy()
    }

    // ---- running proot -----------------------------------------------------

    private fun loop() {
        val log = File(filesDir, "proot.log")
        try {
            if (log.length() > MAX_LOG) log.writeText("")
        } catch (e: Exception) { /* ignore */ }
        var fast = 0
        while (!stopping) {
            val t0 = System.currentTimeMillis()
            try {
                runOnce(log)
            } catch (e: Exception) {
                log.appendText("could not start proot: $e\n")
            }
            if (stopping) break
            fast = if (System.currentTimeMillis() - t0 < 10_000) fast + 1 else 0
            if (fast >= 5) {
                log.appendText("proot keeps stopping right away; giving up. See the lines above.\n")
                break
            }
            try { Thread.sleep(2000) } catch (e: InterruptedException) { break }
        }
        if (!stopping) stopSelf()
    }

    private fun runOnce(log: File) {
        val libs = applicationInfo.nativeLibraryDir
        val root = File(filesDir, "rootfs")
        File(filesDir, "tmp").mkdirs()
        // The phone's shared storage (Downloads, Pictures, Documents…) shows up inside as /sdcard,
        // if Android allows this app to read it (the permission is asked for when the app opens).
        val shared = android.os.Environment.getExternalStorageDirectory()
        val sharedPath = if (shared.canRead()) shared.path else null
        if (sharedPath != null) File(root, "sdcard").mkdirs()
        val cmd = ProotLauncher.command(libs, root.path, sharedPath)
        val pb = ProcessBuilder(cmd)
        pb.directory(filesDir)
        val env = pb.environment()
        env.clear()
        env.putAll(ProotLauncher.env(libs, filesDir.path))
        pb.redirectErrorStream(true)
        pb.redirectOutput(ProcessBuilder.Redirect.appendTo(log))
        log.appendText("--- starting proot (${java.util.Date()})\n")
        val p = pb.start()
        proc = p
        val code = p.waitFor()
        log.appendText("--- proot exited with $code\n")
    }

    private fun killProc() {
        val p = proc ?: return
        p.destroy()
        thread(name = "nami-kill") {
            try { Thread.sleep(1500) } catch (e: InterruptedException) { /* fall through */ }
            try { p.destroyForcibly() } catch (e: Exception) { /* gone */ }
        }
    }

    // ---- notification ------------------------------------------------------

    @Suppress("DEPRECATION")
    private fun notification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Nami running", NotificationManager.IMPORTANCE_LOW))
            b = Notification.Builder(this, CHANNEL)
        } else {
            b = Notification.Builder(this)
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, NamiService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        b.setContentTitle("Nami is running")
        b.setContentText("Your agent sessions keep going. Tap to open.")
        b.setSmallIcon(R.mipmap.ic_launcher)
        b.setContentIntent(open)
        b.setOngoing(true)
        b.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop Nami", stop)
        return b.build()
    }
}
