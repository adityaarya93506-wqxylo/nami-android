package app.namimobile

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.RemoteViews
import android.widget.Toast
import java.io.File
import java.security.MessageDigest
import kotlin.concurrent.thread

/** The widget's label and command, set in Nami's Settings. Two lines: label, then the command. */
object WidgetConfig {
    fun read(ctx: Context): Pair<String, String> {
        val t = try { File(ctx.filesDir, "widget").readText() } catch (e: Exception) { "" }
        val i = t.indexOf('\n')
        return if (i < 0) Pair("Nami", "") else Pair(t.substring(0, i).trim().ifEmpty { "Nami" }, t.substring(i + 1).trim())
    }

    fun write(ctx: Context, label: String, cmd: String) {
        File(ctx.filesDir, "widget").writeText(label.replace('\n', ' ').take(24) + "\n" + cmd.take(4000))
        NamiWidget.refresh(ctx)
    }
}

/** A button on the home screen: runs your command in a new Nami session (or opens Nami if none is set). */
class NamiWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) mgr.updateAppWidget(id, views(context))
    }

    companion object {
        private fun flags() = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)

        fun views(ctx: Context): RemoteViews {
            val (label, cmd) = WidgetConfig.read(ctx)
            val v = RemoteViews(ctx.packageName, R.layout.widget_run)
            v.setTextViewText(R.id.widget_label, if (cmd.isEmpty()) "Nami" else "▶ $label")
            val pi = if (cmd.isEmpty()) PendingIntent.getActivity(ctx, 1, Intent(ctx, MainActivity::class.java), flags())
            else PendingIntent.getBroadcast(ctx, 2, Intent(ctx, WidgetTapReceiver::class.java), flags())
            v.setOnClickPendingIntent(R.id.widget_root, pi)
            return v
        }

        fun refresh(ctx: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(ctx)
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, NamiWidget::class.java))
                for (id in ids) mgr.updateAppWidget(id, views(ctx))
            } catch (e: Exception) { /* no widget placed */ }
        }
    }
}

/** The widget's tap (only our own widget can send this: the receiver is not exported). */
class WidgetTapReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val (label, cmd) = WidgetConfig.read(context)
        if (cmd.isEmpty()) return
        Toast.makeText(context, "Nami: running $label. Open Nami to see it.", Toast.LENGTH_SHORT).show()
        val pending = goAsync()
        thread {
            val ok = Runner.run(context.applicationContext, cmd)
            if (!ok) android.os.Handler(android.os.Looper.getMainLooper()).post { Toast.makeText(context, "Nami could not start. Open it once.", Toast.LENGTH_LONG).show() }
            pending.finish()
        }
    }
}

/** For Tasker and other automation apps: action app.namimobile.RUN with extras "cmd" and "token" (shown in Nami's Settings). */
class RunReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "app.namimobile.RUN") return
        val cmd = intent.getStringExtra("cmd")?.trim().orEmpty()
        val given = intent.getStringExtra("token").orEmpty()
        val real = Runner.token(context)
        if (cmd.isEmpty() || real.isEmpty() || !MessageDigest.isEqual(given.toByteArray(), real.toByteArray())) return
        val pending = goAsync()
        thread { Runner.run(context.applicationContext, cmd); pending.finish() }
    }
}
