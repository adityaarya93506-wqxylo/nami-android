package app.namimobile

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.RemoteViews
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** What the status widget shows: refreshed by NamiService every half minute while Nami runs. */
object WidgetStatus {
    class State(val on: Boolean, val running: Int, val needs: Int, val names: List<String>)

    private fun file(ctx: Context) = File(ctx.filesDir, "widget-status")

    fun read(ctx: Context): State = try {
        val j = JSONObject(file(ctx).readText())
        if (j.optBoolean("off", true)) State(false, 0, 0, emptyList())
        else {
            val a = j.optJSONArray("items")
            val names = ArrayList<String>()
            if (a != null) for (i in 0 until minOf(a.length(), 2)) names.add(a.getJSONObject(i).optString("name"))
            State(true, j.optInt("running"), j.optInt("needs"), names)
        }
    } catch (e: Exception) { State(false, 0, 0, emptyList()) }

    /** Asks the server for the numbers; call off the main thread. */
    fun fetch(ctx: Context) {
        var body = "{\"off\":true}"
        try {
            val t = Runner.token(ctx)
            if (t.isNotEmpty()) {
                val c = URL("http://127.0.0.1:${MainActivity.PORT}/__status").openConnection() as HttpURLConnection
                c.connectTimeout = 2000; c.readTimeout = 4000
                c.setRequestProperty("x-nami-token", t)
                if (c.responseCode == 200) body = c.inputStream.bufferedReader().readText()
                c.disconnect()
            }
        } catch (e: Exception) { /* Linux is not up */ }
        try { file(ctx).writeText(body) } catch (e: Exception) { /* nothing to show */ }
        NamiWidgets.refreshAll(ctx)
    }

    fun markOff(ctx: Context) {
        try { file(ctx).writeText("{\"off\":true}") } catch (e: Exception) { /* fine */ }
        NamiWidgets.refreshAll(ctx)
    }
}

object NamiWidgets {
    private fun flags() = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)

    /** Opens Nami and starts something: "shell" or an agent id (claude, codex, opencode). */
    fun launch(ctx: Context, what: String, code: Int): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).setAction("app.namimobile.LAUNCH").putExtra("launch", what)
        return PendingIntent.getActivity(ctx, code, i, flags())
    }

    fun open(ctx: Context): PendingIntent = PendingIntent.getActivity(ctx, 10, Intent(ctx, MainActivity::class.java), flags())

    private fun buttons(ctx: Context, v: RemoteViews) {
        v.setOnClickPendingIntent(R.id.btn_shell, launch(ctx, "shell", 11))
        v.setOnClickPendingIntent(R.id.btn_claude, launch(ctx, "claude", 12))
        v.setOnClickPendingIntent(R.id.btn_codex, launch(ctx, "codex", 13))
        v.setOnClickPendingIntent(R.id.btn_opencode, launch(ctx, "opencode", 14))
    }

    fun status(ctx: Context): RemoteViews {
        val v = RemoteViews(ctx.packageName, R.layout.widget_status)
        val s = WidgetStatus.read(ctx)
        val pill: String; val bg: Int
        if (!s.on) { pill = "Off"; bg = R.drawable.widget_pill_calm }
        else if (s.needs > 0) { pill = "● ${s.needs} needs you"; bg = R.drawable.widget_pill_alert }
        else if (s.running > 0) { pill = "${s.running} running"; bg = R.drawable.widget_pill_calm }
        else { pill = "Idle"; bg = R.drawable.widget_pill_calm }
        v.setTextViewText(R.id.widget_pill, pill)
        v.setInt(R.id.widget_pill, "setBackgroundResource", bg)
        v.setTextColor(R.id.widget_pill, if (s.on && s.needs > 0) 0xFF2B1D00.toInt() else 0xFFFFFFFF.toInt())
        v.setTextViewText(R.id.widget_line,
            if (!s.on) "Nami is asleep. Tap to wake it."
            else if (s.names.isEmpty()) "No sessions yet. Start one below."
            else s.names.joinToString("  ·  "))
        v.setOnClickPendingIntent(R.id.widget_root, open(ctx))
        buttons(ctx, v)
        return v
    }

    fun agents(ctx: Context): RemoteViews {
        val v = RemoteViews(ctx.packageName, R.layout.widget_agents)
        buttons(ctx, v)
        return v
    }

    fun quick(ctx: Context): RemoteViews {
        val v = RemoteViews(ctx.packageName, R.layout.widget_quick)
        v.setOnClickPendingIntent(R.id.widget_root, launch(ctx, "shell", 11))
        return v
    }

    private fun update(ctx: Context, cls: Class<*>, make: (Context) -> RemoteViews) {
        try {
            val mgr = AppWidgetManager.getInstance(ctx)
            for (id in mgr.getAppWidgetIds(ComponentName(ctx, cls))) mgr.updateAppWidget(id, make(ctx))
        } catch (e: Exception) { /* none placed */ }
    }

    fun refreshAll(ctx: Context) {
        update(ctx, NamiStatusWidget::class.java) { status(it) }
        update(ctx, NamiAgentsWidget::class.java) { agents(it) }
        update(ctx, NamiQuickWidget::class.java) { quick(it) }
        NamiWidget.refresh(ctx)
    }
}

class NamiStatusWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) mgr.updateAppWidget(id, NamiWidgets.status(context))
        Thread { WidgetStatus.fetch(context.applicationContext) }.start()
    }
}

class NamiAgentsWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) mgr.updateAppWidget(id, NamiWidgets.agents(context))
    }
}

class NamiQuickWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) mgr.updateAppWidget(id, NamiWidgets.quick(context))
    }
}
