package app.namimobile;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * A small tar reader for the Linux root filesystem the app unpacks on first run.
 * Handles ustar, pax (x/g) and GNU long names (L/K); files, folders, symlinks and
 * hard links. Device nodes, fifos and the like are skipped (proot provides /dev).
 * Never writes outside the root: ".." is refused, and nothing is written through
 * a symlink that the archive itself created.
 */
public final class TarExtractor {
    public interface Progress { void bytes(long done); }

    public static final class Result {
        public int files, dirs, symlinks, hardlinks, skipped;
        public long bytes;
    }

    private final FileSink sink;
    private final Progress progress;
    private final Set<String> links = new HashSet<>();
    private final byte[] buf = new byte[64 * 1024];
    private long read;

    public TarExtractor(FileSink sink, Progress progress) {
        this.sink = sink;
        this.progress = progress;
    }

    public Result extract(InputStream in) throws IOException {
        Result r = new Result();
        String longName = null, longLink = null;
        Map<String, String> pax = new HashMap<>();
        byte[] h = new byte[512];
        int zero = 0;
        while (true) {
            if (!readFully(in, h, 512, true)) break;
            if (isZero(h)) { if (++zero >= 2) break; continue; }
            zero = 0;
            String name = str(h, 0, 100);
            long size = octal(h, 124, 12);
            int mode = (int) octal(h, 100, 8);
            char type = (char) (h[156] == 0 ? '0' : h[156] & 0xff);
            String link = str(h, 157, 100);
            String prefix = str(h, 345, 155);
            boolean ustar = "ustar".equals(str(h, 257, 5));
            if (ustar && !prefix.isEmpty()) name = prefix + "/" + name;

            if (type == 'x' || type == 'g' || type == 'L' || type == 'K') {
                if (size > 1 << 20) throw new IOException("tar: header block too large");
                byte[] data = new byte[(int) size];
                readFully(in, data, data.length, false);
                skipPad(in, size);
                if (type == 'L') longName = cstr(data);
                else if (type == 'K') longLink = cstr(data);
                else if (type == 'x') parsePax(data, pax);
                continue;
            }
            if (longName != null) name = longName;
            if (longLink != null) link = longLink;
            if (pax.containsKey("path")) name = pax.get("path");
            if (pax.containsKey("linkpath")) link = pax.get("linkpath");
            if (pax.containsKey("size")) size = Long.parseLong(pax.get("size"));
            longName = null; longLink = null; pax.clear();

            String path = clean(name);
            switch (type) {
                case '0': case '7': {
                    if (path.isEmpty()) throw new IOException("tar: file without a name");
                    guard(path);
                    try (OutputStream out = sink.file(path, (mode & 0777) | 0600)) {
                        long left = size;
                        while (left > 0) {
                            int n = in.read(buf, 0, (int) Math.min(buf.length, left));
                            if (n < 0) throw new EOFException("tar: archive ends inside " + path);
                            out.write(buf, 0, n);
                            left -= n;
                            tick(n);
                        }
                    }
                    skipPad(in, size);
                    r.files++; r.bytes += size;
                    break;
                }
                case '5':
                    if (!path.isEmpty()) { guard(path); sink.dir(path, (mode & 0777) | 0700); r.dirs++; }
                    skipData(in, size);
                    break;
                case '2':
                    guard(path);
                    sink.symlink(path, link);
                    links.add(path);
                    r.symlinks++;
                    skipData(in, size);
                    break;
                case '1': {
                    guard(path);
                    String target = clean(link);
                    guard(target);
                    sink.hardlink(path, target);
                    r.hardlinks++;
                    skipData(in, size);
                    break;
                }
                default:
                    skipData(in, size);
                    r.skipped++;
            }
        }
        return r;
    }

    // ---- safety ------------------------------------------------------------

    /** Strips "./" and leading "/" and refuses "..". Returns "" for the root itself. */
    static String clean(String name) throws IOException {
        StringBuilder sb = new StringBuilder();
        for (String part : name.split("/")) {
            if (part.isEmpty() || part.equals(".")) continue;
            if (part.equals("..")) throw new IOException("tar: refusing path with ..: " + name);
            if (part.indexOf('\0') >= 0) throw new IOException("tar: bad name");
            if (sb.length() > 0) sb.append('/');
            sb.append(part);
        }
        return sb.toString();
    }

    /** Refuses a path that goes through a symlink the archive made earlier. */
    private void guard(String path) throws IOException {
        int i = path.indexOf('/');
        while (i >= 0) {
            if (links.contains(path.substring(0, i))) throw new IOException("tar: path goes through a symlink: " + path);
            i = path.indexOf('/', i + 1);
        }
    }

    // ---- reading -----------------------------------------------------------

    private void tick(long n) {
        read += n;
        if (progress != null) progress.bytes(read);
    }

    private static boolean readFully(InputStream in, byte[] b, int len, boolean eofOk) throws IOException {
        int off = 0;
        while (off < len) {
            int n = in.read(b, off, len - off);
            if (n < 0) {
                if (off == 0 && eofOk) return false;
                throw new EOFException("tar: unexpected end of archive");
            }
            off += n;
        }
        return true;
    }

    private void skipData(InputStream in, long size) throws IOException {
        long total = size + ((512 - size % 512) % 512);
        while (total > 0) {
            int n = in.read(buf, 0, (int) Math.min(buf.length, total));
            if (n < 0) throw new EOFException("tar: unexpected end of archive");
            total -= n;
        }
    }

    private void skipPad(InputStream in, long size) throws IOException {
        long pad = (512 - size % 512) % 512;
        while (pad > 0) {
            int n = in.read(buf, 0, (int) pad);
            if (n < 0) throw new EOFException("tar: unexpected end of archive");
            pad -= n;
        }
    }

    private static boolean isZero(byte[] b) {
        for (byte x : b) if (x != 0) return false;
        return true;
    }

    private static String str(byte[] b, int off, int len) {
        int e = off;
        while (e < off + len && b[e] != 0) e++;
        return new String(b, off, e - off, StandardCharsets.UTF_8);
    }

    private static String cstr(byte[] b) {
        int e = 0;
        while (e < b.length && b[e] != 0) e++;
        return new String(b, 0, e, StandardCharsets.UTF_8);
    }

    /** Octal field, or GNU base-256 when the top bit is set (big files). */
    static long octal(byte[] b, int off, int len) {
        if ((b[off] & 0x80) != 0) {
            long v = b[off] & 0x7f;
            for (int i = 1; i < len; i++) v = (v << 8) | (b[off + i] & 0xff);
            return v;
        }
        long v = 0;
        int i = off, end = off + len;
        while (i < end && (b[i] == ' ' || b[i] == 0)) i++;
        for (; i < end && b[i] >= '0' && b[i] <= '7'; i++) v = (v << 3) + (b[i] - '0');
        return v;
    }

    /** pax records: "<len> key=value\n", len counts the whole record in bytes. */
    private static void parsePax(byte[] d, Map<String, String> out) {
        int p = 0;
        while (p < d.length) {
            int sp = p;
            while (sp < d.length && d[sp] != ' ') sp++;
            if (sp >= d.length) break;
            int len;
            try { len = Integer.parseInt(new String(d, p, sp - p, StandardCharsets.US_ASCII)); } catch (NumberFormatException e) { break; }
            if (len <= sp - p + 1 || p + len > d.length) break;
            String rec = new String(d, sp + 1, p + len - sp - 2, StandardCharsets.UTF_8);
            int eq = rec.indexOf('=');
            if (eq > 0) out.put(rec.substring(0, eq), rec.substring(eq + 1));
            p += len;
        }
    }
}
