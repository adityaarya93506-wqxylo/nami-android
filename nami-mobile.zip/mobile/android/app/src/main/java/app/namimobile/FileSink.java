package app.namimobile;

import java.io.IOException;
import java.io.OutputStream;

/** Where TarExtractor puts things. Paths are relative to the root and already checked. */
public interface FileSink {
    void dir(String path, int mode) throws IOException;
    /** Caller writes the content and closes the stream. */
    OutputStream file(String path, int mode) throws IOException;
    void symlink(String path, String target) throws IOException;
    /** A hard link in the archive. Implementations may copy; the target was extracted earlier. */
    void hardlink(String path, String target) throws IOException;
}
