package app.namimobile

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.io.File

/** Starts Nami's Linux after the phone restarts, only if you turned that on in Settings. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!File(context.filesDir, "boot").exists()) return
        try {
            val svc = Intent(context, NamiService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(svc) else context.startService(svc)
        } catch (e: Exception) { /* the system said no; open the app once instead */ }
    }
}
