package app.namimobile;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Builds the proot command that runs the bundled Linux. proot is shipped as
 * libproot.so in the app's native library folder (the only place Android lets an
 * app execute files from), with its loader next to it.
 */
public final class ProotLauncher {
    private ProotLauncher() {}

    public static final String SUPERVISOR = "/usr/local/bin/nami-supervisor";

    public static List<String> command(String nativeLibDir, String rootfs) {
        List<String> c = new ArrayList<>();
        c.add(nativeLibDir + "/libproot.so");
        c.add("-0");                    // look like root inside, so the root-owned files work
        c.add("--link2symlink");        // hard links the filesystem cannot do become symlinks
        c.add("--kill-on-exit");
        c.add("-r"); c.add(rootfs);
        c.add("-b"); c.add("/dev");
        c.add("-b"); c.add("/proc");
        c.add("-b"); c.add("/sys");
        c.add("-w"); c.add("/root");
        c.add("/usr/bin/env"); c.add("-i");
        c.add("HOME=/root");
        c.add("USER=root");
        c.add("TERM=xterm-256color");
        c.add("LANG=C.UTF-8");
        c.add("PATH=/root/.npm-global/bin:/root/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin");
        c.add("NPM_CONFIG_PREFIX=/root/.npm-global");
        c.add("USE_BUILTIN_RIPGREP=0");
        c.add("TMPDIR=/tmp");
        c.add(SUPERVISOR);
        return c;
    }

    public static Map<String, String> env(String nativeLibDir, String filesDir) {
        Map<String, String> e = new LinkedHashMap<>();
        e.put("PROOT_LOADER", nativeLibDir + "/libproot-loader.so");
        e.put("PROOT_TMP_DIR", filesDir + "/tmp");
        e.put("LD_LIBRARY_PATH", nativeLibDir);
        e.put("PROOT_NO_SECCOMP", "1");
        return e;
    }
}
