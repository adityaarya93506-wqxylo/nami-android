package app.namimobile;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Builds the proot command that runs the bundled Linux. proot is shipped as
 * libproot.so in the app's native library folder (the only place Android lets an
 * app execute files from), with its loader next to it.
 */
public final class ProotLauncher {
    private ProotLauncher() {}

    public static final String SUPERVISOR = "/usr/local/bin/nami-supervisor";

    public static List<String> command(String nativeLibDir, String rootfs) {
        return command(nativeLibDir, rootfs, null);
    }

    /** With sharedStorage (the phone's own storage folder), it appears inside as /sdcard. */
    public static List<String> command(String nativeLibDir, String rootfs, String sharedStorage) {
        List<String> c = new ArrayList<>();
        c.add(nativeLibDir + "/libproot.so");
        c.add("-0");                    // look like root inside, so the root-owned files work
        c.add("--link2symlink");        // hard links the filesystem cannot do become symlinks
        c.add("--kill-on-exit");
        c.add("-r"); c.add(rootfs);
        c.add("-b"); c.add("/dev");
        c.add("-b"); c.add("/proc");
        c.add("-b"); c.add("/sys");
        if (sharedStorage != null) { c.add("-b"); c.add(sharedStorage + ":/sdcard"); }
        c.add("-w"); c.add("/root");
        c.add("/usr/bin/env"); c.add("-i");
        c.add("HOME=/root");
        c.add("USER=root");
        c.add("TERM=xterm-256color");
        c.add("LANG=C.UTF-8");
        c.add("PATH=/root/.npm-global/bin:/root/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin");
        c.add("USE_BUILTIN_RIPGREP=0");
        c.add("TMPDIR=/tmp");
        c.add(SUPERVISOR);
        return c;
    }

    public static Map<String, String> env(String nativeLibDir, String filesDir) {
        return env(nativeLibDir, filesDir, false);
    }

    /**
     * accelerated: let proot use a seccomp filter so it only stops for the system calls it must handle
     * (much faster, and what Termux's own proot does). Off by default: on some phones it misbehaves, so it
     * is a setting, and the service switches it back off if proot keeps dying right after starting.
     */
    public static Map<String, String> env(String nativeLibDir, String filesDir, boolean accelerated) {
        Map<String, String> e = new LinkedHashMap<>();
        e.put("PROOT_LOADER", nativeLibDir + "/libproot-loader.so");
        e.put("PROOT_TMP_DIR", filesDir + "/tmp");
        e.put("LD_LIBRARY_PATH", nativeLibDir);
        if (!accelerated) e.put("PROOT_NO_SECCOMP", "1");
        return e;
    }
}
