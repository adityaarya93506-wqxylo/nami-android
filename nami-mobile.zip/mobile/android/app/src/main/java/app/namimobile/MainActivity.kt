package app.namimobile

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.system.ErrnoException
import android.system.Os
import android.system.OsConstants
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.pm.PackageManager
import android.net.Uri
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import org.json.JSONObject
import android.provider.MediaStore
import android.content.ContentValues
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.JavascriptInterface
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.GZIPInputStream
import kotlin.concurrent.thread

/**
 * Nami for Android: one screen around the system WebView, with its own Linux inside.
 *
 * First run: unpack the Linux (assets/rootfs.dat) into the app's private folder.
 * Every run: make sure NamiService (proot) is running, wait for the Nami server in
 * it, read its token from the Linux's files, and show the page. Nothing else
 * (no Termux, no pairing). Sessions live in tmux inside the Linux; your files and
 * agents live in its /root, which survives app updates.
 */
class MainActivity : Activity() {

    companion object {
        const val PORT = 7878
        const val BASE = "http://127.0.0.1:$PORT/"
        const val ROOTFS_ASSET = "rootfs.dat"
        val TOKEN = Regex("^[0-9a-f]{48}$")
        const val CREAM = 0xFFCFC3AC.toInt()
        const val INK = 0xFF2F2B26.toInt()
    }

    private lateinit var web: WebView
    private lateinit var overlay: LinearLayout
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var logScroll: ScrollView
    private lateinit var logView: TextView
    private lateinit var buttons: LinearLayout
    private val ui = Handler(Looper.getMainLooper())

    private var pageLoaded = false
    private var busy = false
    private var lastLog = ""
    private var picker: ValueCallback<Array<Uri>>? = null
    private var recognizer: SpeechRecognizer? = null
    private var askedStorage = false

    private val rootfs get() = File(filesDir, "rootfs")

    // ---- lifecycle ---------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        start()
    }

    override fun onResume() {
        super.onResume()
        // If Android stopped the service while we were away, bring it back; the page reconnects itself.
        if (pageLoaded && !busy) {
            thread { if (!healthy()) ui.post { start() } }
        }
    }

    // ---- speech to text (the microphone button) ---------------------------

    private fun voiceEvent(kind: String, text: String = "") {
        web.evaluateJavascript("window.namiVoice && window.namiVoice(" + JSONObject.quote(kind) + "," + JSONObject.quote(text) + ")", null)
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { voiceEvent("error", "No speech service on this phone."); return }
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 78)
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { voiceEvent("ready") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                voiceEvent("partial", t)
            }
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                voiceEvent("final", t)
            }
            override fun onError(error: Int) {
                // 7 = heard nothing, 6 = no speech: not worth an error message
                voiceEvent(if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) "final" else "error",
                    if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) "" else "Speech error " + error)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        r.startListening(i)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 79) {
            // The Linux is already running; it sees /sdcard from its next start, so restart it once if it was just allowed.
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Phone files will appear as /sdcard after Nami restarts (Stop Nami in the notification, then open it again).", Toast.LENGTH_LONG).show()
            }
            return
        }
        if (requestCode != 78) return
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startListening()
        else voiceEvent("error", "Microphone permission was not given.")
    }

    override fun onDestroy() {
        recognizer?.destroy()
        super.onDestroy()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 77) return
        val cb = picker ?: return
        picker = null
        cb.onReceiveValue(if (resultCode == RESULT_OK) WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null)
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (!pageLoaded) { super.onBackPressed(); return }
        // The page handles Back first (close a sheet, leave a terminal); if it has nothing to do, go home.
        web.evaluateJavascript("(window.namiBack && window.namiBack()) === true") { handled ->
            if (handled != "true") moveTaskToBack(true)
        }
    }

    // ---- starting ----------------------------------------------------------

    private fun start() {
        if (busy) return
        // Once: ask for the phone's files so the Linux can see them as /sdcard. Nami runs either way.
        if (Build.VERSION.SDK_INT >= 23 && !askedStorage && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            askedStorage = true
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 79)
        }
        busy = true
        showStatus("Starting Nami…", null)
        thread {
            try {
                if (!rootfsReady()) installRootfs()
                writeNetFiles()
                val svc = Intent(this, NamiService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)
                var up = false
                for (i in 1..170) {                    // up to about two minutes: the first start is the slowest
                    if (healthy()) { up = true; break }
                    Thread.sleep(700)
                }
                if (!up) throw IOException("The Nami server did not start in the Linux.")
                val token = readToken() ?: throw IOException("The Nami server is up but has no token file.")
                ui.post { busy = false; loadPage(token) }
            } catch (e: Throwable) {
                ui.post { busy = false; showProblem("${e.javaClass.simpleName}: ${e.message}") }
            }
        }
    }

    private fun healthy(): Boolean = try {
        val c = URL("${BASE}healthz").openConnection() as HttpURLConnection
        c.connectTimeout = 800
        c.readTimeout = 800
        val ok = c.responseCode == 200
        c.disconnect()
        ok
    } catch (e: Exception) {
        false
    }

    private fun readToken(): String? {
        val f = File(rootfs, "root/.nami-mobile/token")
        val t = try { f.readText().trim() } catch (e: Exception) { return null }
        return if (TOKEN.matches(t)) t else null
    }

    @Suppress("DEPRECATION")
    private fun versionTag(): String = packageManager.getPackageInfo(packageName, 0).versionCode.toString()

    private fun rootfsReady(): Boolean = try {
        File(rootfs, ".nami-version").readText().trim() == versionTag() && File(rootfs, "usr/local/bin/nami-supervisor").exists()
    } catch (e: Exception) {
        false
    }

    // ---- unpacking the Linux ----------------------------------------------

    private class Counting(i: InputStream, private val cb: (Long) -> Unit) : FilterInputStream(i) {
        private var n = 0L
        override fun read(): Int {
            val r = super.read()
            if (r >= 0) { n += 1; cb(n) }
            return r
        }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val r = super.read(b, off, len)
            if (r > 0) { n += r; cb(n) }
            return r
        }
    }

    private fun installRootfs() {
        // An older Linux may still be running from this folder: stop it before replacing files.
        stopService(Intent(this, NamiService::class.java))
        Thread.sleep(1500)

        val dest = File(filesDir, "rootfs.new")
        deleteTree(dest)
        if (!dest.mkdirs()) throw IOException("Cannot create ${dest.path}")

        // assets.open works whether or not the file got compressed in the APK; openFd only tells us the size.
        val have = assets.list("")?.toList() ?: emptyList()
        if (ROOTFS_ASSET !in have) {
            throw IOException("$ROOTFS_ASSET is not inside this APK (assets: ${have.joinToString()}). The build did not include the Linux image.")
        }
        val total = try {
            assets.openFd(ROOTFS_ASSET).use { it.length.toFloat() }
        } catch (e: IOException) {
            0f
        }
        var shown = -1
        val raw = Counting(assets.open(ROOTFS_ASSET)) { n ->
            val pct = if (total > 0f) (n * 100 / total).toInt().coerceIn(0, 100) else -1
            if (pct != shown) {
                shown = pct
                ui.post {
                    if (pct >= 0) showStatus("Setting up Nami's Linux (first time only)… $pct%", pct)
                    else showStatus("Setting up Nami's Linux (first time only)… ${n / 1_000_000} MB", null)
                }
            }
        }
        GZIPInputStream(BufferedInputStream(raw, 1 shl 16), 1 shl 16).use { gz ->
            TarExtractor(AndroidSink(dest), null).extract(gz)
        }

        ui.post { showStatus("Almost done…", null) }
        // Keep what the user made: the old /root (agents, files, tmux config, token) moves into the new Linux.
        val old = rootfs
        val oldRoot = File(old, "root")
        if (oldRoot.exists()) {
            val newRoot = File(dest, "root")
            deleteTree(newRoot)
            if (!oldRoot.renameTo(newRoot)) throw IOException("Could not carry your files over to the new version.")
        }
        deleteTree(old)
        if (!dest.renameTo(old)) throw IOException("Could not put the Linux in place.")
        File(old, ".nami-version").writeText(versionTag())
    }

    private fun writeNetFiles() {
        val etc = File(rootfs, "etc")
        etc.mkdirs()
        for ((name, text) in listOf(
            "resolv.conf" to "nameserver 8.8.8.8\nnameserver 1.1.1.1\n",
            "hosts" to "127.0.0.1 localhost\n::1 localhost\n",
        )) {
            val f = File(etc, name)
            f.delete()        // removes a symlink itself, never what it points to
            f.writeText(text)
        }
    }

    /** Puts files on disk for the extractor. Permissions matter: Linux programs need their execute bits. */
    private class AndroidSink(private val root: File) : FileSink {
        private fun f(p: String) = File(root, p)

        override fun dir(path: String, mode: Int) {
            val d = f(path)
            if (!d.isDirectory && !d.mkdirs()) throw IOException("Cannot create folder $path")
            Os.chmod(d.path, mode and 0xfff)
        }

        override fun file(path: String, mode: Int): OutputStream {
            val t = f(path)
            t.parentFile?.mkdirs()
            t.delete()
            val out = FileOutputStream(t)
            Os.chmod(t.path, mode and 0xfff)
            return out
        }

        override fun symlink(path: String, target: String) {
            val t = f(path)
            t.parentFile?.mkdirs()
            t.delete()
            Os.symlink(target, t.path)
        }

        override fun hardlink(path: String, target: String) {
            val src = f(target)
            val t = f(path)
            t.parentFile?.mkdirs()
            t.delete()
            FileInputStream(src).use { i -> FileOutputStream(t).use { o -> i.copyTo(o) } }
            Os.chmod(t.path, Os.stat(src.path).st_mode and 0xfff)
        }
    }

    /** Deletes a folder tree without ever following a symlink out of it. */
    private fun deleteTree(f: File) {
        val st = try { Os.lstat(f.path) } catch (e: ErrnoException) { return }
        if (OsConstants.S_ISDIR(st.st_mode)) {
            try { Os.chmod(f.path, 448) } catch (e: ErrnoException) { /* 448 = 0700 */ }
            f.listFiles()?.forEach { deleteTree(it) }
        }
        f.delete()
    }

    // ---- page --------------------------------------------------------------

    private fun loadPage(token: String) {
        overlay.visibility = View.GONE
        pageLoaded = true
        web.loadUrl("$BASE?t=$token")
    }

    // ---- problems ----------------------------------------------------------

    private fun tail(f: File, max: Int = 3000): String = try {
        val s = f.readText()
        if (s.length > max) s.substring(s.length - max) else s
    } catch (e: Exception) {
        "(no log yet)"
    }

    private fun showProblem(text: String) {
        val proot = tail(File(filesDir, "proot.log"))
        val server = tail(File(rootfs, "root/.nami-mobile/server.log"))
        lastLog = "$text\n\n== proot.log ==\n$proot\n\n== server.log ==\n$server"
        status.text = "Nami could not start.\n$text"
        logView.text = lastLog
        bar.visibility = View.GONE
        logScroll.visibility = View.VISIBLE
        buttons.visibility = View.VISIBLE
        overlay.visibility = View.VISIBLE
    }

    private fun showStatus(text: String, percent: Int?) {
        status.text = text
        logScroll.visibility = View.GONE
        buttons.visibility = View.GONE
        if (percent == null) {
            bar.isIndeterminate = true
        } else {
            bar.isIndeterminate = false
            bar.progress = percent
        }
        bar.visibility = View.VISIBLE
        overlay.visibility = View.VISIBLE
    }

    private fun copyLog() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Nami log", lastLog))
    }

    private fun confirmReset() {
        AlertDialog.Builder(this)
            .setTitle("Delete Nami's Linux?")
            .setMessage("This removes everything inside it: installed agents, files and saved sessions. Nami sets itself up again afterwards.")
            .setPositiveButton("Delete") { _, _ -> reset() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun reset() {
        if (busy) return
        busy = true
        showStatus("Deleting…", null)
        stopService(Intent(this, NamiService::class.java))
        thread {
            Thread.sleep(1500)
            deleteTree(rootfs)
            deleteTree(File(filesDir, "rootfs.new"))
            ui.post { busy = false; start() }
        }
    }

    // ---- UI ----------------------------------------------------------------

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = FrameLayout(this)
        root.setBackgroundColor(CREAM)

        web = WebView(this)
        web.setBackgroundColor(CREAM)
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true            // keeps the token, theme and text size between launches
        s.allowFileAccess = false
        s.allowContentAccess = false
        web.addJavascriptInterface(Native(), "NamiNative")
        // The import button in Files opens the system file picker.
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                picker?.onReceiveValue(null)
                picker = cb
                return try {
                    startActivityForResult(params.createIntent(), 77)
                    true
                } catch (e: Exception) {
                    picker = null
                    false
                }
            }
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.host == "127.0.0.1" && u.port == PORT) return false
                // Anything that is not Nami opens in the browser, never inside this window.
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (e: Exception) { /* no browser */ }
                return true
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    pageLoaded = false
                    showProblem("Could not open the Nami page on this phone.")
                }
            }
        }
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        overlay = LinearLayout(this)
        overlay.orientation = LinearLayout.VERTICAL
        overlay.gravity = Gravity.CENTER
        overlay.setBackgroundColor(CREAM)
        overlay.setPadding(dp(24), dp(24), dp(24), dp(24))
        overlay.isClickable = true     // swallow touches so the blank page underneath is not poked

        val mark = TextView(this)
        mark.text = "Nami"
        mark.textSize = 34f
        mark.setTextColor(INK)
        mark.typeface = android.graphics.Typeface.MONOSPACE
        mark.setTypeface(mark.typeface, android.graphics.Typeface.BOLD)
        mark.gravity = Gravity.CENTER
        overlay.addView(mark)

        status = TextView(this)
        status.textSize = 16f
        status.setTextColor(INK)
        status.gravity = Gravity.CENTER
        status.setPadding(0, dp(14), 0, dp(14))
        overlay.addView(status)

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 100
        bar.isIndeterminate = true
        overlay.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        logView = TextView(this)
        logView.textSize = 11f
        logView.setTextColor(INK)
        logView.typeface = android.graphics.Typeface.MONOSPACE
        logView.setTextIsSelectable(true)
        logScroll = ScrollView(this)
        logScroll.addView(logView)
        logScroll.visibility = View.GONE
        overlay.addView(logScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        buttons = LinearLayout(this)
        buttons.orientation = LinearLayout.HORIZONTAL
        buttons.gravity = Gravity.CENTER
        buttons.visibility = View.GONE
        for ((label, action) in listOf<Pair<String, () -> Unit>>(
            "Try again" to { start() },
            "Copy log" to { copyLog() },
            "Reset" to { confirmReset() },
        )) {
            val b = Button(this)
            b.text = label
            b.setOnClickListener { action() }
            buttons.addView(b)
        }
        overlay.addView(buttons)

        root.addView(overlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        window.statusBarColor = CREAM
        window.navigationBarColor = CREAM
        setContentView(root)
    }

    /** What the page may ask of the app. Only pages from this phone's own server are ever loaded here. */
    inner class Native {
        /** The server's token, read from the Linux's files, so the page never shows its token screen. */
        @JavascriptInterface
        fun token(): String = readToken() ?: ""

        /** Saves a file from the Nami server (an address on this phone only) to the Downloads folder. */
        @JavascriptInterface
        fun download(address: String, name: String) {
            val u = try { URL(address) } catch (e: Exception) { return }
            if (u.host != "127.0.0.1" || u.port != PORT) return
            val clean = name.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_").trim().ifEmpty { "download" }
            thread {
                try {
                    val c = u.openConnection() as HttpURLConnection
                    c.connectTimeout = 10000
                    c.readTimeout = 60000
                    val out: OutputStream
                    var uri: Uri? = null
                    if (Build.VERSION.SDK_INT >= 29) {
                        val v = ContentValues()
                        v.put(MediaStore.Downloads.DISPLAY_NAME, clean)
                        v.put(MediaStore.Downloads.RELATIVE_PATH, "Download/Nami")
                        uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                        out = contentResolver.openOutputStream(uri!!)!!
                    } else {
                        val dir = getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS) ?: filesDir
                        dir.mkdirs()
                        out = FileOutputStream(File(dir, clean))
                    }
                    out.use { o -> c.inputStream.use { it.copyTo(o) } }
                    ui.post { android.widget.Toast.makeText(this@MainActivity, "Saved: Download/Nami/$clean", android.widget.Toast.LENGTH_LONG).show() }
                } catch (e: Exception) {
                    ui.post { android.widget.Toast.makeText(this@MainActivity, "Could not save: ${e.message}", android.widget.Toast.LENGTH_LONG).show() }
                }
            }
        }

        /** "Your agent finished": a notification that opens Nami. Only the page can ask, and only about its own sessions. */
        @JavascriptInterface
        fun notify(title: String, text: String) {
            try {
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                val open = PendingIntent.getActivity(this@MainActivity, 0, Intent(this@MainActivity, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                    if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE else PendingIntent.FLAG_UPDATE_CURRENT)
                val b: Notification.Builder
                if (Build.VERSION.SDK_INT >= 26) {
                    nm.createNotificationChannel(NotificationChannel("nami_done", "Session finished", NotificationManager.IMPORTANCE_DEFAULT))
                    b = Notification.Builder(this@MainActivity, "nami_done")
                } else {
                    @Suppress("DEPRECATION")
                    b = Notification.Builder(this@MainActivity)
                }
                b.setSmallIcon(android.R.drawable.stat_notify_chat).setContentTitle(title.take(80)).setContentText(text.take(160)).setContentIntent(open).setAutoCancel(true)
                nm.notify((System.currentTimeMillis() % 100000).toInt() + 100, b.build())
            } catch (e: Exception) { /* a missed notification is not worth a crash */ }
        }

        @JavascriptInterface
        fun listen() { runOnUiThread { startListening() } }

        @JavascriptInterface
        fun stopListening() { runOnUiThread { recognizer?.stopListening() } }

        @JavascriptInterface
        fun paste(): String {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip ?: return ""
            if (clip.itemCount == 0) return ""
            return clip.getItemAt(0).coerceToText(this@MainActivity)?.toString() ?: ""
        }
    }
}
