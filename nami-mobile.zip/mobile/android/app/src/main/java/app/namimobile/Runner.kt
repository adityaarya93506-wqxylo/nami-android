package app.namimobile

import android.content.Context
import android.content.Intent
import android.os.Build
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Asks Nami's Linux to run a command in a new session (used by the home-screen widget and by Tasker). */
object Runner {
    fun token(ctx: Context): String = try { File(ctx.filesDir, "rootfs/root/.nami-mobile/token").readText().trim() } catch (e: Exception) { "" }

    private fun post(token: String, cmd: String): Boolean = try {
        if (token.isEmpty()) false else {
            val c = URL("http://127.0.0.1:${MainActivity.PORT}/__run").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 3000; c.readTimeout = 10000
            c.setRequestProperty("x-nami-token", token)
            c.outputStream.use { it.write(cmd.toByteArray()) }
            val ok = c.responseCode == 200
            c.disconnect(); ok
        }
    } catch (e: Exception) { false }

    /** Runs the command; if the Linux is not up, starts it and waits (up to about 45 seconds). Call off the main thread. */
    fun run(ctx: Context, cmd: String): Boolean {
        if (post(token(ctx), cmd)) return true
        try {
            val svc = Intent(ctx, NamiService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(svc) else ctx.startService(svc)
        } catch (e: Exception) { return false }
        for (i in 0 until 45) {
            Thread.sleep(1000)
            if (post(token(ctx), cmd)) return true
        }
        return false
    }
}
