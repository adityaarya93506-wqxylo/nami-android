// Nami — Electron main process.
// Owns: the window, PTY terminal sessions,
// the open folder + its .claude scan, restart-proof state, and all IPC.

const { app, BrowserWindow, ipcMain: electronIpc, dialog, shell, clipboard, protocol, Menu, nativeImage } = require('electron');
const path = require('path');
const os = require('os');
const fs = require('fs');
const { pathToFileURL } = require('url');
const { rememberBins, knownBin, resolveClaudeExecutable, resolveRunCommand, withSpawnFlags } = require('./bin-cache');
const { claudeSpawnArgs, projectSlug, shellQuote } = require('./claude-args');
const { readTailTitle } = require('./session-title');
const { wireAcpLive } = require('./acp-live');
const { agentForCommand, resumeCommand, sessionExists, startDiscovery, readSessionTitle } = require('./agent-resume.js');
const { feedOscTitle } = require('./osc-title');
const { installAppMenu, buildWindowsExtrasTemplate, editContextTemplate } = require('./app-menu.js');
const { oneShotArgs, feedRunDone } = require('./run-done');
const { startSeedGate } = require('./seed-gate');
const { seedAgentForLaunch, initialPromptArgs, initialPromptEnv, seedHeld, withPromptArgs } = require('./seed-launch');
const { reachesCmd, shimSafe, shimSafeArgs, directLaunch } = require('./cmd-shim');
const { realProgram } = require('./real-program');
const { readLiveSession, liveSessionChanged } = require('./session-registry');
const { buildChildEnv, terminalLaunchPolicy, customAgents, redactChildError } = require('./session-env');
const { detectAgents, agentStatus, findOnDisk, agentRunCommandAllowed } = require('./agents-detect');
const { handles: opensHere, chooseTarget, chooseFolderTarget } = require('./open-with');
const { launchArgs, fromHandoff } = require('./launch-args');
const { statToken } = require('./path-stat');
const { planRemoval, removeAgent } = require('./agent-remove');
const { KNOWN_SERVICES, serviceById } = require('./services-catalog');
const { upsertMcpJson, upsertOpencode, removeService, detectServices, knownFiles } = require('./mcp-config');
const { readMaster, upsertMaster, removeMaster, deliveryPlan, notebookTargets, readNotebooks, coverage, writeCodexBlock, validServiceId } = require('./connections');
const { runPlan } = require('./connections-deliver');
const { checkServer } = require('./mcp-check');
const { execFile } = require('child_process');
const { scanLibrary, createItem, duplicateItem, deleteItem, extractEdges } = require('./library');
const { deliverAgents, deliveryState, liftToMaster, importToMaster, sweepCopies } = require('./agent-master');
const { writePointers, pointerStatus, linkNative, hasForeignSkillsSection, POINTER_FILE } = require('./pointer.js');
const fsActions = require('./fs-actions');
const { createDirWatch } = require('./dir-watch');
const { fmtSize, listDirectory, readTree } = require('./workspace-tree');
const { ptyCwd } = require('./pty-cwd');
const { reportingArgs, feedCwd } = require('./shell-integration');
const { findPwsh } = require('./pwsh-find');
const settingsStore = require('./settings');
const { migrateRecents, sortRecents, rememberFolderIn, setPinnedIn, removeFrom } = require('./recents');
const { windowChrome, paneShell, scriptArgs, spawnPlan } = require('./platform');
const { seedStartHere } = require('./start-here');
const { rememberedWindows } = require('./window-memory');
const { userPath, refreshUserPath } = require('./user-path');
const { exitNote } = require('./exit-note');
const { checkForUpdate, updateStatus } = require('./update-check');
const { sendPing } = require('./ping');
const { downloadUpdate, installNow, hasStagedFile, updaterState } = require('./updater');
const { parseDocUrl, resolveWithinRoot } = require('./doc-protocol');
const { serveDocFile } = require('./doc-response');
const { browserFileUrl } = require('./browser-file');
const { wireBrowserViews } = require('./browser-views');
const stt = require('./stt');

// nami-doc:// — how a viewed HTML page and its neighbouring images are served.
//
// A standard, secure scheme so the page gets a real origin of its own, which is
// what lets an <iframe sandbox="allow-scripts allow-same-origin"> load its
// relative files while staying cross-origin to Nami's file:// renderer — it can
// paint itself but cannot read window.parent. Must be declared before the app is
// ready; the handler that answers requests is installed once it is (below).
protocol.registerSchemesAsPrivileged([{
  scheme: 'nami-doc',
  privileges: { standard: true, secure: true, stream: true, supportFetchAPI: false, corsEnabled: false },
}]);

const { documentPolicy } = require('./doc-policy');

function installDocProtocol() {
  protocol.handle('nami-doc', async (request) => {
    const parsed = parseDocUrl(request.url);
    if (!parsed) return new Response('bad request', { status: 400 });
    const file = resolveWithinRoot(parsed.root, parsed.rel);
    // null means the path escaped its folder — refuse, do not explain.
    if (!file) return new Response('not found', { status: 404 });
    return serveDocFile(file, request, documentPolicy(parsed.root));
  });
}

let pty = null;
try { pty = require('@lydell/node-pty'); } catch (_) { try { pty = require('node-pty'); } catch (_) {} }

process.on('uncaughtException', (err) => { console.error('[main] uncaught:', err && err.stack || err); });

const DEMO = process.argv.includes('--demo');
const SHOT_IDX = process.argv.indexOf('--screenshot');
const SHOT_PATH = SHOT_IDX >= 0 ? process.argv[SHOT_IDX + 1] : null;
const SCENE = (process.argv.find((a) => a.startsWith('--scene=')) || '').split('=')[1] || null;

// Screenshot runs open behind whatever the user has on screen; macOS then stops
// compositing the occluded window and capturePage returns a frozen frame from
// seconds ago (paper theme, no scene). Keep the renderer drawing regardless.
if (SHOT_PATH) {
  app.commandLine.appendSwitch('disable-backgrounding-occluded-windows');
  app.commandLine.appendSwitch('disable-renderer-backgrounding');
}

// `productName: Nami` resolves the same packaged and unpackaged, so a dev run and the
// installed Nami.app would otherwise share one userData — the same state.json (recents,
// open windows) and settings.json (theme, API keys, mode 0600). That makes the shipped
// app impossible to daily-drive while developing, and makes a clean first launch
// impossible to see at all without deleting your own config. Development gets its own
// directory instead. Must run before anything reads userData, hence module scope.
// --user-data <dir> gives a run its own profile — two dev sessions sharing
// Nami-dev otherwise restore each other's desks into every screenshot. Review
// flags default to a disposable profile. An explicit --user-data must also be
// disposable for review: it is used as supplied and is never deleted by Nami.
const { createReviewProfile } = require('./review-profile');
const reviewProfile = createReviewProfile({
  argv: process.argv, normalPath: app.getPath('userData'), packaged: app.isPackaged,
  reviewBuild: require('../../package.json').name === 'nami-review',
});
app.setPath('userData', reviewProfile.path);
const REVIEW = reviewProfile.review;

// One Nami per profile, on Windows. There a file opened with Nami, and a second
// double-click on the icon, both start a whole new process with the path in
// its argv. The lock turns that second process into a messenger: it hands over
// what it was asked to open and leaves, and the running app opens it (see
// 'second-instance' below). It reads its own command line and sends the answer,
// because the argv Electron relays has had its switches reordered by Chromium.
// Must sit after setPath: the lock is keyed on userData, which is what lets a
// dev run, the installed app and a review profile each keep their own.
//
// Windows only, on purpose. macOS already runs one Nami per bundle and delivers
// files as open-file events, so the lock would add nothing there and take two
// things away: a second `npm start`, and a second run against a --review
// profile, both of which share a userData and both of which work today. A
// screenshot or demo run is a tool that must finish, so it never yields either.
const ONE_INSTANCE = process.platform === 'win32' && !SHOT_PATH && !DEMO;
const statPath = (p) => fs.statSync(p);
const LAUNCH = ONE_INSTANCE
  ? launchArgs({ argv: process.argv, cwd: process.cwd(), isPackaged: app.isPackaged, stat: statPath })
  : { files: [], folders: [] };
if (ONE_INSTANCE && !app.requestSingleInstanceLock(LAUNCH)) {
  console.log('[launch] handed to the running Nami:', LAUNCH.files.length, 'file(s),', LAUNCH.folders.length, 'folder(s)');
  app.exit(0);
}

// Nami's own working folder, on Windows, is the home folder from here on.
//
// Opened from a file in Explorer, the process starts life inside that file's
// folder — a repo someone just cloned, a Downloads folder. Windows looks in the
// current folder for every program started by bare name, and ahead of PATH, so
// a powershell.exe or a git.cmd lying in that folder would be the one that ran.
// The shells are started by full path now (platform.js) and cmd.exe is told not
// to look there (spawnPlan); this is the same door shut from the other side,
// for whatever is started by name that nobody has thought of yet. It also lets
// go of the folder, which Windows will not rename or delete while a process
// sits in it.
//
// It has to come after LAUNCH above: a relative argument (`nami .`) is read
// against the folder the launch came from. A screenshot run is left where it
// was, because it writes to a path given relative to there. A Mac is left
// alone: launchd starts an app in /, and nothing there searches the cwd.
if (process.platform === 'win32' && !SHOT_PATH) {
  try { process.chdir(os.homedir()); } catch (_) { /* a home folder that is gone costs nothing here */ }
}

let win = null;                   // most recently created window (fallback target)
const wins = new Set();           // every open window — each is its own project space
const { trustedAppSender, trustedIpc } = require('./trusted-ipc');
const appDocumentUrl = require('node:url').pathToFileURL(path.join(__dirname, '..', 'renderer', 'index.html')).href;
const ipcMain = trustedIpc(electronIpc, event => trustedAppSender(event, wins, appDocumentUrl));
// Only the guest modules receive raw events, and each checks its exact sender.
const browserIpc = { handle: ipcMain.handle, on: electronIpc.on.bind(electronIpc) };
const windowThemes = new Map();
const winFolders = new Map();     // webContents.id -> folder that window works in
const sessionOwners = new Map();  // session id -> webContents.id, so closing a window reaps its sessions
const termSessions = new Map();   // id -> pty
// Sessions Nami is ending on purpose — quit, window close, tile close. pty.kill()
// sends SIGHUP, which surfaces as exit 129, and without this the tile cannot tell
// "you closed me" from "I died". Recorded before the kill, read in onExit.
const deliberateKills = new Set();

// Every intentional teardown goes through here, so the exit note stays honest.
function killSession(id) {
  const p = termSessions.get(id);
  if (!p) return false;
  deliberateKills.add(id);
  try { p.kill(); } catch (_) {}
  termSessions.delete(id);
  return true;
}

// ---- state (restart-proof) -------------------------------------------------
function stateFile() { return path.join(app.getPath('userData'), 'state.json'); }
let state = { recentFolders: [], currentFolder: null, panels: [], panelsByFolder: {}, windows: [] };
function loadState() {
  try { state = Object.assign(state, JSON.parse(fs.readFileSync(stateFile(), 'utf8'))); } catch (_) {}
  if (!state.panelsByFolder || typeof state.panelsByFolder !== 'object') state.panelsByFolder = {};
  if (!Array.isArray(state.windows)) state.windows = [];
  // pre-multi-window states kept a single desk in `panels`
  if (Array.isArray(state.panels) && state.panels.length && state.currentFolder && !state.panelsByFolder[state.currentFolder]) {
    state.panelsByFolder[state.currentFolder] = state.panels;
  }
  // recentFolders used to be a bare path list; it now carries when it was last
  // opened and whether it is pinned, so the popover can sort and label rows.
  state.recentFolders = migrateRecents(state.recentFolders);
}
const folderKey = (f) => f || '__no_folder__';
function panelsFor(folder) { const p = state.panelsByFolder[folderKey(folder)]; return Array.isArray(p) ? p.slice(0, 12) : []; }
let saveTimer = null;
function persist(partial) {
  if (partial) state = Object.assign(state, partial);
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      fs.mkdirSync(path.dirname(stateFile()), { recursive: true });
      fs.writeFileSync(stateFile() + '.tmp', JSON.stringify(state, null, 2));
      fs.renameSync(stateFile() + '.tmp', stateFile());
    } catch (_) {}
  }, 250);
}

// ---- settings (how the app behaves: theme, model, transcription) ------------
// Every write merges and renames — see settings.js for why.
function settingsFile() { return path.join(app.getPath('userData'), 'settings.json'); }
function readSettings() { return settingsStore.readSettings({ file: settingsFile() }); }
function writeSettings(patch) { return settingsStore.writeSettings({ file: settingsFile(), patch }); }

function sendWc(wc, channel, payload) { if (wc && !wc.isDestroyed()) wc.send(channel, payload); }

// ---- folder helpers --------------------------------------------------------
function homeShort(p) { const h = os.homedir(); return p && p.startsWith(h) ? '~' + p.slice(h.length) : p; }
function baseName(p) { return String(p || '').split(/[\\/]/).filter(Boolean).pop() || ''; }

function scanFolder(folder) {
  const info = { path: folder, pathShort: homeShort(folder), name: baseName(folder) || folder, tree: [], agents: [], skills: [], hasClaude: false };
  try {
    const claudeDir = path.join(folder, '.claude');
    info.hasClaude = fs.existsSync(claudeDir);
    // agents
    const agentsDir = path.join(claudeDir, 'agents');
    if (fs.existsSync(agentsDir)) {
      for (const f of fs.readdirSync(agentsDir)) {
        if (!f.endsWith('.md')) continue;
        const full = path.join(agentsDir, f);
        const meta = readFrontmatter(full);
        info.agents.push({
          slug: f.replace(/\.md$/, ''),
          name: meta.name || f.replace(/\.md$/, ''),
          desc: meta.description || '',
          tools: meta.tools || '',
        });
      }
    }
    // skills
    const skillsDir = path.join(claudeDir, 'skills');
    if (fs.existsSync(skillsDir)) {
      for (const d of fs.readdirSync(skillsDir)) {
        const skillMd = path.join(skillsDir, d, 'SKILL.md');
        if (fs.existsSync(skillMd)) {
          const meta = readFrontmatter(skillMd);
          info.skills.push({ slug: d, name: meta.name || d });
        }
      }
    }
    // shallow tree (top level)
    info.tree = readTree(folder, 0, 2);
  } catch (_) {}
  return info;
}

function readFrontmatter(file) {
  try {
    const txt = fs.readFileSync(file, 'utf8').slice(0, 4000);
    const m = txt.match(/^---\s*\n([\s\S]*?)\n---/);
    const out = {};
    if (m) {
      for (const line of m[1].split('\n')) {
        const mm = line.match(/^(\w[\w-]*):\s*(.*)$/);
        if (mm) out[mm[1]] = mm[2].replace(/^["']|["']$/g, '').trim();
      }
    }
    return out;
  } catch (_) { return {}; }
}

function rememberFolder(folder) {
  state.recentFolders = rememberFolderIn(state.recentFolders || [], folder, Date.now());
  state.currentFolder = folder;
  persist();
  broadcastRecents();
}

// The list lives in main but every window renders its own copy, so a change in
// one window has to reach the others or their popovers show a stale order.
function recentsForRenderer() {
  return sortRecents(state.recentFolders || []).map((r) => ({
    path: r.path, pathShort: homeShort(r.path), name: baseName(r.path),
    at: r.at, pinned: !!r.pinned, missing: !fs.existsSync(r.path),
  }));
}
function broadcastRecents() {
  const rows = recentsForRenderer();
  for (const w of wins) sendWc(w.webContents, 'recents:changed', rows);
  refreshAppMenu();   // File > Open Recent is this same list
}

// ---- the application menu --------------------------------------------------
// Two things in it are state, so the menu is rebuilt rather than built once:
// Open Recent is the recents list, and View > Theme ticks the saved theme.
// Both change while the app runs, and a menu is a snapshot of the moment it was
// installed.
//
// Every Nami item sends a string to the window you are looking at. The focused
// window and not all of them: two windows are two project spaces, and ⌘N in one
// must not open a launcher in the other. `win` is the fallback for the moment
// between a window closing and the next taking focus.
function menuSend(cmd) {
  const w = BrowserWindow.getFocusedWindow() || win;
  if (w) sendWc(w.webContents, 'menu:command', cmd);
}
function refreshAppMenu(focusedWindow = BrowserWindow.getFocusedWindow() || win) {
  installAppMenu({
    Menu,
    shell,
    app,
    send: menuSend,
    newWindow: () => createWindow(null),
    theme: windowThemes.get(focusedWindow?.webContents.id) || settingsStore.normalizeTheme(readSettings().theme),
    // A recents row can outlive its folder, and a menu item that opens nothing
    // is worse than one that is not there.
    recents: recentsForRenderer().filter((r) => !r.missing),
  });
}

// ---- updates ---------------------------------------------------------------
// Ask GitHub what the latest release is; if it beats what is running, tell the
// windows so they can offer it. Notify-only — see update-check.js for why.
//
// Never runs in development: the version in package.json is always behind the
// last published release while working, so every launch would nag about an
// update you are in the middle of building.
const UPDATE_EVERY = 6 * 60 * 60 * 1000;
let lastOffered = null;

async function pollForUpdate() {
  const found = await checkForUpdate({ currentVersion: app.getVersion() });
  if (!found) return;
  lastOffered = found;
  for (const w of wins) sendWc(w.webContents, 'update:available', found);
}

function startUpdatePolling() {
  if (!app.isPackaged || REVIEW) return;
  // A beat after launch, not during it — the first seconds belong to the window.
  setTimeout(pollForUpdate, 8000).unref?.();
  setInterval(pollForUpdate, UPDATE_EVERY).unref?.();
}

// ---- window ----------------------------------------------------------------
// Quit used to restore `state.currentFolder` — one slot, so three open windows
// came back as one and which one you got was "whichever folder was touched
// last". `state.windows` records what is open right now instead, so a relaunch
// reopens each window on its own folder, where you left it. A window you close
// on purpose drops out of the list and does not come back.
let winSnapTimer = null;
let lastClosedWindow = null;        // see window-memory.js: off the Mac, closing the last window is quitting
function openWindowRecords() {
  return [...wins].filter((w) => !w.isDestroyed()).map((w) => ({
    folder: winFolders.get(w.webContents.id) || null,
    bounds: w.getNormalBounds(),
  }));
}
function snapshotWindows() {
  clearTimeout(winSnapTimer);
  winSnapTimer = setTimeout(() => {
    state.windows = rememberedWindows({ open: openWindowRecords(), lastClosed: lastClosedWindow });
    persist();
  }, 300);
}

// This window is Nami and nothing may replace it. Rendered content — a doc's
// markdown, anything an agent writes — can carry a link, and a bare <a href>
// would otherwise navigate the whole app away with no way back. Web links are
// handed to the browser instead; everything else is simply refused.
function lockNavigation(wc) {
  wc.on('will-navigate', (e, url) => {
    if (url === wc.getURL()) return;
    e.preventDefault();
    if (/^https?:\/\//i.test(url)) shell.openExternal(url);
  });
  wc.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
}

// Each window is its own project space. `folder` sets what it opens with:
// omit it for the last-used folder, pass null for an empty window.
// Finder handing us a file. Registered here, at module scope, because on macOS
// a cold start fires this *before* whenReady — the path arrives while there is
// no window, no state, nothing to open it into. Those buffer in coldOpens and
// drain at the end of whenReady, once the saved windows are back.
const coldOpens = [];
app.on('open-file', (e, filePath) => {
  e.preventDefault();          // or macOS treats the file as unhandled
  if (!app.isReady()) { coldOpens.push(filePath); return; }
  routeOpenFile(filePath);
});

// The path from a file to a desk. chooseTarget picks the pair; this only
// carries out what it decided. See open-with.js for the four cases.
function routeOpenFile(filePath) {
  if (!filePath || !opensHere(filePath)) return;
  const live = [...wins].filter((w) => !w.isDestroyed());
  const focused = BrowserWindow.getFocusedWindow() || win;
  const target = chooseTarget({
    filePath,
    windows: live.map((w) => ({ id: w.webContents.id, folder: winFolders.get(w.webContents.id) || null })),
    focusedId: focused && !focused.isDestroyed() ? focused.webContents.id : null,
  });
  if (target.action === 'new-window') { sendOpen(createWindow(target.folder), filePath, target.folder, false); return; }
  const w = live.find((x) => x.webContents.id === target.id);
  if (!w) { sendOpen(createWindow(target.folder), filePath, target.folder, false); return; }
  if (w.isMinimized()) w.restore();
  w.focus();
  sendOpen(w, filePath, target.folder, target.action === 'adopt');
}

// The Windows road to the same place. A path on the command line is a file, which
// takes the route above exactly as one from Finder does, or a folder
// (`Nami.exe C:\work`), which is the desk already open on it or a new window —
// never somebody else's desk switched underneath them. Returns whether anything
// was opened, so a launch that asked for nothing can just bring Nami forward.
function routeOpenFolder(folder) {
  const live = [...wins].filter((w) => !w.isDestroyed());
  const focused = BrowserWindow.getFocusedWindow() || win;
  const target = chooseFolderTarget({
    folder,
    windows: live.map((w) => ({ id: w.webContents.id, folder: winFolders.get(w.webContents.id) || null })),
    focusedId: focused && !focused.isDestroyed() ? focused.webContents.id : null,
  });
  if (target.action === 'replace-empty') {
    // The new window first, in the old one's place, so there is never a moment
    // with no windows — which off a Mac is the moment Nami quits.
    const old = live.find((x) => x.webContents.id === target.id);
    createWindow(folder, old ? old.getNormalBounds() : undefined);
    if (old && !old.isDestroyed()) old.close();
    return;
  }
  const w = target.action === 'here' ? live.find((x) => x.webContents.id === target.id) : null;
  if (!w) { createWindow(folder); return; }
  if (w.isMinimized()) w.restore();
  w.focus();
}
function routeLaunch(asked) {
  const files = asked.files.filter((f) => opensHere(f));
  for (const folder of asked.folders) routeOpenFolder(folder);
  for (const filePath of files) routeOpenFile(filePath);
  return asked.folders.length + files.length > 0;
}

// A second Nami was started and has already left; this is what it was asked to
// open. `handed` is its own reading of its own command line (see ONE_INSTANCE
// above) and is checked again here, since it crossed a process boundary. argv
// is the fallback for a sender that handed nothing over.
app.on('second-instance', (_e, argv, cwd, handed) => {
  const asked = handed && typeof handed === 'object'
    ? fromHandoff(handed, { stat: statPath })
    : launchArgs({ argv, cwd, isPackaged: app.isPackaged, stat: statPath });
  console.log('[launch] second instance:', asked.files.length, 'file(s),', asked.folders.length, 'folder(s)');
  if (!app.isReady()) { LAUNCH.files.push(...asked.files); LAUNCH.folders.push(...asked.folders); return; }
  if (routeLaunch(asked)) return;
  // Nothing to open: the icon was clicked again. Show them the Nami they have.
  const w = (win && !win.isDestroyed()) ? win : [...wins].find((x) => !x.isDestroyed());
  if (!w) { createWindow(); return; }
  if (w.isMinimized()) w.restore();
  w.focus();
});

// One send, three callers: the cold start, a window made for the file, and the
// switch sheet's "open in a new window". A window that has not finished loading
// has no listener yet, so the message waits for the load rather than vanishing.
function sendOpen(w, filePath, folder, adopt) {
  if (!w || w.isDestroyed() || !opensHere(filePath)) return;
  const msg = { filePath, folder, adopt: !!adopt };
  const send = () => { if (!w.isDestroyed()) w.webContents.send('open:file', msg); };
  if (w.webContents.isLoading()) w.webContents.once('did-finish-load', send);
  else send();
}

function createWindow(folder, bounds) {
  const w = new BrowserWindow({
    // The floor is what the layout survives, not what looks best: below 560 the
    // tile head runs out of room even with its controls dropped. Nami is often a
    // side pane next to an editor, so the old 1040 floor — wider than half a
    // laptop screen — made that impossible. See the narrow-window media queries
    // at the foot of paper.css.
    width: 1360, height: 940, minWidth: 560, minHeight: 480,
    ...(bounds && Number.isFinite(bounds.width) ? bounds : {}),
    ...windowChrome(process.platform, settingsStore.themeBackground(readSettings().theme)),
    backgroundColor: settingsStore.themeBackground(readSettings().theme),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, plugins: true },
  });
  browserViews.bindWindow(w);
  const wcId = w.webContents.id;
  wins.add(w); win = w;
  windowThemes.set(wcId, settingsStore.normalizeTheme(readSettings().theme));
  w.on('focus', () => refreshAppMenu(w));
  winFolders.set(wcId, folder === undefined ? state.currentFolder : folder);
  lockNavigation(w.webContents);
  w.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
  w.on('resize', snapshotWindows);
  w.on('move', snapshotWindows);
  // Native fullscreen hides the traffic lights, so the renderer collapses the
  // deck it reserves for them; it needs to hear both edges of the transition.
  w.on('enter-full-screen', () => w.webContents.send('window:fullscreen', true));
  w.on('leave-full-screen', () => w.webContents.send('window:fullscreen', false));
  // Windows only, and only where the page has not answered the right-click
  // itself: Cut, Copy and Paste by mouse, which on a Mac is the Edit menu.
  w.webContents.on('context-menu', (_e, params) => {
    const template = editContextTemplate(params);
    // At the click, which the event reports, rather than wherever the pointer
    // is by the time this runs — the two differ whenever the click was not made
    // by the pointer: a touch, a pen, a screen reader, an automated test.
    if (template) Menu.buildFromTemplate(template).popup({ window: w, x: params.x, y: params.y });
  });
  // Read while the window still exists: by 'closed' its bounds and its folder
  // are both gone, and on Windows that is the moment they are needed most.
  w.on('close', () => { lastClosedWindow = { folder: winFolders.get(wcId) || null, bounds: w.getNormalBounds() }; });
  w.on('closed', () => {
    wins.delete(w);
    windowThemes.delete(wcId);
    winFolders.delete(wcId);
    reapSessions(wcId);
    if (win === w) win = [...wins].pop() || null;
    snapshotWindows();
  });
  snapshotWindows();

  if (SHOT_PATH && wins.size === 1) {
    w.webContents.on('did-finish-load', async () => {
      // a --scene= shot has to wait out the library scan before the surface is real
      const zi = process.argv.indexOf('--zoom');
      if (zi >= 0) w.webContents.setZoomFactor(Number(process.argv[zi + 1]));
      await new Promise((r) => setTimeout(r, (SCENE ? 2600 : (DEMO ? 1400 : 700)) + Number(process.env.SHOT_WAIT || 0)));
      // capturePage can grab a stale (blank) compositor frame; force a repaint
      // and give it a beat, or roughly one shot in three comes back empty
      w.webContents.invalidate();
      await new Promise((r) => setTimeout(r, 350));
      try {
        if (process.env.SHOT_DEBUG) {
          const probe = await w.webContents.executeJavaScript(process.env.SHOT_DEBUG);
          console.log('[shot-debug]', JSON.stringify(probe));
        }
        const png = await require('./window-capture').captureWindow(w, new Map(w.contentView.children.filter(view => view.webContents && view.webContents !== w.webContents).map((view, i) => [i, { window:w, view }])));
        fs.mkdirSync(path.dirname(path.resolve(SHOT_PATH)), { recursive: true });
        fs.writeFileSync(path.resolve(SHOT_PATH), png);
        console.log('screenshot →', path.resolve(SHOT_PATH));
      } catch (e) { console.error('shot failed', e); }
      setTimeout(() => app.quit(), 300);
    });
  }
  return w;
}

// A closing window takes its live sessions with it (same as quit does for all).
function reapSessions(wcId) {
  for (const [id, owner] of [...sessionOwners]) {
    if (owner !== wcId) continue;
    sessionOwners.delete(id);
    killSession(id);
  }
}

app.whenReady().then(() => {
  loadState();
  // Before any window: the menu belongs to the app, and setting it after a
  // window exists makes the first one flash the stock menu bar.
  refreshAppMenu();
  // No menu item opens the stock About panel any more, but macOS can still
  // reach it, and it was saying the wrong thing: electron-builder derives
  // NSHumanReadableCopyright from `author` when the yml does not set
  // `copyright`, so a company's app credited a person. Fixed in both places,
  // here for the panel and in electron-builder.yml for the bundle.
  //
  // The year is written out rather than taken from the clock. A copyright year
  // belongs to the release, not to whenever the machine happens to be running
  // it.
  app.setAboutPanelOptions({
    applicationName: 'Nami',
    applicationVersion: app.getVersion(),
    copyright: 'Copyright © 2026 Dainami AI',
    credits: 'AI agent workbench, by Dainami',
  });
  installDocProtocol();  // serve viewed HTML + its assets from nami-doc://
  // Ask the login shell for the real PATH now, so the answer is already waiting
  // when the first session spawns. Deliberately not awaited: a slow .zshrc must
  // delay a terminal, never the window.
  userPath({ settings: readSettings() });
  // point the on-device engine at its weights, then warm the session in the
  // background so the first dictation isn't the slow one
  try {
    const engine = require('./stt-local');
    engine.configure({ dir: sttModelDir() });
    setTimeout(() => engine.warm(stt.sttConfig(readSettings(), process.env)), 1500);
  } catch (e) { console.error('[stt] local engine unavailable:', e.message); }
  // Screenshot and demo runs want exactly one predictable window, never the
  // desk the developer happened to leave open.
  const restore = (!SHOT_PATH && !DEMO && state.windows.length) ? state.windows.slice(0, 8) : null;
  if (restore) for (const w of restore) createWindow(w.folder || null, w.bounds);
  // `Nami.exe C:\work` with nothing to restore: that folder is the window, so
  // the usual one on the last-used folder would only be a second, unasked-for.
  else if (!LAUNCH.folders.length) createWindow();
  if (process.argv.includes('--second-window')) createWindow(null); // dev: multi-window smoke test
  startUpdatePolling();
  // The silent ping — anonymous "launched today" note, deduped server-side to
  // one per user per day. Not awaited: a launch never waits on the network,
  // and sendPing resolves (never rejects) whatever happens. See ping.js.
  sendPing({
    settings: readSettings(), saveSettings: writeSettings,
    isPackaged: app.isPackaged, env: process.env,
    version: app.getVersion(), arch: process.arch,
  });
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
  // Anything Finder sent while the app was still starting. Drained last, so
  // the restored windows are already in wins and can be chosen between.
  while (coldOpens.length) routeOpenFile(coldOpens.shift());
  // The same for Windows, where the file or folder came in on the command line
  // (and anything a second launch handed over before there was a window).
  routeLaunch(LAUNCH);
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('before-quit', () => {
  // The snapshot is debounced; quitting mid-debounce would lose the last move
  // or the folder a window switched to a moment ago.
  clearTimeout(winSnapTimer);
  state.windows = rememberedWindows({ open: openWindowRecords(), lastClosed: lastClosedWindow });
  clearTimeout(saveTimer);
  try {
    fs.mkdirSync(path.dirname(stateFile()), { recursive: true });
    fs.writeFileSync(stateFile() + '.tmp', JSON.stringify(state, null, 2));
    fs.renameSync(stateFile() + '.tmp', stateFile());
  } catch (_) {}
  for (const id of [...termSessions.keys()]) killSession(id);
});

// Quit means quit. The window closes at once, but the process was observed
// living another 30 to 140 seconds — native threads (the Whisper engine, pty
// plumbing) keep a dead Electron alive long after the event loop is done. To
// the user that is invisible; to Squirrel it is fatal: install-on-quit waits
// for the process to actually go, and anyone reopening Nami inside that window
// got "App Still Running Error" and no update, with nothing said.
//
// By the time 'quit' fires, everything that matters has already happened —
// state written, sessions killed, the updater's own quit handler run (it
// spawns ShipIt as a separate process, which does not need us alive). The
// timer is unref'd so it never holds a fast exit open; it only fires if the
// process is still here two seconds after it had any reason to be.
app.on('quit', () => {
  try { reviewProfile.cleanup(); } catch (err) { console.error('[review] profile cleanup:', err.message); }
  setTimeout(() => process.exit(0), 2000).unref?.();
});

// ---- IPC: boot + folders ---------------------------------------------------

// Every session map in main (termSessions, sessionOwners, titleWatch) is keyed
// by the panel id the renderer chose — and each renderer numbers its panels from
// 1. Two windows therefore both call their first tile p_1, and main, having no
// way to tell them apart, hands window A's keystrokes to window B's pty and
// reaps A's sessions when B closes a folder. Handing every renderer a unique
// prefix at boot makes the names it invents globally unique, which is all the
// bookkeeping below ever needed.
//
// Counted per boot rather than per window on purpose: webContents.id survives a
// reload while the renderer's counter restarts, so a reloaded window would
// collide with the sessions it just left behind.
let bootSeq = 0;

const browserViews = wireBrowserViews(browserIpc, { readSettings, writeSettings });
const browserOverlays = require('./browser-overlays').wireBrowserOverlays(browserIpc);
let usagePending;
ipcMain.handle('usage:read', async (e) => {
  const w = BrowserWindow.fromWebContents(e.sender);
  if (!w || e.sender !== w.webContents) return { accounts: [] };
  if (usagePending) return usagePending;
  usagePending = (async () => {
    // Reuse Nami's detected binaries. A usage refresh must not launch a fresh
    // interactive login shell for every provider (rc scripts can hang).
    let timer;
    const envPath = await Promise.race([userPath({ settings: readSettings() }), new Promise((resolve) => { timer = setTimeout(() => resolve(process.env.PATH || ''), 2000); })]);
    clearTimeout(timer);
    const agents = await detectAgents({ exec: (bin) => knownBin(bin) || findOnDisk(bin, { env: { ...process.env, PATH: envPath } }) });
    return require('./usage').readUsage({ agents, directory: path.join(app.getPath('userData'), 'usage'), envPath, settings: readSettings() });
  })().finally(() => { usagePending = null; });
  return usagePending;
});

wireAcpLive(ipcMain, { readSettings });
ipcMain.handle('link:open', (_e, url) => {
  if (/^https?:\/\//.test(String(url))) shell.openExternal(String(url));
  return { ok: true };
});

ipcMain.handle('boot', (e) => {
  // each window boots with its own folder; fresh windows fall back to the last-used one
  const folder = winFolders.has(e.sender.id) ? winFolders.get(e.sender.id) : state.currentFolder;
  const ok = folder && fs.existsSync(folder);
  bootSeq += 1;
  return {
    winId: bootSeq,
    // Where `~` is. The renderer used to read it off the front of a path, which
    // works for /Users/you and says nothing about a project on D:\.
    home: os.homedir(),
    // A window opened after the check already ran would otherwise never hear
    // about the update — the event has been and gone.
    update: lastOffered,
    // And a window opened mid-download, or after one finished, would otherwise
    // offer to start a download that is already running or already done.
    // `staged` is the one that survives a restart: a download left in the cache
    // by an earlier run, which nothing would otherwise ever install.
    updater: { ...updaterState(), staged: stagedUpdateWaiting(), sessions: liveSessionCount() },
    // For the About pane. Sent at boot rather than fetched when the tab opens,
    // so opening it costs nothing and shows the truth instantly; the button is
    // the only thing that touches the network.
    version: app.getVersion(),
    updatedAt: appUpdatedAt(),
    demo: DEMO,
    review: REVIEW,
    theme: settingsStore.normalizeTheme(readSettings().theme),
    collapsed: process.argv.includes('--collapsed'),
    // --theme=operator forces a theme for this run (screenshots); not persisted
    themeArg: (process.argv.find((a) => a.startsWith('--theme=')) || '').split('=')[1] || null,
    // Desk or Split, as last saved; the renderer's own localStorage wins when it has one
    view: settingsStore.normalizeView(readSettings().view),
    // --scene=<name> opens one surface on boot so it can be screenshotted; screenshots only
    scene: SCENE,
    // ask the provider registry, not the environment — a key typed into Settings
    // counts just as much as an exported one, and the local engine needs neither
    sttInfo: sttStatus(),
    recentFolders: recentsForRenderer(),
    currentFolder: ok ? scanFolder(folder) : null,
    panels: panelsFor(ok ? folder : null),
  };
});

// Renderer sends its panel layout after every change; restored per folder on next boot.
ipcMain.handle('panels:save', (_e, { panels, folder }) => {
  state.panelsByFolder[folderKey(folder)] = Array.isArray(panels) ? panels.slice(0, 12) : [];
  persist();
  return { ok: true };
});
// A folder switch inside a live window needs the incoming folder's desk without
// a restart — same snapshot boot would have handed it.
ipcMain.handle('panels:load', (_e, folder) => panelsFor(folder));

ipcMain.handle('recents:pin', (_e, { path: p, pinned }) => {
  state.recentFolders = setPinnedIn(state.recentFolders || [], p, pinned);
  persist(); broadcastRecents();
  return recentsForRenderer();
});
ipcMain.handle('recents:remove', (_e, p) => {
  state.recentFolders = removeFrom(state.recentFolders || [], p);
  // Forget the desk too — leaving it behind would resurrect the tiles if the
  // same path is ever opened again, which is not what "remove" looks like.
  delete state.panelsByFolder[folderKey(p)];
  if (state.currentFolder === p) state.currentFolder = null;
  persist(); broadcastRecents();
  return recentsForRenderer();
});

ipcMain.handle('window:new', (_e, args) => {
  const folder = (args && args.folder) || null;
  const w = createWindow(folder);
  // The switch sheet sends the file along: it declined to take over this desk,
  // so the file has to follow into the window that was made for it instead.
  if (args && args.openFile) sendOpen(w, args.openFile, folder, false);
  return { ok: true };
});

// The Nami mark, clicked on Windows: the few menu items with nowhere else to
// live (app-menu.js says which, and why). The renderer sends where the mark is
// in its own pixels; a zoomed page has bigger pixels than the window does.
ipcMain.handle('menu:extras', (e, at) => {
  const w = BrowserWindow.fromWebContents(e.sender);
  if (process.platform !== 'win32' || !w) return { ok: false };
  const zoom = e.sender.getZoomFactor();
  const px = (v) => Math.max(0, Math.round((Number(v) || 0) * zoom));
  Menu.buildFromTemplate(buildWindowsExtrasTemplate({ open: (url) => shell.openExternal(url) }))
    .popup({ window: w, x: px(at && at.x), y: px(at && at.y) });
  return { ok: true };
});

ipcMain.handle('app:version', () => app.getVersion());
// What the About pane shows: which copy this is, and whether it is behind.
//
// `updatedAt` is the app bundle's own timestamp, which macOS stamps when the
// bundle lands in Applications, so it answers "when did I last update this"
// rather than "when was this built" — the same version number can sit on two
// machines that installed it weeks apart. Running from source there is no
// bundle, so the folder's own date stands in.
//
// The check runs even in development, unlike the background poll: the poll is
// switched off there because it would nag about a version you are in the middle
// of writing, but a button somebody pressed should always answer.
function appUpdatedAt() {
  try {
    // .../Nami.app/Contents/MacOS/Nami → .../Nami.app
    const bundle = app.isPackaged
      ? path.resolve(app.getPath('exe'), '..', '..', '..')
      : app.getAppPath();
    return fs.statSync(bundle).mtime.toISOString();
  } catch (_) { return null; }
}

ipcMain.handle('update:status', async () => {
  const st = await updateStatus({ currentVersion: app.getVersion() });
  // A manual check that finds something also re-arms the bar: the renderer
  // clears its "skipped" mark off the back of this, so a version somebody once
  // waved away can be found again.
  if (st.state === 'update') lastOffered = { version: st.version, url: st.url };
  // `version` is always the one running and `latest` the one on offer. They were
  // one field to begin with, and the pane duly announced "Nami 0.1.3, updated
  // tonight" about a copy the user did not have.
  return {
    state: st.state,
    version: app.getVersion(),
    updatedAt: appUpdatedAt(),
    latest: st.version || null,
    url: st.url || null,
  };
});

// Still here, and still the fallback rather than the plan. The updater below
// installs in place; when it cannot, this is what the bar goes back to offering,
// so the worst outcome of a failed update is the app we shipped in 0.1.3.
// Only https — the url arrives from a network response, and shell.openExternal
// will happily run other schemes.
ipcMain.handle('update:open', (_e, url) => {
  const ok = /^https:\/\//i.test(String(url || ''));
  if (ok) shell.openExternal(String(url));
  return { ok };
});

// Download the update the user just accepted, and tell every window how it is
// going. All the windows share one copy of Nami on disk, so they share one
// download and see the same progress — a second window opened halfway through
// asks for the current state at boot rather than starting its own.
ipcMain.handle('update:download', () => downloadUpdate({
  isPackaged: app.isPackaged,
  emit: (channel, payload) => {
    for (const w of wins) sendWc(w.webContents, channel, payload);
  },
}));
ipcMain.handle('update:state', () => updaterState());

// Install it now and come back on the new version, instead of waiting for a
// quit and hoping to beat the user back to the app.
ipcMain.handle('update:install', () => installNow({
  isPackaged: app.isPackaged,
  emit: (channel, payload) => {
    for (const w of wins) sendWc(w.webContents, channel, payload);
  },
}));

// electron-updater's cache dir, which it names from updaterCacheDirName in
// app-update.yml. Only somewhere to look — nothing here writes to it.
function stagedUpdateWaiting() {
  try { return hasStagedFile(path.join(app.getPath('cache'), 'nami-updater')); } catch (_) { return false; }
}

// What an update would end if it happened right now. The renderer says so
// before installing, because an update that silently kills four agents
// mid-thought is the outcome this whole feature was shaped to avoid.
function liveSessionCount() {
  return termSessions.size;
}
ipcMain.handle('update:sessions', () => liveSessionCount());

// Which of the curated agent CLIs are on this Mac (via the user's login shell).
// Every scan writes down where it found each program, because the scan is the
// only code that asks the user's own shell. Everything that spawns an agent
// reads that memo instead of guessing (bin-cache.js says why).
ipcMain.handle('agents:detect', async () => {
  const settings = readSettings();
  const agents = await detectAgents({ settings });
  rememberBins(agents);
  return [...agents, ...customAgents(settings)];
});
// Who is signed in to one of them. Lazy and per-agent — a CLI that hangs must
// never stall the launcher, so every failure lands on signedIn: null.
// storedEnvKeys so a pasted XAI_API_KEY counts as signed in for grok — the
// parser only receives a boolean, never the secret (agent-status.js).
ipcMain.handle('agents:status', (_e, { id } = {}) => agentStatus(id, { envKeys: storedEnvKeys(), settings: readSettings() }));
// Removal is planned before it is done, so the confirm can name real paths.
ipcMain.handle('agents:removalPlan', (_e, { id, binPath } = {}) =>
  planRemoval({ id, binPath, home: os.homedir() }));
ipcMain.handle('agents:remove', (_e, { id, binPath } = {}) =>
  removeAgent({ id, binPath, home: os.homedir() }));

// ---- IPC: connect-a-service -------------------------------------------------
// The catalog goes to the renderer without its entry-builder functions.
function catalogForRenderer() {
  return KNOWN_SERVICES.map((s) => ({ id: s.id, name: s.name, desc: s.desc, code: s.code, kind: s.kind, keys: s.keys, keyHelpUrl: s.keyHelpUrl, docs: s.docs, guide: s.guide }));
}
// CLI delivery steps run the resolved `claude` binary directly with an argv
// array — no login shell, so nothing in an id or entry can be parsed as a
// command. Falls back to the bare name when the bin scan has not run.
// `mcp add-json` carries a connector's JSON, which is other people's text. To
// npm's claude.cmd on Windows it goes round the shim when it can
// (real-program.js) — the claude.exe or the node script behind it, and no
// cmd.exe at all — and through spawnPlan's escaping when it cannot.
function claudeExec(argv) {
  return new Promise((resolve) => {
    const run = realProgram(knownBin('claude') || 'claude');
    const plan = spawnPlan(run.file, [...run.args, ...argv]);
    execFile(plan.file, plan.args, { timeout: 20000, env: buildChildEnv({ settings: readSettings(), purpose: 'agent', agentId: 'claude' }), ...plan.options }, (err) => {
      resolve(err ? { ok: false, error: redactChildError(err, { settings: readSettings() }).split('\n')[0] } : { ok: true });
    });
  });
}
// One connection, one master, copies for every installed agent. The full master
// set is always re-delivered — the codex marker block is regenerated whole, so
// delivering a single entry would silently drop its siblings from that block.
async function deliverConnections({ scope, projectPath, agentIds }) {
  const masters = readMaster({ scope, projectPath, homeDir: os.homedir() });
  if (!Object.keys(masters).length) return [];
  const plan = deliveryPlan({ masters, scope, agentIds: agentIds || [], projectPath, homeDir: os.homedir() });
  return runPlan({ plan, execCmd: claudeExec });
}
// What a delivery looked like, in the words the connect-done sheet shows.
// Windows writes the same home folder in more than one case and ends it at
// either separator, so there the shortening is agents-detect's, which knows.
function shortHome(p) {
  if (process.platform === 'win32') return require('./agents-detect').shortHome(p, os.homedir(), 'win32');
  return String(p || '').replace(os.homedir(), '~');
}
function deliveredNames(results) {
  return results.filter((r) => r.ok).map((r) => (r.via === 'cli' ? r.agent + ' (its own CLI)' : shortHome(r.wrote)));
}
// What an install will take here, asked before it runs: the line for this
// shell, and anything it needs that a PC does not come with (install-plan.js).
// Programs are looked for on the PATH a tile is given, not on Nami's own.
const { installPlan } = require('./install-plan');
ipcMain.handle('install:plan', (_e, { connectorId, agentId } = {}) => installPlan({
  connectorId, agentId, home: os.homedir(), shell: paneShell(process.platform, process.env),
  exists: (p) => fs.existsSync(p), refresh: refreshUserPath,
  findBin: async (bin) => findOnDisk(bin, { env: { ...process.env, PATH: await userPath({ settings: readSettings() }) } }),
}));
ipcMain.handle('services:list',(_e, { projectPath, agentIds } = {}) => {
  const home = os.homedir();
  const masters = {
    ...readMaster({ scope: 'user', projectPath, homeDir: home }),
    ...readMaster({ scope: 'project', projectPath, homeDir: home }),
  };
  const notebooks = (agentIds && agentIds.length) ? readNotebooks({ projectPath, homeDir: home, agentIds }) : null;
  return {
    catalog: catalogForRenderer(),
    connected: detectServices({ projectPath, home }),
    masters: Object.keys(masters),
    coverage: notebooks ? coverage({ masters, notebooks }) : null,
  };
});
ipcMain.handle('services:connect', async (_e, { id, values, scope, agentIds, projectPath }) => {
  const s = serviceById(id);
  if (!s) return { ok: false, error: 'unknown service' };
  if (values && values.installDir) values.installDir = values.installDir.replace(/^~/, os.homedir());
  try {
    const entry = s.entry(values);
    const up = upsertMaster({ scope, projectPath, homeDir: os.homedir(), id, entry });
    if (!up.ok) return up;
    const delivered = await deliverConnections({ scope, projectPath, agentIds });
    const files = [shortHome(up.file) + ' (the master)'].concat(deliveredNames(delivered));
    const check = entry.command
      ? await checkServer({ command: entry.command, args: entry.args, env: entry.env || {}, settings: readSettings() })
      : { ok: false, error: 'remote servers are checked by the first session that uses them' };
    return { ok: true, files, delivered, tools: check.ok ? check.tools : 0, checked: check.ok, checkError: check.ok ? null : check.error };
  } catch (e) { return { ok: false, error: e.message }; }
});
// The other two doors: a .mcpb bundle, or a pasted address / command line.
// Both end at the same place as the catalog — a master entry, delivered.
const { parseManifest, userConfigFields, buildEntry, parseCommandLine } = require('./mcpb');
ipcMain.handle('services:pickBundle', async (e) => {
  const parent = BrowserWindow.fromWebContents(e.sender) || win;
  const res = await dialog.showOpenDialog(parent, {
    properties: ['openFile'], title: 'Choose a bundle',
    filters: [{ name: 'MCP bundle', extensions: ['mcpb', 'zip'] }],
  });
  if (res.canceled || !res.filePaths[0]) return null;
  const file = res.filePaths[0];
  try {
    const { dir, manifest: m } = await require('./bundle-install').installBundle(file, path.join(os.homedir(), '.nami', 'bundles'));
    return {
      ok: true, dir,
      name: m.display_name || m.name, slug: m.name, version: m.version || '',
      description: m.description || '', fields: userConfigFields(m),
    };
  } catch (err) {
    return { ok: false, error: 'Could not install the bundle: ' + err.message };
  }
});
ipcMain.handle('services:connectCustom', async (_e, { name, address, values, bundleDir, scope, agentIds, projectPath } = {}) => {
  try {
    let entry;
    if (bundleDir) {
      const parsed = parseManifest(fs.readFileSync(path.join(bundleDir, 'manifest.json'), 'utf8'));
      if (!parsed.ok) return parsed;
      entry = buildEntry({ manifest: parsed.manifest, dir: bundleDir, values: values || {} });
    } else if (/^https?:\/\//i.test(String(address || '').trim())) {
      entry = { url: String(address).trim() };
    } else {
      const cmd = parseCommandLine(address);
      if (!cmd) return { ok: false, error: 'Paste an address (https://…) or a command line first.' };
      entry = cmd;
    }
    const id = String(name || '').trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    if (!id) return { ok: false, error: 'Give it a name first.' };
    const up = upsertMaster({ scope, projectPath, homeDir: os.homedir(), id, entry });
    if (!up.ok) return up;
    const delivered = await deliverConnections({ scope, projectPath, agentIds });
    const files = [shortHome(up.file) + ' (the master)'].concat(deliveredNames(delivered));
    const check = entry.command
      ? await checkServer({ command: entry.command, args: entry.args, env: entry.env || {}, settings: readSettings() })
      : { ok: false, error: 'remote servers are checked by the first session that uses them' };
    return { ok: true, id, files, delivered, tools: check.ok ? check.tools : 0, checked: check.ok, checkError: check.ok ? null : check.error };
  } catch (err) { return { ok: false, error: err.message }; }
});
// Repair: re-deliver current masters (both scopes) to every installed agent.
ipcMain.handle('services:deliver', async (_e, { projectPath, agentIds } = {}) => {
  const out = [];
  out.push(...await deliverConnections({ scope: 'user', projectPath, agentIds }));
  if (projectPath) out.push(...await deliverConnections({ scope: 'project', projectPath, agentIds }));
  return out;
});
ipcMain.handle('services:disconnect', async (_e, { id, projectPath }) => {
  const home = os.homedir();
  const changed = [];
  // Masters first — they are what delivery would faithfully restore.
  for (const scope of ['project', 'user']) {
    const res = removeMaster({ scope, projectPath, homeDir: home, id });
    if (res.ok) changed.push(res.file);
  }
  // Every JSON notebook a delivery (or a hand) could have written, both scopes.
  const jsonFiles = new Set(knownFiles(projectPath, home).filter(([f]) => f.indexOf('.claude.json') < 0).map(([f]) => f));
  for (const scope of ['project', 'user']) {
    const targets = notebookTargets({ scope, projectPath, homeDir: home });
    for (const t of Object.values(targets)) if (t.kind === 'json' && t.file) jsonFiles.add(t.file);
  }
  changed.push(...removeService({ files: [...jsonFiles], id }));
  // TOML blocks (Codex, Grok) regenerate from what remains in each master.
  for (const scope of ['project', 'user']) {
    const targets = notebookTargets({ scope, projectPath, homeDir: home });
    for (const t of Object.values(targets)) {
      if (t.kind !== 'block' || !t.file || !fs.existsSync(t.file)) continue;
      const res = writeCodexBlock({ file: t.file, masters: readMaster({ scope, projectPath, homeDir: home }) });
      if (res.ok) changed.push(t.file);
    }
  }
  const viaCli = validServiceId(id) ? await new Promise((resolve) => {
    const bin = knownBin('claude') || 'claude';
    const plan = spawnPlan(bin, ['mcp', 'remove', '--scope', 'user', id]);
    execFile(plan.file, plan.args, { timeout: 20000, env: buildChildEnv({ settings: readSettings(), purpose: 'agent', agentId: 'claude' }), ...plan.options }, (err) => resolve(!err));
  }) : false;
  if (viaCli) changed.push('claude user settings');
  return { changed };
});
// http as well as https: a dev server an agent just started (localhost:3000) is
// the most clickable thing in a session. Still nothing else — no file://, no
// custom schemes, so a link in output can never launch an app.
ipcMain.handle('url:open', (_e, url) => {
  if (typeof url === 'string' && /^https?:\/\//i.test(url)) shell.openExternal(url);
});

// Theme lives in settings.json so the window background matches on next launch.
ipcMain.on('theme:applied', (e, theme) => {
  const w = BrowserWindow.fromWebContents(e.sender);
  if (!wins.has(w)) return;
  windowThemes.set(e.sender.id, settingsStore.normalizeTheme(theme));
  // The Windows caption buttons are painted by the system on a colour we chose
  // at creation, so a theme change has to repaint them or they stay behind.
  const overlay = windowChrome(process.platform, settingsStore.themeBackground(theme)).titleBarOverlay;
  if (overlay && !w.isDestroyed()) w.setTitleBarOverlay(overlay);
  refreshAppMenu();
});
ipcMain.handle('theme:set', (_e, theme) => {
  if (REVIEW) return { ok: true };
  const saved = writeSettings({ theme: settingsStore.normalizeTheme(theme) });
  refreshAppMenu();
  return saved;
});

// Desk or Split, so the app reopens in the view you left.
ipcMain.handle('view:set', (_e, view) => REVIEW ? { ok: true } : writeSettings({ view: settingsStore.normalizeView(view) }));

// The Settings page reads and writes settings.json directly. Only these keys are
// writable from the renderer — panel layout and recents live in state.json and
// have their own channels, and nothing else should be reachable from a page.
const WRITABLE_SETTINGS = new Set([
  'theme', 'view',
  'sttProvider', 'openaiKey', 'elevenKey', 'openaiModel', 'elevenModel',
  'sttModelId',
]);
ipcMain.handle('settings:get', () => {
  const s = readSettings();
  // keys never travel back to the renderer in full — it only needs to know one exists
  const out = Object.assign({}, s, {
    openaiKey: s.openaiKey ? '••••' + String(s.openaiKey).slice(-4) : '',
    elevenKey: s.elevenKey ? '••••' + String(s.elevenKey).slice(-4) : '',
    sttKey: s.sttKey ? '••••' + String(s.sttKey).slice(-4) : '',
  });
  delete out.envKeys; // full secrets — the Keys pane has its own masked channel
  return out;
});

// ---- IPC: keys — named secrets shared by permitted consumers ---------------
// Stored under settings.envKeys; child-process permissions are applied at spawn.
const KEY_NAME_RE = /^[A-Za-z_][A-Za-z0-9_]*$/;
function storedEnvKeys() { const k = readSettings().envKeys; return (k && typeof k === 'object' && !Array.isArray(k)) ? k : {}; }
ipcMain.handle('keys:get', () => {
  const stored = storedEnvKeys();
  return {
    stored: Object.keys(stored).sort().map((name) => ({
      name,
      masked: '••••••••' + String(stored[name]).slice(-4),
    })),
  };
});
ipcMain.handle('settings:reveal', () => { try { shell.showItemInFolder(settingsFile()); } catch (_) {} });
ipcMain.handle('keys:set', (_e, { name, value }) => {
  if (!KEY_NAME_RE.test(String(name || ''))) return { ok: false, error: 'The name has to look like AN_ENV_VAR.' };
  if (!value || !String(value).trim()) return { ok: false, error: 'Paste the secret first.' };
  const next = Object.assign({}, storedEnvKeys(), { [name]: String(value).trim() });
  const res = writeSettings({ envKeys: next });
  return res.ok ? { ok: true } : res;
});
ipcMain.handle('keys:delete', (_e, { name }) => {
  const next = Object.assign({}, storedEnvKeys()); delete next[name];
  const res = writeSettings({ envKeys: next });
  return res.ok ? { ok: true } : res;
});
ipcMain.handle('keys:reveal', (_e, { name }) => ({ value: storedEnvKeys()[name] || '' }));
ipcMain.handle('settings:set', (_e, patch) => {
  const clean = {};
  for (const [k, v] of Object.entries(patch || {})) if (WRITABLE_SETTINGS.has(k)) clean[k] = v;
  if (REVIEW) { delete clean.theme; delete clean.view; }
  const res = writeSettings(clean);
  return res.ok ? { ok: true, sttInfo: sttStatus() } : res;
});

ipcMain.handle('folder:pick', async (e) => {
  const parent = BrowserWindow.fromWebContents(e.sender) || win;
  // createDirectory is what puts macOS's own New Folder button in the panel.
  // Without it the one user who most needs to make a folder -- somebody with no
  // project at all, sent here by the empty desk -- lands in a picker that can
  // only choose things that already exist.
  const res = await dialog.showOpenDialog(parent, {
    properties: ['openDirectory', 'createDirectory'],
    title: 'Open a folder',
  });
  if (res.canceled || !res.filePaths[0]) return null;
  // Deliberately does NOT commit: the renderer may still decide this folder
  // belongs in a new window instead. It commits with folder:open.
  return scanFolder(res.filePaths[0]);
});

// Make the folder for them. The save panel rather than a sheet of our own: it
// arrives with the favourites sidebar, iCloud, search and tags, and it is the
// dialog every Mac user has already learned. Pre-filled so Return is enough for
// anyone who does not care where it goes.
//
// Returns the same shape as folder:pick, so the renderer hands it to the switch
// path it already has and nothing downstream knows the difference.
ipcMain.handle('folder:make', async (e) => {
  const parent = BrowserWindow.fromWebContents(e.sender) || win;
  const res = await dialog.showSaveDialog(parent, {
    title: 'Where should Nami work?',
    defaultPath: path.join(app.getPath('documents'), 'Nami'),
    buttonLabel: 'Create',
    nameFieldLabel: 'Folder name:',
    properties: ['createDirectory'],
  });
  if (res.canceled || !res.filePath) return null;
  try {
    await fs.promises.mkdir(res.filePath, { recursive: true });
  } catch (err) {
    return { error: err.message };
  }
  // Best effort, and never fatal -- see seedStartHere. A folder that got made
  // is a success even if the welcome note did not land.
  await seedStartHere(res.filePath);
  return scanFolder(res.filePath);
});

// Adopting a folder is what makes it this window's folder, bumps it up Recents
// and marks the window for restore. It is separate from *reading* a folder
// because a switch can still be called off — a desk with live sessions gets
// offered a new window instead, and a cancelled switch must leave no trace.
function commitFolder(e, folder) {
  winFolders.set(e.sender.id, folder);
  rememberFolder(folder);
  snapshotWindows();
}
ipcMain.handle('folder:open', (e, arg) => {
  const folder = typeof arg === 'string' ? arg : (arg && arg.folder);
  const commit = typeof arg === 'string' ? true : !(arg && arg.commit === false);
  // A recents row can outlive its folder. Say so instead of returning a bare
  // null the renderer can only turn into a silent no-op.
  if (!folder) return { missing: true, path: folder };
  if (!fs.existsSync(folder)) { broadcastRecents(); return { missing: true, path: folder }; }
  if (commit) commitFolder(e, folder);
  return scanFolder(folder);
});
ipcMain.handle('folder:scan', (_e, folder) => (folder && fs.existsSync(folder)) ? scanFolder(folder) : null);
ipcMain.handle('folder:rescan', (_e, folder) => (folder && fs.existsSync(folder)) ? scanFolder(folder) : null);

// ---- IPC: explorer + editor ------------------------------------------------
ipcMain.handle('dir:list', (_e, arg) => {
  const dir = typeof arg === 'string' ? arg : arg.dir;
  const all = typeof arg === 'object' && !!arg.all;
  // null, not []: "this folder is gone" and "this folder is empty" are
  // different answers, and the tree acts on the difference — a deleted folder's
  // row is removed, an empty one is kept. Returning [] for both made
  // onDirChanged's removal branch unreachable. Every other caller tolerates a
  // null: one guards with `|| []`, the rest assign into S.tree, whose readers
  // all begin `if (!children) return`.
  return listDirectory(dir, all);
});
ipcMain.handle('file:raw', (_e, file) => {
  try {
    const stat = fs.statSync(file);
    if (stat.isDirectory()) return { ok: false, error: 'is a directory' };
    if (stat.size > 2 * 1024 * 1024) return { ok: false, error: 'file too large to edit (' + fmtSize(stat.size) + ')', size: fmtSize(stat.size) };
    const buf = fs.readFileSync(file);
    if (buf.includes(0)) return { ok: false, binary: true, error: 'binary file', size: fmtSize(stat.size) };
    return { ok: true, text: buf.toString('utf8'), path: file, size: fmtSize(stat.size) };
  } catch (e) { return { ok: false, error: e.message }; }
});
// The hash of what was just written, handed back so the renderer can store it
// on the panel and recognise the watcher event its own save is about to
// provoke. Without it every save bounces off the watcher and comes back as a
// change somebody else made.
//
// One implementation, imported from the renderer's pure module rather than
// copied: two hashes of the same bytes drift the moment either is touched, and
// the drift shows up as a mystery reload months later. A failure to load it is
// not a failure to save — the guard goes quiet, decideReload still drops an
// identical file, and the worst case is one reload that changes nothing.
let fileSyncMod = null;
function fileSync() {
  if (!fileSyncMod) fileSyncMod = import(pathToFileURL(path.join(__dirname, '../renderer/file-sync.mjs')).href);
  return fileSyncMod;
}
async function savedHash(text) {
  try { const { hashText } = await fileSync(); return hashText(text); } catch (_) { return null; }
}
ipcMain.handle('file:save', async (_e, { file, text }) => {
  try { fs.writeFileSync(file, text); } catch (e) { return { ok: false, error: e.message }; }
  return { ok: true, hash: await savedHash(text) };
});
// Resolve a token clicked in a terminal: statToken, in path-stat.js.
//
// The session's own cwd is tried first and wins outright, so the retry below
// can only ever turn a dead link live — never the reverse. Only a relative
// miss pays for the lsof, and only while a link is being hovered.
//
// `roots` is what lets a project on a network share keep its links while a
// printed \\evil\share path is never so much as statted (remote-path.js): the
// folder the tile was opened on, which somebody chose, and the home folder.
ipcMain.handle('path:stat', async (_e, { token, cwd, id }) => {
  const roots = [cwd, os.homedir()];
  const hit = await statToken(token, cwd, { roots });
  if (hit.exists || !hit.relative) return hit;
  const term = id ? termSessions.get(id) : null;
  if (!term || !term.pid) return hit;
  const live = await ptyCwd(term.pid);
  if (!live || live === cwd) return hit;
  return statToken(token, live, { roots });
});

// ---- IPC: agents & skills library ------------------------------------------
ipcMain.handle('library:scan', (_e, { projectPath, scope } = {}) => {
  try { const items = scanLibrary({ projectPath, scope }); return { items, edges: extractEdges(items) }; }
  catch (_) { return { items: [], edges: [] }; }
});
ipcMain.handle('library:create', (_e, args) => {
  const res = createItem(args || {});
  // A new master is worth nothing until every tool has its copy.
  if (res.ok && args && args.type === 'agent' && args.platform === 'project') {
    res.delivered = deliverAgents({ projectPath: args.projectPath, agentIds: args.agentIds || [] });
  }
  return res;
});
ipcMain.handle('library:duplicate', (_e, args) => duplicateItem(args || {}));
ipcMain.handle('library:delete', async (_e, args) => {
  const a = args || {};
  const res = await deleteItem({ ...a, trashFn: (p) => shell.trashItem(p) });
  // A deleted master takes its delivered copies with it — leaving them behind
  // would keep the agent alive in every tool with no master to edit.
  if (res.ok && a.projectPath && String(a.filePath || '').startsWith(path.join(a.projectPath, 'agents') + path.sep)) {
    res.swept = sweepCopies({ projectPath: a.projectPath, slug: path.basename(a.filePath, '.md') });
  }
  return res;
});
// Deliver every master to every installed tool (create, save, repair all land here).
// Where one agent's copies stand, for the picker's tool list. Read-only, so it
// is safe to call every time a row opens — nothing is written until a launch
// asks for it.
ipcMain.handle('library:agentDelivery', (_e, { projectPath, slug, agentIds } = {}) =>
  (projectPath && slug ? deliveryState({ projectPath, slug, agentIds: agentIds || [] }) : []));

// The copy-over drawer: lift a personal agent from a home folder into agents/
// as a master, then deliver it. The source is the user's own file and is read,
// never written — unlike adoption, which converts a file inside the project.
ipcMain.handle('library:importAgent', (_e, { filePath, projectPath, agentIds } = {}) => {
  const res = importToMaster({ filePath, projectPath });
  if (res.ok) res.delivered = deliverAgents({ projectPath, agentIds: agentIds || [] });
  return res;
});

// Deliver every master to every installed tool (create, save, repair all land here).
ipcMain.handle('library:deliverAgents', (_e, { projectPath, agentIds } = {}) =>
  (projectPath ? deliverAgents({ projectPath, agentIds: agentIds || [] }) : []));
// "Make it everyone's": lift a hand-made platform agent into the drawer.
ipcMain.handle('library:adoptAgent', (_e, { filePath, platform, projectPath, agentIds } = {}) => {
  const res = liftToMaster({ filePath, platform, projectPath });
  if (res.ok) res.delivered = deliverAgents({ projectPath, agentIds: agentIds || [] });
  return res;
});

// ---- IPC: the skills pointer ------------------------------------------------
// Nothing here runs unless the renderer asks. Opening a folder is a read: the
// only paths that write are a skill being created and the buttons that say so.
ipcMain.handle('pointer:status', (_e, args) => {
  const { dir, agentIds } = args || {};
  try {
    const skills = projectSkills(dir);
    const st = pointerStatus({ dir, skills, agentIds });
    const text = safeReadText(dir && path.join(dir, POINTER_FILE));
    return { ...st, skills: skills.map((s) => s.slug), foreignSection: hasForeignSkillsSection(text) };
  } catch (e) { return { inSync: true, unlisted: [], stale: [], missingFiles: [], listed: [], error: e.message }; }
});
ipcMain.handle('pointer:write', (_e, args) => {
  const { dir, agentIds, dryRun } = args || {};
  try {
    const skills = projectSkills(dir);
    const res = writePointers({ dir, skills, agentIds, dryRun });
    if (!res.ok || dryRun) return res;
    // Native registration is the stronger route where an agent's own project
    // path is verified; it is additive, so a failure here must not fail the write.
    const link = linkNative({ dir, slugs: skills.map((s) => s.slug), agentIds });
    return { ...res, linked: link.linked || [], swept: link.swept || [] };
  } catch (e) { return { ok: false, error: e.message, written: [], preview: {} }; }
});

// The pointer announces what the folder holds, so the folder is the source of
// truth — read fresh each time rather than trusting anything the renderer sends.
function projectSkills(dir) {
  if (!dir) return [];
  return scanLibrary({ projectPath: dir })
    .filter((i) => i.type === 'skill' && i.scope === 'project' && !i.broken)
    .map((i) => ({ slug: i.slug, description: i.description }));
}
function safeReadText(p) { try { return p ? fs.readFileSync(p, 'utf8') : ''; } catch (_) { return ''; } }

// ---- IPC: quick look / files ----------------------------------------------
ipcMain.handle('file:read', (_e, file) => {
  try {
    const stat = fs.statSync(file);
    if (stat.isDirectory()) {
      const files = fs.readdirSync(file).slice(0, 60).map((n) => ({ name: n }));
      return { kind: 'dir', name: baseName(file), files };
    }
    if (stat.size > 400 * 1024) return { kind: 'text', name: baseName(file), rows: [{ n: 1, t: '(file too large to preview)' }], size: fmtSize(stat.size) };
    const txt = fs.readFileSync(file, 'utf8');
    const rows = txt.split('\n').slice(0, 400).map((t, i) => ({ n: i + 1, t }));
    return { kind: 'text', name: baseName(file), rows, size: fmtSize(stat.size) };
  } catch (e) { return { kind: 'text', name: baseName(file), rows: [{ n: 1, t: 'Could not read: ' + e.message }] }; }
});
ipcMain.handle('file:reveal', (_e, file) => { try { shell.showItemInFolder(file); } catch (_) {} });
ipcMain.handle('file:openBrowser', async (_e, file) => {
  const url = browserFileUrl(file);
  if (!url) return { ok: false, error: 'Only saved HTML files can open in the browser.' };
  try {
    await shell.openExternal(url);
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e && e.message ? e.message : 'Could not open the browser.' };
  }
});
// Workspace file verbs: guarded in fs-actions.js to stay inside the project root.
ipcMain.handle('fs:newFile', (_e, a) => fsActions.newFile(a || {}));
ipcMain.handle('fs:newFolder', (_e, a) => fsActions.newFolder(a || {}));
ipcMain.handle('fs:move', (_e, a) => fsActions.movePath(a || {}));
ipcMain.handle('fs:rename', (_e, a) => fsActions.renamePath(a || {}));
ipcMain.handle('fs:import', (_e, a) => fsActions.importPaths(a || {}));
ipcMain.handle('fs:duplicate', (_e, a) => fsActions.duplicatePath(a || {}));
ipcMain.handle('fs:trash', (_e, a) => fsActions.trashPath({ ...(a || {}), trashFn: (p) => shell.trashItem(p) }));

// ---- the Workspace tree's watcher ------------------------------------------
// One dir-watch per window, because each window has its own open folder, and one
// recursive watcher inside it — see src/main/dir-watch.js for why recursive, and
// why the ignore list runs before the debounce rather than after. Closed on
// window destruction so a closed window leaves no descriptors.
const dirWatchers = new Map();   // webContents.id -> dir-watch
function dirWatchFor(wc) {
  let w = dirWatchers.get(wc.id);
  if (w) return w;
  // `files` rides along so an open tile can tell whether it was its own file
  // that moved; null means the platform would not say, and the renderer then
  // re-checks every open panel rather than none.
  w = createDirWatch({ onChange: (dir, files) => { try { wc.send('dir:changed', { dir, files }); } catch (_) {} } });
  dirWatchers.set(wc.id, w);
  wc.once('destroyed', () => { w.close(); dirWatchers.delete(wc.id); });
  return w;
}
ipcMain.handle('dir:watch', (e, a) => {
  const root = a && typeof a.root === 'string' && a.root ? a.root : null;
  if (!root) {
    const existing = dirWatchers.get(e.sender.id);
    if (existing) existing.close();
    return { watching: 0, failed: 0 };
  }
  return dirWatchFor(e.sender).watchRoot(root);
});
// Plain directory dialog for Move to…: unlike folder:pick it must NOT remember
// the choice as a recent project.
ipcMain.handle('folder:choose', async (e) => {
  const parent = BrowserWindow.fromWebContents(e.sender) || win;
  const res = await dialog.showOpenDialog(parent, { properties: ['openDirectory'], title: 'Move to which folder?' });
  return res.canceled || !res.filePaths[0] ? null : res.filePaths[0];
});
ipcMain.handle('clipboard:save-image', (_e, dataUrl) => {
  try {
    if (typeof dataUrl !== 'string' || dataUrl.length > 28 * 1024 * 1024 || !/^data:image\/(png|jpeg|webp);base64,/.test(dataUrl)) return { ok: false, error: 'Paste a PNG, JPEG or WebP image under 20 MB.' };
    const img = nativeImage.createFromDataURL(dataUrl);
    if (img.isEmpty()) return { ok: false, error: 'That image could not be read.' };
    const { storePng } = require('./pasted-images');
    const file = storePng(path.join(app.getPath('userData'), 'pastes'), img.toPNG());
    const size = img.getSize(), scale = Math.min(96 / size.width, 64 / size.height);
    return { ok: true, path: file, thumbnail: img.resize({ width: Math.max(1, Math.round(size.width * scale)), height: Math.max(1, Math.round(size.height * scale)), quality: 'good' }).toDataURL() };
  } catch (_) { return { ok: false, error: 'Could not save the pasted image.' }; }
});
ipcMain.handle('clipboard:write', (_e, text) => { try { clipboard.writeText(String(text || '')); } catch (_) {} return true; });
ipcMain.handle('clipboard:read', () => { try { return clipboard.readText(); } catch (_) { return ''; } });

// ---- IPC: dictation → text -------------------------------------------------
// Which engine runs is stt.js's problem; this only supplies config and a way to
// report download progress back to the window that asked.
function sttEnv() { return { settings: readSettings(), env: process.env }; }
function sttStatus() { return stt.status(sttEnv()); }

// Whisper weights live in one writable folder under userData. A packaged build
// ships tiny.en inside the app bundle, which is read-only, so on first launch we
// copy it across — after that there is a single place that both the engine reads
// and a bigger model can be downloaded into.
function sttModelDir() {
  const user = path.join(app.getPath('userData'), 'models');
  const bundled = process.resourcesPath && path.join(process.resourcesPath, 'models');
  try {
    if (bundled && fs.existsSync(bundled) && !fs.existsSync(path.join(user, 'onnx-community'))) {
      fs.mkdirSync(user, { recursive: true });
      fs.cpSync(bundled, user, { recursive: true, force: false, errorOnExist: false });
    }
  } catch (e) { console.error('[stt] could not seed bundled model:', e.message); }
  return user;
}

ipcMain.handle('stt:transcribe', (e, clip) =>
  stt.transcribe(Object.assign(sttEnv(), {
    clip,
    deps: { onProgress: (p) => sendWc(e.sender, 'stt:progress', p) },
  })));
ipcMain.handle('stt:status', () => sttStatus());
ipcMain.handle('stt:prepare', (e) =>
  stt.prepare(Object.assign(sttEnv(), {
    deps: { onProgress: (p) => sendWc(e.sender, 'stt:progress', p) },
  })));

// Each session receives only credentials allowed for its purpose and agent.
// An allowed saved key wins over the inherited value.
//
// `path` is the user's real login PATH, not the one this process was handed.
// Launched from the Dock that difference is everything: launchd gives an app
// four directories, so an agent spawned with it cannot find node, git, or any
// tool the user installed. A shell tile papers over this by sourcing .zshrc on
// its way up, but anything spawned directly — claude, a harness — does not.
function sessionEnv(path, launch, policy = sessionPolicy(launch)) {
  // stripInheritedClaude first: a tile is a top-level agent, and inheriting the
  // launching conversation's handles makes claude disable transcript saving.
  const env = Object.assign(buildChildEnv({ parentEnv: process.env, settings: readSettings(), ...policy }), { TERM: 'xterm-256color', FORCE_COLOR: '1' });
  if (path) env.PATH = path;
  // TUIs that check COLORFGBG (vim, htop, some harnesses) pick palettes that
  // suit the theme's ground: "fg;bg" where bg 15=light desk, 0=dark desk.
  const theme = settingsStore.normalizeTheme(readSettings().theme);
  env.COLORFGBG = (theme === 'paper' || theme === 'glass' || theme === 'soft') ? '0;15' : '15;0';
  return env;
}

// The credential policy a launch ends up with, decided once and used for both
// the environment and the way the process is started. A run tile whose command
// is not the registered command for its declared agent falls back to a plain
// terminal: it gets no keys, and it is typed into a shell like any other
// terminal. The policy shape is what buildChildEnv takes.
function sessionPolicy(launch) {
  const policy = terminalLaunchPolicy(launch);
  if (launch?.kind === 'run' && policy.purpose === 'agent' && !agentRunCommandAllowed(launch)) return { purpose: 'terminal' };
  return policy;
}

// ---- IPC: terminal / harness sessions --------------------------------------
// kind: 'claude' (spawn the logged-in claude directly), 'shell' (a plain shell),
// 'run' (a shell that runs `command`), 'harness' (spawn `program args`).
//
// How a shell-run command reaches the shell depends on the credential policy.
// A tile whose policy is purpose 'agent' holds that agent's keys, so the shell
// is started with the command as its script (`-i -c`) and the pty ends when the
// agent does: no prompt carrying OPENAI_API_KEY is left behind after a Ctrl-C.
// A tile with no keys — a legacy run tile, a plain shell — is typed into an
// interactive shell as before and stays a terminal afterwards.
ipcMain.handle('term:create', async (e, { id, cwd, cols, rows, kind, command, program, args, seed, cont, sid, acpSid, name, watchDone, oneShot, purpose, agentId }) => {
  const wc = e.sender;
  browserViews.registerSession({id,windowId:wc.id,title:name||command||kind||'Session'});
  if (!pty) { sendWc(wc, 'term:data', { id, data: '\r\n[node-pty unavailable — terminal disabled]\r\n' }); return { ok: false }; }
  // Primed at startup, so by the time anyone opens a tile this is already
  // settled; the await only ever bites on a session created within the first
  // second of launch.
  const envPath = await userPath({ settings: readSettings() });
  // PowerShell 7 when the PC has it, looked for on the PATH the pane is about
  // to be given. Only Windows looks: a Mac pane is the user's own shell.
  const onWindows = process.platform === 'win32';
  const shellPath = paneShell(process.platform, process.env, onWindows ? findPwsh({ pathValue: envPath || undefined }) : '');
  const quote = (a) => shellQuote(a, shellPath);
  const claudeExe = resolveClaudeExecutable();
  const launch = { kind, purpose, agentId, program, command, args, watchDone, oneShot };
  const policy = sessionPolicy(launch);
  const seedAgent = seedAgentForLaunch(launch);
  // What a found program really is. On Windows npm's claude.cmd and codex.cmd
  // are shims, and one that plainly runs node on a script, or a .exe of the
  // package's own, is started as that instead (real-program.js), so from here
  // down it is a real .exe like any other. Anything else, and everything on a
  // Mac, is itself.
  const real = (found) => realProgram(found, { platform: process.platform, pathValue: envPath || undefined });
  const claudeRun = real(claudeExe);
  // Where the agent the message is for really is. On Windows that decides
  // whether it may travel as an argument at all: a shim Nami could not go round
  // is read by cmd.exe, and a message is not something cmd.exe may read
  // (cmd-shim.js). On a Mac the answer is always yes and nothing changes.
  const seedProgram = kind === 'claude' ? claudeRun.file : real(knownBin(seedAgent)).file;
  const promptArgs = initialPromptArgs(seedAgent, seed, { program: seedProgram, platform: process.platform });
  const held = seedHeld(seedAgent, seed, { program: seedProgram, platform: process.platform });

  let file = shellPath, spawnArgs = [], afterStart = null, claudeWatch = null, echoLine = null, discoverAgent = null, storeWatch = null;
  if (kind === 'claude') {
    // sid: the panel's own conversation id, minted in the renderer at first spawn.
    // A fresh spawn pins it with --session-id; a restored panel resumes it with
    // --resume, so four tiles come back as four conversations. cont-without-sid is
    // the migration path for snapshots saved before ids existed: --continue.
    // --resume on a conversation that never got a first message errors out, so a
    // restored-but-unused panel falls back to a fresh spawn keeping the same id.
    const transcript = sid && path.join(os.homedir(), '.claude', 'projects', projectSlug(cwd), sid + '.jsonl');
    const hasTranscript = !!transcript && fs.existsSync(transcript);
    const claudeArgs = claudeSpawnArgs({ cont, sid, hasTranscript, name });
    // From here on, claude's own title for this conversation drives the label.
    // The pinned id is only a starting guess: /resume moves claude to another
    // conversation, so the watcher re-reads the live id and follows it. Started
    // after the spawn below, because following it needs the pty's pid.
    if (transcript) claudeWatch = { transcript, sid, cwd };
    // Extra args ride along — the agents picker launches claude as the agent
    // with `--agent <slug>` (probe-backed; see agent-launch.mjs).
    // To npm's claude.cmd the name and the agent's slug go reduced to what
    // cmd.exe cannot act on; a real claude.exe, and a Mac, get them whole. With
    // no resolved binary the shell will find whichever claude it finds, so the
    // typed line is written for the shim it may turn out to be.
    const extraArgs = Array.isArray(args) ? args : [];
    const ownArgs = shimSafeArgs([...claudeArgs, ...extraArgs], claudeRun.file, process.platform);
    if (claudeExe) { file = claudeRun.file; spawnArgs = [...claudeRun.args, ...ownArgs, ...promptArgs]; }
    // No resolvable binary: type the command into a shell instead. It has to be
    // the WHOLE command. A session spawned with a first message used to fall
    // into a marker branch below that typed a bare `claude`, dropping
    // --session-id, --resume and --name — so the pinned id was never used, the
    // title watcher followed a transcript nothing ever wrote, and the tile came
    // back empty on the next launch. Quoted because --name carries a sentence,
    // and an unquoted sentence arrives as four arguments.
    // The line is the shell's script, not typed (see the policy note above):
    // this tile carries claude's keys, so it must not outlive claude.
    else {
      file = shellPath;
      const displayLine = ['claude', ...ownArgs].map(quote).join(' ');
      const line = displayLine + (promptArgs.length ? ' ' + promptArgs.map(quote).join(' ') : '');
      if (policy.purpose === 'agent' || promptArgs.length) { spawnArgs = scriptArgs(shellPath, line); echoLine = displayLine; }
      else afterStart = line;
    }
  } else if (kind === 'harness' && program) {
    file = program; spawnArgs = Array.isArray(args) ? args : [];
  } else if (kind === 'run' && command) {
    // watchDone marks a one-shot: a command Nami ran on the user's behalf and
    // needs to know the end of, rather than a session that happens to be a
    // shell. It is spawned rather than typed, so the reporting suffix is never
    // echoed back at the user; the header below stands in for the echo.
    // The typed command uses the scan's absolute path when it has one — the
    // interactive shell's PATH can miss a binary the launcher calls ready
    // (see resolveRunCommand). The echo keeps the pretty bare name.
    file = shellPath;
    // A library agent's slug is a file name out of the project, and a file may
    // be called `x&calc.md`. On its way to opencode.cmd that is a command
    // (cmd-shim.js), and the line was written and checked by the renderer, so it
    // cannot be reduced here without ceasing to be the line that was checked.
    // It is turned away instead, with the reason where the agent would be.
    const head = (/^[A-Za-z][\w.-]*/.exec(String(command)) || [''])[0];
    if (Array.isArray(args) && reachesCmd(real(knownBin(head)).file, process.platform) && args.some((a) => shimSafe(a) !== String(a))) {
      sendWc(wc, 'term:data', { id, data: `\r\n[not started: this agent's name has a character in it that cannot be handed to ${head} safely on Windows — one of " % & | < > ^ ! ( )]\r\n` });
      return { ok: false };
    }
    // withSpawnFlags first, while the head is still a bare name: it is keyed
    // by binary, and resolveRunCommand may replace the head with a full path.
    // This is where grok gets --minimal; see the table in bin-cache.js for why
    // the flag is not stored on the panel.
    let bare = withSpawnFlags(command);   // the line before anything resolves it, for directLaunch below
    let typed = resolveRunCommand(bare, shellPath, real);
    // A known agent tile restoring with a saved conversation id gets its
    // resume line typed instead of the bare bin — but only while the agent's
    // store still holds that session (the same restored-but-unused guard as
    // claude's hasTranscript above): a store without it falls back to the
    // bare bin, fresh. resolveRunCommand resolves the whole line, so the bin
    // keeps its absolute path here too; the sid is charset-checked inside
    // resumeCommand, so the tail needs no quoting.
    // A tile with no saved id spawns fresh and is registered for discovery
    // after the spawn below. One-shots (watchDone) are Nami's errands, never
    // conversations — neither path applies.
    const agent = watchDone ? null : agentForCommand(command);
    if (agent) {
      if (cont && acpSid) {
        const resume = sessionExists(agent, cwd, acpSid) ? resumeCommand(agent, acpSid) : null;
        if (resume) { bare = withSpawnFlags(resume); typed = resolveRunCommand(bare, shellPath, real); storeWatch = { agent, sid: acpSid }; }
      } else if (!acpSid) discoverAgent = agent;
    }

    // On Windows an agent tile whose line is just a program and plain words is
    // started by the pty itself, the way a claude tile already is: PowerShell
    // 5.1 cannot hand a quote to a Bun-built program intact (see directLaunch).
    // The platform test comes first so nothing else is even looked up on a Mac.
    const direct = (process.platform === 'win32' && !watchDone && (policy.purpose === 'agent' || promptArgs.length))
      ? directLaunch(bare, { real, knownBin, platform: process.platform }) : null;
    typed = withPromptArgs(typed, promptArgs, { quote, shell: shellPath });
    if (direct) { file = direct.file; spawnArgs = [...direct.args, ...promptArgs]; echoLine = command; }
    else if (watchDone) { spawnArgs = oneShotArgs(shellPath, typed); echoLine = command; }
    // An agent tile: the shell runs the line as its script and exits with the
    // agent, so the keys in its environment die with it. Still `-i`, so the
    // user's rc file is read and `a && b` registry commands work; no `exec`
    // prefix for the same reason. Unlike a one-shot there is no trailing
    // `exec <shell> -i` — a fresh prompt is exactly the thing to avoid here.
    else if (policy.purpose === 'agent' || promptArgs.length) { spawnArgs = scriptArgs(shellPath, typed); echoLine = command; }
    else afterStart = typed;
  } else {
    file = shellPath;
  }

  // Windows cannot be asked where a shell is, so a PowerShell that will show a
  // prompt is started with a hook that says (shell-integration.js). It rides
  // in on the launch arguments — never typed, so never echoed into the tile.
  const tellsCwd = onWindows && file === shellPath;
  if (tellsCwd) spawnArgs = reportingArgs(shellPath, spawnArgs);

  let p;
  try {
    p = pty.spawn(file, spawnArgs, {
      name: 'xterm-256color', cols: cols || 100, rows: rows || 30,
      cwd: (cwd && fs.existsSync(cwd)) ? cwd : os.homedir(),
      env: initialPromptEnv(sessionEnv(envPath, launch, policy), seedAgent, seed),
    });
  } catch (err) { sendWc(wc, 'term:data', { id, data: '\r\n[could not start: ' + redactChildError(err, { settings: readSettings() }) + ']\r\n' }); return { ok: false }; }

  termSessions.set(id, p);
  sessionOwners.set(id, wc.id);
  if (claudeWatch) watchTitle(id, wc, claudeWatch.transcript, { pid: p.pid, sid: claudeWatch.sid, cwd: claudeWatch.cwd });
  // A resumed run tile (codex, kimi, …) knows its id now; its name comes from
  // the agent's store rather than a transcript file. A fresh one registers
  // the moment discovery finds its id, below.
  if (storeWatch) watchTitle(id, wc, null, { agent: storeWatch.agent, sid: storeWatch.sid, cwd });
  // A fresh agent tile does not know its conversation id — the agent only
  // files the new session in its store once it starts. Poll for it (shared
  // unref'd interval, see agent-resume.js); a hit goes to the renderer, which
  // saves it as the id the next launch resumes. Stopped at teardown below.
  const stopDiscovery = discoverAgent ? startDiscovery({
    id, agent: discoverAgent,
    cwd: (cwd && fs.existsSync(cwd)) ? cwd : os.homedir(), // the pty's own cwd rule
    sinceMs: Date.now(),
    onFound: (found) => { sendWc(wc, 'term:session-id', { id, sid: found }); watchTitle(id, wc, null, { agent: discoverAgent, sid: found, cwd }); },
  }) : null;
  // Claude publishes its name for the LIVE conversation as an OSC 0 title on
  // nearly every frame. Reading it out of the stream costs nothing and, unlike
  // the transcript, it is still right after the user runs /resume inside the
  // tile and lands in a different conversation. feedOscTitle reports only when
  // the name changes, so the spinner glyph never re-renders the rail.
  // Display-only: straight to the renderer, never into the pty. A spawned
  // one-shot echoes nothing, and a tile that opens on silent output does not
  // say what it is doing.
  if (echoLine) sendWc(wc, 'term:data', { id, data: `\x1b[38;2;141;128;101m$ ${echoLine}\x1b[0m\r\n` });

  const osc = { last: null };
  const done = { buf: '' };
  // roots: the shares this pane may honestly report being on (cleanCwd).
  const where = tellsCwd ? { buf: '', roots: [(cwd && fs.existsSync(cwd)) ? cwd : os.homedir(), os.homedir()] } : null;
  let reported = false;
  let seedGate = null;
  p.onData((data) => {
    sendWc(wc, 'term:data', { id, data });
    if (seedGate) seedGate.onData(data);
    // The shell saying which folder it is in now. path:stat asks ptyCwd for it
    // when a relative path printed after a `cd` misses against the tile's own.
    if (where) { const at = feedCwd(where, data); if (at) ptyCwd.tell(p.pid, at); }
    // A one-shot command announcing its own exit code. Same channel as the
    // title below, opposite direction: the shell talking to Nami.
    if (watchDone && !reported) {
      const code = feedRunDone(done, data);
      if (code !== null) {
        reported = true;
        // An installer writes a PATH line into the user's rc file. The memo we
        // hand every session was taken before that, so it is now wrong — drop
        // it and the next tile asks the shell again (user-path.js).
        refreshUserPath();
        sendWc(wc, 'term:command-done', { id, code });
      }
    }
    if (kind !== 'claude') return;
    const t = feedOscTitle(osc, data);
    if (t) sendWc(wc, 'session:title', { id, title: t });
  });
  p.onExit(({ exitCode, signal }) => {
    if (seedGate) { seedGate.stop(); seedGate = null; }
    if (stopDiscovery) stopDiscovery(); // a closed tile stops polling agent stores
    if (where) ptyCwd.forget(p.pid); // Windows hands the pid to the next process
    termSessions.delete(id); sessionOwners.delete(id); titleWatch.delete(id);
    // The note is built here rather than in the renderer because only main knows
    // whether this teardown was Nami's own doing.
    const deliberate = deliberateKills.delete(id);
    sendWc(wc, 'term:exit', { id, code: exitCode, signal, deliberate, note: exitNote({ code: exitCode, signal, deliberate }) });
  });

  // Type a launch command into a plain shell (a keyless run tile / the keyless
  // claude-in-shell fallback). One branch, and it writes what it was given.
  // The seed is a separate thing on its own timer below; conflating the two
  // is what dropped claude's args.
  if (afterStart) setTimeout(() => { try { p.write(afterStart + '\r'); } catch (_) {} }, 200);

  // Native initial-message arguments handle most agents, including startup
  // questions. The remaining interactive CLIs receive one bracketed paste.
  if (seed && !promptArgs.length && ['kimi', 'hermes'].includes(seedAgent)) {
    seedGate = startSeedGate({
      write: (s) => { try { p.write(s); } catch (_) {} }, seed, agentId: seedAgent,
    });
    p.namiSeedGate = seedGate;
  }
  // `seedHeld`: there was a first message and it could not be sent (a shim on
  // Windows, see above). The renderer puts it on the clipboard and says so.
  return held ? { ok: true, seedHeld: true } : { ok: true };
});
// ---- claude's own name for a session ---------------------------------------
// Claude titles its conversations and writes the title into the transcript.
// Watching for it is what keeps the rail label honest: a tile named from your
// first typed line ("go ahead") upgrades itself to what the session is really
// about, and it matches what `claude --resume` will show you tomorrow.
//
// A poll, not fs.watch: transcripts are appended to constantly, so a watcher
// would fire hundreds of times per turn for a string that changes twice a
// session. Only the tail is read — these files reach hundreds of megabytes.
//
const titleWatch = new Map(); // panel id -> { file, wc, mtime, title }
let titleTimer = null;
let titleEvery = 0;
const TITLE_MS = 4000;

function retimeTitles() {
  if (titleTimer && titleEvery === TITLE_MS) return;
  if (titleTimer) clearInterval(titleTimer);
  titleEvery = TITLE_MS;
  titleTimer = setInterval(sweepTitles, TITLE_MS);
  if (titleTimer.unref) titleTimer.unref(); // never hold the app open
}

function sweepTitles() {
  for (const [id, w] of titleWatch) {
    if (w.wc.isDestroyed()) { titleWatch.delete(id); continue; } // window went away
    // Follow the conversation, not the id we guessed. /resume inside a tile
    // moves claude to another conversation and never writes a line to the
    // pinned one, so without this the stat below fails forever, in silence.
    if (w.pid) {
      const live = readLiveSession(w.pid);
      if (live && liveSessionChanged(w.sid, live.sessionId)) {
        w.sid = live.sessionId;
        w.file = path.join(os.homedir(), '.claude', 'projects', projectSlug(w.cwd), w.sid + '.jsonl');
        w.mtime = 0;
        // The renderer persists this, so the next launch resumes the conversation
        // the user is actually in rather than starting a blank one.
        sendWc(w.wc, 'session:sid', { id, sid: w.sid });
      }
    }
    let title = null;
    if (w.file) {
      let stat = null;
      try { stat = fs.statSync(w.file); } catch (_) { continue; } // not written yet
      if (stat.mtimeMs === w.mtime) continue;
      w.mtime = stat.mtimeMs;
      title = readTailTitle(w.file);
    } else if (w.agent && w.sid) {
      // No file to stat: ask the agent's store on the same cadence. Each
      // reader is one small file or one indexed row (agent-resume.js).
      title = readSessionTitle(w.agent, w.cwd, w.sid);
    } else continue;
    if (!title || title === w.title) continue;
    w.title = title;
    sendWc(w.wc, 'session:title', { id, title });
  }
  if (!titleWatch.size) { clearInterval(titleTimer); titleTimer = null; titleEvery = 0; }
}

function watchTitle(id, wc, file, { pid = null, sid = null, cwd = null, agent = null } = {}) {
  titleWatch.set(id, { file, wc, mtime: 0, title: null, pid, sid, cwd, agent });
  retimeTitles();
}

// A chat card learns its session id in the renderer (the ACP handshake), so it
// asks from there. Agent ids are the launcher's; the stores are keyed by bin.
// Closing the card goes through term:kill, which drops the watch.
const STORE_AGENT = { antigravity: 'agy' };
ipcMain.handle('session:watch-title', (e, { id, agent, cwd, sid }) => {
  if (!id || !sid) return { ok: false };
  const key = STORE_AGENT[agent] || agent || 'claude';
  watchTitle(id, e.sender, null, { agent: key, sid, cwd });
  return { ok: true };
});

ipcMain.handle('term:write', (_e, { id, data }) => {
  const p = termSessions.get(id);
  if (!p) return { ok: false };
  if (p.namiSeedGate) p.namiSeedGate.onInput(data);
  try { p.write(data); return { ok: true }; } catch (_) { return { ok: false }; }
});
let ptyResizeN = 0;
ipcMain.handle('term:resize', (_e, { id, cols, rows }) => {
  if (process.env.NAMI_PTY_LOG) {
    ptyResizeN++;
    const line = `${ptyResizeN} ${id} ${cols}x${rows}\n`;
    try { fs.appendFileSync(process.env.NAMI_PTY_LOG, line); } catch (_) {}
    console.log('[term:resize]', line.trim());
  }
  const p = termSessions.get(id); if (p) try { p.resize(cols, rows); } catch (_) {} return { ok: !!p };
});
ipcMain.handle('term:kill', (_e, { id }) => { killSession(id); sessionOwners.delete(id); titleWatch.delete(id); return { ok: true }; });
